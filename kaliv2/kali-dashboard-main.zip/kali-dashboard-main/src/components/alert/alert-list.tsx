import Image from 'next/image'
import { Table } from '../ui/table'
import Pagination from '../ui/pagination'

import { Alert } from '@/types/alerts'
import { MappedPaginatorInfo, SortOrder } from '@/types/index'
import { siteSettings } from '@/settings/site.settings'
import ActionButtons from '../ui/action-buttons'
import { AlignType } from 'rc-table/lib/interface'
import { formatDate } from '@/utils/format-date'
import { Routes } from '@/config/routes'
import TitleWithSort from '../ui/title-with-sort'
import { useState } from 'react'
import { StarIcon } from '../icons/star-icon'
import Button from '../ui/button'
import { useTranslation } from 'react-i18next'
import { useRouter } from 'next/router'

type AlertListProps = {
  alerts: Alert[] | null | undefined
  paginatorInfo?: MappedPaginatorInfo | null
  onPagination?: (page: number) => void
  seletedAlert?: (alert: Alert) => void
}

const AlertList = ({ alerts, paginatorInfo, onPagination }: AlertListProps) => {
  const { t } = useTranslation()
  const router = useRouter()

  const columns: any = [
    {
      title: 'Imágen',
      dataIndex: 'image',
      key: 'image',
      align: 'center' as AlignType,
      width: 60,
      render: (image: string) => (
        <>
          {image ? (
            <div className="flex justify-center">
              <Image src={image} alt="Avatar" width={40} height={40} />
            </div>
          ) : (
            '-'
          )}
        </>
      ),
    },
    {
      title: 'Mensaje',
      dataIndex: 'content',
      key: 'content',
      align: 'center' as AlignType,
      render: (text: string) => (
        // Create a label clean ui component
        <div
          className="text-sm text-gray-600"
          dangerouslySetInnerHTML={{ __html: text }}
        />
      ),
    },
    {
      title: 'Creado',
      dataIndex: 'createdAt',
      key: 'createdAt',
      align: 'center' as AlignType,
      render: (date: string) => (
        <div className="text-sm text-gray-600">{formatDate(date)}</div>
      ),
    },
    {
      title: 'Última actualización',
      dataIndex: 'updatedAt',
      key: 'updatedAt',
      align: 'center' as AlignType,
      render: (date: string) => (
        <div className="text-sm text-gray-600">{formatDate(date)}</div>
      ),
    },
    {
      title: 'Acciones',
      dataIndex: 'id',
      key: 'id',
      align: 'right' as AlignType,
      render: (id: string) => {
        return (
          <ActionButtons
            id={id}
            editModalView={'CHANGE_STATUS_ALERT'}
            deleteModalView={'ALERT_DELETE'}
            detailsUrl={Routes.alerts.details({ id })}
          />
        )
      },
    },
  ]

  function back() {
    router.back()
  }

  return (
    <>
      <div className="mb-6 overflow-hidden rounded shadow">
        <Table
          columns={columns}
          data={alerts ?? []}
          rowKey={'id'}
          scroll={{ x: 800 }}
        />
      </div>
      {!!paginatorInfo && (
        <div>
          <Pagination
            //@ts-ignore
            total={parseInt(paginatorInfo.total)}
            //@ts-ignore
            current={parseInt(paginatorInfo.currentPage)}
            //@ts-ignore
            pageSize={parseInt(paginatorInfo.perPage)}
            onChange={onPagination}
          />
        </div>
      )}

      <div className="flex justify-end">
        <Button onClick={back}>{t('form:form-button-back')}</Button>
      </div>
    </>
  )
}

export default AlertList
