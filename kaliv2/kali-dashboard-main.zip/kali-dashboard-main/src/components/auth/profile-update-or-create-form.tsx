/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState } from 'react'
import { useTranslation } from 'react-i18next'
import Image from 'next/image'
import pick from 'lodash/pick'
import { useForm } from 'react-hook-form'
import { Switch } from '@headlessui/react'
import { nanoid } from 'nanoid'
import { addIcon } from '@/utils/addicon'

import { useCreateUserMutation, useUpdateUserMutation } from '@/data/users'
import { useShiftQuery } from '@/data/shift'

import Card from '@/components/common/card'
import Description from '@/components/ui/description'
import FileInput from '@/components/ui/file-input'
import Input from '@/components/ui/input'
import Button from '@/components/ui/button'
import Label from '@/components/ui/label'
import SelectInput from '@/components/ui/select-input'
import WebcamComponent from '@/components/ui/webcam'
import { CloseIcon } from '@/components/icons/close-icon'

import { JobPosition, UsersResponse } from '@/types/users'
import { Sector, Shift } from '@/types/suggestions'
import { ROLES } from '@/utils/constants'
import { formatDate, jobPosition } from '@/utils/format-date'
import { useUploadMutation } from '@/data/upload'
import {
  useSectorPutdQuery,
  userSectorListQuery,
  userSectorQuery,
} from '@/data/analytics'
import { yupResolver } from '@hookform/resolvers/yup'
import { ProfileSchema } from './profile-schema-validation'
import ValidationError from '../ui/form-validation-error'
import { WarningCompoenent } from '../warning/warning'
import { useRouter } from 'next/router'

type IProps = {
  initialValues?: UsersResponse
}

type FormValue = {
  email: string
  firstName: string
  lastName: string
  birthDate: string
  registrationDate: string
  role: string
  username: string
  environmentId: string
  image: string
  shift?: Shift | null
  jobPosition?: JobPosition | null
  password: string
  middleName: string
  sector?: Sector | null
}

export default function ProfileUpdateOrCreateForm({ initialValues }: IProps) {
  const { t } = useTranslation()
  const { mutate: updateUser, isLoading: loading } = useUpdateUserMutation()

  const router = useRouter()

  const [showCam, setShowCam] = useState(false)
  const [editImage, setEditImage] = useState(
    initialValues?.image ?? initialValues?.image ? false : true
  )
  const { mutate: upload, isLoading: uploadLoading } = useUploadMutation()

  const { sector } = userSectorListQuery({
    limit: 100000,
    page: 1,
  })

  const {
    mutate: create,
    isLoading: createLoading,
    error,
  } = useCreateUserMutation()

  const { shifts, loading: loadingShifts } = useShiftQuery({
    limit: 20,
    page: 1,
  })

  const {
    register,
    control,
    handleSubmit,
    resetField,
    setValue,
    formState: { errors },
  } = useForm<FormValue>({
    resolver: yupResolver(ProfileSchema),

    ...(Boolean(initialValues) && {
      defaultValues: {
        ...initialValues,
        registrationDate: formatDate(initialValues?.registrationDate ?? ''),
        password: '*********',
        role: {
          label: initialValues?.role,
          value: initialValues?.role,
        },
        jobPosition: {
          label: initialValues?.jobPosition,
          value: initialValues?.jobPosition,
        },
      } as any,
    }),
  })

  async function onSubmit(values: any) {
    values.username = values.email
    values.shift = values.shift.id
    values.sector = values.sector.id
    values.shiftId = values.shift.id

    const input: any = {
      id: initialValues?.id,
      input: {
        role: values.role?.value,
        ...pick(values, [
          'email',
          'firstName',
          'lastName',
          'birthDate',
          'registrationDate',
          'username',
          'environmentId',
          'image',
          'shift',
          'password',
          'jobPosition',
          'middleName',
          'sector',
        ]),
      },
    }

    const icon = addIcon(input.input.jobPosition.value)
    input.input.icon = icon

    if (initialValues?.id !== undefined) {
      const updateData = {
        ...input.input,
        id: initialValues?.id,
        shiftId: values?.shift,
        sectorId: values.sector,
        jobPosition: values?.jobPosition.value,
        Sector: values.sector,

        registrationDate: initialValues?.registrationDate ?? new Date(),
      }
      delete updateData.password

      console.log('==== update data ====', JSON.stringify(updateData))

      updateUser({
        ...updateData,
      })
    } else {
      const createData = {
        ...input.input,
        shiftId: values?.shift.id,
        jobPosition: values?.jobPosition.value,
        Sector: values.sector,
      }

      delete values.sector

      console.log(createData)
      create(createData, {
        onError: (error) => {
          resetField('email')
          setValue('sector', null)
          setValue('shift', null)
        },
      })
    }
  }

  function changeStatus(status: boolean) {
    setEditImage(status)
  }

  function changeStatusCam(status: boolean) {
    setShowCam(status)
  }

  // On save Selfie image
  const onSaveSelfie = (image: string) => {
    const id = nanoid(10)

    const formData = new FormData()
    const binaryData = atob(image.split(',')[1])
    const arrayBuffer = new ArrayBuffer(binaryData.length)

    const view = new Uint8Array(arrayBuffer)
    for (let i = 0; i < binaryData.length; i++) {
      view[i] = binaryData.charCodeAt(i)
    }

    const nameImage = 'image' + id + '.jpg'
    const blob = new Blob([arrayBuffer], { type: 'image/jpeg' })
    formData.append('file', blob, nameImage)
    upload(formData, {
      onSuccess(data, _variables, _context) {
        const dataUrl = {
          target: {
            name: 'image',
            value: data,
          },
        }
        register('image').onChange(dataUrl)
      },
    })
  }

  return (
    <>
      <div className="flex flex-wrap pb-8 my-5 border-b border-dashed border-border-base sm:my-8">
        <Description
          title={t('form:input-label-selfie-text') ?? ''}
          details={t('form:selfie-help-text') ?? ''}
          className="w-full px-0 pb-5 sm:w-4/12 sm:py-8 sm:pe-4 md:w-1/3 md:pe-5"
        />

        {initialValues?.image && !editImage ? (
          <Card className="w-full sm:w-8/12 md:w-2/3">
            <div className="relative">
              <div className="flex justify-center">
                <Image
                  src={initialValues?.image}
                  alt="Profile"
                  className="w-60 h-60 rounded-md"
                  width={450}
                  height={450}
                />
              </div>

              <span
                className="absolute cursor-pointer top-0 left-0 transform -translate-x-1/2 -translate-y-1/2 bg-red-500 text-white p-2 rounded-full"
                onClick={() => changeStatus(!editImage)}
              >
                <CloseIcon className="w-4 h-4" />
              </span>
            </div>
          </Card>
        ) : null}

        {editImage ? (
          <Card className="w-full sm:w-8/12 md:w-2/3">
            {showCam ? (
              <WebcamComponent onSave={onSaveSelfie} />
            ) : (
              <FileInput name="image" control={control} multiple={false} />
            )}
            <Switch
              checked={showCam}
              onChange={(value) => changeStatusCam(value)}
              disabled={false}
              className={`${
                showCam ? 'bg-accent' : 'bg-gray-300'
              } relative inline-flex h-6 w-11 items-center rounded-full focus:outline-none mt-5`}
            >
              <span
                className={`${
                  showCam ? 'translate-x-6' : 'translate-x-1'
                } inline-block h-4 w-4 transform rounded-full bg-light`}
              />
            </Switch>

            <p className="mt-2 text-xs text-gray-500">
              {t('form:webcam-text')}
            </p>
          </Card>
        ) : null}
      </div>
      <form onSubmit={handleSubmit(onSubmit)} noValidate>
        <div className="my-5 flex flex-wrap border-b border-dashed border-border-base pb-8 sm:my-8">
          <Description
            title="Nombre"
            details={t('form:form-update-user-description') as string}
            className="w-full px-0 pb-5 sm:w-4/12 sm:py-8 sm:pe-4 md:w-1/3 md:pe-5"
          />
          <Card className="mb-5 w-full sm:w-8/12 md:w-2/3">
            <Input
              label={t('form:form-email') as string}
              {...register('email')}
              variant="outline"
              className="mb-5"
              disabled={initialValues?.id !== undefined}
              error={errors.email?.message ?? ''}
            />

            <Input
              label={t('form:form-password') as string}
              {...register('password')}
              type="password"
              variant="outline"
              className="mb-5"
              disabled={initialValues?.id !== undefined}
              error={errors.password?.message ?? ''}
            />
            {/* Column with Nombre and Apellido Input */}
            <div className="flex flex-wrap">
              <div className="w-full sm:w-1/2">
                <Input
                  label={t('form:form-first-name') as string}
                  {...register('firstName')}
                  variant="outline"
                  className="mb-5 mr-5"
                  error={errors.firstName?.message ?? ''}
                />
              </div>
              <div className="w-full sm:w-1/2">
                <Input
                  label={t('form:form-last-name') as string}
                  {...register('lastName')}
                  variant="outline"
                  className="mb-5 ml-5"
                  error={errors.lastName?.message ?? ''}
                />
              </div>
            </div>
            <Input
              label={t('form:form-middle-name') as string}
              {...register('middleName')}
              variant="outline"
              className="mb-5"
              disabled={initialValues?.id !== undefined}
            />

            {/* <Label className="mb-4">{t('form:form-select-environment')}</Label>
            <Select
              {...register('environmentId')}
              options={enviroments ?? []}
              isLoading={loading}
              getOptionLabel={(option: any) => option?.name ?? ''}
              getOptionValue={(option: any) => option?.id ?? ''}
              placeholder={t('form:form-select-environment') as string}
              onChange={(value: any) => {
                setEnvironment(value.id)
              }}
              isClearable={true}
            /> */}

            <div className="mb-5 mt-5">
              <Label>{`${t('form:form-select-role')}`}</Label>
              <SelectInput
                {...register('role')}
                control={control}
                getOptionLabel={(option: any) => option.label}
                getOptionValue={(option: any) => option.value}
                options={ROLES}
              />
              <ValidationError message={errors.role?.message ?? ''} />
            </div>

            <Label className="mb-4 mt-5">{`${t(
              'form:form-select-shift'
            )}`}</Label>
            <SelectInput
              {...register('shift')}
              control={control}
              getOptionLabel={(option: any) => option.name}
              getOptionValue={(option: any) => option.id}
              options={shifts ?? []}
              isMulti={false}
            />
            <ValidationError message={errors.shift?.message ?? ''} />

            <Label className="mb-4 mt-5">{`${t(
              'form:form-select-sector'
            )}`}</Label>
            <SelectInput
              {...register('sector')}
              control={control}
              getOptionLabel={(option: any) => option.name}
              getOptionValue={(option: any) => option.id}
              options={sector ?? []}
              isMulti={false}
            />
            <ValidationError message={errors.sector?.message ?? ''} />

            <Label className="mb-4 mt-5">
              {t('form:form-select-job-position')}
            </Label>
            <SelectInput
              {...register('jobPosition')}
              control={control}
              getOptionValue={(option: any) => option.value}
              getOptionLabel={(option: any) => option.label}
              options={jobPosition ?? []}
              isMulti={false}
            />
            <ValidationError message={errors.jobPosition?.message ?? ''} />
          </Card>

          <div className="w-full text-end">
            <Button
              type="button"
              onClick={() => router.back()}
              className="bg-zinc-600 mx-3"
            >
              {t('form:form-button-back')}
            </Button>
            <Button
              loading={
                loading || loadingShifts || uploadLoading || createLoading
              }
              disabled={
                loading || loadingShifts || uploadLoading || createLoading
              }
            >
              {initialValues
                ? t('form:form-update-user')
                : t('form:form-create-user')}
            </Button>
          </div>
        </div>
      </form>
    </>
  )
}
