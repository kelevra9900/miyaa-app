// //@ts-nocheck
// import { useEffect, useRef, useState } from 'react'
// import { fabric } from 'fabric'
// import Select from '../select/select' // Asumiendo que este componente renderiza un elemento <select> con opciones
// import { useForm } from 'react-hook-form'

// const Home = () => {
//   const { control } = useForm<any>({})
//   const canvasRef = useRef<HTMLCanvasElement>(null)
//   const fabricCanvasRef = useRef<fabric.Canvas>(null)
//   const backgroundImageRef = useRef<fabric.Image>(null)
//   const [selectedOption, setSelectedOption] = useState<string>('/fp.jpg')

//   let fabricCanvas = fabricCanvasRef.current
//   useEffect(() => {
//     const canvas = canvasRef.current
//     if (!canvas) return

//     if (!fabricCanvas) {
//       // Si no hay una instancia de fabric.Canvas, crear una nueva
//       fabricCanvas = new fabric.Canvas(canvas)
//       fabricCanvasRef.current = fabricCanvas
//     }

//     // Establecer una imagen como fondo
//     const imageUrl = selectedOption // Ruta de la imagen
//     fabric.Image.fromURL(imageUrl, (img) => {
//       if (backgroundImageRef.current) {
//         // Limpiar la imagen de fondo anterior si existe
//         fabricCanvas!.remove(backgroundImageRef.current)
//       }

//       const canvasWidth = canvas.width
//       const canvasHeight = canvas.height

//       // Escalar la imagen para que se ajuste al tamaño del canvas
//       const scale = Math.max(
//         canvasWidth / img.width!,
//         canvasHeight / img.height!
//       )
//       img.scale(scale)

//       fabricCanvas!.setBackgroundImage(
//         img,
//         fabricCanvas!.renderAll.bind(fabricCanvas!)
//       )

//       backgroundImageRef.current = img

//       fabricCanvas!.centerObject(img)
//       fabricCanvas!.renderAll()
//     })

//     fabricCanvas.on('mouse:wheel', function (opt) {
//       var delta = opt.e.deltaY
//       var zoom = fabricCanvas.getZoom()
//       zoom *= 0.999 ** delta
//       if (zoom > 20) zoom = 20
//       if (zoom < 0.01) zoom = 0.01
//       fabricCanvas.zoomToPoint({ x: opt.e.offsetX, y: opt.e.offsetY }, zoom)
//       opt.e.preventDefault()
//       opt.e.stopPropagation()
//     })

//     fabricCanvas.add(circle)

//     // Limpiar
//     return () => {
//       fabricCanvas.remove(circle)
//       // Limpiar recursos si es necesario
//     }
//   }, [selectedOption])

//   const handleSelectChange = (selectedOption: any) => {
//     setSelectedOption(selectedOption.value)
//   }

//   const circle = new fabric.Circle({
//     radius: 5, // Radio del círculo
//     fill: 'red', // Color de relleno del círculo
//     left: 100, // Posición horizontal del círculo
//     top: 100, // Posición vertical del círculo
//   })

//   const imageUrl = '/RV_ Seguimiento MIYAA/Icono Asistente Facilitacion_01.png' // Ruta de la imagen
//   fabric.Image.fromURL(imageUrl, (img) => {
//     // Establecer posición y otras propiedades de la imagen
//     img.set({
//       left: 100, // Posición horizontal de la imagen
//       top: 100, // Posición vertical de la imagen
//       scaleX: 0.1, // Escala horizontal de la imagen (opcional)
//       scaleY: 0.1, // Escala vertical de la imagen (opcional)
//       selectable: true, // Permitir que la imagen sea seleccionable
//       evented: true, // Permitir que la imagen desencadene eventos
//     })

//     // Agregar la imagen al lienzo
//     fabricCanvas?.add(img)
//   })

//   return (
//     <div>
//       <h1>Canvas en Next.js con TypeScript</h1>
//       <Select
//         onChange={handleSelectChange}
//         options={
//           [
//             // {
//             //   label: 'Piso 1',
//             //   value: '/plano.jpeg',
//             // },
//             // {
//             //   label: 'Piso 1',
//             //   value: '/planta-baja.png',
//             // },
//           ]
//         }
//         getOptionLabel={(option: any) => option.label}
//         getOptionValue={(option: any) => option.value}
//         name={'selectOption'}
//       />

//       <div className="border-2 border-black inline-block">
//         <canvas
//           ref={canvasRef}
//           width={800} // Ancho deseado del canvas en píxeles
//           height={600} // Alto deseado del canvas en píxeles
//         />
//       </div>
//     </div>
//   )
// }

// export default Home

//@ts-nocheck

import { useEffect, useRef, useState } from 'react'
import { fabric } from 'fabric'
import Select from '../select/select'
import { useForm } from 'react-hook-form'
import Card from '../common/card'
import PageHeading from '@/components/common/page-heading'

const Home = () => {
  const { control } = useForm<any>({})
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const fabricCanvasRef = useRef<fabric.Canvas>(null)
  const backgroundImageRef = useRef<fabric.Image>(null)
  const [selectedOption, setSelectedOption] =
    useState<string>('/planta-baja.jpeg')

  let fabricCanvas = fabricCanvasRef.current
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    if (!fabricCanvas) {
      // Si no hay una instancia de fabric.Canvas, crear una nueva
      fabricCanvas = new fabric.Canvas(canvas)
      fabricCanvasRef.current = fabricCanvas
    }

    // Establecer una imagen como fondo
    const imageUrl = selectedOption // Ruta de la imagen
    fabric.Image.fromURL(imageUrl, (img) => {
      if (backgroundImageRef.current) {
        // Limpiar la imagen de fondo anterior si existe
        fabricCanvas!.remove(backgroundImageRef.current)
      }

      const canvasWidth = window.innerWidth - 350 // Ancho de la ventana del navegador
      const canvasHeight = window.innerHeight - 200 // Alto de la ventana del navegador

      // Escalar la imagen para que se ajuste al tamaño del canvas
      const scale = Math.max(
        canvasWidth / img.width!,
        canvasHeight / img.height!
      )
      img.scale(scale)

      fabricCanvas!.setBackgroundImage(
        img,
        fabricCanvas!.renderAll.bind(fabricCanvas!)
      )

      backgroundImageRef.current = img

      fabricCanvas!.centerObject(img)
      fabricCanvas!.renderAll()
    })

    fabricCanvas.on('mouse:wheel', function (opt) {
      var delta = opt.e.deltaY
      var zoom = fabricCanvas.getZoom()
      zoom *= 0.999 ** delta
      if (zoom > 20) zoom = 20
      if (zoom < 0.01) zoom = 0.01
      fabricCanvas.zoomToPoint({ x: opt.e.offsetX, y: opt.e.offsetY }, zoom)
      opt.e.preventDefault()
      opt.e.stopPropagation()
    })

    fabricCanvas.add(circle)

    // Manejar eventos del teclado
    window.addEventListener('keydown', handleKeyDown)

    // Limpiar
    return () => {
      fabricCanvas.remove(circle)
      window.removeEventListener('keydown', handleKeyDown)
      // Limpiar recursos si es necesario
    }
  }, [selectedOption])

  const handleSelectChange = (selectedOption: any) => {
    setSelectedOption(selectedOption.value)
  }

  const handleKeyDown = (event: KeyboardEvent) => {
    const stepSize = 10 // Tamaño del paso de movimiento del círculo
    const circleObject = fabricCanvas!.getObjects()[0] as fabric.Circle // Obtener el objeto de círculo

    switch (event.key) {
      case 'ArrowUp':
        circleObject.top -= stepSize
        break
      case 'ArrowDown':
        circleObject.top += stepSize
        break
      case 'ArrowLeft':
        circleObject.left -= stepSize
        break
      case 'ArrowRight':
        circleObject.left += stepSize
        break
      default:
        break
    }

    fabricCanvas!.renderAll()
  }

  useEffect(() => {
    const interval = setInterval(() => {
      const stepSize = 10 // Tamaño del paso de movimiento del círculo
      const circleObject = fabricCanvas!.getObjects()[0] as fabric.Circle // Obtener el objeto de círculo

      circleObject.left += stepSize

      fabricCanvas!.renderAll()
    }, 2000)

    return () => clearInterval(interval)
  }, [])

  const circle = new fabric.Circle({
    radius: 5, // Radio del círculo
    fill: 'red', // Color de relleno del círculo
    left: 100, // Posición horizontal del círculo
    top: 100, // Posición vertical del círculo
  })

  const imageUrl = '/RV_ Seguimiento MIYAA/Icono Asistente Facilitacion_01.png' // Ruta de la imagen
  fabric.Image.fromURL(imageUrl, (img) => {
    // Establecer posición y otras propiedades de la imagen
    img.set({
      left: 100, // Posición horizontal de la imagen
      top: 100, // Posición vertical de la imagen
      scaleX: 0.1, // Escala horizontal de la imagen (opcional)
      scaleY: 0.1, // Escala vertical de la imagen (opcional)
      selectable: true, // Permitir que la imagen sea seleccionable
      evented: true, // Permitir que la imagen desencadene eventos
    })

    // Agregar la imagen al lienzo
    fabricCanvas?.add(img)
  })

  return (
    <div>
      {/* <Select
        onChange={handleSelectChange}
        options={
          [
            // {
            //   label: 'Piso 1',
            //   value: '/plano.jpeg',
            // },
            // {
            //   label: 'Piso 1',
            //   value: '/planta-baja.png',
            // },
          ]
        }
        getOptionLabel={(option: any) => option.label}
        getOptionValue={(option: any) => option.value}
        name={'selectOption'}
      /> */}

      <Card className="flex justify-between">
        <div className="mb-4 md:mb-0 md:w-1/4">
          <PageHeading title="Mapeo" />
        </div>

        <div className="w-1/2">
          <Select
            onChange={handleSelectChange}
            options={[
              {
                label: 'Plano 1',
                value: '/planta-baja.jpeg',
              },
              {
                label: 'Plano 2',
                value: '/plano-2.jpeg',
              },

              {
                label: 'Plano 3',
                value: '/plano-3.jpg',
              },

              {
                label: 'Plano 4',
                value: '/plano-4.jpg',
              },
            ]}
            getOptionLabel={(option: any) => option.label}
            getOptionValue={(option: any) => option.value}
            name={'selectOption'}
          />
        </div>
      </Card>
      <div className=" inline-block rounded-md mt-5">
        <canvas
          ref={canvasRef}
          width={window.innerWidth - 350} // Ancho de la ventana del navegador
          height={window.innerHeight - 200} // Alto de la ventana del navegador
        />
      </div>
    </div>
  )
}

export default Home
