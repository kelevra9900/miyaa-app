//@ts-nocheck
import React, { useRef, useEffect } from 'react'

const CanvasMap = ({ coordinates }) => {
  const canvasRef = useRef(null)

  useEffect(() => {
    const canvas = canvasRef.current
    const ctx = canvas.getContext('2d')

    // Dimensiones del plano arquitectónico en el canvas
    const canvasWidth = canvas.width - 200
    const canvasHeight = canvas.height - 120

    const minLongitude = -109.71728
    const maxLongitude = -109.71773
    const minLatitude = 23.16166
    const maxLatitude = 23.164

    const minCanvasX = 350
    const maxCanvasX = canvasWidth - 380
    const minCanvasY = 0
    const maxCanvasY = canvasHeight + 100

    // Convertir coordenadas geográficas a coordenadas del canvas
    function geoToCanvas(longitude, latitude) {
      const x =
        ((longitude - minLongitude) / (maxLongitude - minLongitude)) *
          (maxCanvasX - minCanvasX) +
        minCanvasX
      const y =
        (1 - (latitude - minLatitude) / (maxLatitude - minLatitude)) *
          (maxCanvasY - minCanvasY) +
        minCanvasY

      console.log('x', x, 'y', y)
      return { x, y }
    }

    // Limpiar el canvas
    ctx.clearRect(0, 0, canvasWidth, canvasHeight)

    // Dibujar puntos en el canvas
    function drawPoints() {
      coordinates.forEach(({ latitude, longitude }) => {
        const { x, y } = geoToCanvas(longitude, latitude)
        ctx.beginPath()
        ctx.arc(x, y, 5, 0, 2 * Math.PI)
        ctx.fillStyle = 'red'
        ctx.fill()
        ctx.stroke()
      })
    }

    drawPoints()
  }, [coordinates])

  return (
    <canvas
      ref={canvasRef}
      width={1200}
      height={750}
      style={{ border: '1px solid #000' }}
    />
  )
}

export default CanvasMap

// //@ts-nocheck
// import React, { useRef, useState, useEffect } from 'react'

// const CanvasMap = ({ coordinates, imageUrl }) => {
//   const canvasRef = useRef(null)
//   const [zoom, setZoom] = useState(1) // Estado para el zoom

//   useEffect(() => {
//     const canvas = canvasRef.current
//     const ctx = canvas.getContext('2d')

//     // Dimensiones del canvas
//     const canvasWidth = canvas.width
//     const canvasHeight = canvas.height

//     // Cargar la imagen
//     const image = new Image()
//     image.src = imageUrl

//     // Definir el rango de coordenadas geográficas
//     const minLongitude = -109.8 // Ajusta según tu plano
//     const maxLongitude = -109.5
//     const minLatitude = 22.9 // Ajusta según tu plano
//     const maxLatitude = 23.3

//     // Dimensiones de la imagen
//     const imageWidth = 1000 // Cambia según las dimensiones reales de tu imagen
//     const imageHeight = 800 // Cambia según las dimensiones reales de tu imagen

//     // Definir el rango de coordenadas del plano en el canvas
//     const minCanvasX = 0 // Coordenada X mínima del plano en el canvas
//     const maxCanvasX = canvasWidth // Coordenada X máxima del plano en el canvas
//     const minCanvasY = 0 // Coordenada Y mínima del plano en el canvas
//     const maxCanvasY = canvasHeight // Coordenada Y máxima del plano en el canvas

//     // Convertir coordenadas geográficas a coordenadas del canvas
//     function geoToCanvas(longitude, latitude) {
//       // Ajuste aquí para mover los puntos hacia la derecha
//       const x =
//         ((longitude - minLongitude) / (maxLongitude - minLongitude)) *
//           (maxCanvasX - minCanvasX) +
//         minCanvasX +
//         200 // Ajuste de 50 píxeles a la derecha (puedes cambiar este valor según sea necesario)

//       const y =
//         (1 - (latitude - minLatitude) / (maxLatitude - minLatitude)) *
//           (maxCanvasY - minCanvasY) +
//         minCanvasY

//       return { x, y }
//     }

//     image.onload = () => {
//       // Limpiar el canvas
//       ctx.clearRect(0, 0, canvasWidth, canvasHeight)

//       // Ajustar y dibujar la imagen en el canvas con zoom
//       ctx.drawImage(image, 0, 0, imageWidth * zoom, imageHeight * zoom)

//       // Dibujar puntos sobre la imagen con el zoom aplicado
//       function drawPoints() {
//         coordinates.forEach(({ latitude, longitude }) => {
//           const { x, y } = geoToCanvas(longitude, latitude)
//           // Aplicar zoom a las coordenadas de los puntos
//           const zoomedX = x * zoom
//           const zoomedY = y * zoom
//           ctx.beginPath()
//           ctx.arc(zoomedX, zoomedY, 5 / zoom, 0, 2 * Math.PI) // Ajustar tamaño del punto en base al zoom
//           ctx.fillStyle = 'red'
//           ctx.fill()
//           ctx.stroke()
//         })
//       }

//       drawPoints()
//     }
//   }, [coordinates, imageUrl, zoom])

//   // Manejar el zoom
//   const handleZoomIn = () => setZoom((prevZoom) => Math.min(prevZoom * 1.2, 5)) // Incrementar zoom
//   const handleZoomOut = () =>
//     setZoom((prevZoom) => Math.max(prevZoom / 1.2, 0.2)) // Disminuir zoom

//   return (
//     <div>
//       <canvas
//         ref={canvasRef}
//         width={800} // Ajusta según el tamaño del canvas
//         height={600} // Ajusta según el tamaño del canvas
//         style={{ border: '1px solid #000' }}
//       />
//       <div>
//         <button onClick={handleZoomIn}>Zoom In</button>
//         <button onClick={handleZoomOut}>Zoom Out</button>
//       </div>
//     </div>
//   )
// }

// export default CanvasMap
