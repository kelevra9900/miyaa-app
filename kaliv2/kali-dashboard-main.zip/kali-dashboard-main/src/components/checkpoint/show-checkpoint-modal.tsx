import { useRouter } from 'next/router'
import React, { useEffect, useState } from 'react'
import { Modal } from 'rizzui'
import { useModalState } from '../ui/modal/modal.context'
import { useUserQuery } from '@/data/user'
import Select from '@/components/ui/select/select'
import { format, parseISO } from 'date-fns'
import { es } from 'date-fns/locale'
import { TrackingRoundIcon } from '../icons/tracking-round'

type Props = {}

function ShowCheckpointModal({}: Props) {
  const [show, setShow] = useState(false)
  const router = useRouter()
  const { id } = router.query // Obtiene el `id` de la URL
  const { data: modalData } = useModalState()

  const { user, loading, error } = useUserQuery({
    id: Number(modalData),
  })
  const [date, setDate] = useState('')
  const [uniqueDates, setUniqueDates] = useState([])

  function restarHoras(horaOriginal: any, horasARestar: any) {
    const [horas, minutos, segundos] = horaOriginal.split(':').map(Number)

    const fecha = new Date()
    fecha.setHours(horas, minutos, segundos, 0)

    fecha.setHours(fecha.getHours() - horasARestar)

    const nuevaHora = [
      String(fecha.getHours()).padStart(2, '0'),
      String(fecha.getMinutes()).padStart(2, '0'),
      String(fecha.getSeconds()).padStart(2, '0'),
    ].join(':')

    return nuevaHora
  }

  function formatDateToSpanish(dateString: string): string {
    const date = parseISO(dateString)
    return format(date, "eeee d 'de' MMMM yyyy", { locale: es })
  }

  function prueba(roundId: number) {
    let uniqueDates = new Set()

    user?.checkpointLog?.forEach((element) => {
      if (element.roundId === roundId) {
        //@ts-ignore
        const date = element.timestamp.split('T')[0]
        uniqueDates.add(date)
      }
    })

    const uniqueDatesArray = Array.from(uniqueDates).map((date: any) => ({
      value: date,
      label: formatDateToSpanish(date),
    }))

    return uniqueDatesArray
  }

  useEffect(() => {
    const dates = prueba(Number(id))
    //@ts-ignore
    setUniqueDates(dates)
  }, [id])

  // return (
  //   <>
  //     {/* <Modal
  //       isOpen={show}
  //       onClose={() => {
  //         setShow(!show)
  //       }}
  //       containerClassName="!max-w-3xl !shadow-2xl"
  //     > */}
  //     <div className="bg-white p-8 rounded shadow-lg">
  //       <h2 className="font-semibold mb-2 text-center text-2xl text-gray-700">
  //         Checkpoint logs
  //       </h2>
  //       <div className="border-b-4 mb-3 "></div>

  //       <div className="justify-center grid grid-cols-4">
  //         {//@ts-ignore
  //         user?.checkpointLog.map((checkpoint, index) => (
  //           <>
  //             {Number(id) === checkpoint.roundId ? (
  //               <div className="flex items-center ml-8 mb-2">
  //                 <div className="relative">
  //                   <div className="ml-4 text-gray-500">
  //                     Checkpoint {checkpoint.id}
  //                   </div>
  //                   <div className="flex justify-center">
  //                     <div className="relative z-10 flex items-center justify-center h-12 w-12 rounded-full bg-blue-400 text-white">
  //                       {checkpoint.id}
  //                     </div>
  //                   </div>

  //                   <span className="flex justify-center text-gray-700 bg-green-300 py-1 mt-2 rounded-md">
  //                     {
  //                       //@ts-ignore

  //                       restarHoras(
  //                         //@ts-ignore
  //                         checkpoint?.timestamp.split('T')[1].split('.')[0],
  //                         7
  //                       )
  //                     }
  //                   </span>

  //                   {/* Línea horizontal */}
  //                   {/* {index !== 4 &&
  //                       index !== */}
  //                   {/* //@ts-ignore user.checkpointLog.length - 1 && ( */}
  //                   {/* <div className="absolute top-[50px] left-[123px] transform -translate-x-1/2 -translate-y-1/2 w-44 h-1 bg-green-500/30"></div> */}
  //                   {/*   )} */}
  //                 </div>
  //               </div>
  //             ) : null}
  //           </>
  //         ))}
  //       </div>

  //       <div className="border-b-2 border-dashed mb-3 my-3"></div>

  //       {/* <div className="flex justify-center mt-2">
  //           <div className="border-1 border w-1/2 h-full rounded-md shadow-xl">
  //             <div className="mx-2 text-center py-2 text-gray-700">
  //               Checkpoints: <span>{user?.checkpointLog.length}</span>
  //             </div>
  //             <div className="border-b-2 border-dashed mb-3 mx-2"></div>

  //             <div className="grid grid-cols-2 py-3">
  //               <div className="mx-2  text-gray-700">
  //                 Tiempo Usuario: <span>{user?.checkpointLog.length}</span>
  //               </div>
  //               <div className="mx-2  text-gray-700">
  //                 Tiempo estimado: <span>{user?.checkpointLog.length}</span>
  //               </div>
  //             </div>
  //           </div>
  //         </div> */}
  //     </div>
  //     {/* </Modal> */}
  //   </>
  // )

  return (
    <div className="bg-white p-8 rounded shadow-lg h-full">
      <div className="flex justify-between items-center mb-5">
        <h2 className="font-semibold mb-2 text-center text-2xl text-gray-700">
          Checkpoint logs
        </h2>

        <Select
          className="w-1/2 "
          options={uniqueDates}
          onChange={(e: any) => setDate(e.value)}
        />
      </div>

      <div className="border-b-4 mb-3 "></div>
      <div
        className={`justify-center grid  ${
          date !== '' ? 'grid-cols-4 ' : 'grid-cols-1'
        }   `}
      >
        {//@ts-ignore
        user?.checkpointLog.map((checkpoint, index) => (
          <>
            {Number(id) === checkpoint.roundId ? (
              <div className="flex items-center ml-8 ">
                {/* {uniqueDates.map((elemen) => ( */}
                <>
                  {
                    //@ts-ignore
                    date === checkpoint.timestamp.split('T')[0] ? (
                      <div className="relative -z-0">
                        <div className="ml-4 text-gray-500">
                          Checkpoint {checkpoint.id}
                        </div>
                        <div className="flex justify-center">
                          <div className="relative z-10 flex items-center justify-center h-12 w-12 rounded-full bg-blue-400 text-white">
                            {checkpoint.id}
                          </div>
                        </div>

                        <span className="flex justify-center text-gray-700 bg-green-300 py-1 mt-2 rounded-md">
                          {
                            //@ts-ignore

                            restarHoras(
                              //@ts-ignore
                              checkpoint?.timestamp.split('T')[1].split('.')[0],
                              8
                            )
                          }
                        </span>

                        {/* {index !== 4 &&
                  index !== */}
                        {/* //@ts-ignore user.checkpointLog.length - 1 && ( */}
                        {/* <div className="absolute top-[50px] left-[123px] transform -translate-x-1/2 -translate-y-1/2 w-44 h-1 bg-green-500/30"></div> */}
                        {/*   )} */}
                      </div>
                    ) : null
                  }
                </>
                {/* ))} */}
              </div>
            ) : null}
          </>
        ))}

        {date === '' ? (
          <div className=" py-3">
            <div className="flex justify-center items-center w-full  text-gray-500">
              <TrackingRoundIcon />
            </div>
            <p className="text-3xl text-center text-gray-500">
              No se ha seleccionado una fecha
            </p>
          </div>
        ) : null}
      </div>
      <div className="border-b-2 border-dashed mb-3 my-3"></div>
    </div>
  )
}

export default ShowCheckpointModal
