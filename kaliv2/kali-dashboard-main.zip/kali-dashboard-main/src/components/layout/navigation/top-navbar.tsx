import { SearchIcon } from '@/components/icons/search-icon'
import Alert from '@/components/ui/alert'
import LinkButton from '@/components/ui/link-button'
import Loader from '@/components/ui/loader/loader'
import Logo from '@/components/ui/logo'
import { useModalAction } from '@/components/ui/modal/modal.context'
import { Config } from '@/config'
import { useUI } from '@/contexts/ui.context'
import { useSettingsQuery } from '@/data/settings'
import {
  adminAndOwnerOnly,
  adminOnly,
  getAuthCredentials,
  hasAccess,
} from '@/utils/auth-utils'
import {
  RESPONSIVE_WIDTH,
  checkIsMaintenanceModeComing,
  checkIsMaintenanceModeStart,
  miniSidebarInitialValue,
  searchModalInitialValues,
} from '@/utils/constants'
import cn from 'classnames'
import { eachDayOfInterval, isTomorrow } from 'date-fns'
import { motion } from 'framer-motion'
import { useAtom } from 'jotai'
import { useTranslation } from 'next-i18next'
import { useRouter } from 'next/router'
import { useEffect } from 'react'
import { useWindowSize } from 'react-use'
import AuthorizedMenu from './authorized-menu'
import SearchBar from '../topbar/search-bar'
import VisitStore from '../topbar/visit-store'
import RecentOrderBar from '../topbar/recent-order-bar'
import MessageBar from '../topbar/message-bar'
import StoreNoticeBar from '../topbar/store-notice-bar'
import LanguageSwitcher from './language-switcher'

export const isInArray = (array: Date[], value: Date) => {
  return !!array?.find((item) => {
    return item?.getDate() == value?.getDate()
  })
}

const Navbar = () => {
  const { t } = useTranslation()
  const { toggleSidebar } = useUI()
  const { permissions } = getAuthCredentials()
  const { enableMultiLang } = Config
  const { locale } = useRouter()
  const { openModal } = useModalAction()
  const [searchModal, setSearchModal] = useAtom(searchModalInitialValues)
  const [miniSidebar, setMiniSidebar] = useAtom(miniSidebarInitialValue)
  const [isMaintenanceMode, setUnderMaintenance] = useAtom(
    checkIsMaintenanceModeComing
  )
  const [isMaintenanceModeStart, setUnderMaintenanceStart] = useAtom(
    checkIsMaintenanceModeStart
  )
  const { width } = useWindowSize()
  const { settings, loading } = useSettingsQuery()

  useEffect(() => {
    if (
      settings?.options?.maintenance?.start &&
      settings?.options?.maintenance?.until
    ) {
      const dateInterVal = eachDayOfInterval({
        start: new Date(settings?.options?.maintenance?.start as string),
        end: new Date(settings?.options?.maintenance?.until as string),
      })
      const beforeDay = isTomorrow(
        new Date(settings?.options?.maintenance?.start as string)
      )
      const checkIsMaintenance =
        beforeDay && settings?.options?.isUnderMaintenance
      const checkIsMaintenanceStart =
        isInArray(dateInterVal, new Date()) &&
        settings?.options?.isUnderMaintenance
      setUnderMaintenance(checkIsMaintenance as boolean)
      setUnderMaintenanceStart(checkIsMaintenanceStart as boolean)
    }
  }, [
    settings?.options?.maintenance?.start,
    settings?.options?.maintenance?.until,
    settings?.options?.isUnderMaintenance,
  ])

  if (loading) {
    return <Loader showText={false} />
  }

  const { options } = settings!

  function handleClick() {
    // openModal('SEARCH_VIEW');
    setSearchModal(true)
  }

  return (
    <header className="fixed top-0 z-40 w-full bg-white shadow">
      {/* {width >= RESPONSIVE_WIDTH && isMaintenanceMode ? (
        <Alert
          message={t('text-maintenance-mode-title')}
          variant="info"
          className="sticky top-0 left-0 z-50"
          childClassName="flex justify-center items-center w-full gap-4 font-bold"
        >
          <CountdownTimer
            date={new Date(options?.maintenance?.start)}
            className="text-blue-600 [&>p]:bg-blue-200 [&>p]:p-2 [&>p]:text-xs [&>p]:text-blue-600"
          />
        </Alert>
      ) : (
        ''
      )} */}
      {width >= RESPONSIVE_WIDTH && isMaintenanceModeStart ? (
        <Alert
          message={t('text-maintenance-mode-start-title')}
          className="py-[1.375rem]"
          childClassName="text-center w-full font-bold"
        />
      ) : (
        ''
      )}
      <nav className="flex items-center px-5 md:px-8">
        <div className="relative flex w-full flex-1 items-center">
          <div className="flex items-center">
            <motion.button
              whileTap={{ scale: 0.88 }}
              onClick={toggleSidebar}
              className="group flex h-5 w-5 shrink-0 cursor-pointer flex-col justify-center space-y-1 me-4 focus:text-accent focus:outline-none lg:hidden"
            >
              <span
                className={cn(
                  'h-0.5 rounded-full bg-gray-600 transition-[width] group-hover:bg-accent',
                  miniSidebar ? 'w-full' : 'w-2/4'
                )}
              />
              <span className="h-0.5 w-full rounded-full bg-gray-600 group-hover:bg-accent" />
              <span className="h-0.5 w-3/4 rounded-full bg-gray-600 transition-[width] group-hover:bg-accent" />
            </motion.button>
            <div
              className={cn(
                'flex h-16 shrink-0 transition-[width] duration-300 me-4 lg:h-[76px] lg:border-solid lg:border-gray-200/80 lg:me-8 lg:border-e',
                miniSidebar ? 'lg:w-[65px]' : 'lg:w-[257px]'
              )}
            >
              <Logo />
            </div>
            <button
              className="group hidden h-5 w-5 shrink-0 cursor-pointer flex-col justify-center space-y-1 me-6 lg:flex"
              onClick={() => setMiniSidebar(!miniSidebar)}
            >
              <span
                className={cn(
                  'h-0.5 rounded-full bg-gray-600 transition-[width] group-hover:bg-accent',
                  miniSidebar ? 'w-full' : 'w-2/4'
                )}
              />
              <span className="h-0.5 w-full rounded-full bg-gray-600 group-hover:bg-accent" />
              <span
                className={cn(
                  'h-0.5 rounded-full bg-gray-600 transition-[width] group-hover:bg-accent',
                  miniSidebar ? 'w-full' : 'w-3/4'
                )}
              />
            </button>
          </div>
          <div
            className="relative ml-auto mr-1.5 flex h-9 w-9 shrink-0 cursor-pointer items-center justify-center rounded-full border border-gray-200 bg-gray-50 py-4 text-gray-600 hover:border-transparent hover:border-gray-200 hover:bg-white hover:text-accent sm:mr-6 lg:hidden xl:hidden"
            onClick={handleClick}
          >
            <SearchIcon className="h-4 w-4" />
          </div>
          <div className="relative hidden w-full max-w-[710px] py-4 me-6 lg:block 2xl:me-auto">
            <SearchBar />
          </div>

          {enableMultiLang ? <LanguageSwitcher /> : null}

          <AuthorizedMenu />
        </div>
      </nav>
    </header>
  )
}

export default Navbar
