//@ts-nocheck
import cn from 'classnames'
import MapTrackComponent from './map-user-id'
import MapArray from './map-user-id'

export type IProps = {
  className?: string
  title: string
  latitude?: number
  longitude?: number
  // plano: string
  // userOnline: any
  // coordenadas?: any
}
const MapTrackUserId = ({
  className,
  latitude,
  longitude,
  userOnline,
  coordenadas,
}: IProps) => {
  return (
    <>
      <div
        className={cn(
          'overflow-hidden rounded-lg bg-white p-6 md:p-7',
          className
        )}
      >
        <MapTrackComponent latitud={latitude} longitud={longitude} />
      </div>
    </>
  )
}

export default MapTrackUserId
