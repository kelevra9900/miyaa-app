//@ts-nocheck
import React, { useEffect, useMemo, useState } from 'react'
import {
  GoogleMap,
  useLoadScript,
  MarkerF,
  CircleF,
  InfoWindowF,
} from '@react-google-maps/api'
import Loader from '@/components/ui/loader/loader'
import Router from 'next/router'
import { Modal } from 'rizzui'
import { User } from '@/types/suggestions'
import Avatar from '../common/avatar'
import Select from '../select/select'
import Image from 'next/image'
import { addMonths, endOfDay, isBefore, parseISO, startOfDay } from 'date-fns'

const containerStyle = {
  width: '500px',
  height: '600px',
  borderRadius: '10px',
}

type IProps = {
  latitud: number
  longitud: number
  userOnline: any
  coordernadas?: any
}

function MapTrackComponent({
  latitud,
  longitud,
  userOnline,
  coordernadas,
}: IProps) {
  const [mapCenter, setMapCenter] = useState<{ lat: number; lng: number }>({
    lat: latitud,
    lng: longitud,
  })
  // const mapCenter = useMemo(
  //   () => ({ lat: latitud, lng: longitud }),
  //   [latitud, longitud]
  // )

  const { isLoaded } = useLoadScript({
    id: 'google-map-script',
    googleMapsApiKey: process.env.NEXT_PUBLIC_GOOGLE_MAP_API_KEY || '',
  })

  const [show, setShow] = useState(false)
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [lati, setLati] = useState(latitud)
  const [longi, setLongi] = useState(longitud)
  const [map, setMap] = useState<any>(null)

  useEffect(() => {
    if (userOnline && userOnline.length > 0) {
      setLati(userOnline[0].map((e: any) => e.longitude)[0])
      setLongi(userOnline[0].map((e: any) => e.latitude)[0])
    }
  }, [userOnline])

  const onLoad = React.useCallback((map: any) => {
    let bounds
    if (userOnline) {
      bounds = new window.google.maps.LatLngBounds({
        lat: userOnline[0].map((e: any) => e.longitude)[0],
        lng: userOnline[0].map((e: any) => e.latitude)[0],
      })
    } else {
      bounds = new window.google.maps.LatLngBounds({
        lat: latitud,
        lng: longitud,
      })
    }

    map.fitBounds(bounds)
    setMap(map)
  }, [])

  const onUnmount = React.useCallback(() => {
    setMap(null)
  }, [])

  const userDetails = (id: any) => {
    Router.push('/users/' + id)
  }
  const [showInfoWindow, setShowInfoWindow] = useState(false)

  const [selectedOption, setSelectedOption] = useState<string>('')
  const [historicalOverlay, setHistoricalOverlay] =
    useState<google.maps.GroundOverlay | null>(null)
  const imageSize = 0.001

  let imageBounds = {
    north: 0,
    south: 0,
    east: 0,
    west: 0,
  }

  const calculateBounds = (
    lat: number,
    lng: number,
    size: number,
    padding: number
  ) => ({
    north: lat + size / 2 + padding,
    south: lat - size / 2 - padding,
    east: lng + size / 2 + padding,
    west: lng - size / 2 - padding,
  })

  const handleSelectChange = (selectedOption: any) => {
    if (selectedOption) {
      setSelectedOption(selectedOption.value)

      // Eliminar el overlay previo si existe
      if (historicalOverlay) {
        historicalOverlay.setMap(null)
      }

      if (selectedOption.id === 1) {
        const padding = 0.0005
        imageBounds = calculateBounds(23.1626, -109.7176, imageSize, padding) //terminal 1
        setMapCenter({ lat: 23.1626, lng: -109.7176 })
      } else if (selectedOption.id === 2) {
        const padding = 0.0009
        imageBounds = calculateBounds(23.1574, -109.71685, imageSize, padding) //terminal 2
        setMapCenter({ lat: 23.1574, lng: -109.71685 })
      } else if (selectedOption.id === 3) {
        // const padding = 0.0006

        // imageBounds = calculateBounds(23.1577, -109.71678, imageSize, padding) //terminal 3
        const padding = 0.0007
        imageBounds = calculateBounds(23.1568, -109.7169, imageSize, padding) //terminal 2
        setMapCenter({ lat: 23.1568, lng: -109.7169 })
      }
      // Crear un nuevo GroundOverlay
      const newHistoricalOverlay = new google.maps.GroundOverlay(
        selectedOption.value, // Asegúrate de usar `selectedOption.value` aquí
        imageBounds
      )
      newHistoricalOverlay.setMap(map)
      setHistoricalOverlay(newHistoricalOverlay)
    } else {
      removeOverlay()
    }
  }

  const removeOverlay = () => {
    if (historicalOverlay) {
      historicalOverlay.setMap(null)
    }
    setSelectedOption('')
  }
  const [expiredDocuments, setExpiredDocuments] = useState([])
  const [soonToExpireDocuments, setSoonToExpireDocuments] = useState([])

  const categorizeDocuments = (documents) => {
    const now = new Date() // Fecha actual
    const oneMonthFromNow = addMonths(startOfDay(now), 1)
    const expiredDocuments = []
    const soonToExpireDocuments = []

    documents?.forEach((document) => {
      const validUntilDate = startOfDay(new Date(document.validUntil))

      if (isBefore(validUntilDate, now)) {
        expiredDocuments.push(document)
      } else if (isBefore(validUntilDate, oneMonthFromNow)) {
        soonToExpireDocuments.push(document)
      }
    })

    return { expiredDocuments, soonToExpireDocuments }
  }

  const handleMarkerClick = (user) => {
    setSelectedUser(user)

    const { expiredDocuments, soonToExpireDocuments } = categorizeDocuments(
      user.user.documents
    )
    setExpiredDocuments(expiredDocuments)
    setSoonToExpireDocuments(soonToExpireDocuments)
  }

  return isLoaded ? (
    <>
      <div className="border-2"></div>

      <Select
        className="w-full my-7"
        onChange={handleSelectChange}
        isClearable
        options={[
          {
            id: 1,
            label: 'Terminal 1',
            value: '/terminal_1.jpeg',
          },
          {
            id: 2,
            label: 'Terminal 2 piso 1',
            value: '/terminal_2_1.jpeg',
          },
          {
            id: 3,
            label: 'Terminal 2 piso 2',
            value: '/terminal_2.jpeg',
          },
        ]}
        getOptionLabel={(option: any) => option.label}
        getOptionValue={(option: any) => option.value}
        name={'selectOption'}
      />
      {userOnline ? (
        <>
          <GoogleMap
            mapContainerStyle={containerStyle}
            mapTypeId={google.maps.MapTypeId.ROADMAP}
            center={mapCenter}
            // center={{
            //   lat: lati,
            //   lng: longi,
            // }}
            zoom={7}
            onLoad={onLoad}
            onUnmount={onUnmount}
          >
            <>
              {userOnline.map((subArray: any, index: number) => (
                <div key={index}>
                  {subArray.map((user: any) => (
                    <>
                      <MarkerF
                        icon={user.user.icon}
                        // onClick={() => {
                        //   userDetails(user.userId)
                        // }}
                        onClick={() => handleMarkerClick(user)}
                        position={{ lat: user.longitude, lng: user.latitude }}
                        onLoad={() =>
                          console.log(`Marker for point ${user.id} Loaded`)
                        }
                        // onMouseOver={() => setShowInfoWindow(true)}
                        // onMouseOut={() => setShowInfoWindow(false)}
                      />

                      {selectedUser && (
                        <InfoWindowF
                          position={{
                            lat: selectedUser.longitude,
                            lng: selectedUser.latitude,
                          }}
                          onCloseClick={() => setSelectedUser(null)} // Cierra el InfoWindow cuando se cierra
                        >
                          <div className="w-[20em] ">
                            <div
                              className={`flex p-3 rounded-md ${
                                selectedUser.user.documents.length === 36 &&
                                expiredDocuments.length === 0
                                  ? 'bg-green-100'
                                  : 'bg-yellow-100'
                              }`}
                            >
                              <Image
                                className="rounded-full"
                                src={selectedUser.user.image}
                                alt={'Imagen'}
                                width={40}
                                height={10}
                              />
                              <div className="block ml-3">
                                <p className="font-bold">
                                  {selectedUser.user.firstName +
                                    ' ' +
                                    selectedUser.user.lastName}
                                </p>
                                <div>
                                  <p>
                                    Documentos:{' '}
                                    {selectedUser.user.documents.length}
                                  </p>
                                </div>

                                <span
                                  onClick={() => {
                                    userDetails(selectedUser.userId)
                                  }}
                                  className="text-blue-500 underline hover:text-blue-700 hover:cursor-pointer"
                                >
                                  Ir a perfil
                                </span>
                              </div>
                            </div>

                            <div className=" p-3 rounded-md mt-3 bg-blue-100 text-gray-800">
                              <span className="font-bold text-sm">
                                {soonToExpireDocuments.length > 0
                                  ? 'Documentos por vencer:'
                                  : 'Sin Documentos por vencer'}
                              </span>
                              {soonToExpireDocuments.map((document) => (
                                <div className="block text-center">
                                  <span>{document.documentType}</span>
                                </div>
                              ))}
                            </div>

                            <div className=" p-3 rounded-md mt-3 bg-red-100 text-gray-800">
                              <span className="font-bold text-sm">
                                {expiredDocuments.length > 0
                                  ? 'Documentos vencidos:'
                                  : 'Sin Documentos vencidos'}
                              </span>
                              {expiredDocuments.map((document) => (
                                <div className="block text-center">
                                  <span>{document.documentType}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </InfoWindowF>
                      )}
                      {/* {userOnline &&
                        userOnline.map((subArray: any, index: number) => (
                          <div key={index}>
                            {subArray.map((user: any) =>
                              [0.7, 0.01].map((radius, idx) => (
                                <CircleF
                                  key={idx}
                                  center={{
                                    lat: user.latitude,
                                    lng: user.longitude,
                                  }}
                                  radius={radius}
                                  options={{
                                    fillColor:
                                      user.user.documents.length === 36
                                        ? 'green'
                                        : 'yellow',
                                    strokeOpacity: 0.2,
                                  }}
                                />
                              ))
                            )}
                          </div>
                        ))} */}

                      {[0.7, 0.01].map((radius, idx) => (
                        <CircleF
                          key={idx}
                          center={{ lat: user.longitude, lng: user.latitude }}
                          radius={radius}
                          options={{
                            fillColor:
                              user?.user?.documents.length === 36
                                ? 'green'
                                : 'yellow',
                            strokeOpacity: 0.2,
                          }}
                        />
                      ))}
                    </>
                  ))}
                </div>
              ))}
            </>
          </GoogleMap>
        </>
      ) : (
        <GoogleMap
          mapContainerStyle={containerStyle}
          mapTypeId={google.maps.MapTypeId.ROADMAP}
          center={mapCenter}
          zoom={7}
          onLoad={onLoad}
          onUnmount={onUnmount}
        >
          {/* <MarkerF
            position={mapCenter}
            onClick={() => setShowInfoWindow(!showInfoWindow)}
          />
          {showInfoWindow && (
            <InfoWindowF
              position={mapCenter}
              onCloseClick={() => setShowInfoWindow(false)}
            >
              <div>
                <p></p>
              </div>
            </InfoWindowF>
          )} */}
          {/* {[0.3, 0.01].map((radius, idx) => (
            // <CircleF
            //   key={idx}
            //   center={mapCenter}
            //   radius={radius}
            //   options={{
            //     fillColor: as = 10=== 36 ? 'green' : 'yellow',
            //     strokeOpacity: 0.2,
            //   }}
            // />
          ))} */}
        </GoogleMap>
      )}
    </>
  ) : (
    <Loader />
  )
}

export default React.memo(MapTrackComponent)
