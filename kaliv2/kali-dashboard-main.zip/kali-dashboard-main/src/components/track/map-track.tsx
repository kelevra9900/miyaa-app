//@ts-nocheck
import cn from 'classnames'
import MapTrackComponent from './map'

export type IProps = {
  className?: string
  title: string
  latitude: number
  longitude: number
  userOnline: any
}
const MapTrack = ({ className, latitude, longitude, userOnline }: IProps) => {
  return (
    <>
      <div
        className={cn(
          'overflow-hidden rounded-lg bg-white p-6 md:p-7',
          className
        )}
      >
        <MapTrackComponent
          latitud={latitude}
          longitud={longitude}
          userOnline={userOnline}
        />
      </div>
    </>
  )
}

export default MapTrack
