//@ts-nocheck
import React, { useEffect, useMemo, useState } from 'react'
import {
  GoogleMap,
  useLoadScript,
  MarkerF,
  CircleF,
  Polyline,
  GroundOverlay,
  InfoWindowF,
} from '@react-google-maps/api'
import Loader from '@/components/ui/loader/loader'
import Router from 'next/router'
import { useUserQuery } from '@/data/user'
import Select from '../select/select'
import { DatePicker } from '../ui/date-picker'
import { Controller } from 'react-hook-form'
import { LATITUDE, LONGITUDE } from '@/utils/constants'
import Image from 'next/image'
import { User } from '@/types/suggestions'
import { addMonths, isBefore, startOfDay } from 'date-fns'

const containerStyle = {
  width: '1000px',
  height: '600px',
  borderRadius: '10px',
}

type IProps = {
  latitud: number
  longitud: number
  plano: string
}
function MapTrackComponentUserId({ latitud, longitud }: IProps) {
  // const mapCenter = useMemo(
  //   () => ({
  //     lat: latitud !== 0 ? latitud : LATITUDE,
  //     lng: longitud !== 0 ? longitud : LONGITUDE,
  //   }),
  //   [latitud, longitud]
  // )

  const [mapCenter, setMapCenter] = useState<{ lat: number; lng: number }>({
    lat: latitud === 0 ? LATITUDE : latitud,
    lng: longitud === 0 ? LONGITUDE : longitud,
  })
  const { id } = Router.query

  const { user } = useUserQuery({
    id: Number(id),
  })

  const { isLoaded } = useLoadScript({
    id: 'google-map-script',
    googleMapsApiKey: process.env.NEXT_PUBLIC_GOOGLE_MAP_API_KEY || '',
  })

  const [map, setMap] = React.useState<any>(null)
  const [selectedOption, setSelectedOption] = useState<string>('')
  const [isCheckedUser, setIsCheckedUser] = useState(false)
  const [historicalOverlay, setHistoricalOverlay] =
    useState<google.maps.GroundOverlay | null>(null)
  const [flightPath, setFlightPath] = useState<google.maps.Polyline | null>(
    null
  )

  const [expiredDocuments, setExpiredDocuments] = useState([])
  const [soonToExpireDocuments, setSoonToExpireDocuments] = useState([])

  const [selectedUser, setSelectedUser] = useState<User | null>(null)

  const [disabled, setDisabaled] = useState(true)
  const [disabledDate, setDisabaledDate] = useState(false)
  const imageSize = 0.001

  let imageBounds = {
    north: 0,
    south: 0,
    east: 0,
    west: 0,
  }

  const calculateBounds = (
    lat: number,
    lng: number,
    size: number,
    padding: number
  ) => ({
    north: lat + size / 2 + padding,
    south: lat - size / 2 - padding,
    east: lng + size / 2 + padding,
    west: lng - size / 2 - padding,
  })

  const onLoad = React.useCallback(
    function callback(map: any) {
      const bounds = new window.google.maps.LatLngBounds(mapCenter)
      map.fitBounds(bounds)
      setMap(map)
    },
    [mapCenter]
  )
  const [selectedDate, setSelectedDate] = useState(null)
  const [selectedDateFilter, setSelectedDateFilter] = useState(null)

  const handleSelectChange = (selectedOption: any) => {
    if (selectedOption) {
      setSelectedOption(selectedOption.value)

      // Eliminar el overlay previo si existe
      if (historicalOverlay) {
        historicalOverlay.setMap(null)
      }

      if (selectedOption.id === 1) {
        const padding = 0.0005
        imageBounds = calculateBounds(23.1626, -109.7176, imageSize, padding) //terminal 1
        setMapCenter({ lat: 23.1626, lng: -109.7176 })
      } else if (selectedOption.id === 2) {
        const padding = 0.0009
        imageBounds = calculateBounds(23.1574, -109.71685, imageSize, padding) //terminal 2
        setMapCenter({ lat: 23.1574, lng: -109.71685 })
      } else if (selectedOption.id === 3) {
        // const padding = 0.0006
        // imageBounds = calculateBounds(23.1577, -109.71678, imageSize, padding) //terminal 3
        const padding = 0.0007
        imageBounds = calculateBounds(23.1568, -109.7169, imageSize, padding) //terminal 2
        setMapCenter({ lat: 23.1568, lng: -109.7169 })
      }

      // Crear un nuevo GroundOverlay
      const newHistoricalOverlay = new google.maps.GroundOverlay(
        selectedOption.value, // Asegúrate de usar `selectedOption.value` aquí
        imageBounds
      )
      newHistoricalOverlay.setMap(map)
      setHistoricalOverlay(newHistoricalOverlay)
    } else {
      removeOverlay()
    }
  }

  const removeOverlay = () => {
    if (historicalOverlay) {
      historicalOverlay.setMap(null)
    }
    setSelectedOption('')
  }

  const removePolyline = () => {
    if (flightPath) {
      flightPath.setMap(null)
    }
    setFlightPath(null)
  }

  const handleToggleUser = () => {
    setIsCheckedUser(!isCheckedUser)

    if (!isCheckedUser) {
      setDisabaledDate(true)
      const flightPath = new google.maps.Polyline({
        path: selectedDateFilter,
        strokeColor: '#2480c5',
        strokeOpacity: 1.0,
        strokeWeight: 2,
      })

      flightPath.setMap(map)
      setFlightPath(flightPath)
    } else {
      removePolyline()
      setDisabaledDate(false)
    }
  }

  const onUnmount = React.useCallback(
    function callback(map: any) {
      setMap(null)
      if (flightPath) {
        flightPath.setMap(null)
      }
    },
    [flightPath]
  )

  const handleDateChange = (date: any) => {
    if (date) {
      setSelectedDate(date)
      setDisabaled(false)

      const isoString = date.toISOString().split('T')[0]

      const filteredItems = filterByDate(user?.tracking, isoString)

      setSelectedDateFilter(filteredItems)
    } else {
      setSelectedDate(null)
      setDisabaled(true)
    }
  }

  function filterByDate(trackingItems: any, targetDate: string) {
    return trackingItems
      ?.filter((item: any) => {
        const itemDate = item.createdAt?.split('T')[0]
        return itemDate === targetDate
      })
      .map((item: any) => ({
        lat: item.longitude,
        lng: item.latitude,
      }))
  }
  const [showInfoWindow, setShowInfoWindow] = useState(false)

  const userDetails = (id: any) => {
    Router.push('/users/' + id)
  }

  const categorizeDocuments = (documents: any) => {
    const now = new Date() // Fecha actual
    const oneMonthFromNow = addMonths(startOfDay(now), 1)
    const expiredDocuments: any[] = []
    const soonToExpireDocuments: any[] = []

    documents?.forEach((document: any) => {
      const validUntilDate = startOfDay(new Date(document.validUntil))

      if (isBefore(validUntilDate, now)) {
        expiredDocuments.push(document)
      } else if (isBefore(validUntilDate, oneMonthFromNow)) {
        soonToExpireDocuments.push(document)
      }
    })

    return { expiredDocuments, soonToExpireDocuments }
  }

  const handleMarkerClick = (user: any) => {
    setSelectedUser(user)

    const { expiredDocuments, soonToExpireDocuments } = categorizeDocuments(
      user.documents
    )
    setExpiredDocuments(expiredDocuments)
    setSoonToExpireDocuments(soonToExpireDocuments)
  }

  return isLoaded ? (
    <>
      <div className="border-2"></div>
      <div className="flex items-center">
        <Select
          className="w-1/2 my-7"
          onChange={handleSelectChange}
          isClearable
          options={[
            {
              id: 1,
              label: 'Terminal 1',
              value: '/terminal_1.jpeg',
            },
            {
              id: 2,
              label: 'Terminal 2 piso 1',
              value: '/terminal_2_1.jpeg',
            },
            {
              id: 3,
              label: 'Terminal 2 piso 2',
              value: '/terminal_2.jpeg',
            },
          ]}
          getOptionLabel={(option: any) => option.label}
          getOptionValue={(option: any) => option.value}
          name={'selectOption'}
        />

        <div className="w-1/2 ml-5">
          <DatePicker
            disabled={disabledDate}
            placeholderText="Selecciona una fecha"
            isClearable={!disabledDate}
            selected={selectedDate}
            dateFormat="dd/MM/yyyy"
            onChange={(date) => handleDateChange(date)}
          />
        </div>

        <div className="mx-5">
          <label className="inline-flex items-center cursor-pointer">
            <input
              disabled={disabled}
              type="checkbox"
              value=""
              className="sr-only peer"
              onChange={handleToggleUser}
            />
            <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
            <span className="ms-3 text-sm font-medium text-gray-900  ">
              <p className="text-black"></p>
            </span>
          </label>
        </div>
      </div>

      <GoogleMap
        mapContainerStyle={containerStyle}
        mapTypeId={google.maps.MapTypeId.ROADMAP}
        zoom={7}
        onLoad={onLoad}
        onUnmount={onUnmount}
        center={mapCenter}
      >
        <MarkerF
          icon={{
            //@ts-ignore
            url: '/' + user?.icon,
            scaledSize: new window.google.maps.Size(48, 48),
          }}
          // onClick={() => Router.push('/users/' + id)}
          //@ts-ignore
          onClick={() => handleMarkerClick(user)}
          position={{ lat: latitud, lng: longitud }}
          onLoad={() => console.log('Marker Loaded')}
        />
        {latitud !== 0 && longitud !== 0 ? (
          <>
            {selectedUser && (
              <InfoWindowF
                position={{
                  lat: latitud,
                  lng: longitud,
                }}
                onCloseClick={() => setSelectedUser(null)} // Cierra el InfoWindow cuando se cierra
              >
                <div className="w-[20em] ">
                  <div
                    className={`flex p-3 rounded-md ${
                      selectedUser.documents.length === 36 &&
                      expiredDocuments.length === 0
                        ? 'bg-green-100'
                        : 'bg-yellow-100'
                    }`}
                  >
                    <Image
                      className="rounded-full"
                      src={selectedUser.image}
                      alt={'Imagen'}
                      width={40}
                      height={10}
                    />
                    <div className="block ml-3">
                      <p className="font-bold">
                        {selectedUser.firstName + ' ' + selectedUser.lastName}
                      </p>
                      <div>
                        <p>Documentos: {selectedUser.documents.length}</p>
                      </div>

                      <span
                        onClick={() => {
                          userDetails(selectedUser.id)
                        }}
                        className="text-blue-500 underline hover:text-blue-700 hover:cursor-pointer"
                      >
                        Ir a perfil
                      </span>
                    </div>
                  </div>

                  <div className=" p-3 rounded-md mt-3 bg-blue-100 text-gray-800">
                    <span className="font-bold text-sm">
                      {soonToExpireDocuments.length > 0
                        ? 'Documentos por vencer:'
                        : 'Sin Documentos por vencer'}
                    </span>
                    {soonToExpireDocuments.map((document) => (
                      <div className="block text-center">
                        <span>{document.documentType}</span>
                      </div>
                    ))}
                  </div>

                  <div className=" p-3 rounded-md mt-3 bg-red-100 text-gray-800">
                    <span className="font-bold text-sm">
                      {expiredDocuments.length > 0
                        ? 'Documentos vencidos:'
                        : 'Sin Documentos vencidos'}
                    </span>
                    {expiredDocuments.map((document) => (
                      <div className="block text-center">
                        <span>{document.documentType}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </InfoWindowF>
            )}

            {[0.3, 0.01].map((radius, idx) => (
              <CircleF
                key={idx}
                center={{ lat: latitud, lng: longitud }}
                radius={radius}
                options={{
                  fillColor: user?.documents.length === 36 ? 'green' : 'yellow',
                  strokeOpacity: 0.2,
                }}
              />
            ))}
          </>
        ) : null}

        <GroundOverlay bounds={imageBounds} url={selectedOption} />
      </GoogleMap>
    </>
  ) : (
    <Loader />
  )
}

export default React.memo(MapTrackComponentUserId)
