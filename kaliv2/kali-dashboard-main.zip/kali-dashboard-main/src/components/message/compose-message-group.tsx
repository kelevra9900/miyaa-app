import { useState } from 'react'
import { useForm } from 'react-hook-form'
import Image from 'next/image'
import isEmpty from 'lodash/isEmpty'

import { MessageAvatarPlaceholderIcon } from '@/components/icons/message-avatar-placeholder-icon'
import Button from '@/components/ui/button'
import Select from '../select/select'
import { useUsersQuery } from '@/data/users'
import { useCreateConversations } from '@/data/conversations'
import ErrorMessage from '../ui/error-message'
import { jobPosition } from '@/utils/format-date'
import TextArea from '../ui/text-area'
import Label from '../ui/label'
import { useSocketContext } from '@/contexts/socket.context'
import { useModalAction } from '../ui/modal/modal.context'
import { useMeQuery } from '@/data/user'

type FormatOptionLabelProps = {
  firstName: string
  lastName: string
  image: string
}

const formatOptionLabel = ({
  image,
  firstName,
  lastName,
}: FormatOptionLabelProps) => (
  <div className="flex items-center">
    <div className="relative mr-3 h-6 w-6 shrink-0 overflow-hidden rounded-full">
      {!isEmpty(image) ? (
        <Image
          src={image}
          alt={firstName}
          className="product-image object-contain"
          fill
          sizes="(max-width: 768px) 100vw"
        />
      ) : (
        <MessageAvatarPlaceholderIcon
          className="text-[1.5rem]"
          color="#DDDDDD"
        />
      )}
    </div>
    <div className="truncate">
      {firstName} {lastName}
    </div>
  </div>
)

const ComposeMessageGroupModal = () => {
  const { handleSubmit } = useForm()
  const [user, setUser] = useState<any>(null)
  const [jobposition, setJobposition] = useState<any>(null)
  const [content, setcontent] = useState<any>(null)
  const [active, setIsActive] = useState<boolean>(Boolean(0))
  const [page, setPage] = useState(1)

  const { data } = useMeQuery()

  const { createChatGroup } = useSocketContext()
  const { closeModal } = useModalAction()

  const { users, loading, error } = useUsersQuery({
    limit: 100,
    page,
  })

  // if (errorSending) return <ErrorMessage message={error?.message} />

  const onTypeFilter = (user: any | undefined) => {
    setUser(user)
    setIsActive(user?.banned)
  }

  const onTypeFilterJob = (jobPosition: any | undefined) => {
    if (jobPosition) {
      setJobposition(jobPosition.value)
    } else {
      setJobposition(null)
    }
  }

  async function onSubmit() {
    console.log(users)

    if (jobposition) {
      // Filtrar usuarios por puesto de trabajo y mapear a un array de participant
      const userIds = users
        .filter((user) => user.jobPosition === jobposition)
        .map((user) => user.id)

      userIds.push(data.id)

      // Crear objeto con la estructura participant: [{1, 2, 3}]
      const participants = { participants: userIds }

      createChatGroup(participants)
      closeModal()
      window.location.reload()
    }
  }
  return (
    <div className="m-auto block max-w-lg rounded bg-light p-6 md:w-[32.5rem]">
      <h2 className="mb-6 text-base font-medium">Iniciar conversación</h2>
      <form onSubmit={handleSubmit(onSubmit)}>
        <Select
          className="my-3"
          options={jobPosition ?? []}
          isLoading={loading}
          placeholder="Selecciona perfil de usuario"
          onChange={onTypeFilterJob as any}
          isClearable={true}
          // @ts-ignore
        />

        {/* {jobposition !== null ? (
          <>
            <Label>Contenido del mensaje</Label>
            <TextArea
              name={''}
              onChange={(e) => {
                setcontent(e.target.value)
              }}
            ></TextArea>
          </>
        ) : null} */}

        <div className="mt-6 text-right">
          <Button
            className="px-4 text-base "
            // loading={creating}
            // disabled={!user || Boolean(active)}
          >
            Enviar
          </Button>
        </div>
      </form>
    </div>
  )
}

export default ComposeMessageGroupModal
