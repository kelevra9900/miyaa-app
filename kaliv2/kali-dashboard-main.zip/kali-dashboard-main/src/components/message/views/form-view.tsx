import { useEffect, useRef, useState } from 'react'
import { useRouter } from 'next/router'
import { useForm } from 'react-hook-form'
import { toast } from 'react-toastify'
import { isEmpty } from 'lodash'

import Button from '@/components/ui/button'
import { SendMessageIcon } from '@/components/icons/send-message'
import { useSendMessage } from '@/data/conversations'
import * as yup from 'yup'
import TextArea from '@/components/ui/text-area'
import { yupResolver } from '@hookform/resolvers/yup'
import { UploadIcon } from '@/components/icons/upload-icon copy'
import { UploadMessage } from '@/components/icons/upload-file-message'
import Image from 'next/image'
import { PlusIcon } from '@/components/icons/plus-icon'
import PDFIcon from '@/components/icons/pdf-solid'
import ImageIcon from '@/components/icons/image-solid'
import { VideoIcon } from '@/components/icons/video-icon'
import { useUploadMutation } from '@/data/upload'
import { nanoid } from 'nanoid'
import { useMeQuery } from '@/data/user'
import { useSocketContext } from '@/contexts/socket.context'

type FormValues = {
  content: string
  prueba: string
}

// const messageSchema = yup.object().shape({
//   content: yup.string().required('error-body-required'),
// })

interface Props {
  className?: string
  user?: any
}

const CreateMessageForm = ({ className, user, ...rest }: Props) => {
  const { register, handleSubmit, getValues, setFocus, reset } =
    useForm<FormValues>({
      // resolver: yupResolver(messageSchema),
    })

  const fileInputRef = useRef<HTMLInputElement>(null)
  const [base64, setBase64] = useState('')
  const [urlImage, setImageUrl] = useState('')
  const [show, setShow] = useState(false)
  const [pdf, setPdf] = useState(false)
  const { mutate: upload, isLoading: uploadLoading } = useUploadMutation()
  const { sendMessage } = useSocketContext()

  const { data } = useMeQuery()

  const router = useRouter()
  const { query } = router
  // const { mutate: createMessage, isLoading: creating } = useSendMessage()
  useEffect(() => {
    const listener = (event: any) => {
      if (event.key === 'Enter' && event.shiftKey) {
        return false
      }
      if (event.code === 'Enter' || event.code === 'NumpadEnter') {
        event.preventDefault()
        const values = getValues()

        if (values.content.length > 0) {
          onSubmit(values)
        }
      }
    }
    document.addEventListener('keydown', listener)
    return () => {
      document.removeEventListener('keydown', listener)
    }
  }, [query?.id])

  const onSubmit = async (values: FormValues) => {
    const message = {
      conversationId: query.id,
      userId: data.id,
      message: base64 ? base64 : urlImage ? urlImage : values.content,
      type: 'TEXT',
      seen: true,
    }
    sendMessage(message)
    reset()
    setBase64('')
    setImageUrl('')

    const chatBody = document.getElementById('chatBody')
    chatBody?.scrollTo({
      top: chatBody?.scrollHeight,
      behavior: 'smooth',
    })

    // if (isEmpty(values.message)) {
    //   toast?.error('Message is required')
    //   return
    // }
    // createMessage(
    //   {
    //     media: urlImage,
    //     content: values?.message,
    //     conversationId: Number(query?.id),
    //     recipientId: Number(user.userId),
    //   },
    //   {
    //     onError: (error: any) => {
    //       toast?.error(error?.message)
    //     },
    //     onSuccess: () => {
    //       setBase64('')
    //       setPdf(false)
    //       const chatBody = document.getElementById('chatBody')
    //       chatBody?.scrollTo({
    //         top: chatBody?.scrollHeight,
    //         behavior: 'smooth',
    //       })
    //       reset()
    //     },
    //   }
    // )
  }
  useEffect(() => {
    setFocus('content')
  }, [setFocus])

  const [selectedFile, setSelectedFile] = useState(null)

  const handleFileChange = (e: any) => {
    const formData = new FormData()
    const file = e.target.files[0]
    if (file) {
      formData.append('file', file, nanoid(10) + '.' + file.name.split('.')[1])
      upload(formData, {
        onSuccess(data, _variables, _context) {
          const dataUrl = {
            target: {
              name: 'image',
              value: data,
            },
          }
          //@ts-ignore
          setImageUrl(dataUrl.target.value)
        },
      })
      setSelectedFile(file)
      convertFileToBase64(file)
    }
  }

  const handleFileChangeDocument = (e: any) => {
    console.log('entre')

    const file = e.target.files[0]
    setSelectedFile(file)
    // convertFileToBase64(file)

    console.log('Archivo seleccionado:', file)
  }

  const convertFileToBase64 = (file: any) => {
    if (file.type.split('/')[1] !== 'pdf') {
      setPdf(false)
      const reader = new FileReader()
      reader.readAsDataURL(file)
      reader.onloadend = () => {
        //@ts-ignore
        setBase64(reader.result)
        console.log('Archivo en base64:', reader.result)
      }
      reader.onerror = (error) => {
        console.error('Error al convertir archivo a base64:', error)
      }
    } else {
      setPdf(true)
      setBase64('')
    }
  }

  const handleClick = () => {
    if (fileInputRef.current) {
      setShow(false)
      fileInputRef.current.click()
    }
  }

  function deleteFile() {
    setBase64('')
    setImageUrl('')
  }

  return (
    <div className="mt-10">
      <form noValidate onSubmit={handleSubmit(onSubmit)}>
        {base64 ? (
          <div className="flex justify-center border-2 py-2 rounded-md">
            <div className="absolute left-4 ">
              <div
                onClick={deleteFile}
                className="bg-red-600 px-2 py-1.3 font-extralight text-white rounded-full hover:bg-red-700 hover:cursor-pointer"
              >
                x
              </div>
            </div>
            <Image src={base64} alt={'Prueba'} width={100} height={100}></Image>
          </div>
        ) : urlImage ? (
          <div className="flex justify-center border-2 py-2 rounded-md">
            <div className="absolute left-4 ">
              <div
                onClick={deleteFile}
                className="bg-red-600 px-2 py-1.3 font-extralight text-white rounded-full hover:bg-red-700 hover:cursor-pointer"
              >
                x
              </div>
            </div>
            <PDFIcon width={100} />
          </div>
        ) : null}

        <div className="flex justify-around items-center">
          {/* {!!creating ? (
            <div className="absolute left-0 top-0 z-50 flex h-full w-full cursor-not-allowed bg-[#EEF1F4]/50">
              <div className="m-auto h-5 w-4 animate-spin rounded-full border-2 border-t-2 border-transparent border-t-accent"></div>
            </div>
          ) : (
            ''
          )} */}

          {show === true ? (
            <div className="bg-slate-900/80 absolute bottom-12 rounded-md px-3 py-2 left-2">
              {/* <div className="hover:bg-slate-500/50 rounded-md hover:cursor-pointer  py-2 px-3">
                <div className="flex text-white" onClick={handleClick}>
                  <PDFIcon width={20} className="mr-2" /> Documento
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  style={{ display: 'none' }}
                  onChange={handleFileChangeDocument}
                />
              </div> */}
              <div className="hover:bg-slate-500/50 rounded-md hover:cursor-pointer  py-2 px-3">
                <div className="flex text-white" onClick={handleClick}>
                  <ImageIcon width={20} className="mr-2" /> Archivo
                </div>
              </div>
              {/* <div className="hover:bg-slate-500/50 rounded-md hover:cursor-pointer  py-2 px-3">
                <div className="flex text-white" onClick={handleClick}>
                  <VideoIcon width={20} className="mr-2" /> Video
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  style={{ display: 'none' }}
                  onChange={handleFileChange}
                />
              </div> */}
            </div>
          ) : null}

          <input
            ref={fileInputRef}
            type="file"
            style={{ display: 'none' }}
            onChange={handleFileChange}
          />

          {/* <div className="absolute left-0 top-3 h-full"> */}
          <UploadMessage
            className="hover:cursor-pointer "
            onClick={() => {
              setShow(!show)
              // reset()
            }}
            width={30}
          />
          {/* </div> */}

          <TextArea
            className="overflow-y-auto overflow-x-hidden ml-11 mr-11 shadow-chatBox w-full"
            placeholder="Type your message here.."
            {...register('content')}
            variant="solid"
            inputClassName="!border-0 bg-white pr-12 block !h-full"
            rows={1}
            required
          />

          <Button
            className="!h-full px-4 text-lg focus:!shadow-none focus:!ring-0"
            variant="custom"
            // disabled={!!creating}
          >
            <SendMessageIcon />
          </Button>
        </div>

        {/* <div className="absolute right-0 top-3 h-full"> */}

        {/* </div> */}
      </form>
    </div>
  )
}

export default CreateMessageForm
