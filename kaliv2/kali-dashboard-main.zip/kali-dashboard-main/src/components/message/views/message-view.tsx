import cn from 'classnames'
import { useRouter } from 'next/router'
import isEmpty from 'lodash/isEmpty'
import dayjs from 'dayjs'
import relativeTime from 'dayjs/plugin/relativeTime'
import utc from 'dayjs/plugin/utc'
import timezone from 'dayjs/plugin/timezone'
import ErrorMessage from '@/components/ui/error-message'
import Loader from '@/components/ui/loader/loader'
import { useTranslation } from 'next-i18next'
import Avatar from '@/components/common/avatar'
import { siteSettings } from '@/settings/site.settings'
import { DataChat, Message } from '@/types'
import MessageNotFound from '@/components/message/views/no-message-found'
import React, { useEffect, useState, useRef } from 'react'
import { useWindowSize } from '@/utils/use-window-size'
import { RESPONSIVE_WIDTH } from '@/utils/constants'
import {
  offset,
  flip,
  autoUpdate,
  useFloating,
  shift,
} from '@floating-ui/react-dom-interactions'
import { ArrowDown } from '@/components/icons/arrow-down'
import { useMeQuery } from '@/data/user'
import { adminOnly, getAuthCredentials, hasAccess } from '@/utils/auth-utils'
import Image from 'next/image'
import PDFIcon from '@/components/icons/pdf-solid'

dayjs.extend(relativeTime)
dayjs.extend(utc)
dayjs.extend(timezone)

interface Props {
  // conversation?: DataChat
  className?: string
  id?: string
  // listen?: boolean
  // loading?: boolean
  messages: any[]
  // error: any
  classes: any
  user: any
  // isSuccess: boolean
  // children: React.ReactNode
  // isLoadingMore: boolean
  // isFetching: boolean
}

const UserMessageView = ({
  className,
  id,
  // listen,
  messages = [],
  // error,
  // loading,
  classes,
  user = {},
  // isSuccess,
  // children,
  // isLoadingMore,
  // isFetching,
  ...rest
}: Props) => {
  const { query } = useRouter()
  const { t } = useTranslation()
  const { width } = useWindowSize()
  const [visible, setVisible] = useState(false)
  const { data, loading: meLoading, error: meError } = useMeQuery()
  const messagesEndRef = useRef(null)
  const { x, y, reference, floating, strategy, update, refs } = useFloating({
    strategy: 'fixed',
    placement: 'bottom',
    middleware: [offset(-80), flip(), shift()],
  })

  //default scroll to bottom
  const defaultScrollToBottom = () => {
    //@ts-ignore
    messagesEndRef?.current?.scrollIntoView({ behavior: 'smooth' })
  }
  useEffect(defaultScrollToBottom, [messages ? messages[0]?.messages : null])

  // scroll to bottom
  useEffect(() => {
    const chatBody = document.getElementById('chatBody')
    // @ts-ignore
    chatBody?.scrollTo({
      top: chatBody?.scrollHeight,
    })
    if (!refs.reference.current || !refs.floating.current) {
      return
    }
    return autoUpdate(refs.reference.current, refs.floating.current, update)
  }, [query?.id, refs.reference, refs.floating, update])
  const chatBody = document.getElementById('chatBody')
  const scrollToBottom = () => {
    chatBody?.scrollTo({
      top: chatBody?.scrollHeight,
      behavior: 'smooth',
    })
  }
  useEffect(() => {
    const chatBody = document.getElementById('chatBody')
    const toggleVisible = () => {
      if (
        Number(
          Number(chatBody?.scrollHeight) - Number(chatBody?.clientHeight)
        ) !== Number(chatBody?.scrollTop) &&
        Number(chatBody?.clientHeight) <= Number(chatBody?.scrollHeight)
      ) {
        setVisible(true)
      } else {
        setVisible(false)
      }
    }
    chatBody?.addEventListener('scroll', toggleVisible)
    return () => {
      chatBody?.removeEventListener('scroll', toggleVisible)
    }
  }, [])

  // if (loading || meLoading)
  //   return (
  //     <Loader
  //       className="!h-full flex-1"
  //       text={t('common:text-loading') ?? ''}
  //     />
  //   )
  if (meError)
    return (
      <div className="!h-full flex-1">
        <ErrorMessage message={meError?.message} />
      </div>
    )

  function openPdfInNewTab(url: string) {
    window.open(url, '_blank')
  }
  function validateImageFormart(arg0: string): React.ReactNode {
    let bool
    switch (arg0) {
      case 'jpg':
        bool = true
        break
      case 'webp':
        bool = true
        break
      case 'png':
        bool = true
        break
      case 'jpge':
        bool = true
        break
      default:
        bool = false
        break
    }
    return bool
  }

  return (
    <>
      <div
        id={id}
        className="relative flex-auto flex-grow h-full py-16 overflow-x-hidden overflow-y-auto"
        ref={reference}
        style={{
          maxHeight:
            width >= RESPONSIVE_WIDTH
              ? 'calc(100vh - 336px)'
              : 'calc(100vh - 300px)',
        }}
        {...rest}
      >
        {/* <div
          onClick={scrollToBottom}
          className={`flex h-10 w-10 transform cursor-pointer rounded-full border border-solid border-[#F3F4F6] bg-[#F3F4F6] text-black shadow-lg transition-all duration-300 hover:border-accent-hover hover:bg-accent-hover hover:text-white ${
            visible
              ? 'visible translate-y-0 opacity-100'
              : 'invisible translate-y-1 opacity-0'
          }`}
          ref={floating}
          style={{
            position: strategy,
            top: y ?? '',
            left: x ?? '',
            zIndex: 50,
          }}
        >
          <ArrowDown height="14" width="14" className="m-auto" />
        </div> */}

        {/* render loader */}
        {/* {children} */}
        {/* render content */}
        {/* {isSuccess ? ( */}
        {/* <>
          {!isEmpty(messages) ? (
            <div className="space-y-6">
              {messages.map((item: any, key: number) => {
                console.log(item.messages)
                // const checkUser = Number(data?.id) === Number(item?.sender.id)
                const checkUser = item.users.find(
                  //@ts-ignore
                  (user) => user.user.id !== Number(data?.id)
                )
                // let avatarUrl = item?.sender?.image
                let avatarUrl = checkUser.user.image

                return (
                  <div
                    className={`flex w-full gap-x-3 ${
                      checkUser ? 'flex-row-reverse' : ''
                    }`}
                    key={key}
                  >
                    {checkUser ? null : (
                      <div className="w-10">
                        <Avatar
                          src={avatarUrl ?? siteSettings?.avatar?.placeholder}
                          {...rest}
                          name="avatar"
                          className={cn(
                            'relative h-full w-full border-0',
                            avatarUrl
                              ? ''
                              : 'bg-muted-black text-base font-medium text-white'
                          )}
                        />
                      </div>
                    )}
                    <div
                      className={`w-full sm:w-3/4 ${
                        checkUser ? 'text-right' : 'text-left'
                      }`}
                    >
                      <div className="space-y-1">
                        <h2
                          className={`${cn(
                            classes?.common,
                            checkUser ? classes?.default : classes?.reverse
                          )}`}
                        >
                          {item?.media ? (
                            <div className="flex justify-center">
                              {validateImageFormart(
                                item?.media.split('.')[5]
                              ) ? (
                                <Image
                                  src={item?.media}
                                  alt={'imagen'}
                                  width={150}
                                  height={150}
                                />
                              ) : item?.media.split('.')[5] === 'pdf' ? (
                                <div
                                  className="bg-red-900/20 h-15 w-[200px] px-2 flex py-4 rounded-md items-center cursor-pointer"
                                  onClick={() => {
                                    openPdfInNewTab(item.media)
                                  }}
                                >
                                  <PDFIcon width={50} />

                                  <span className="text-xl text-white">
                                    Archivo pdf
                                  </span>
                                </div>
                              ) : null}
                            </div>
                          ) : null}

                          {item.content.replace(/['"]+/g, '')}
                        </h2>
                      </div>

                      <div className="mt-2 text-xs text-[#686D73]">
                        {dayjs().to(dayjs.utc(item?.createdAt))}
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          ) : (
            <>
              <MessageNotFound />
            </>
          )}
        </> */}

        <>
          {!isEmpty(messages) ? (
            <div className="space-y-6">
              {messages.map((item: any, key: number) => {
                const checkUser = Number(data?.id) === item.userId

                // const user = messages[0].participants[0].user

                // let avatarUrl = user?.image

                return (
                  <div
                    className={`flex w-full gap-x-3 ${
                      checkUser ? 'flex-row-reverse' : ''
                    }`}
                    key={key}
                  >
                    {checkUser ? null : (
                      <div className="w-10">
                        <Avatar
                          //@ts-ignore
                          src={user.image ?? siteSettings?.avatar?.placeholder}
                          {...rest}
                          name="avatar"
                          className={cn(
                            'relative h-full w-full border-0',
                            //@ts-ignore
                            user.image
                              ? ''
                              : 'bg-muted-black text-base font-medium text-white'
                          )}
                        />
                      </div>
                    )}
                    <div
                      className={`w-full sm:w-3/4 ${
                        checkUser ? 'text-right' : 'text-left'
                      }`}
                    >
                      <div className="space-y-1">
                        <div>
                          <div
                            className={`${cn(
                              classes?.common,
                              checkUser ? classes?.default : classes?.reverse
                            )}`}
                          >
                            {item.content.startsWith(
                              'data:image/jpeg;base64,'
                            ) === true ? (
                              <>
                                <Image
                                  src={item?.content}
                                  alt={'imagen'}
                                  width={90}
                                  height={90}
                                />
                              </>
                            ) : item?.content.split('.')[5] === 'pdf' ? (
                              <div
                                className="bg-red-900/20 h-15 w-[200px] px-2 flex py-4 rounded-md items-center cursor-pointer"
                                onClick={() => {
                                  openPdfInNewTab(item.content)
                                }}
                              >
                                <PDFIcon width={50} />

                                <span className="text-xl text-white">
                                  Archivo pdf
                                </span>
                              </div>
                            ) : (
                              <>{item.content.replace(/['"]+/g, '')}</>
                            )}
                          </div>

                          <div className="mt-2 text-xs text-[#686D73]">
                            {dayjs().to(dayjs.utc(item?.createdAt))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          ) : (
            <>
              <MessageNotFound />
            </>
          )}
        </>

        {/* ) : (
          ''
        )} */}
        <div ref={messagesEndRef} />
      </div>
    </>
  )
}

export default UserMessageView
