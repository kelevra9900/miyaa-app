import React from 'react'
import cn from 'classnames'
import { useRouter } from 'next/router'
import isEmpty from 'lodash/isEmpty'
import Image from 'next/image'
import dayjs from 'dayjs'
import relativeTime from 'dayjs/plugin/relativeTime'
import utc from 'dayjs/plugin/utc'
import timezone from 'dayjs/plugin/timezone'
import { DataChat } from '@/types'
import { MessageAvatarPlaceholderIcon } from '@/components/icons/message-avatar-placeholder-icon'
import { adminOnly, getAuthCredentials, hasAccess } from '@/utils/auth-utils'
import { useMeQuery } from '@/data/users'
import Loader from '@/components/ui/loader/loader'
import { Routes } from '@/config/routes'
import { avatarPlaceholder, logoPlaceholder } from '@/utils/placeholders'
import CameraIconChat from '@/components/icons/camera-icon'
import PDFIcon from '@/components/icons/pdf-solid'

dayjs.extend(relativeTime)
dayjs.extend(utc)
dayjs.extend(timezone)

interface Props {
  conversation: DataChat
  className?: string
}

const UserListView = ({ conversation, className, ...rest }: Props) => {
  const router = useRouter()
  const { data, loading } = useMeQuery()
  const { permissions } = getAuthCredentials()
  let permission = hasAccess(adminOnly, permissions)

  let isGroup = false

  if (loading) return <Loader text="Loading..." />

  //@ts-ignore
  const participant = conversation?.conversation?.participants?.find(
    //@ts-ignore
    (participant) => participant?.user.id !== data?.id
  )
  //@ts-ignore
  if (conversation?.conversation?.participants.length > 2) {
    isGroup = true
  }

  //@ts-ignore
  // const participant = conversation?.participants[0].user

  // console.log(participant)

  //@ts-ignore

  const id = conversation?.conversationId
  const routes = permission
    ? Routes?.message?.details({ id: id?.toString() })
    : Routes?.users?.details({ id: participant?.id.toString() ?? '' })

  return (
    <>
      <div
        className={cn(
          'relative cursor-pointer border-b border-solid border-b-[#E5E7EB] transition-all duration-500 hover:bg-[#e4e5e7]',
          Number(router?.query?.id) === conversation?.id ? 'bg-[#F3F4F6]' : '',
          className
        )}
        onClick={() => {
          router.push(`${routes}`)
        }}
        {...rest}
      >
        {/* {Boolean(conversation?.latestMessage?.isRead) ? (
          <div className="absolute left-2 top-1/2 z-50 h-[.375rem] w-[.375rem] -translate-y-1/2 transform rounded-full bg-[#EF4444]"></div>
        ) : (
          ''
        )} */}

        {!Boolean(
          //@ts-ignore

          //@ts-ignore
          conversation?.conversation?.messages[
            //@ts-ignore
            conversation?.conversation?.messages.length - 1
          ]?.seen
        ) ? (
          <div className="absolute left-2 top-1/2 z-50 h-[.375rem] w-[.375rem] -translate-y-1/2 transform rounded-full bg-[#EF4444]"></div>
        ) : (
          ''
        )}
        <div
          className={cn(
            'flex w-full gap-x-3 p-3 sm:p-6'
            // !isEmpty(conversation?.latestMessage?.content) ? 'items-center' : ''
          )}
        >
          <div className="relative h-8 w-8 overflow-hidden rounded-full 2xl:h-10 2xl:w-10">
            {/* {!isEmpty(conversation?.latestMessage?.sender?.image) ? ( */}
            <Image
              // @ts-ignore
              src={
                isGroup == false ? participant?.user?.image : avatarPlaceholder
              }
              alt={'imagen'}
              fill
              sizes="(max-width: 768px) 100vw"
              className="product-image object-contain"
            />
            {/* ) : (
              <MessageAvatarPlaceholderIcon
                className="text-[2rem] 2xl:text-[2.5rem]"
                color="#DDDDDD"
              />
            )} */}
          </div>
          <div className="block w-10/12">
            <div className="flex items-center justify-between">
              {/* {isEmpty(conversation?.latestMessage?.content) ? ( */}
              <h2 className="mr-1 w-[70%] truncate text-sm font-semibold">
                {/* {conversation?.latestMessage?.sender.firstName} */}

                {
                  // @ts-ignore
                  // conversation?.participants[0]?.user.firstName
                  isGroup === false ? (
                    participant?.user?.firstName
                  ) : (
                    <div>
                      <span>Grupo</span>
                      <br />
                      <p className="lowercase">
                        {participant?.user?.jobPosition}
                      </p>
                    </div>
                  )
                }
              </h2>
              {/* ) : (
                 <h2 className="mr-1 w-[70%] truncate text-sm font-semibold">
                   {conversation?.latestMessage?.content}
                 </h2>
               )} */}

              {/* {conversation?.latestMessage?.createdAt ? ( */}
              <p className="truncate text-xs text-[#686D73]">
                {dayjs().to(
                  dayjs.utc(
                    //@ts-ignore
                    // conversation?.messages[0].messages[

                    conversation?.conversation?.messages[
                      //@ts-ignore
                      conversation?.conversation?.messages.length - 1
                    ]?.createdAt

                    //   conversation?.messages[0].messages.length - 1
                    // ].createdAt
                  )
                )}
              </p>
              {/* ) : (
                ''
              )} */}
            </div>
            {/* {!isEmpty(conversation?.latestMessage?.content) ? ( */}
            <p className="text-xs text-[#64748B] truncate">
              {/* {participant?.firstName} {participant?.lastName} */}

              <>
                {
                  //@ts-ignore
                  conversation?.conversation?.messages[
                    //@ts-ignore
                    conversation?.conversation?.messages.length - 1
                  ]?.content.startsWith('data:image/jpeg;base64,') === true ? (
                    <div className="flex items-center">
                      <CameraIconChat className="mr-2 " />
                      <span className="text-sm">Imagén</span>
                    </div>
                  ) : //@ts-ignore

                  conversation?.conversation?.messages[
                      //@ts-ignore
                      conversation?.conversation?.messages.length - 1
                    ]?.content.split('.')[5] === 'pdf' ? (
                    <div className="flex items-center">
                      <PDFIcon width={15} className="mr-2 " />
                      <span className="text-sm">Archivo.pdf</span>
                    </div>
                  ) : (
                    <>
                      {
                        //@ts-ignore
                        conversation?.conversation?.messages[
                          //@ts-ignore
                          conversation?.conversation?.messages.length - 1
                        ]?.content
                      }
                    </>
                  )
                }
              </>
            </p>
            {/* ) : (
              ''
            )} */}
          </div>
        </div>
      </div>
    </>
  )
}

export default UserListView
