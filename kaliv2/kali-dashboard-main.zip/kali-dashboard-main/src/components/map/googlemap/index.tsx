export { default } from './GoogleMap'
