export { default } from '@/components/map/Map'
