// eslint-disable-next-line import/no-extraneous-dependencies
import 'jest-extended';
