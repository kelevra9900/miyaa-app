import {
  ConflictException,
  Injectable,
  Logger,
} from '@nestjs/common';
import {
  Attendance,
  AttendanceStatus,
  CheckpointLog,
  JobPosition,
  Role,
  RoundStatus,
  Shift as shift,
} from '@prisma/client';
import {S3} from 'aws-sdk';

import {PrismaService} from '../common/services/prisma.service';
import {AuthUser,UserPagination} from '../auth/auth-user';
import {UpdateUserRequest} from './models';
import {AttendanceResponse} from '../attendance/models';
import {AuthService} from '../auth/auth.service';
import {allDocumentTypes} from 'src/utils';

@Injectable()
export class UserService {
  private readonly logger = new Logger('UserService');
  private s3: S3;

  constructor(
    private readonly prisma: PrismaService,
    private readonly authService: AuthService,
  ) {
    this.s3 = new S3({
      signatureVersion: 'v4',
      accessKeyId: process.env.AWS_ACCESS_KEY_ID,
      secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
      region: process.env.AWS_DEFAULT_REGION,
    });
  }

  /**
   * Retrieves a user entity by its ID.
   *
   * @param id - The ID of the user entity.
   * @returns A Promise that resolves to the user entity with the specified ID, or null if not found.
   */
  public async getUserEntityById(id: number): Promise<AuthUser | null> {
    return this.prisma.user.findUnique({
      where: {id},
      include: {
        shift: true,
      },
    });
  }

  /**
   * Retrieves a user entity by username.
   *
   * @param username - The username of the user.
   * @returns A promise that resolves to the user entity if found, or null if not found.
   */
  public async getUserEntityByUsername(
    username: string,
  ): Promise<AuthUser | null> {
    const normalizedUsername = username.toLowerCase();
    return this.prisma.user.findUnique({
      where: {username: normalizedUsername},
    });
  }

  /**
   * Get all users with pagination.
   *
   * @param page - The current page number (default: 1).
   * @param limit - The number of users to fetch per page (default: 10).
   * @param search - Optional search query to filter users by name or email.
   * @param jobPosition - Optional job position to filter users by.
   * @returns A promise that resolves to a UserPagination object containing the list of users, total number of users, total number of pages, current page number, and number of users per page.
   */
  async findAll(
    page = 1,
    limit = 10,
    search?: string,
    jobPosition?: JobPosition,
  ): Promise<UserPagination> {
    // Pagination Logic
    const total = await this.getTotalUserCountUser(search,jobPosition);
    const users = await this.getUsersList(page,limit,search,jobPosition);

    const totalPages = Math.ceil(total / limit);
    const currentPage = page;
    const perPage = limit;

    return {
      users,
      total,
      totalPages,
      currentPage,
      perPage,
    };
  }

  /**
   * Retrieves a paginated list of all admin users.
   *
   * @param page - The page number to retrieve (default: 1).
   * @param limit - The maximum number of users to retrieve per page (default: 10).
   * @param search - Optional search query to filter users by (default: undefined).
   * @returns A UserPagination object containing the paginated list of admin users, as well as total number of users, total number of pages, current page number, and number of users per page.
   */
  async findAllAdmins(
    page = 1,
    limit = 10,
    search?: string,
  ): Promise<UserPagination> {
    // Pagination Logic
    const total = await this.getTotalUserCount(search);
    const users = await this.getAdminsList(page,limit,search);

    const totalPages = Math.ceil(total / limit);
    const currentPage = page;
    const perPage = limit;

    return {
      users,
      total,
      totalPages,
      currentPage,
      perPage,
    };
  }

  /**
   * Retrieves the total count of users based on the provided search criteria.
   *
   * @param search - Optional. A string used to search for users by their first name, last name, email, or username. The search is case-insensitive.
   * @param jobPosition - Optional. The job position of the users to include in the count.
   * @returns A promise that resolves to the total count of users.
   */
  async getTotalUserCount(
    search?: string,
    jobPosition?: JobPosition,
  ): Promise<number> {
    let whereCondition: any = {
      role: 'SUPER_ADMIN'
    };
    if (search) {
      whereCondition.OR = [
        {firstName: {contains: search,mode: 'insensitive'}},
        {lastName: {contains: search,mode: 'insensitive'}},
        {email: {contains: search,mode: 'insensitive'}},
        {username: {contains: search,mode: 'insensitive'}},
      ];
    }
    if (jobPosition) {
      whereCondition.jobPosition = jobPosition;
    }

    return this.prisma.user.count({
      where: whereCondition,
    });
  }

  /**
 * Retrieves the total count of users based on the provided search criteria.
 *
 * @param search - Optional. A string used to search for users by their first name, last name, email, or username. The search is case-insensitive.
 * @param jobPosition - Optional. The job position of the users to include in the count.
 * @returns A promise that resolves to the total count of users.
 */
  async getTotalUserCountUser(
    search?: string,
    jobPosition?: JobPosition,
  ): Promise<number> {
    let whereCondition: any = {
      role: 'USER',
    };

    if (search) {
      whereCondition.OR = [
        {firstName: {contains: search,mode: 'insensitive'}},
        {lastName: {contains: search,mode: 'insensitive'}},
        {email: {contains: search,mode: 'insensitive'}},
        {username: {contains: search,mode: 'insensitive'}},
      ];

    }
    if (jobPosition) {
      whereCondition.jobPosition = jobPosition;
    }

    return this.prisma.user.count({
      where: whereCondition,
    });
  }



  /**
   * Retrieves the total count of documents based on the provided search criteria.
   *
   * @param search - Optional. A string used to filter the documents by document type or file path.
   *
   * @returns A Promise that resolves to the total count of documents.
   */
  async getTotalDocumentsCount(search?: string): Promise<number> {
    let whereCondition: any = {};

    if (search) {
      whereCondition.OR = [
        {documentType: {contains: search,mode: 'insensitive'}},
        {filePath: {contains: search,mode: 'insensitive'}},
      ];
    }

    return this.prisma.document.count({
      where: whereCondition,
    });
  }

  /**
   * Retrieves a paginated list of documents based on the provided parameters.
   *
   * @param page - The page number of the results (default: 1).
   * @param limit - The maximum number of documents per page (default: 10).
   * @param search - The search string to filter documents by (optional).
   * @param valid - The validity status of the documents (optional).
   * @param validUntil - The validity date of the documents (optional).
   * @returns A paginated list of documents, including the total number of documents, total pages, current page, and documents per page.
   */
  async findAllDocuments(
    page = 1,
    limit = 10,
    search?: string,
    valid?: boolean,
    validUntil?: Date,
  ): Promise<UserPagination> {
    const total = await this.getTotalDocumentsCount(search);
    const documents = await this.prisma.document.findMany({
      skip: (page - 1) * limit,
      take: limit,
      where: {
        OR: [
          {filePath: {contains: search,mode: 'insensitive'}},
          // {valid: valid},
          // {validUntil: validUntil},
        ],
      },
      include: {
        user: true,
      },
    });

    const totalPages = Math.ceil(total / limit);
    const currentPage = page;
    const perPage = limit;

    return {
      users: documents,
      total,
      totalPages,
      currentPage,
      perPage,
    };
  }

  /**
   * Retrieves a list of users based on the provided parameters.
   *
   * @param page - The page number of the results (default: 1).
   * @param limit - The maximum number of users to retrieve per page (default: 10).
   * @param search - Optional. A search string to filter users by first name, last name, or email.
   * @param jobPosition - Optional. The job position to filter users by.
   * @returns A promise that resolves to an array of AuthUser objects.
   */
  async getUsersList(
    page = 1,
    limit = 10,
    search?: string,
    jobPosition?: JobPosition, // Asumiendo que JobPosition es un enum
  ): Promise<AuthUser[]> {
    const skip = (page - 1) * limit;

    let whereCondition: any = {
      role: 'USER',
    };

    // Condición de búsqueda
    if (search) {
      whereCondition.OR = [
        {firstName: {contains: search,mode: 'insensitive'}},
        {lastName: {contains: search,mode: 'insensitive'}},
        {email: {contains: search,mode: 'insensitive'}},
      ];
    }

    if (jobPosition) {
      whereCondition.jobPosition = jobPosition;
    }

    const users = await this.prisma.user.findMany({
      skip,
      take: limit,
      where: whereCondition,
      include: {
        shift: true,
        documents: true
      },
      orderBy: {
        online: 'desc',
      },
    });

    return users;
  }

  /**
   * Retrieves a list of administrators.
   *
   * @param page - The page number of the results (default: 1).
   * @param limit - The maximum number of administrators to retrieve per page (default: 10).
   * @param search - Optional search query to filter administrators by first name, last name, or email.
   * @returns A Promise that resolves to an array of AuthUser objects representing the administrators.
   */
  async getAdminsList(
    page = 1,
    limit = 10,
    search?: string,
  ): Promise<AuthUser[]> {
    if (search) {
      const skip = (page - 1) * limit;
      const users = await this.prisma.user.findMany({
        skip,
        take: limit,
        where: {
          OR: [
            {
              firstName: {
                contains: search,
                mode: 'insensitive',
              },
            },
            {
              lastName: {
                contains: search,
                mode: 'insensitive',
              },
            },
            {
              email: {
                contains: search,
                mode: 'insensitive',
              },
            },
          ],
          role: {
            in: ['ADMIN','SUPER_ADMIN'],
          },
        },
      });
      return users;
    }

    const skip = (page - 1) * limit;
    const users = await this.prisma.user.findMany({
      skip,
      take: limit,
      where: {
        role: {
          in: ['ADMIN','SUPER_ADMIN'],
        },
      },
    });
    return users;
  }
  // updateOnesignalId

  async updateOnesignalId(userId: number,onesignalId: string): Promise<AuthUser> {
    return this.prisma.user.update({
      where: {id: userId},
      data: {
        fcm: onesignalId,
      },
    });
  }

  async getMe(userId: number): Promise<any> {
    const user = await this.prisma.user.findUnique({
      where: {
        id: userId,
      },
      include: {
        shift: true,
        sector: true,
        documents: true,
      },
    });

    const uploadedDocumentTypes = user?.documents.map(doc => doc.documentType);
    const validUploadedDocumentTypes = uploadedDocumentTypes?.filter(docType => allDocumentTypes.includes(docType));
    const uniqueValidUploadedDocumentTypes = Array.from(new Set(validUploadedDocumentTypes)); // Remover duplicados
    const missingDocuments = allDocumentTypes.filter(docType => !uniqueValidUploadedDocumentTypes.includes(docType));

    const percentage = ((uniqueValidUploadedDocumentTypes.length / allDocumentTypes.length) * 100).toFixed(2);

    return {
      user,
      analytics: {
        documentPercentage: parseFloat(percentage),
        missingDocuments
      }
    };
  }

  async getNotifications(userId: number): Promise<any> {
    const notifications = await this.prisma.notification.findMany({
      where: {
        user_id: userId,
      },
      orderBy: {
        created_at: 'desc',
      },
    });

    return notifications;
  }

  /**
   * Updates a user by their ID.
   *
   * @param id - The ID of the user to update.
   * @param data - The data to update the user with.
   * @returns A Promise that resolves to the updated user.
   */
  async updateUserById(id: number,data: UpdateUserRequest): Promise<AuthUser> {
    const roleMapped = data.role ? Role[data.role as keyof typeof Role] : undefined;

    const updatePayload: any = {
      username: data.username,
      firstName: data.firstName,
      lastName: data.lastName,
      middleName: data.middleName,
      birthDate: data.birthDate,
      registrationDate: data.registrationDate,
      image: data.image,
      jobPosition: data.jobPosition,
      role: roleMapped,
      icon: data.icon
    };

    Object.keys(updatePayload).forEach(key => updatePayload[key] === undefined && delete updatePayload[key]);

    if (data.shiftId) {
      updatePayload.shift = {connect: {id: data.shiftId}};
    }


    if (data.sectorId) {
      updatePayload.sector = {connect: {id: data.sectorId}};
    }



    return this.prisma.user.update({
      where: {id},
      data: updatePayload,
    });
  }



  /**
   * Updates the ban status of a user.
   *
   * @param userId - The ID of the user to be banned/unbanned.
   * @param ban - A boolean value indicating whether to ban or unban the user.
   * @returns A Promise that resolves to the updated user object.
   */
  async banUser(userId: number,ban: boolean): Promise<AuthUser> {
    return this.prisma.user.update({
      where: {id: userId},
      data: {
        banned: ban,
      },
    });
  }

  /**
   * Modifies the role of a user identified by the given userId.
   *
   * @param {number} userId - The ID of the user to modify.
   * @param {string} role - The new role to assign to the user.
   * @returns {Promise<AuthUser>} - A promise that resolves to the updated user object with the modified role.
   * @throws {ConflictException} - If there is an error updating the user's role.
   */
  async modifyUserRole(userId: number,role: string): Promise<AuthUser> {
    return this.prisma.user.update({
      where: {id: userId},
      data: {
        role: role as Role,
      },
    });
  }

  /**
   * Retrieves the total count of users.
   *
   * @returns {Promise<number>} The total count of users.
   */
  async countUsers(): Promise<number> {
    return this.prisma.user.count();
  }

  /**
   * Retrieves a user by their ID.
   *
   * @param id - The ID of the user.
   * @returns A Promise that resolves to an AuthUser object if the user is found, or an object with an 'error' property if the user is not found.
   * @throws ConflictException if there is an error retrieving the user.
   */
  async getUserById(id: number): Promise<AuthUser | {error: string}> {
    try {
      const user: any = await this.prisma.user.findUnique({
        where: {id},
        include: {
          alerts: true,
          conversations: true,
          tracking: true,
          shift: true,
          sector: true,
          round_roundParticipants: true,
          checkpointLog: {
            include:{
              round: true
            }
          },
          documents: true
          
        },
      });

      delete user.passwordHash;

      if (!user) {
        return {
          error: 'User not found',
        };
      }

      return user;
    } catch (e) {
      this.logger.error('Error get user by id method',e,'UserService');
      throw new ConflictException();
    }
  }

  /**
   * Retrieves the documents associated with a user.
   *
   * @param userId - The ID of the user.
   * @param jobPosition - The job position of the user.
   * @returns A Promise that resolves to an object containing the message and data of the retrieved documents. If no documents are found, the message will be 'No documents found' and the data will be an empty array.
   * @throws ConflictException if there is an error retrieving the documents.
  */
  async getDocuments(userId: number): Promise<any> {
    try {
      const documents = await this.prisma.document.findMany({
        where: {userId},
        orderBy: {valid: 'desc'},
      });

      const uploadedDocumentTypes = documents.map(doc => doc.documentType);
      const validUploadedDocumentTypes = uploadedDocumentTypes.filter(docType => allDocumentTypes.includes(docType));
      const uniqueValidUploadedDocumentTypes = Array.from(new Set(validUploadedDocumentTypes)); // Remover duplicados
      const missingDocuments = allDocumentTypes.filter(docType => !uniqueValidUploadedDocumentTypes.includes(docType));

      const percentage = (uniqueValidUploadedDocumentTypes.length / allDocumentTypes.length) * 100;

      return {
        message: uniqueValidUploadedDocumentTypes.length > 0 ? 'Documents found' : 'No documents found',
        data: {
          percentage,
          uploaded: documents ?? [],
          missing: missingDocuments,
        },
      };
    } catch (e) {
      this.logger.error('Error get documents by user id method',e.stack,'UserService');
      throw new ConflictException('Error fetching documents');
    }
  }


  /**
   * Uploads a document for a user.
   *
   * @param userId - The ID of the user.
   * @param file - The file to be uploaded.
   * @param documentType - The type of the document.
   * @returns A promise that resolves to an object with a success message and the uploaded document data, or an error message if the upload fails.
   * @throws ConflictException if there is an error creating the document.
   */
  async createDocument(
    userId: number,
    file: Express.Multer.File,
    documentType: string,
  ): Promise<any> {
    try {
      const document = await this.documentUpload(file,userId);

      if (!document) {
        return {
          message: 'Error uploading document',
        };
      }
      const data = await this.prisma.document.create({
        data: {
          user: {
            connect: {
              id: Number(userId),
            },
          },
          documentType: documentType as any,
          filePath: document,
          issuedAt: new Date(),
        },
      });

      this.logger.log('Document uploaded successfully',data);

      return {
        message: 'Document uploaded successfully',
        data,
      };
    } catch (e) {
      this.logger.error('Error create document method',e,'UserService');
      throw new ConflictException();
    }
  }

  /**
   * Deletes a user by their ID.
   *
   * @param id - The ID of the user to delete.
   * @returns A message indicating the success of the operation.
   * @throws ConflictException if there is an error deleting the user.
   */
  async deleteUser(id: number) {
    try {
      await this.prisma.user.update({
        where: {id},
        data: {
          banned: true,
        },
      });
    } catch (e) {
      this.logger.error('Error delete user by id method',e,'UserService');
      throw new ConflictException();
    }
  }

  /**
   * Creates an attendance record for a user.
   *
   * @param userId - The ID of the user for whom the attendance is being created.
   * @param file - The file containing the face verification data.
   * @returns A Promise that resolves to the created attendance record if successful, or an object with an error message if unsuccessful.
   * @throws ConflictException if there is an error creating the attendance record.
   */
  async createAttendence(
    userId: number,
    file: Express.Multer.File,
  ): Promise<Attendance | {error: string}> {
    try {
      const verify = await this.authService.faceUpload(file);

      if (!verify) {
        return {
          error: 'Face verification failed',
        };
      }

      const user: any = await this.prisma.user.findUnique({
        where: {id: userId},
      });

      if (!user) {
        return {
          error: 'User not found',
        };
      }

      const attendence = await this.prisma.attendance.create({
        data: {
          checkIn: new Date(),
          status: AttendanceStatus.ON_SITE,
          user: {
            connect: {
              id: userId,
            },
          },
        },
      });

      return attendence;
    } catch (e) {
      this.logger.error(
        'Error create attendance method',
        e,
        'AttendanceService',
      );
      throw new ConflictException();
    }
  }

  // FIXME: Update checkout attendance, handle attendance by user reading if attendance are Done or not
  /**
   * Updates the attendance record for a user.
   *
   * @param userId - The ID of the user.
   * @param file - The file containing the user's face image for verification.
   * @returns A Promise that resolves to the updated attendance record if successful, or an object with a message property if the face verification fails or the attendance record is not found.
   * @throws ConflictException if there is an error updating the attendance record.
   */
  async updateAttendence(
    userId: number,
    file: Express.Multer.File,
  ): Promise<Attendance | {message: string}> {
    // Check if user has already checked in today
    try {
      const verify = await this.authService.faceUpload(file);

      if (!verify) {
        return {
          message: 'Face verification failed',
        };
      }

      const exist = await this.prisma.attendance.findFirst({
        where: {
          userId,
          checkIn: {
            gte: new Date(new Date().setHours(0,0,0,0)),
          },
        },
      });

      if (!exist) {
        return {
          message: 'Attendance not found for this user',
        };
      }

      const updated = await this.prisma.attendance.update({
        where: {
          id: exist.id,
        },
        data: {
          checkOut: new Date(),
          status: AttendanceStatus.DONE,
        },
      });

      return updated;
    } catch (e) {
      this.logger.error(
        'Error update attendance with checkout method',
        e,
        'AttendanceService',
      );
      throw new ConflictException();
    }
  }

  /**
   * Retrieves the attendance record for a user.
   *
   * @param userId - The ID of the user.
   * @returns A promise that resolves to an AttendanceResponse object if the attendance record exists, or an object with a message and data properties if the attendance record does not exist.
   * @throws ConflictException if there is an error retrieving the attendance record.
   */
  public async getAttendence(
    userId: number,
  ): Promise<AttendanceResponse | {message: string; data: any}> {
    try {
      const exist = await this.prisma.attendance.findFirst({
        where: {
          userId,
          checkIn: {
            gte: new Date(new Date().setHours(0,0,0,0)),
          },
          // checkOut: null,
          status: AttendanceStatus.ON_SITE,
        },
      });

      if (!exist) {
        return {
          message: 'Attendance not found for this user',
          data: null,
        };
      }
      return AttendanceResponse.fromAttendanceEntity(exist);
    } catch (e) {
      this.logger.error(
        'Error update attendance with checkout method',
        e,
        'AttendanceService',
      );
      throw new ConflictException();
    }
  }
  // Get all attendances by userId


  public async getAttendencesByUserId(
    userId: number,
  ): Promise<AttendanceResponse[]> {
    try {
      // Latest attendances first
      const exist = await this.prisma.attendance.findMany({
        where: {
          userId,
        },
        orderBy: {
          checkIn: 'desc',
        },
      });

      if (!exist) {
        return [];
      }
      return exist.map(AttendanceResponse.fromAttendanceEntity);
    } catch (e) {
      this.logger.error(
        'Error update attendance with checkout method',
        e,
        'AttendanceService',
      );
      throw new ConflictException();
    }
  }

  /**
   * Uploads a document file to AWS S3 and returns the file location.
   *
   * @param file - The document file to be uploaded.
   * @param userId - The ID of the user associated with the document.
   * @returns The file location of the uploaded document.
   * @throws Error if AWS_BUCKET_NAME is not defined.
   * @throws ConflictException if there is an error uploading the file to AWS S3.
   */
  async documentUpload(
    file: Express.Multer.File,
    userId: number,
  ): Promise<string> {
    const bucketName = process.env.AWS_BUCKET;
    if (!bucketName) {
      throw new Error('AWS_BUCKET_NAME is not defined');
    }

    // String name random
    var random = Math.random().toString(36).substring(7);

    const fileName = `${userId}-${random}-${file.originalname}`;
    const folderName = userId.toString();

    const uploadParams = {
      Bucket: bucketName,
      Key: `${folderName}/${fileName}`,
      Body: file.buffer,
    };

    try {
      const uploarResult = await this.s3.upload(uploadParams).promise();
      this.logger.log('File uploaded',uploarResult.Location);

      return uploarResult.Location;
    } catch (e) {
      this.logger.error('Error uploading file to s3',e);
      throw new ConflictException();
    }
  }

  async updateFcmToken(userId: number,fcmToken: string): Promise<String> {

    this.logger.log('Updating fcm token',fcmToken);
    const user = await this.prisma.user.update({
      where: {id: userId},
      data: {
        fcm: fcmToken,
      },
    });

    return user.fcm!;
  }

  /**
   * Retrieves all documents with pagination and search options.
   *
   * @param page - The page number to retrieve (default: 1).
   * @param limit - The maximum number of documents per page (default: 10).
   * @param search - The search string to filter documents by (optional).
   * @param valid - The validity status of the documents (optional).
   * @param validUntil - The maximum validity date of the documents (optional).
   * @returns A Promise that resolves to an object containing the documents, total count, total pages, current page, and documents per page.
   * @throws ConflictException if there is an error retrieving the documents.
   */
  async getAllDocuments(
    page = 1,
    limit = 10,
    search?: string,
    valid?: boolean,
    validUntil?: Date,
  ): Promise<any> {
    try {
      return await this.prisma.document.findMany({
        skip: (page - 1) * limit,
        take: limit,
        include: {
          user: true,
        },
      });
    } catch (e) {
      this.logger.error('Error get all documents method',e,'UserService');
      throw new ConflictException();
    }
  }

  /**
   * Retrieves the rounds associated with a user.
   *
   * @param userId - The ID of the user.
   * @returns A Promise that resolves to an array of available rounds (in progress or completed).
   * @throws ConflictException if the user is not found.
   * @throws ConflictException if there is an error retrieving the rounds.
   */
  async getRounds(userId: number): Promise<any> {
    try {
      let shift: shift | null = null;
      const user = await this.prisma.user.findUnique({
        where: {
          id: userId,
        },
        include: {
          round_roundParticipants: true,
        },
      });

      if (!user) {
        throw new ConflictException('User not found');
      }

      const availableRounds = user.round_roundParticipants.filter(
        (round) => round.status === 'ACTIVE' || round.status === 'IN_PROGRESS',
      );

      if (availableRounds.length === 0) {
        return [];
      }

      const checkpoints = availableRounds.map((round) => round.id);

      const roundCheckpoints = await this.prisma.round.findMany({
        where: {
          id: {
            in: checkpoints,
          },
        },
        include: {
          checkpoint: true,
        },
      });

      if (user.shiftId !== null) {
        shift = await this.prisma.shift.findUnique({
          where: {
            id: user.shiftId,
          },
        });
      }

      return {
        rounds: roundCheckpoints,
        shift: shift,
      };
    } catch (e) {
      this.logger.error('Error get rounds method',e,'UserService');
      throw new ConflictException();
    }
  }
  /**
   * Records a checkpoint log for a round, guard, and checkpoint.
   *
   * @param roundId - The ID of the round.
   * @param guardId - The ID of the guard.
   * @param checkpointId - The ID of the checkpoint.
   * @returns The created checkpoint log.
   */
  async recordCheckpointLog(
    roundId: number,
    guardId: number,
    checkpointId: number,
  ): Promise<CheckpointLog> {
    return await this.prisma.checkpointLog.create({
      data: {
        checkpoint: {connect: {id: checkpointId}},
        guard: {connect: {id: guardId}},
        round: {connect: {id: roundId}},
      },
    });
  }

  /**
   * Asynchronous method that starts a new round for a user.
   *
   * @param userId - The ID of the user.
   * @returns A Promise that resolves to void.
   * @throws ConflictException if the user is not found or an error occurs while starting the round.
   */
  async startRound(userId: number): Promise<void> {
    try {
      const user = await this.prisma.user.findUnique({
        where: {
          id: userId,
        },
      });

      if (!user) {
        throw new ConflictException('User not found');
      }

      // Crear una nueva ronda
      await this.prisma.round.create({
        data: {
          start: new Date(),
          user_roundParticipants: {
            connect: {id: userId},
          },
          status: RoundStatus.IN_PROGRESS,
          name: 'Round',
        },
      });
    } catch (e) {
      this.logger.error('Error starting round',e,'UserService');
      throw new ConflictException();
    }
  }

  /**
   * Finish the current round for a user.
   *
   * This method finds the last in-progress round for the specified user and updates it to mark it as completed.
   *
   * @param userId - The ID of the user for whom to finish the round.
   * @returns A Promise that resolves to void.
   * @throws ConflictException if no active round is found for the user.
   * @throws ConflictException if there is an error finishing the round.
   */
  async finishRound(userId: number): Promise<void> {
    try {
      // Encontrar la última ronda en progreso del usuario
      const round = await this.prisma.round.findFirst({
        where: {
          user_roundParticipants: {
            some: {
              id: userId,
            },
          },
          status: RoundStatus.IN_PROGRESS,
        },
        orderBy: {
          start: 'desc',
        },
      });

      if (!round) {
        throw new ConflictException('No active round found for user');
      }

      await this.prisma.round.update({
        where: {
          id: round.id,
        },
        data: {
          end: new Date(),
          status: RoundStatus.COMPLETED,
        },
      });
    } catch (e) {
      this.logger.error('Error finishing round',e,'UserService');
      throw new ConflictException();
    }
  }

  /**
   * Marks a checkpoint as reached for a user in their active round.
   *
   * @param userId - The ID of the user.
   * @param checkpointId - The ID of the checkpoint to be marked as reached.
   * @returns A Promise that resolves to void.
   * @throws ConflictException if there is no active round found for the user or if the checkpoint does not belong to the user's active round.
   * @throws ConflictException if there is an error reaching the checkpoint.
   */
  async checkpointReached(userId: number,checkpointId: number): Promise<void> {
    try {
      // Encontrar la última ronda en progreso del usuario
      const round = await this.prisma.round.findFirst({
        where: {
          user_roundParticipants: {
            some: {
              id: userId,
            },
          },
          status: RoundStatus.IN_PROGRESS,
        },
        orderBy: {
          start: 'desc', // Ordenar para obtener la última ronda en progreso
        },
        include: {
          checkpoint: true,
        },
      });

      if (!round) {
        throw new ConflictException('No active round found for user');
      }

      // Verificar si el checkpoint pertenece a la ronda en progreso del usuario
      const checkpointExists = round.checkpoint.some(
        (cp) => cp.id === checkpointId,
      );

      if (!checkpointExists) {
        throw new ConflictException(
          "Checkpoint does not belong to the user's active round",
        );
      }

      // Marcar el checkpoint como alcanzado
      await this.prisma.checkpoint.update({
        where: {
          id: checkpointId,
        },
        data: {
          checkedAt: new Date(),
        },
      });
    } catch (e) {
      this.logger.error('Error reaching checkpoint',e,'UserService');
      throw new ConflictException();
    }
  }

  /**
   * Checks if all checkpoints in a round have been reached in order.
   *
   * @param roundId - The ID of the round to check.
   * @returns A boolean indicating whether all checkpoints have been reached in order.
   * @throws ConflictException if the round is not found.
   * @throws ConflictException if there is an error checking the round completion.
   */
  async checkRoundCompletion(roundId: number): Promise<boolean> {
    try {
      // Encontrar la ronda por su ID
      const round = await this.prisma.round.findUnique({
        where: {
          id: roundId,
        },
        include: {
          checkpoint: true,
        },
      });

      if (!round) {
        throw new ConflictException('Round not found');
      }

      // Verificar si todos los checkpoints han sido alcanzados en orden
      const checkpointsReached = round.checkpoint.every(
        (cp) => cp.checkedAt !== null,
      );

      return checkpointsReached;
    } catch (e) {
      this.logger.error('Error checking round completion',e,'UserService');
      throw new ConflictException();
    }
  }

  async userMetrics(id: number): Promise<any> {
    try {
      const user = await this.prisma.user.findUnique({
        where: {
          id
        },
        include: {
          shift: true,
          sector: true,
          documents: true
        }
      })
    } catch (e) {
      this.logger.error('Error getting user metrics',e,'UserService');
      throw new ConflictException
    }
  }
  async getMyconversation(userId: number): Promise<any> {
    try {
      const userConversations = await this.prisma.conversationUser.findMany({
        where: {userId: userId},
        select: {conversationId: true},


      });

      const conversationIds = userConversations.map(uc => uc.conversationId);

      const otherUsers = await this.prisma.conversationUser.findMany({
        where: {
          conversationId: {in: conversationIds},
          userId: {not: userId},
        },
        select: {userId: true},
        distinct: ['userId'],
      });


      return otherUsers

    } catch (e) {

    }

  }


}
