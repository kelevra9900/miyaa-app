import { Module } from '@nestjs/common';
import { PassportModule } from '@nestjs/passport';
import { JwtModule, JwtService } from '@nestjs/jwt';

import { UserService } from './user.service';
import { UserController } from './user.controller';
import { PrismaService } from '../common/services/prisma.service';
import config from '../config';
import { AuthService } from '../auth/auth.service';
import { MailSenderService } from '../mail-sender/mail-sender.service';

@Module({
  imports: [
    JwtModule.register({
      secret: config.jwt.secretOrKey,
      signOptions: {
        expiresIn: config.jwt.expiresIn,
      },
    }),
    PassportModule.register({ defaultStrategy: 'jwt' }),
  ],
  providers: [
    UserService,
    PrismaService,
    AuthService,
    JwtService,
    MailSenderService,
  ],
  exports: [UserService],
  controllers: [UserController],
})
export class UserModule {}
