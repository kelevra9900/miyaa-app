import { createParamDecorator, ExecutionContext } from '@nestjs/common';

/**
 * Creates a parameter decorator called `Usr`.
 *
 * This decorator is used to extract the `user` property from the request object in a NestJS application.
 *
 * @param data - Additional data passed to the decorator (unused in this implementation).
 * @param ctx - The execution context containing the request object.
 * @returns The `user` property from the request object.
 */
export const Usr = createParamDecorator(
  (data: unknown, ctx: ExecutionContext) => {
    const request = ctx.switchToHttp().getRequest();
    return request.user;
  },
);
