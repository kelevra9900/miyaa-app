import {JobPosition,Role,Shift} from '@prisma/client';
import {
  IsBoolean,
  IsDate,
  IsEnum,
  IsNotEmpty,
  IsOptional,
  IsString,
  Matches,
  MaxLength,
  IsInt,
} from 'class-validator';
import {Transform} from 'class-transformer';

export class UpdateUserRequest {
  @IsOptional()
  @IsInt()
  @Transform(({value}) => Number(value))
  id: number;

  @IsOptional()
  @IsNotEmpty()
  @Matches(RegExp('^[a-zA-Z0-9\\-]+$'))
  @MaxLength(20)
  username?: string;

  @IsOptional()
  @IsNotEmpty()
  @Matches(RegExp('^[A-Za-zıöüçğşİÖÜÇĞŞñÑáéíóúÁÉÍÓÚ]+$'))
  @MaxLength(20)
  firstName?: string;

  @IsOptional()
  @IsNotEmpty()
  @Matches(RegExp('^[A-Za-zıöüçğşİÖÜÇĞŞñÑáéíóúÁÉÍÓÚ ]+$'))
  @MaxLength(40)
  lastName?: string;

  @IsOptional()
  @IsNotEmpty()
  @MaxLength(40)
  @Matches(RegExp('^[A-Za-zıöüçğşİÖÜÇĞŞñÑáéíóúÁÉÍÓÚ ]+$'))
  middleName?: string;

  @IsOptional()
  @IsString()
  image?: string;

  @IsOptional()
  @IsString()
  oneSignalId?: string;

  @IsOptional()
  birthDate?: string | null; // ISO Date

  @IsOptional()
  @IsBoolean()
  online?: boolean;

  @IsOptional()
  @IsDate()
  @Transform(({value}) => new Date(value))
  lastSeen?: Date;

  @IsOptional()
  @IsEnum(Role)
  @IsString()
  role?: Role;

  @IsOptional()
  @IsInt()
  @Transform(({value}) => Number(value))
  environmentId?: number;

  @IsOptional()
  @IsEnum(JobPosition)
  @IsString()
  jobPosition?: JobPosition;

  @IsOptional()
  @IsInt()
  @Transform(({value}) => Number(value))
  shiftId?: number;

  @IsOptional()
  @IsInt()
  @Transform(({value}) => Number(value))
  sectorId?: number;


  @IsOptional()
  shift?: Shift;

  @IsOptional()
  @IsString()
  registrationDate: string;

  @IsOptional()
  @IsString()
  icon: string;
}
