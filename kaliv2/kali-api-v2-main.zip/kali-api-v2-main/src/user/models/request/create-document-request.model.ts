import { DocumentType } from '@prisma/client';
import { IsEnum, IsNotEmpty, IsString } from 'class-validator';

export class CreateDocumentRequest {
  @IsNotEmpty()
  @IsString()
  @IsEnum(DocumentType)
  documentType: string;
}
