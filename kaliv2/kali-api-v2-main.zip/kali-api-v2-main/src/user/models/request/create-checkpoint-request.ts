import { IsInt } from 'class-validator';

export class RecordCheckpointLogDto {
  @IsInt()
  roundId: number;

  @IsInt()
  checkpointId: number;
}
