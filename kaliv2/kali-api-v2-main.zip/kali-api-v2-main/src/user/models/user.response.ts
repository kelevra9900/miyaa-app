import type {Role,User,Shift} from '@prisma/client';

export class UserResponse {
  id: number;
  username: string;
  email: string;
  emailVerified: boolean;
  name: string;
  image: string | null;
  birthDate: Date | null; // ISO Date
  registrationDate: Date; // ISO Date
  role: Role | null;
  shift: Shift | null;

  static fromUserEntity(entity: User): UserResponse {
    const response = new UserResponse();
    response.id = entity.id;
    response.username = entity.username;
    response.email = entity.email;
    response.emailVerified = entity.emailVerified;
    response.name = [entity.firstName,entity.middleName,entity.lastName]
      .filter((s) => s !== null)
      .join(' ');
    response.image = entity.image;
    response.birthDate = entity.birthDate;
    response.registrationDate = entity.registrationDate;
    response.role = entity.role;
    return response;
  }
}
