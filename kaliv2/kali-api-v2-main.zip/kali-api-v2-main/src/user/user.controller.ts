import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  ParseIntPipe,
  Patch,
  Post,
  Put,
  Query,
  UnauthorizedException,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import {ApiBearerAuth,ApiTags} from '@nestjs/swagger';
import {AuthGuard} from '@nestjs/passport';
import {UserService} from './user.service';
import {Usr} from './user.decorator';
import {UpdateUserRequest} from './models';
import {AuthUser,UserPagination} from '../auth/auth-user';
import {JobPosition,Role} from '@prisma/client';
import {FileInterceptor} from '@nestjs/platform-express';
import {CreateDocumentRequest} from './models/request/create-document-request.model';
import {RecordCheckpointLogDto} from './models/request/create-checkpoint-request';
import {PaginationModel} from 'src/notes/models/request/pagination.model';
import {UpdateFcmTokenDto} from './models/update-fcm-user-request.model';

@ApiTags('users')
@Controller('users')
@ApiBearerAuth()
@UseGuards(AuthGuard())
export class UserController {
  constructor(private readonly userService: UserService) { }

  /**
   * Update a user by their ID.
   *
   * @param id - The ID of the user to update.
   * @param updateRequest - The updated user information.
   * @returns A promise that resolves to the updated user.
   */
  @Put(':id')
  @HttpCode(HttpStatus.OK)
  async updateUser(
    @Param('id',ParseIntPipe) id: number,
    @Body() updateRequest: UpdateUserRequest,
  ) {
    return this.userService.updateUserById(id,updateRequest);
  }

  /**
   * Get all users.
   *
   * @param page - The page number.
   * @param limit - The maximum number of users to retrieve per page.
   * @param search - The search query to filter users.
   * @param jobPosition - The job position to filter users.
   * @returns A promise that resolves to the users matching the specified criteria.
   */
  @Get()
  @HttpCode(HttpStatus.OK)
  async findAll(
    // Pagination
    @Query('page',ParseIntPipe) page?: number,
    @Query('limit',ParseIntPipe) limit?: number,
    @Query('search') search?: string | undefined,
    @Query('jobPosition') jobPosition?: JobPosition,
  ): Promise<UserPagination> {
    return this.userService.findAll(page,limit,search,jobPosition);
  }

  @Patch('fcm')
  @HttpCode(HttpStatus.OK)
  async updateFcmToken(
    @Body() data: {fcmToken: string},
    @Usr() user: AuthUser,
  ): Promise<any> {
    console.log('==== updateFcmToken ====',data);
    return this.userService.updateFcmToken(user.id,data.fcmToken);
  }

  /**
   * Get all admins.
   *
   * @param page - The page number.
   * @param limit - The maximum number of admins to retrieve per page.
   * @param search - The search query to filter admins.
   * @returns A promise that resolves to the admins matching the specified criteria.
   */
  @Get('admins')
  @HttpCode(HttpStatus.OK)
  async findAllAdmins(
    @Query('page',ParseIntPipe) page: number,
    @Query('limit',ParseIntPipe) limit: number,
    @Query('search') search: string,
  ): Promise<UserPagination> {
    return this.userService.findAllAdmins(page,limit,search);
  }

  /**
   * Ban a user.
   *
   * @param id - The ID of the user to ban.
   * @returns A promise that resolves to void.
   */
  @Put(':id/block')
  @HttpCode(HttpStatus.OK)
  async banUser(@Param('id',ParseIntPipe) id: number): Promise<void> {
    await this.userService.banUser(id,true);
  }

  /**
   * Unban a user.
   *
   * @param id - The ID of the user to unban.
   * @returns A promise that resolves to void.
   */
  @Put(':id/unblock')
  @HttpCode(HttpStatus.OK)
  async unbanUser(
    @Param('id',ParseIntPipe) id: number,
    // @Usr() user: AuthUser,
  ): Promise<void> {
    await this.userService.banUser(id,false);
  }

  /**
   * Modify the role of a user.
   *
   * @param id - The ID of the user to modify.
   * @param role - The new role for the user.
   * @returns A promise that resolves to void.
   */
  @Put(':id/role')
  @HttpCode(HttpStatus.OK)
  async modifyUserRole(
    @Param('id',ParseIntPipe) id: number,
    @Body('role') role: Role,
    // @Usr() user: AuthUser,
  ): Promise<void> {
    await this.userService.modifyUserRole(id,role);
  }

  /**
   * Identify user by token.
   *
   * @param user - The authenticated user.
   * @returns A promise that resolves to the authenticated user.
   */
  @Get('me')
  @HttpCode(HttpStatus.OK)
  async identify(@Usr() user: AuthUser): Promise<AuthUser> {
    return this.userService.getMe(user.id);
  }

  @Get('me/notifications')
  @HttpCode(HttpStatus.OK)
  async getNotifications(@Usr() user: AuthUser) {
    return this.userService.getNotifications(user.id);
  }

  /**
   * Update the authenticated user's profile.
   *
   * @param updateRequest - The updated user information.
   * @param user - The authenticated user.
   * @returns A promise that resolves to void.
   */
  @Put('me')
  @HttpCode(HttpStatus.OK)
  async updateMe(
    @Body() updateRequest: UpdateUserRequest,
    @Usr() user: AuthUser,
  ): Promise<void> {
    await this.userService.updateUserById(user.id,updateRequest);
  }


  @Put('me/onesignal')
  @HttpCode(HttpStatus.OK)
  async updateOnesignalId(
    @Body('onesignalId') onesignalId: string,
    @Usr() user: AuthUser,
  ): Promise<void> {
    await this.userService.updateOnesignalId(user.id,onesignalId);
  }

  /**
   * Get a user by their ID.
   *
   * @param id - The ID of the user to retrieve.
   * @returns A promise that resolves to the user with the specified ID.
   */
  @Get(':id')
  @HttpCode(HttpStatus.OK)
  async getUserById(@Param('id',ParseIntPipe) id: number) {
    return this.userService.getUserById(id);
  }

  /**
   * Delete a user by their ID.
   *
   * @param id - The ID of the user to delete.
   * @param user - The authenticated user.
   * @throws UnauthorizedException if the authenticated user does not have the necessary permissions.
   * @returns A promise that resolves to the deleted user.
   */
  @Delete(':id')
  @HttpCode(HttpStatus.OK)
  async deleteUser(
    @Param('id',ParseIntPipe) id: number,
    @Usr() user: AuthUser,
  ) {
    if (
      user.role !== Role.ADMIN &&
      user.id !== id &&
      user.role !== Role.SUPER_ADMIN
    ) {
      throw new UnauthorizedException();
    }
    return this.userService.deleteUser(id);
  }

  /**
   * Create an attendance record for the authenticated user.
   *
   * @param user - The authenticated user.
   * @param file - The uploaded file containing the attendance record.
   * @returns A promise that resolves to the created attendance record.
   */
  @Post('me/attendance/check-in')
  @HttpCode(HttpStatus.OK)
  @UseInterceptors(FileInterceptor('file'))
  async checkIn(
    @Usr() user: AuthUser,
    @UploadedFile() file: Express.Multer.File,
  ) {
    return this.userService.createAttendence(user.id,file);
  }

  /**
   * Update the attendance record for the authenticated user.
   *
   * @param user - The authenticated user.
   * @param file - The uploaded file containing the attendance record.
   * @returns A promise that resolves to the updated attendance record.
   */
  @Put('me/attendance/check-out')
  @HttpCode(HttpStatus.OK)
  @UseInterceptors(FileInterceptor('file'))
  async updateAttendence(
    @Usr() user: AuthUser,
    @UploadedFile() file: Express.Multer.File,
  ) {
    return this.userService.updateAttendence(user.id,file);
  }

  /**
   * Get the attendance records for the authenticated user.
   *
   * @param user - The authenticated user.
   * @returns A promise that resolves to the attendance records for the user.
   */
  @Get('/me/attendance')
  @HttpCode(HttpStatus.OK)
  async getAttendence(@Usr() user: AuthUser) {
    return this.userService.getAttendence(user.id);
  }

  @Get('/me/attendance/summary')
  @HttpCode(HttpStatus.OK)
  async getAttendenceSummary(@Usr() user: AuthUser) {
    return this.userService.getAttendencesByUserId(user.id);
  }

  /**
   * Get documents for the authenticated user.
   *
   * @param user - The authenticated user.
   * @returns A promise that resolves to the documents for the user.
   */
  @Get('/me/documents')
  @HttpCode(HttpStatus.OK)
  async getDocuments(@Usr() user: AuthUser) {
    return this.userService.getDocuments(user.id);
  }

  /**
   * Create a document for the authenticated user.
   *
   * @param user - The authenticated user.
   * @param file - The uploaded file.
   * @param body - The request body containing the document type.
   * @returns A promise that resolves to the created document.
   */
  @Post('/me/documents')
  @HttpCode(HttpStatus.OK)
  @UseInterceptors(FileInterceptor('file'))
  async createDocument(
    @Usr() user: AuthUser,
    @UploadedFile() file: Express.Multer.File,
    @Body() body: CreateDocumentRequest,
  ) {
    const documentType = body.documentType;
    return this.userService.createDocument(user.id,file,documentType);
  }

  /**
   * Get documents by type.
   *
   * @param page - The page number.
   * @param limit - The maximum number of documents to retrieve per page.
   * @param search - The search query to filter documents.
   * @returns A promise that resolves to the documents matching the specified type.
   */
  @Get('/documents')
  @HttpCode(HttpStatus.OK)
  async getDocumentsByType(
    @Query() params?: PaginationModel
  ) {
    return this.userService.getAllDocuments(
      params?.page ? params.page : 1,
      params?.limit ? params.limit : 10,
      params?.search ? params.search : '',
    );
  }

  /**
   * Get the rounds for the authenticated user.
   *
   * @param user - The authenticated user.
   * @returns A promise that resolves to the rounds for the user.
   */
  @Get('/me/rounds')
  @HttpCode(HttpStatus.OK)
  async getRounds(@Usr() user: AuthUser) {
    return this.userService.getRounds(user.id);
  }
  /**
   * This code snippet represents a method called `checkPoint` inside a controller class.
   * It is decorated with `@Post('/me/checkpoint')` to handle HTTP POST requests at the '/me/checkpoint' endpoint.
   * The method is asynchronous and returns a Promise that resolves to the result of `this.userService.recordCheckpointLog(roundId, guardId, checkpointId)`.
   *
   * @param body - An object of type `RecordCheckpointLogDto` received in the request body.
   * @param user - An object of type `AuthUser` obtained from the `@Usr()` decorator, representing the authenticated user.
   * @returns A Promise that resolves to the result of `this.userService.recordCheckpointLog(roundId, guardId, checkpointId)`.
   */
  @Post('/me/checkpoint')
  @HttpCode(HttpStatus.OK)
  async checkPoint(
    @Body() body: RecordCheckpointLogDto,
    @Usr() user: AuthUser,
  ) {
    const {roundId,checkpointId} = body;
    const guardId = user.id;
    return this.userService.recordCheckpointLog(roundId,guardId,checkpointId);
  }

  @Get('/userInConversations/:id')
  @HttpCode(HttpStatus.OK)
  async getUserById2(@Param('id',ParseIntPipe) id: number) {
    return this.userService.getMyconversation(id);
  }

}
