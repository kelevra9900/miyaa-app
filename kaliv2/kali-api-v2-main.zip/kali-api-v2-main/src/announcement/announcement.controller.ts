import {Body,Controller,Delete,Get,HttpCode,HttpStatus,Param,Post,Put,Query,UseGuards} from '@nestjs/common';
import {AuthGuard} from '@nestjs/passport';
import {ApiBearerAuth,ApiTags} from '@nestjs/swagger';
import {AnnouncementService} from './announcement.service';
import {PaginationModel} from '../notes/models/request/pagination.model';
import {CreateAnnouncementRequest} from './models/announcement-create-request';

@ApiTags('Announcements')
@ApiBearerAuth()
@UseGuards(AuthGuard())
@Controller('announcement')
export class AnnouncementController {
	constructor(private readonly announcementService: AnnouncementService) { }


	@Get()
	@HttpCode(HttpStatus.OK)
	async get(
		@Query() params: PaginationModel,
	) {
		return this.announcementService.paginate({
			page: params.page || 1,
			limit: params.limit || 15,
		});
	}

	@Post()
	@HttpCode(HttpStatus.CREATED)
	async create(
		@Body() data: CreateAnnouncementRequest,
	) {
		return this.announcementService.create(data);
	}



	@Get(':id')
	@HttpCode(HttpStatus.OK)
	async getOne(
		@Param('id') id: number,
	) {
		return this.announcementService.findOne(id);
	}

	@Put(':id')
	@HttpCode(HttpStatus.OK)
	async update(
		@Param('id') id: number,
		@Body() data: CreateAnnouncementRequest,
	) {
		return this.announcementService.update(id,data);
	}

	@Delete(':id')
	@HttpCode(HttpStatus.NO_CONTENT)
	async delete(
		@Param('id') id: number,
	) {
		return this.announcementService.delete(id);
	}
}
