import {Announcement} from "@prisma/client";

export class AnnouncementResponse {
	id: number;
	title: string;
	content: string;
	image: string | null;
	createdAt?: Date | null;
	updatedAt?: Date | null;


	static fromAnnouncementEntity(entity: Announcement): AnnouncementResponse {
		const response = new AnnouncementResponse();
		response.id = entity.id;
		response.title = entity.title;
		response.content = entity.content;
		response.image = entity.image ?? null;
		response.createdAt = entity.createdAt ?? new Date();
		response.updatedAt = entity.updatedAt ?? new Date();
		return response;
	}
}


export type AnnouncementPagination = {
	data: AnnouncementResponse[];
	total: number;
	totalPages: number;
	currentPage: number;
	perPage: number;
}