import {ApiProperty} from "@nestjs/swagger";
import {IsBoolean,IsInt,IsString,IsUrl} from "class-validator";

export class CreateAnnouncementRequest {
	@ApiProperty({
		default: 'This is a sample title',
	})
	@IsString()
	title: string;

	@ApiProperty({
		default: 'This is a sample content',
	})
	@IsString()
	content: string;

	@ApiProperty({
		default: 'https://via.placeholder.com/150',
		description: 'The image URL of the announcement.'
	})
	@IsUrl()
	image: string;


	@ApiProperty({
		default: false,
		description: 'The approval status of the announcement.'
	})
	@IsBoolean()
	is_approved: boolean;


	@ApiProperty({
		example: 1,
		description: 'The user id of the creator of the announcement.'
	})
	@IsInt()
	created_by: number;
}