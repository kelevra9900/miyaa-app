import {Logger} from '@nestjs/common';

import {
  ConnectedSocket,
  MessageBody,
  OnGatewayConnection,
  OnGatewayDisconnect,
  SubscribeMessage,
  WebSocketGateway,
  WebSocketServer,
} from '@nestjs/websockets';
import {Namespace,Socket} from 'socket.io';


@WebSocketGateway({
  cors: true,
})
export class AnnouncementGateway implements OnGatewayConnection,OnGatewayDisconnect {
  @WebSocketServer() io: Namespace;

  private readonly logger = new Logger('AnnouncementGateway');

  async handleConnection() {
    this.logger.log('Client connected to AnnouncementGateway');
  }

  async handleDisconnect() {
    this.logger.log('Client disconnected');
  }

  afterInit() {
    this.logger.log('=======================');
    this.logger.log('Initialized AnnouncementGateway');
    this.logger.log('=======================');
  }
  @SubscribeMessage('message')
  handleMessage(client: any,payload: any): string {
    return 'Hello world!';
  }

  @SubscribeMessage('announcement')
  handleAnnouncement(client: any,payload: any): string {
    return 'Hello world!';
  }

  @SubscribeMessage('announcements')
  handleAnnouncements(client: any,payload: any): string {
    return 'Hello world!';
  }


  @SubscribeMessage('createAnnouncement')
  handleCreateAnnouncement(client: any,payload: any): string {
    return 'Hello world!';
  }

  @SubscribeMessage('updateAnnouncement')
  handleUpdateAnnouncement(client: any,payload: any): string {
    return 'Hello world!';
  }

  @SubscribeMessage('deleteAnnouncement')
  handleDeleteAnnouncement(client: any,payload: any): string {
    return 'Hello world!';
  }

}
