import {Injectable} from '@nestjs/common';
import {PrismaService} from '../common/services/prisma.service';
import {AnnouncementPagination} from './models/announcement-request';
import {Announcement} from '@prisma/client';
import {CreateAnnouncementRequest} from './models/announcement-create-request';

@Injectable()
export class AnnouncementService {
	constructor(
		private readonly prisma: PrismaService,
	) { }


	public async paginate({page,limit}): Promise<AnnouncementPagination> {
		const skip = page ? (page - 1) * limit : 0;
		const take = limit ? limit : 15;

		const announcements = await this.prisma.announcement.findMany({
			skip: Number(skip),
			take: Number(take),
			orderBy: {
				createdAt: 'desc',
			},
			include: {
				user: true,
			}
		});


		return {
			data: announcements,
			total: announcements.length,
			totalPages: Math.ceil(announcements.length / take),
			currentPage: page,
			perPage: take,
		}
	}

	public async create(data: CreateAnnouncementRequest): Promise<Announcement> {
		return await this.prisma.announcement.create({
			data: {
				title: data.title,
				content: data.content,
				image: data.image,
				is_approved: data.is_approved,
				createdBy: data.created_by,
			}
		});
	}

	public async update(id: number,data: CreateAnnouncementRequest): Promise<Announcement> {
		return await this.prisma.announcement.update({
			where: {
				id: id,
			},
			data: {
				title: data.title,
				content: data.content,
				image: data.image,
				is_approved: data.is_approved,
			}
		});
	}


	public async delete(id: number): Promise<Announcement> {
		return await this.prisma.announcement.delete({
			where: {
				id: id,
			}
		});
	}

	public async findOne(id: number): Promise<Announcement | null> {
		return await this.prisma.announcement.findUnique({
			where: {
				id: id,
			}
		});
	}
}
