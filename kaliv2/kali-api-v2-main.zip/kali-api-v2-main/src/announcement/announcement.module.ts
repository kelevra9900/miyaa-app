import {Module} from '@nestjs/common';
import {JwtService} from '@nestjs/jwt';
import {PassportModule} from '@nestjs/passport';
import {AuthService} from '../auth/auth.service';
import {PrismaService} from '../common/services/prisma.service';
import {AnnouncementGateway} from './announcement.gateway';
import {AnnouncementService} from './announcement.service';
import {AnnouncementController} from './announcement.controller';
import {MailSenderService} from '../mail-sender/mail-sender.service';

@Module({
	imports: [PassportModule.register({defaultStrategy: 'jwt'})],
	providers: [
		AuthService,
		JwtService,
		MailSenderService,
		PrismaService,
		AnnouncementGateway,
		AnnouncementService,
	],
	exports: [AnnouncementService,],
	controllers: [AnnouncementController],
})
export class AnnouncementModule { }
