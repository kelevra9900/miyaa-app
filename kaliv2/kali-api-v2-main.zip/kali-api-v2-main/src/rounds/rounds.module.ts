import { PassportModule } from '@nestjs/passport';
import { Module } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';

import { RoundsController } from './rounds.controller';
import { RoundsService } from './rounds.service';
import { PrismaService } from '../common/services/prisma.service';

@Module({
  imports: [PassportModule.register({ defaultStrategy: 'jwt' })],
  providers: [RoundsService, JwtService, PrismaService],
  controllers: [RoundsController],
  exports: [RoundsService],
})
export class RoundsModule {}
