import { Round } from '@prisma/client';

class RoundsResponse {
  id: number;
  name: string;
  status: string;
  start: Date;
  end?: Date | null;
  checkpoints: CheckpointResponse[];

  static fromRoundEntity(entity: Round): RoundsResponse {
    const response = new RoundsResponse();
    response.id = entity.id;
    response.status = entity.status;
    response.start = entity.start;
    response.end = entity.end;
    return response;
  }
}

export type RoundsPagination = {
  data: Round[];
  total: number;
  totalPages: number;
  currentPage: number;
  perPage: number;
};

export class CheckpointResponse {
  id: number;
  name: string;
  status: string;
  roundId: number;

  static fromCheckpointEntity(entity: any): CheckpointResponse {
    const response = new CheckpointResponse();
    response.id = entity.id;
    response.name = entity.name;
    response.status = entity.status;
    response.roundId = entity.roundId;
    return response;
  }
}
