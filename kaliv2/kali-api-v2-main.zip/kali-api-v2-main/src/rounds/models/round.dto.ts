import {ApiProperty} from '@nestjs/swagger';
import {RoundStatus} from '@prisma/client';
import {Type} from 'class-transformer';
import {
  IsArray,
  IsDateString,
  IsEnum,
  IsNotEmpty,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

class CheckpointDTO {
  @IsNotEmpty()
  @IsString()
  name: string;

  @IsNotEmpty()
  @IsString()
  location: string;

  @IsDateString()
  timestamp: string;

  @IsNotEmpty()
  latitude: number;

  @IsNotEmpty()
  longitude: number;
}

class UserDTO {
  @IsNotEmpty()
  @IsString()
  userId: string;
}

export class CreateRoundDTO {
  @ApiProperty({
    description: 'Name of the round',
    example: 'Round 1',
  })
  @IsNotEmpty()
  @IsString()
  name: string;

  @ApiProperty({
    description: 'Date time when the round starts',
    example: '2021-08-05T14:48:00.000Z',
  })
  @IsNotEmpty()
  @IsDateString()
  start: string;

  @ApiProperty({
    description: 'Date time when the round ends',
    example: '2021-08-05T14:48:00.000Z',
  })
  @IsOptional()
  @IsDateString()
  end?: string;

  @ApiProperty({
    description: 'Status of the round',
    example: 'IN_PROGRESS',
  })
  @IsNotEmpty()
  @IsEnum(RoundStatus)
  status: RoundStatus;

  @ApiProperty({
    description: 'List of participants in the round',
    example: [
      {
        userId: '1',
      },
    ],
    type: [UserDTO],
  })
  @IsArray()
  @IsOptional()
  @ValidateNested({each: true})
  @Type(() => UserDTO)
  user_roundParticipants?: UserDTO[];

  @ApiProperty({
    description: 'List of delayed users in the round',
    type: [UserDTO],
    example: [
      {
        userId: '1',
      },
    ],
  })
  @IsArray()
  @ValidateNested({each: true})
  @Type(() => UserDTO)
  user_delayedRounds: UserDTO[];

  @ApiProperty({
    description: 'List of checkpoints in the round',
    example: [
      {
        name: 'Checkpoint 1',
        location: 'Location 1',
        timestamp: '2021-08-05T14:48:00.000Z',
        latitude: 10.0232,
        longitude: -21.12342,
      },
    ],
    type: [CheckpointDTO],
  })
  @IsOptional()
  @IsArray()
  @ValidateNested({each: true})
  @Type(() => CheckpointDTO)
  checkpoints: CheckpointDTO[];
}
