import {Injectable,InternalServerErrorException, Logger} from '@nestjs/common';
import {PrismaService} from '../common/services/prisma.service';
import {CreateRoundDTO} from './models/round.dto';
import {Round,RoundStatus} from '@prisma/client';
import {RoundsPagination} from './models/rounds.response';

@Injectable()
export class RoundsService {
  constructor(private readonly prisma: PrismaService) { }

  /**
   * Retrieves a paginated list of rounds.
   *
   * @param page - The page number to retrieve (default: 1).
   * @param limit - The maximum number of rounds per page (default: 10).
   * @param search - The search string to filter rounds by status (optional).
   * @returns A promise that resolves to an array of Round objects.
   */
  async paginated(
    page = 1,
    limit = 10,
    search?: RoundStatus,
  ): Promise<RoundsPagination> {
    const skip = (page - 1) * limit;

    const where = search
      ? {
        status: search,
      }
      : {};

    try {
      const [rounds,count] = await Promise.all([
        this.prisma.round.findMany({
          skip,
          take: Number(limit),
          where,
        }),
        this.prisma.round.count({where}),
      ]);

      const totalPages = Math.ceil(count / limit);

      return {
        data: rounds,
        total: count,
        totalPages,
        currentPage: Number(page),
        perPage: Number(limit),
      };
    } catch (e) {
      console.error('Error fetching rounds:',e);
      throw new InternalServerErrorException('Failed to fetch rounds');
    }
  }

  async getRound(id: number): Promise<Round> {
    try {
      const round = await this.prisma.round.findUnique({
        where: {
          id: Number(id),
        },
        include: {
          checkpoint: true,
          user_roundParticipants: true,
        },
      });

      if (!round) {
        throw new Error('Round not found');
      }

      return round;
    } catch (e) {
      throw new InternalServerErrorException('Failed to fetch round');
    }
  }

  async getRoundId(id: number): Promise<Round> {
    try {
      const round = await this.prisma.round.findUnique({
        where: {
          id: Number(id),
        },
       
      });

      if (!round) {
        throw new Error('Round not found');
      }

      return round;
    } catch (e) {
      throw new InternalServerErrorException('Failed to fetch round');
    }
  }

  /**
   * Retrieves the total number of rounds.
   *
   * @param search - The search string to filter rounds by status (optional).
   * @returns A promise that resolves to the total number of rounds.
   */
  async getTotalRounds(search?: string): Promise<number> {
    let whereCondition: any = {};
    if (search) {
      whereCondition.OR = [
        {
          status: {contains: search,mode: 'insensitive'},
        },
      ];
    }
    return this.prisma.round.count({
      where: whereCondition,
    });
  }

  /**
   * Retrieves a paginated list of rounds.
   *
   * @param page - The page number to retrieve (default: 1).
   * @param limit - The maximum number of rounds per page (default: 10).
   * @param search - The search string to filter rounds by status (optional).
   * @returns A promise that resolves to an array of Round objects.
   */
  async getRoundesList(
    page = 1,
    limit = 10,
    search?: string,
  ): Promise<Round[]> {
    const skip = (page - 1) * limit;
    let whereCondition: any = {};
    if (search) {
      whereCondition.OR = [
        {
          status: {contains: search,mode: 'insensitive'},
        },
      ];
    }
    return this.prisma.round.findMany({
      skip,
      take: limit,
      where: whereCondition,
      include: {
        checkpoint: true,
        user_roundParticipants: true,
      },
    });
  }

  async create(data: CreateRoundDTO) {
    try {
      const createData: any = {
        start: new Date(data.start),
        end: data.end ? new Date(data.end) : null,
        status: data.status,
        name: data.name,
      };

      if (data.user_roundParticipants?.length) {
        createData.user_roundParticipants = {
          connect: data.user_roundParticipants.map((user) => ({
            id: Number(user.userId),
          })),
        };
      }

      if (data.checkpoints?.length) {
        createData.checkpoint = {
          create: data.checkpoints.map((checkpoint) => ({
            location: checkpoint.location,
            checkedAt: checkpoint.timestamp ? new Date(checkpoint.timestamp) : null,
            latitude: checkpoint.latitude,
            longitude: checkpoint.longitude,
          })),
        };
      }

      return await this.prisma.round.create({
        data: {
          ...createData,
        },
      });
    } catch (e) {
      console.error('Error creating round:',e);
      throw new InternalServerErrorException('Failed to create round');
    }
  }

  async update(data: Round) {
    try {
      const roundUpdate =  await this.prisma.round.update({
        where: {
          id: data.id,
        },
        data: {
          name: data.name,
          start: data.start,
          end: data.end,
          status: data.status,
        },
      });


      // const updatedCheckpoints = await Promise.all(
      //   //@ts-ignore
      //   data.checkpoint.map(async (checkpoint:any) => {

      //     // Actualiza el checkpoint existente
      //     return this.prisma.checkpoint.update({
      //       where: { id: checkpoint.id },
      //       data: {
      //         location: checkpoint.location,
      //         longitude: parseInt( checkpoint.longitude),
      //         latitude: parseInt( checkpoint.latitude),
      //         // Aquí puedes añadir más campos que desees actualizar en Checkpoint
      //       },
      //     });
      //   })
      // );

      return roundUpdate
    } catch (e) {
      console.error('Error updating round:',e);
      throw new InternalServerErrorException('Failed to update round');
    }
  }


}
