import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  Post,
  Put,
  Query,
  UseGuards,
} from '@nestjs/common';
import {ApiBearerAuth,ApiProperty,ApiTags} from '@nestjs/swagger';
import {Round,RoundStatus} from '@prisma/client';
import {AuthGuard} from '@nestjs/passport';

import {RoundsService} from './rounds.service';
import {PaginationModel} from '../notes/models/request/pagination.model';
import {RoundsPagination} from './models/rounds.response';
import {CreateRoundDTO} from './models/round.dto';

@ApiTags('Rounds Management')
@Controller('rounds')
// @ApiBearerAuth()
// @UseGuards(AuthGuard())
export class RoundsController {
  constructor(private readonly roundsService: RoundsService) { }

  /**
   * Retrieves rounds based on the provided pagination parameters.
   *
   * @param params - The pagination parameters.
   * @returns A Promise that resolves to the retrieved rounds.
   */
  @Get()
  @HttpCode(HttpStatus.OK)
  async getRounds(
    @Query() params: PaginationModel,
  ): Promise<RoundsPagination | {message: string}> {
    return this.roundsService.paginated(
      params.page,
      params.limit,
      params.search as RoundStatus,
    );
  }

  /**
   * Retrieves a specific round based on the provided ID.
   *
   * @param params - The pagination parameters.
   * @returns A Promise that resolves to the retrieved round.
   */
  @Get(':id')
  @HttpCode(HttpStatus.OK)
  async getRound(
    @Param('id') id: number,
  ): Promise<Round> {
    return this.roundsService.getRound(id);
  }

  
  /**
   * Creates a new round.
   *
   * @param round - The round data to be created.
   * @returns A Promise that resolves to the created round.
   */
  @Post()
  @ApiProperty({type: CreateRoundDTO})
  @HttpCode(HttpStatus.CREATED)
  async createRound(@Body() round: CreateRoundDTO): Promise<Round> {
    return this.roundsService.create(round);
  }

  /**
   * Updates a specific round.
   *
   * @param round - The round data to be updated.
   * @returns A Promise that resolves to the updated round.
   */
  @Put(':id')
  @HttpCode(HttpStatus.OK)
  async updateRound(@Body() round: Round): Promise<Round> {
    return this.roundsService.update(round);
  }


}
