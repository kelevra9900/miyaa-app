import { Logger } from '@nestjs/common';
import {
  OnGatewayConnection,
  OnGatewayDisconnect,
  SubscribeMessage,
  WebSocketGateway,
  WebSocketServer,
} from '@nestjs/websockets';

import { Namespace } from 'socket.io';

@WebSocketGateway({
  cors: true,
})
export class RoundsGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer() io: Namespace;
  private readonly logger = new Logger('RoundsGateway');

  async handleConnection() {
    this.logger.log('Client connected');
  }

  async handleDisconnect() {
    this.logger.log('Client disconnected');
  }

  afterInit() {
    this.logger.log('Initialized RoundsGateway');
  }

  @SubscribeMessage('startRound')
  handleStartRound(client: any, payload: any): void {
    this.io.emit('roundStarted', { status: 'Iniciado', details: payload });
  }

  @SubscribeMessage('checkpoint')
  handleCheckpoint(client: any, payload: any): void {
    this.io.emit('checkpointRegistered', {
      status: 'Registrado',
      details: payload,
    });
  }

  @SubscribeMessage('endRound')
  handleEndRound(client: any, payload: any): void {
    this.io.emit('roundEnded', { status: 'Finalizado', details: payload });
  }
}
