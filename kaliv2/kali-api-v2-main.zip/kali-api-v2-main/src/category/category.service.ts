import {ApiBody} from '@nestjs/swagger';
import {Injectable,Logger} from '@nestjs/common';
import {PrismaService} from '../common/services/prisma.service';
import {CreateCategoryRequest} from './model/create-category.model';
import {
  CategoryPagination,
  CategoryResponse,
} from './model/category.response';

@Injectable()
export class CategoryService {
  constructor(private readonly prisma: PrismaService) { }

  /**
   * Creates a new category.
   *
   * @param data - The data for creating the category.
   * @returns The created category.
   * @throws If an error occurs during the creation process.
   */
  @ApiBody({type: CreateCategoryRequest})
  async createCategory(data: CreateCategoryRequest) {
    try {
      const category = await this.prisma.category.create({
        data: {
          name: data.name,
          slug: data.slug,
          thumbnail: data.thumbnail,
          image: data.image,
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      });

      return category;
    } catch (e) {
      console.log(e);
      return e;
    }
  }

  /**
   * Retrieves a list of categories with pagination and search functionality.
   *
   * @param page - The page number to retrieve. Defaults to 1.
   * @param limit - The maximum number of categories to retrieve per page. Defaults to 10.
   * @param search - The search term to filter categories by name or slug. Defaults to undefined.
   * @returns A CategoryPagination object containing the retrieved categories and pagination information.
   */
  async getCategories(
    page?: number,
    limit = 0,
    search?: string,
  ): Promise<CategoryPagination> {
    const skip = page ? (page - 1) * limit : 0;
    const take = limit ? limit : 10;
    let categories: any;

    if (search) {
      categories = await this.prisma.category.findMany({
        skip,
        take: Number(take),
        where: {
          OR: [
            {
              name: {
                contains: search,
                mode: 'insensitive',
              },
            },
            {
              slug: {
                contains: search,
                mode: 'insensitive',
              },
            },
          ],
        },
      });
    } else {
      categories = await this.prisma.category.findMany({
        skip,
        take: Number(take),
      });
    }

    const count = await this.prisma.category.count({
      where: {
        OR: [
          {
            name: {
              contains: search,
              mode: 'insensitive',
            },
          },
          {
            slug: {
              contains: search,
              mode: 'insensitive',
            },
          },
        ],
      },
    });

    // Pagination
    const totalPages = Math.ceil(count / limit);
    const currentPage = page ? page : 1;
    const perPage = limit ? limit : 10;

    return {
      data: categories.map((category) =>
        CategoryResponse.fromCategoryEntity(category),
      ),
      total: count ?? 0,
      totalPages: totalPages ?? 0,
      currentPage,
      perPage,
    };
  }

  /**
   * Retrieves a category by its slug.
   *
   * @param slug - The slug of the category.
   * @returns A Promise that resolves to a CategoryResponse object if the category is found, or an object with a 'message' property set to 'Category not found' if the category is not found.
   */
  async getCategoryBySlug(slug: string): Promise<CategoryResponse | any> {
    const category = await this.prisma.category.findUnique({
      where: {
        slug,
      },
    });

    if (!category) {
      return {
        message: 'Category not found',
      };
    }

    return CategoryResponse.fromCategoryEntity(category);
  }

  /**
   * Retrieves a category by its ID.
   *
   * @param id - The ID of the category.
   * @returns A Promise that resolves to a CategoryResponse object if the category is found, or an object with a 'message' property set to 'Category not found' if the category is not found.
   */
  async getCategoryById(id: number): Promise<CategoryResponse | any> {
    const category = await this.prisma.category.findUnique({
      where: {
        id,
      },
    });

    if (!category) {
      return {
        message: 'Category not found',
      };
    }

    return CategoryResponse.fromCategoryEntity(category);
  }

  async updateCategory(
    id: number,
    data: CreateCategoryRequest,
  ): Promise<CategoryResponse | any> {
    const category = await this.prisma.category.findUnique({
      where: {
        id,
      },
    });

    if (!category) {
      return {
        message: 'Category not found',
      };
    }

    const updatedCategory = await this.prisma.category.update({
      where: {
        id,
      },
      data: {
        name: data.name,
        slug: data.slug,
        thumbnail: data.thumbnail,
        updatedAt: new Date(),
      },
    });

    return CategoryResponse.fromCategoryEntity(updatedCategory);
  }

  async deleteCategory(id: number): Promise<CategoryResponse | any> {
    const category = await this.prisma.category.findUnique({
      where: {id},
    });

    if (!category) {
      return {message: 'Category not found'};
    }

    await this.prisma.note.updateMany({
      where: {category_id: id},
      data: {category_id: null},
    });

    const deletedCategory = await this.prisma.category.delete({
      where: {id},
    });

    return CategoryResponse.fromCategoryEntity(deletedCategory);
  }
}
