import { Category } from '@prisma/client';

export class CategoryResponse {
  id: number;
  slug: string;
  name: string;
  thumbnail?: string | null;
  image?: string | null;
  createdAt: Date;
  updatedAt: Date;

  static fromCategoryEntity(entity: Category): CategoryResponse {
    const response = new CategoryResponse();
    response.id = entity.id;
    response.name = entity.name;
    response.slug = entity.slug;
    response.thumbnail = entity.thumbnail;
    response.image = entity.image;
    response.createdAt = entity.createdAt;
    response.updatedAt = entity.updatedAt;
    return response;
  }
}

export type CategoryPagination = {
  data: CategoryResponse[];
  total: number;
  totalPages: number;
  currentPage: number;
  perPage: number;
};
