import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsUrl } from 'class-validator';

export class CreateCategoryRequest {
  @ApiProperty({
    type: 'string',
  })
  @IsString()
  name: string;

  @ApiProperty({
    type: 'string',
  })
  @IsString()
  slug: string;

  @ApiProperty({
    type: 'string',
  })
  @IsString()
  @IsUrl()
  thumbnail: string;

  @ApiProperty({
    type: 'string',
  })
  @IsString()
  image: string;
}
