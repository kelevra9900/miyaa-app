import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
  UseGuards,
} from '@nestjs/common';
import {AuthGuard} from '@nestjs/passport';
import {ApiBearerAuth,ApiTags} from '@nestjs/swagger';
import {CategoryService} from './category.service';
import {CreateCategoryRequest} from './model/create-category.model';
import {PaginationModel} from 'src/notes/models/request/pagination.model';

@Controller('category')
@ApiTags('Category')
export class CategoryController {
  constructor(private readonly categoryService: CategoryService) { }

  /**
   * Retrieves a list of categories based on the provided parameters.
   *
   * @param page The page number for pagination.
   * @param limit The maximum number of categories to retrieve per page.
   * @param search The search query to filter categories.
   * @returns A list of categories matching the provided parameters.
   */
  @Get()
  public async getCategories(
    @Query() params: PaginationModel,
  ) {
    return this.categoryService.getCategories(
      params.page ? params.page : 1,
      params.limit ? params.limit : 10,
      params.search ? params.search : '',
    );
  }

  /**
   * Creates a new category.
   *
   * @param data The data for creating the category.
   * @returns The created category.
   */
  @Post()
  @ApiBearerAuth()
  @UseGuards(AuthGuard())
  public async createCategory(@Body() data: CreateCategoryRequest) {
    return this.categoryService.createCategory(data);
  }

  /**
   * Retrieves a category by its ID.
   *
   * @param id The ID of the category to retrieve.
   * @returns The category with the specified ID.
   */
  @Get(':id')
  public async getCategoryById(@Param('id',ParseIntPipe) id: number) {
    return this.categoryService.getCategoryById(id);
  }

  /**
   * Updates a category with the specified ID.
   *
   * @param data The data for updating the category.
   * @param id The ID of the category to update.
   * @returns The updated category.
   */
  @Put(':id')
  @ApiBearerAuth()
  @UseGuards(AuthGuard())
  public async updateCategory(
    @Body() data: CreateCategoryRequest,
    @Body() id: number,
  ) {
    return this.categoryService.updateCategory(id,data);
  }
  /**
   * Deletes a category with the specified ID.
   *
   * @param id The ID of the category to delete.
   * @returns The deleted category.
   */
  @Delete(':id')
  @ApiBearerAuth()
  @UseGuards(AuthGuard())
  public async deleteCategory(@Param('id',ParseIntPipe) id: number) {
    return this.categoryService.deleteCategory(id);
  }
}
