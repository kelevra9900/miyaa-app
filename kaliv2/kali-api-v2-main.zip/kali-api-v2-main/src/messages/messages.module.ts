import { PassportModule } from '@nestjs/passport';
import { Module } from '@nestjs/common';
import { JwtModule, JwtService } from '@nestjs/jwt';
import { MessagesController } from './messages.controller';
import { MessagesService } from './messages.service';
import { PrismaService } from '../common/services/prisma.service';
import { AuthService } from '../auth/auth.service';
import { UserService } from '../user/user.service';
import { MailSenderService } from '../mail-sender/mail-sender.service';
import config from '../config';

@Module({
  imports: [
    JwtModule.register({
      secret: config.jwt.secretOrKey,
      signOptions: {
        expiresIn: config.jwt.expiresIn,
      },
    }),
    PassportModule.register({ defaultStrategy: 'jwt' }),
  ],
  controllers: [MessagesController],
  providers: [
    MessagesService,
    PrismaService,
    AuthService,
    UserService,
    JwtService,
    MailSenderService,
  ],
  exports: [MessagesService],
})
export class MessagesModule {}
