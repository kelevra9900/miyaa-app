import {
  WebSocketGateway,
  SubscribeMessage,
  MessageBody,
  OnGatewayInit,
  OnGatewayConnection,
  OnGatewayDisconnect,
} from '@nestjs/websockets';
import { Logger } from '@nestjs/common';
import { Socket, Server } from 'socket.io';

@WebSocketGateway()
export class MessagesGateway
  implements OnGatewayInit, OnGatewayConnection, OnGatewayDisconnect
{
  private logger: Logger = new Logger('MessagesGateway');

  constructor(private server: Server) {}

  afterInit() {
    this.logger.log('=======================');
    this.logger.log('Initialized MessagesGateway');
    this.logger.log('=======================');
  }
  handleConnection(client: Socket, ...args: any[]) {
    this.logger.log(`Client connected: ${client.id}`);
  }

  handleDisconnect(client: Socket) {
    this.logger.log(`Client disconnected: ${client.id}`);
  }

  @SubscribeMessage('chat')
  handleMessage(@MessageBody() message: any): void {
    console.log('========= Chat ==============');
    console.log(message);
    console.log('=======================');
    this.server.emit('chat', message);
  }
}
