import {INestApplicationContext,Logger} from '@nestjs/common';
import {JwtService} from '@nestjs/jwt';
import {IoAdapter} from '@nestjs/platform-socket.io';

import {Server,ServerOptions} from 'socket.io';
import {SocketWithAuth} from './auth/jwt-payload';

export class SocketIOAdapter extends IoAdapter {
  private readonly logger = new Logger(SocketIOAdapter.name);
  constructor(private app: INestApplicationContext) {
    super(app);
  }

  createIOServer(port: number,options?: ServerOptions) {
    const cors = {
      origin: [
        'http://localhost:3000',
        'http://localhost:3009',
        'https://kali-v2.vercel.app',
        '*',
      ],
    };

    this.logger.log('Configuring SocketIO server with custom CORS options',{
      cors,
    });

    const optionsWithCORS: ServerOptions | any = {
      ...options,
      cors,
    };

    const jwtService = this.app.get(JwtService);
    const server: Server = super.createIOServer(port,optionsWithCORS);
    server.of('messages').use(createTokenMiddleware(jwtService,this.logger));
    return server;
  }
}

const createTokenMiddleware = (jwtService: JwtService,logger: Logger) => {
  return (socket: SocketWithAuth,next) => {
    // for Postman testing support, fallback to token header
    const token =
      socket.handshake.auth.token || socket.handshake.headers['token'];

    try {
      const payload = jwtService.decode(token) as SocketWithAuth;
      socket.userId = payload.userId;
      socket.username = payload.username;
      socket.email = payload.email;
      next();
    } catch {
      next(new Error('Invalid Token'));
    }
  };
};
