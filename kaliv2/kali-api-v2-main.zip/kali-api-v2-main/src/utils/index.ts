// create slug from name

import {StoreStatus,AlertStatus,Role,DocumentType} from '@prisma/client';

/**
 * Converts a string into a slug format.
 *
 * @param name - The string to be converted into a slug.
 * @returns The slug representation of the input string.
 */
export const slugify = (name: string) => {
  return name
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g,'')
    .replace(/[^a-zA-Z0-9]+/g,'-')
    .replace(/^-+|-+$/g,'')
    .toLowerCase();
};

/**
 * Converts a string representation of a StoreStatus to its corresponding enum value.
 *
 * @param status - The string representation of the StoreStatus.
 * @returns The enum value corresponding to the StoreStatus.
 */
export const stringToStoreStatus = (status: string): StoreStatus => {
  switch (status) {
    case 'HIGHT':
      return StoreStatus.HIGHT;
    case 'MEDIUM':
      return StoreStatus.MEDIUM;
    case 'LOW':
      return StoreStatus.LOW;
    default:
      return StoreStatus.LOW;
  }
};

/**
 * Converts a string representation of a role to its corresponding enum value.
 *
 * @param role - The string representation of the role.
 * @returns The enum value corresponding to the role.
 */
export const roleStringToEnum = (role: string) => {
  switch (role) {
    case 'SUPER_ADMIN':
      return Role.SUPER_ADMIN;
    case 'OPERATOR':
      return Role.OPERATOR;
    case 'USER':
      return Role.USER;
    default:
      return 'USER';
  }
};

/**
 * Converts a string representation of an AlertStatus to its corresponding human-readable value.
 *
 * @param status - The string representation of the AlertStatus.
 * @returns The human-readable value of the AlertStatus.
 */
export const stringToAlertStatus = (status: AlertStatus) => {
  switch (status) {
    case 'CREATED':
      return 'Creada';
    case 'UNDER_REVIEW':
      return 'En revisión';
    case 'SOLVED':
      return 'Resuelta';
    case 'FALSE_ALARM':
      return 'Falsa alarma';
    case 'REJECTED':
      return 'Rechazada';
    default:
      return 'PENDING';
  }
};


export const allDocumentTypes = [
  DocumentType.EMPLOYMENT_CONTRACT,
  DocumentType.CRIMINAL_RECORD_LETTER,
  DocumentType.MEDICAL_EXAMINATION,
  DocumentType.PSYCHOLOGICAL_FIT_CERTIFICATE,
  DocumentType.TRUST_EXAM,
  DocumentType.TOXICOLOGICAL_EXAM,
  DocumentType.COMMON_TRUNK_CERTIFICATE,
  DocumentType.CERTIFICATES_OF_SPECIALITIES,
  DocumentType.EC1099_PIPEM_INSPECTORS,
  DocumentType.EC1102_HBS_INSPECTORS,
  DocumentType.SAFETY_AND_HYGIENE_CERTIFICATE,
  DocumentType.TRAINING_FROM_THE_LOCAL_AIRPORT_SECURITY_PROGRAM,
  DocumentType.MRX_OPERATION_RECORD,
  DocumentType.DMP_OPERATION_RECORD,
  DocumentType.ETD_OPERATION_RECORD,
  DocumentType.CTX_OPERATION_RECORD,
  DocumentType.CCTV_OPERATION_RECORD,
  DocumentType.RECORD_SECURITY_SURVEILLANCE_PROPERTY_REAL_STATE,
  DocumentType.RECORD_IN_PERSONAL_DEFENSE,
  DocumentType.RECORD_PHYSICAL_CONDITION,
  DocumentType.RECORD_IN_DEALING_WITH_THE_PUBLIC,
  DocumentType.RECORD_FIRST_AID,
  DocumentType.RECORD_RADIO_COMMUNICATION,
  DocumentType.RECORD_PREPARING_REPORTS,
  DocumentType.CERTIFICATE_OF_STUDIES,
  DocumentType.CURP,
  DocumentType.BIRTH_CERTIFICATE,
  DocumentType.CUIP,
  DocumentType.OFFICIAL_IDENTIFICATION,
  DocumentType.PROOF_OF_ADDRESS,
  DocumentType.JOB_APPLICATION,
  DocumentType.IMSS_REGISTRATION,
];