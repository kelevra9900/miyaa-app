import {RekognitionClient} from '@aws-sdk/client-rekognition'

const config = {
	region: 'us-west-1',
	accessKeyId: process.env.AWS_ACCESS_KEY_ID,
	secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
}

const rekognitionClient = new RekognitionClient(config)


export default rekognitionClient