import { Module } from '@nestjs/common';
import { PassportModule } from '@nestjs/passport';
import { JwtService } from '@nestjs/jwt';

import { NotesService } from '../notes/notes.service';
import { AlertsService } from '../alerts/alerts.service';
import { PrismaService } from '../common/services/prisma.service';
import { UserService } from '../user/user.service';
import { AnalyticsController } from './analytics.controller';
import { AnalyticsService } from './analytics.service';
import { NotificationService } from '../notification/notification.service';
import { AuthService } from '../auth/auth.service';
import { MailSenderService } from '../mail-sender/mail-sender.service';

@Module({
  imports: [PassportModule.register({ defaultStrategy: 'jwt' })],
  providers: [
    AnalyticsService,
    NotificationService,
    PrismaService,
    UserService,
    AuthService,
    JwtService,
    MailSenderService,
    AlertsService,
    NotesService,
  ],
  exports: [AnalyticsService],
  controllers: [AnalyticsController],
})
export class AnalyticsModule {}
