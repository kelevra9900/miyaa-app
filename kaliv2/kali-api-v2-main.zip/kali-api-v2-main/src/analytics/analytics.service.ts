import { Injectable } from '@nestjs/common';
import { AlertsService } from '../alerts/alerts.service';
import { NotesService } from '../notes/notes.service';
import { UserService } from '../user/user.service';

@Injectable()
export class AnalyticsService {
  constructor(
    private readonly userService: UserService,
    private readonly alertService: AlertsService,
    private readonly noteService: NotesService,
  ) {}
  // Create a method that returns the number of users in the database
  getUsersCount(): Promise<number> {
    return this.userService.countUsers();
  }
  // Create a method that returns the number of alerts in the database
  getAlertsCount(): Promise<number> {
    return this.alertService.countAlerts();
  }

  // Create a method that returns the number of notes in the database
  getNotesCount(): Promise<number> {
    return this.noteService.countNotes();
  }

  // Get all data from the database in a single method
  async getAllData(): Promise<{
    usersCount: number;
    alertsCount: number;
    notesCount: number;
    alertsByYear: number;
  }> {
    const usersCount = await this.getUsersCount();
    const alertsCount = await this.getAlertsCount();
    const notesCount = await this.getNotesCount();
    const alertsByYear = await this.getAlertsByYear();
    return { usersCount, alertsCount, notesCount, alertsByYear };
  }

  // Alerts by year method
  async getAlertsByYear(): Promise<any> {
    const alerts = await this.alertService.getAlertsByYear();
    return alerts;
  }
}
