import {Module} from '@nestjs/common';
import {PassportModule} from '@nestjs/passport';
import {JwtModule,JwtService} from '@nestjs/jwt';

import config from '../config';
import {AuthService} from '../auth/auth.service';
import {PrismaService} from '../common/services/prisma.service';
import {SectorService} from './sector.service';
import {SectorController} from './sector.controller';
import {MailSenderService} from '../mail-sender/mail-sender.service';


@Module({
	imports: [
		JwtModule.register({
			secret: config.jwt.secretOrKey,
			signOptions: {
				expiresIn: config.jwt.expiresIn,
			},
		}),
		PassportModule.register({defaultStrategy: 'jwt'}),
	],
	providers: [
		SectorService,
		PrismaService,
		AuthService,
		MailSenderService,
		JwtService,
	],
	exports: [SectorService],
	controllers: [SectorController]
})
export class SectorModule { }
