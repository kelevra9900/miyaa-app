import {Injectable, InternalServerErrorException} from '@nestjs/common';
import {PrismaService} from '../common/services/prisma.service';
import { Sector } from '@prisma/client';
import { SectorPagination } from './models/sector.response';
import { CreateSectorRequest } from './models/request/create-sector-request.model';

@Injectable()
export class SectorService {
	constructor(private readonly prisma: PrismaService) { }

	async getSectors(
		page: number,
		limit: number,
		search?: string,
	  ): Promise<Sector[]> {
		const whereCondition: any = {};
	
		if (search) {
		  whereCondition.OR = [{ name: { contains: search } }];
		}
	
		return this.prisma.sector.findMany({
		  where: whereCondition,
		  skip: (page - 1) * limit,
		  take: limit,
		
		});
	  }


	  public async pagination(
		page = 1,
		limit = 10,
		search?: string,
	  ): Promise<SectorPagination> {
		const total = await this.getTotalSectorCount(search);
		const sectors = await this.getSectors(page, limit, search);
	
		const totalPages = Math.ceil(total / limit);
		const currentPage = page;
		const perPage = limit;
	
		return {
		  total,
		  totalPages,
		  currentPage,
		  perPage,
		  data: sectors,
		};
	  }


	async getTodayAttendances(shiftId?: string) {
		const today = new Date();
		today.setHours(0, 0, 0, 0);
		const tomorrow = new Date(today);
		tomorrow.setDate(today.getDate() + 1);
	  
		// Crear el objeto de condiciones de búsqueda
		const whereConditions: any = {
		  checkIn: {
			gte: today,
			lt: tomorrow,
		  },
		};
	  
		// Añadir la condición shiftId solo si está definida
		if (shiftId !== undefined) {
		  whereConditions.shiftId =  parseInt(shiftId);
		}
	  
		const attendances = await this.prisma.attendance.findMany({
		  where: whereConditions,
		  include: {
			user: true,
			sector: true,
			shift: true,
		  },
		});
	  
		console.log(attendances);
	  
		// Agrupar usuarios por sector
		const sectors = await this.prisma.sector.findMany({
		  include: {
			user: true,
		  },
		});
	  
		const sectorStats = sectors.map(sector => {
		  const sectorAttendances = attendances.filter(attendance => attendance.sectorId === sector.id);
		  const onSiteUsers = sectorAttendances.filter(attendance => attendance.status === 'ON_SITE').length;
		  return {
			sector: sector.name,
			totalUsers: sector.user.length,
			onSiteUsers: onSiteUsers,
			offSiteUsers: sector.user.length - onSiteUsers,
		  };
		});
	  
		return {
		  attendances,
		  sectorStats,
		};
	  }
	  


	async getTotalSectorCount(search?: string): Promise<number> {
		if (search) {
		  return this.prisma.sector.count({
			where: {
			  OR: [{ name: { contains: search } }],
			},
		  });
		}
		return this.prisma.sector.count();
	  }


	  async create(data: CreateSectorRequest): Promise<any> {
		try {
		  const sector = await this.prisma.sector.create({
			data: {
			  name: data.name,
			  createdAt: new Date(),		  
			},
		  });
	
		  if (!sector) {
			throw new InternalServerErrorException('Failed to create Sector');
		  }
	
		  return {
			success: true,
			message: 'sector created successfully',
			data: sector,
		  };
		} catch (error) {
		  console.error('Error creating Sector:', error);
		  throw new InternalServerErrorException('Failed to create Sector');
		}
	  }

	  public async updateSectorById(id: number, input: any) {
		try {
		  const sector = await this.prisma.sector.update({
			where: {
			  id: Number(id),
			},
			data: {
			  name: input.name,
			  updatedAt: new Date(),
			
			},
		  });
		  return {
			data: sector,
			success: true,
			message: 'sector created successfully',

		  };
		} catch (error) {
			console.error('Error updated Sector:', error);
			throw new InternalServerErrorException('Failed to update Sector');
		}
	  }


	  public async getSectorById(id: number) {
		try {
		  const sector = await this.prisma.sector.findUnique({
			where: {
			  id,
			},
		  });
		  return {
			data: sector,
			success: true,
			message: 'sector successfully',

		  };
		} catch (e) {
			console.error('Error updated Sector:', e);

		}
	  }
}
