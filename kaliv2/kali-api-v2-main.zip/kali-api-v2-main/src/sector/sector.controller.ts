import {
	Controller,
	Get,
	Post,
	HttpCode,
	HttpStatus,
	ParseIntPipe,
	Query,
	UseGuards,
	Body,
	Put,
	Param,
} from '@nestjs/common';
import {ApiBearerAuth,ApiResponse,ApiTags} from '@nestjs/swagger';
import {AuthGuard} from '@nestjs/passport';

import {SectorService} from './sector.service';
import { SectorPagination } from './models/sector.response';
import { CreateSectorRequest } from './models/request/create-sector-request.model';
import { Sector } from '@prisma/client';

@ApiTags('Sectors Management')
@Controller('sector')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'))
export class SectorController {
	constructor(private readonly sectorService: SectorService) { }

	@Get()
	@HttpCode(HttpStatus.OK)
	async getSectors(
		@Query('shiftId') shiftId?: string,
	) {
	//   console.log('getSectors');
	  return this.sectorService.getTodayAttendances(shiftId);
	}

	@Get('sector-list')
	@HttpCode(HttpStatus.OK)
	async getSectorsOnly(
		@Query('page', ParseIntPipe) page?: number,
		@Query('limit', ParseIntPipe) limit?: number,
		@Query('search') search?: string,
	): Promise<SectorPagination>{
		return this.sectorService.pagination(page, limit,search);
	}


	 @Post()
	 @ApiBearerAuth()
	 @UseGuards(AuthGuard())
	 public async createSector(@Body() data: CreateSectorRequest): Promise<Sector> {
	   return this.sectorService.create(data);
	 }

	 @Put(':id')
	 public async updateNoticeById(@Param('id') id: number, @Body() data: Sector) {
		return this.sectorService.updateSectorById(id, data);
	}

	@Get(':id')
	@HttpCode(HttpStatus.OK)
	@ApiResponse({ status: 403, description: 'Forbidden.' })
	public async getSectorById(@Param('id', ParseIntPipe) id: number) {
	  return this.sectorService.getSectorById(id);
	}
	
}