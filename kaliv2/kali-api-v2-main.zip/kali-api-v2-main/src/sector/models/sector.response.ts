


import { Sector, User } from '@prisma/client';

export class SectorResponse {
  id: number;
  name: string;

  createdAt: Date;
  updatedAt: Date;


  static fromShiftEntity(entity: Sector): SectorResponse {
    const response = new SectorResponse();
    response.id = entity.id;
    response.name = entity.name;
    response.createdAt = entity.createdAt;
    response.updatedAt = entity.updatedAt;
    return response;
  }
}


export type SectorPagination = {
    data: SectorResponse[];
    total: number;
    totalPages: number;
    currentPage: number;
    perPage: number;
  };