import { Transform } from 'class-transformer';
import { IsNotEmpty, IsString, Matches } from 'class-validator';

export class CreateSectorRequest {
  @IsNotEmpty()
  name: string;

  @IsNotEmpty()
  @IsString()
  createdAt: Date;

  @IsNotEmpty()
  @IsString()
  updateAt: Date;
}


