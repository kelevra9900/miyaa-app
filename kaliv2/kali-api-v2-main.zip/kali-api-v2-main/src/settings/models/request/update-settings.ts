import { CreateSettingsRequest } from './create-settings';

export class UpdateSettingsRequest extends CreateSettingsRequest {
  id: number;
}
