import {ApiProperty} from '@nestjs/swagger';
import {IsOptional,IsString,IsUrl} from 'class-validator';

export class CreateSettingsRequest {
  @ApiProperty({
    type: 'string',
    format: 'binary',
  })
  @IsString()
  @IsOptional()
  logo: string;

  @ApiProperty({
    type: 'string',
  })
  @IsString()
  @IsOptional()
  siteName: string;

  @ApiProperty({
    type: 'string',
  })
  @IsString()
  @IsOptional()
  siteSubtitle: string;

  @ApiProperty({
    type: 'string',
  })
  @IsString()
  @IsOptional()
  metaTitle: string;

  @ApiProperty({
    type: 'string',
  })
  @IsString()
  @IsOptional()
  metaDescription: string;

  @ApiProperty({
    type: 'string',
  })
  @IsString()
  @IsOptional()
  metaTags: string;

  @ApiProperty({
    type: 'string',
  })
  @IsString()
  @IsOptional()
  canonicalUrl: string;

  @ApiProperty({
    type: 'string',
  })
  @IsString()
  @IsOptional()
  ogTitle: string;

  @ApiProperty({
    type: 'string',
  })
  @IsString()
  @IsOptional()
  ogDescription: string;

  @ApiProperty({
    type: 'string',
  })
  @IsString()
  @IsOptional()
  ogImage: string;

  @ApiProperty({
    type: 'string',
  })
  @IsString()
  @IsOptional()
  ogUrl: string;

  @ApiProperty({
    type: 'string',
  })
  @IsString()
  @IsOptional()
  twitterHandle: string;

  @ApiProperty({
    type: 'string',
  })
  @IsString()
  @IsOptional()
  twitterCardType: string;

  @ApiProperty({
    type: 'string',
  })
  @IsString()
  @IsOptional()
  location: string;

  @ApiProperty({
    type: 'string',
  })
  @IsString()
  @IsOptional()
  contactNumber: string;

  @ApiProperty({
    type: 'string',
  })
  @IsOptional()
  @IsUrl()
  website: string;

  @ApiProperty({
    type: 'string',
  })
  @IsOptional()
  @IsUrl()
  facebookUrl: string;

  @ApiProperty({
    type: 'string',
  })
  @IsOptional()
  @IsUrl()
  twitterUrl: string;

  @ApiProperty({
    type: 'string',
  })
  @IsOptional()
  @IsUrl()
  instagramUrl: string;

  @ApiProperty({
    type: 'string',
  })
  @IsOptional()
  @IsUrl()
  linkedinUrl: string;

  @ApiProperty({
    type: 'string',
  })
  @IsOptional()
  @IsUrl()
  youtubeUrl: string;

  @ApiProperty({
    type: 'string',
  })
  @IsOptional()
  @IsUrl()
  tiktokUrl: string;


  @ApiProperty({
    type: 'string',
  })
  @IsOptional()
  @IsString()
  terms: string;
}
