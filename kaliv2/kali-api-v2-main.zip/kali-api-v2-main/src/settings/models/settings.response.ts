import { Settings } from '@prisma/client';

export class SettingsResponse {
  id: number;
  logo: string;
  siteName: string;
  siteSubtitle: string;
  currency: string;
  metaTitle: string;
  metaDescription: string;
  metaTags: string;
  canonicalUrl: string;
  ogTitle: string;
  ogDescription: string;
  ogImage: string;
  ogUrl: string;
  twitterHandle: string;
  twitterCardType: string;

  location: string;
  contactNumber: string;
  website: string;

  facebookUrl: string;
  twitterUrl: string;
  instagramUrl: string;
  youtubeUrl: string;
  linkedinUrl: string;
  tiktokUrl: string;

  static fromSettings(settings: Settings): SettingsResponse {
    const response = new SettingsResponse();
    response.id = settings.id;
    response.logo = settings.logo || '';
    response.siteName = settings.siteName || '';
    response.siteSubtitle = settings.siteSubtitle || '';
    response.metaTitle = settings.metaTitle || '';
    response.metaDescription = settings.metaDescription || '';
    response.metaTags = settings.metaTags || '';
    response.canonicalUrl = settings.canonicalUrl || '';
    response.ogTitle = settings.ogTitle || '';
    response.ogDescription = settings.ogDescription || '';
    response.ogImage = settings.ogImage || '';
    response.ogUrl = settings.ogUrl || '';
    response.twitterHandle = settings.twitterHandle || '';
    response.twitterCardType = settings.twitterCardType || '';

    response.location = settings.location || '';
    response.contactNumber = settings.contactNumber || '';
    response.website = settings.website || '';

    response.facebookUrl = settings.facebookUrl || '';
    response.twitterUrl = settings.twitterUrl || '';
    response.instagramUrl = settings.instagramUrl || '';
    response.youtubeUrl = settings.youtubeUrl || '';
    response.linkedinUrl = settings.linkedinUrl || '';
    response.tiktokUrl = settings.tiktokUrl || '';

    return response;
  }
}
