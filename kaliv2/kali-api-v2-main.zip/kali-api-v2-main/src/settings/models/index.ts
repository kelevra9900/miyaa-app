import { Settings } from '@prisma/client';

export { CreateSettingsRequest } from './request/create-settings';
export { UpdateSettingsRequest } from './request/update-settings';
export { SettingsResponse } from './settings.response';

export type { Settings } from '@prisma/client';

export type SettingsTypeResponse = {
  data?: Settings | null;
  message: string;
};
