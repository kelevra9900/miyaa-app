import {Injectable} from '@nestjs/common';
import {PrismaService} from '../common/services/prisma.service';
import {CreateSettingsRequest,Settings,SettingsTypeResponse} from './models';
import {UpdateSettingsRequest} from './models/request/update-settings';

@Injectable()
export class SettingsService {
  constructor(private readonly prisma: PrismaService) { }

  /**
   * Creates a new settings entry.
   *
   * @param data - The data for the new settings entry.
   * @returns A promise that resolves to the created settings entry.
   */
  public async create(data: CreateSettingsRequest) {

    return this.prisma.settings.create({
      data,
    });
  }

  /**
   * Retrieves the settings.
   *
   * @returns A promise that resolves to the settings response.
   *          The response contains the settings data and a message indicating the success or failure of the retrieval.
   */
  public async get(): Promise<SettingsTypeResponse> {
    try {
      const settings = await this.prisma.settings.findMany({
        take: 1,
      });

      return {
        data: settings.length ? settings[0] : null,
        message: 'Settings retrieved successfully',
      };
    } catch (e) {
      return {
        data: null,
        message: 'Settings not found',
      };
    }
  }

  /**
   * Updates a settings entry.
   *
   * @param id - The ID of the settings entry to update.
   * @param data - The updated data for the settings entry.
   * @returns A promise that resolves to the updated settings entry.
   */
  public async update(id: number,{...data}: UpdateSettingsRequest): Promise<Settings> {
    return this.prisma.settings.update({
      where: {
        id: Number(id),
      },
      data,
    });
  }
  /**
   * Deletes all settings entries.
   *
   * @returns A promise that resolves to the number of deleted settings entries.
   */
  public async delete() {
    return this.prisma.settings.deleteMany();
  }
}
