import {
  Body,
  Controller,
  Get,
  Param,
  Post,
  Put,
  UseGuards,
  ParseIntPipe,
} from '@nestjs/common';
import {AuthGuard} from '@nestjs/passport';
import {ApiBearerAuth,ApiTags} from '@nestjs/swagger';
import {CreateSettingsRequest,Settings,SettingsTypeResponse} from './models';
import {UpdateSettingsRequest} from './models/request/update-settings';
import {SettingsService} from './settings.service';

@ApiTags('Settings')
@Controller('settings')
export class SettingsController {
  constructor(private readonly settingsService: SettingsService) { }

  /**
   * Retrieves the settings.
   *
   * @returns {Promise<SettingsTypeResponse>} The settings response.
   */
  @Get()
  public async getSettings(): Promise<SettingsTypeResponse> {
    return this.settingsService.get();
  }

  /**
   * Updates the settings.
   *
   * @param {number} id - The ID of the settings to update.
   * @param {UpdateSettingsRequest} data - The updated settings data.
   * @returns {Promise<any>} The updated settings.
   */
  @Put(':id')
  @ApiBearerAuth()
  @UseGuards(AuthGuard())
  public async updateSettings(
    @Param('id',ParseIntPipe) id: number,
    @Body() data: UpdateSettingsRequest,
  ): Promise<Settings> {
    return this.settingsService.update(id,data);
  }

  /**
   * Creates new settings.
   *
   * @param {CreateSettingsRequest} data - The data for creating the settings.
   * @returns {Promise<any>} The created settings.
   */
  @Post()
  @ApiBearerAuth()
  @UseGuards(AuthGuard())
  public async createSettings(@Body() data: CreateSettingsRequest): Promise<any> {
    return this.settingsService.create(data);
  }
}
