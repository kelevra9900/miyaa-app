import {
  Body,
  Controller,
  Get,
  HttpCode,
  HttpStatus,
  Post,
  Put,
  Query,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';

import {
  CreateAttendanceReq,
  UpdateAttendanceRequest,
  AttendanceResponse,
} from './models';
import { AttendanceService } from './attendance.service';
import { Usr } from '../user/user.decorator';
import { AuthUser } from '../auth/auth-user';
import { FileInterceptor } from '@nestjs/platform-express';

@ApiTags('Attendances')
@ApiBearerAuth()
@UseGuards(AuthGuard())
@Controller('attendances')
export class AttendanceController {
  constructor(private readonly attendanceService: AttendanceService) {}

  /**
   * Retrieves a paginated list of attendance records.
   *
   * @param page The page number to retrieve (optional, default: 1).
   * @param limit The maximum number of records per page (optional, default: 15).
   * @param search The search query to filter records (optional).
   * @returns A paginated list of attendance records.
   */
  @Get()
  @HttpCode(HttpStatus.OK)
  async get(
    @Query('page') page?: number,
    @Query('limit') limit?: number,
    @Query('search') search?: string,
    @Query('status') status?: string,
  ) {
    return this.attendanceService.paginate({
      page: page || 1,
      limit: limit || 15,
      search,
      status
    });
  }

  /**
   * Creates a new attendance record.
   *
   * @param data The data for creating the attendance record.
   * @param file The uploaded file (optional).
   * @param user The authenticated user.
   * @returns The created attendance record.
   */
  @Post()
  @HttpCode(HttpStatus.CREATED)
  @UseInterceptors(FileInterceptor('file'))
  async create(
    @Body() data: CreateAttendanceReq,
    @UploadedFile() file: Express.Multer.File,
    @Usr() user: AuthUser,
  ): Promise<AttendanceResponse | null> {
    return this.attendanceService.create(data, user.id, file);
  }

  /**
   * Updates the checkout status of an attendance record.
   *
   * @param data The data for updating the attendance record.
   * @param user The authenticated user.
   * @returns The updated attendance record.
   */
  @Put('checkout')
  @HttpCode(HttpStatus.OK)
  async checkOut(@Body() data: UpdateAttendanceRequest, @Usr() user: AuthUser) {
    return this.attendanceService.checkOut(data, user.id);
  }
}
