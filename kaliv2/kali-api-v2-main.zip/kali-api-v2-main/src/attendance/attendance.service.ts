import { ConflictException, Injectable, Logger } from '@nestjs/common';
import { AttendanceStatus } from '@prisma/client';

import { PrismaService } from '../common/services/prisma.service';
import { CreateAttendanceReq } from './models';
import { AttendanceResponse, UpdateAttendanceRequest } from './models';
import { AuthService } from 'src/auth/auth.service';

@Injectable()
export class AttendanceService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly authService: AuthService,
  ) {}

  /**
   * Paginates the attendance records.
   *
   * @param page - The page number.
   * @param limit - The number of records per page.
   * @param search - The search query to filter the records.
   * @returns An object containing the paginated attendance records.
   *          - data: An array of attendance records.
   *          - total: The total number of attendance records.
   *          - totalPages: The total number of pages.
   *          - currentPage: The current page number.
   *          - perPage: The number of records per page.
   */
  public async paginate({ page, limit, search, status }) {
    const skip = page ? (page - 1) * limit : 0;
    const take = limit ? limit : 15;

    let attendances = [] as any;
    if (search || status) {
      attendances = await this.prisma.attendance.findMany({
        skip: Number(skip),
        take: Number(take),
        orderBy: {
          createdAt: 'desc',
        },
        where: {
          ...(status && { status: status } ), 
          ...(search && {
            OR: [
              {
                user: {
                  firstName: {
                    contains: search,
                    mode: 'insensitive',
                  },
                },
              },
            ]
          })
         
        },
        include: {
          user: true,
        },
      });
    } else {
      attendances = await this.prisma.attendance.findMany({
        skip: Number(skip),
        take: Number(take),
        orderBy: {
          createdAt: 'desc',
        },
        include: {
          user: true,
        },
      });
    }

    const count = await this.prisma.alert.count();
    const totalPages = Math.ceil(count / limit);
    const currentPage = page ? page : 1;
    const perPage = limit ? limit : 10;
    return {
      data: attendances,
      total: count,
      totalPages: Number(totalPages),
      currentPage: Number(currentPage),
      perPage: Number(perPage),
    };
  }

  /**
   * Creates a new attendance record.
   *
   * @param data - The attendance data.
   * @param userId - The ID of the user associated with the attendance.
   * @param file - The file containing the face recognition data.
   * @returns The created attendance record.
   * @throws ConflictException if there is an error creating the attendance.
   */
  public async create(
    data: CreateAttendanceReq,
    userId: number,
    file: Express.Multer.File,
  ) {
    try {
      const faceRecognitionResponse = await this.authService.faceUpload(file);

      if (!faceRecognitionResponse) {
        return null;
      }
      const newAttendance = await this.prisma.attendance.create({
        data: {
          ...data,
          status: AttendanceStatus.ON_SITE,
          createdAt: new Date(),
          user: {
            connect: {
              id: userId,
            },
          },
        },
      });
      return AttendanceResponse.fromAttendanceEntity(newAttendance);
    } catch (e) {
      Logger.error('Error creating attendance', e, 'UserService');
      throw new ConflictException();
    }
  }

  /**
   * Updates the attendance record with the check-out time and status.
   *
   * @param data - The updated attendance data.
   * @param userId - The ID of the user associated with the attendance.
   * @returns The updated attendance record.
   * @throws ConflictException if there is an error updating the attendance.
   */
  public async checkOut(
    data: UpdateAttendanceRequest,
    userId: number,
  ): Promise<AttendanceResponse | { message: string }> {
    try {
      const exist = await this.prisma.attendance.findFirst({
        where: {
          userId,
          checkIn: {
            gte: new Date(new Date().setHours(0, 0, 0, 0)),
          },
        },
      });

      if (!exist) {
        return {
          message: 'Attendance not found for this user',
        };
      }
      const updated = await this.prisma.attendance.update({
        where: { id: exist.id },
        data: {
          status: data.status as AttendanceStatus,
        },
      });
      return AttendanceResponse.fromAttendanceEntity(updated);
    } catch (e) {
      Logger.error(
        'Erro update attendance with checkout method',
        e,
        'AttendanceService',
      );
      throw new ConflictException();
    }
  }

  /**
   * Updates the attendance record with the check-out time and status.
   *
   * @param data - The updated attendance data.
   * @returns The updated attendance record.
   * @throws ConflictException if there is an error updating the attendance.
   */
  public async updateAttendance(data: UpdateAttendanceRequest) {
    try {
      const updateData = await this.prisma.attendance.update({
        where: { id: data.id },
        data: {
          ...data,
          status: data.status as AttendanceStatus,
        },
      });
    } catch (e) {
      Logger.error(
        'Erro update attendance with checkout method',
        e,
        'AttendanceService',
      );
      throw new ConflictException();
    }
  }
}
