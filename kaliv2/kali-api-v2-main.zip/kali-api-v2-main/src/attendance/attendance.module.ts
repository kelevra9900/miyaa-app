import { Module } from '@nestjs/common';
import { PassportModule } from '@nestjs/passport';
import { JwtService } from '@nestjs/jwt';

import { AttendanceService } from './attendance.service';
import { PrismaService } from '../common/services/prisma.service';
import { AttendanceController } from './attendance.controller';
import { AuthService } from '../auth/auth.service';
import { MailSenderService } from '../mail-sender/mail-sender.service';

@Module({
  imports: [PassportModule.register({ defaultStrategy: 'jwt' })],
  controllers: [AttendanceController],
  providers: [
    AttendanceService,
    PrismaService,
    AuthService,
    JwtService,
    MailSenderService,
  ],
  exports: [AttendanceService],
})
export class AttendanceModule {}
