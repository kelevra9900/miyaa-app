import type {Attendance} from '@prisma/client';

export class AttendanceResponse {
  id: number;
  checkIn: Date;
  checkOut: Date | null;
  latitude: number;
  longitude: number;

  static fromAttendanceEntity(attendance: Attendance): AttendanceResponse {
    const response = new AttendanceResponse();
    response.id = attendance.id;
    response.checkIn = attendance.checkIn;
    response.checkOut = attendance.checkOut;
    response.latitude = attendance.latitude ?? 0.1222;
    response.longitude = attendance.longitude ?? 0.23323;

    return response;
  }
}
