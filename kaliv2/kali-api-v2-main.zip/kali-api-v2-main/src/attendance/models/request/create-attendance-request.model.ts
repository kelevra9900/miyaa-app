import { ApiProperty } from '@nestjs/swagger';
import { AttendanceStatus } from '@prisma/client';
import { IsDateString, IsEnum, IsOptional } from 'class-validator';

export class CreateAttendanceReq {
  @ApiProperty()
  @IsDateString()
  checkIn: string;

  @ApiProperty()
  @IsDateString()
  @IsOptional()
  checkOut: string;

  @ApiProperty()
  @IsOptional()
  @IsEnum(AttendanceStatus)
  status: string;
}
