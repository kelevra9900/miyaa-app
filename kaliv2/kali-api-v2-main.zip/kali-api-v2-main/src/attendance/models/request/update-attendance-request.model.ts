import { AttendanceStatus } from '@prisma/client';
import { IsEnum, IsNotEmpty, IsString, Matches } from 'class-validator';

export class UpdateAttendanceRequest {
  @IsNotEmpty()
  @Matches(RegExp('^[0-9]+$'))
  id: number;

  @IsString()
  @IsEnum(AttendanceStatus)
  status: string;
}
