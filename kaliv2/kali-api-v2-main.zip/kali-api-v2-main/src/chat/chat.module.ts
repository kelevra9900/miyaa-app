import {Module} from '@nestjs/common';
import {PassportModule} from '@nestjs/passport';
import {ChatController} from './chat.controller';
import {ChatService} from './chat.service';
import {PrismaService} from '../common/services/prisma.service';
import {ChatGateway} from './chat.gateway';
import {MailSenderService} from 'src/mail-sender/mail-sender.service';
import {JwtService} from '@nestjs/jwt';
import {AuthService} from 'src/auth/auth.service';

@Module({
  imports: [PassportModule.register({defaultStrategy: 'jwt'})],
  controllers: [ChatController],
  providers: [
    ChatService,
    PrismaService,
    ChatGateway,
    AuthService,
    JwtService,
    MailSenderService,
  ],
  exports: [ChatService],
})
export class ChatModule { }
