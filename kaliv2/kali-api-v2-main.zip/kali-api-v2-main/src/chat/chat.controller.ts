import {
  Controller,
  Get,
  Param,
  Post,
  Body,
  UseGuards,
  HttpCode,
  HttpStatus,
  Query,
} from '@nestjs/common';
import {AuthGuard} from '@nestjs/passport';
import {ChatService} from './chat.service';
import {CreateMessageInput,CreateMessageInputApp} from './models/chat.dto';
import {ApiBearerAuth,ApiTags} from '@nestjs/swagger';
import {Usr} from 'src/user/user.decorator';
import {AuthUser} from 'src/auth/auth-user';

@ApiTags('Chat')
@ApiBearerAuth()
@UseGuards(AuthGuard())
@Controller('chat')
export class ChatController {
  constructor(private readonly chatService: ChatService) { }

  /**
   * Retrieves a conversation by its ID.
   *
   * @param id - The ID of the conversation.
   * @param page - The page number for pagination (optional, default: 1).
   * @param limit - The maximum number of items per page (optional, default: 15).
   * @param search - The search query for filtering conversations (optional).
   * @param orderBy - The field to order conversations by (optional).
   * @returns The conversation with the specified ID.
   */
  @Get('conversations/:id')
  @HttpCode(HttpStatus.OK)
  getConversationById(
    @Param('id') id: number,
    @Query('page') page?: number,
    @Query('limit') limit?: number,
    @Query('search') search?: string,
    @Query('orderBy') orderBy?: string,
  ) {
    // return this.chatService.getConversationById({
    //   id,
    //   search,
    //   orderBy,
    //   page: page || 1,
    //   limit: limit || 15,
    // });
  }

  /**
   * Creates a new conversation between the authenticated user and the specified recipient.
   *
   * @param user - The authenticated user object.
   * @param recipientId - The ID of the recipient user.
   * @returns The created conversation object.
   */
  @Post('conversations')
  @HttpCode(HttpStatus.CREATED)
  createConversation(
    @Usr() user: AuthUser,
    @Body() {recipientId}: {recipientId: number},
  ) {
    const senderId = user.id;
    const body = {
      recipientId,
      senderId: senderId,
    };
    // return this.chatService.createConversation(body);
  }

  /**
   * Creates a new message in the conversation.
   *
   * @param createMessageDto - The data for creating the message.
   * @param user - The authenticated user object.
   * @returns The created message object.
   */
  @Post('message')
  @HttpCode(HttpStatus.CREATED)
  createMessage(
    @Body() createMessageDto: CreateMessageInput,
    @Usr() user: AuthUser,
  ) {
    const {id: senderId} = user;
    // return this.chatService.createMessage(createMessageDto,senderId);
  }
  /**
   * Marks a message as seen by a user.
   *
   * @param messageId - The ID of the message to be marked as seen.
   * @param userId - The ID of the user who has seen the message.
   * @returns The updated message object.
   */
  @Post('message/seen')
  @HttpCode(HttpStatus.OK)
  seenMessage(
    @Body() {messageId,userId}: {messageId: number; userId: number},
  ) {
    return ''
  }

  /**
   * Retrieves conversations for a specific user.
   *
   * @param user - The authenticated user object.
   * @returns An array of conversations for the specified user.
   */
  @Get('conversations')
  @HttpCode(HttpStatus.OK)
  getConversationsByUserId(@Usr() user: AuthUser) {
    const userId = user.id;
    return ''
  }
  /**
   * Retrieves messages for a specific user.
   *
   * @param user - The authenticated user object.
   * @returns A promise that resolves to an array of messages for the specified user.
   */
  // @Get('my-conversations')
  // @HttpCode(HttpStatus.OK)
  // getMessagesByUserId(@Usr() user: AuthUser): Promise<any> {
  //   const userId = user.id;
  //   return ''
  // }

  /**
   * Sends a message from the authenticated user to a recipient.
   *
   * @param content - The content of the message.
   * @param user - The authenticated user object.
   * @returns The created message object.
   */
  // @Post('send-message')
  // @HttpCode(HttpStatus.CREATED)
  // sendMessage(
  //   @Body() {content}: CreateMessageInputApp,
  //   @Usr() user: AuthUser,
  // ) {
  //   const {id: senderId} = user;
  //   return this.chatService.sendMessage(content,senderId);
  // }
}
