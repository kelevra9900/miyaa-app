import { ApiProperty } from '@nestjs/swagger';
import { UserResponse } from '../../user/models';
import { IsString } from 'class-validator';
import { Transform } from 'class-transformer';

export class CreateMessageDto {
  content: string;
  senderId: number;
  recipientId: number;
  conversationId: number;
  media: string
}

export class MessageDto {
  id: number;
  content: string;
  sender: UserResponse;
  recipient: UserResponse;
  createdAt: Date;
}

export class ConversationDto {
  id: number;
  participants: UserResponse[];
  messages: MessageDto[];
}

export interface MessageResponse {
  id: number;
  content: string;
  isRead: boolean;
  isMedia: boolean;
  media: null;
  senderId: number;
  recipientId: number;
  createdAt: Date;
  conversationId: number;
  sender: Recipient;
  recipient: Recipient;
}

export interface Recipient {
  id: number;
  username: string;
  email: string;
  passwordHash: string;
  firstName: string;
  lastName: string;
  middleName: null;
  image: null;
  emailVerified: boolean;
  birthDate: null;
  registrationDate: Date;
  lastSeen: Date;
  role: string;
  banned: boolean;
  online: boolean;
  oneSignalId: null;
  environmentId: null;
}

export interface PaginationMessages {
  messages: MessageResponse[];
  total: number;
  totalPages: number;
  currentPage: number;
  perPage: number;
}

export class CreateMessageInput {
  @ApiProperty({
    type: 'string',
  })
  @IsString()
  content: string;

  @IsString()
  media: string;

  @ApiProperty({
    type: 'number',
    description: 'The recipient id',
  })
  @IsString()
  @Transform(({ value }) => parseInt(value))
  recipientId?: number;

  @ApiProperty({
    type: 'number',
  })
  @IsString()
  @Transform(({ value }) => parseInt(value))
  conversationId?: number;
}

export class CreateMessageInputApp {
  @ApiProperty({
    type: 'string',
  })
  @IsString()
  content: string;
}
