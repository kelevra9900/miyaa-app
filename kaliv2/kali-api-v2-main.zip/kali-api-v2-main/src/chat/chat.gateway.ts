import {Logger} from '@nestjs/common';
import {
  ConnectedSocket,
  MessageBody,
  OnGatewayConnection,
  OnGatewayDisconnect,
  SubscribeMessage,
  WebSocketGateway,
  WebSocketServer,
} from '@nestjs/websockets';
import {Namespace,Socket} from 'socket.io';
import {JobPosition,Role,TypeMessage} from '@prisma/client';

import {AuthService} from '../auth/auth.service';
import {ChatService} from './chat.service';

@WebSocketGateway({
  cors: true,
})
export class ChatGateway implements OnGatewayConnection,OnGatewayDisconnect {
  @WebSocketServer() io: Namespace;
  private readonly logger = new Logger('ChatGateway');

  constructor(
    private readonly authService: AuthService,
    private readonly chatService: ChatService,
  ) { }

  async handleConnection() {
    this.logger.log('Client connected');
  }

  async handleDisconnect() {
    this.logger.log('Client disconnected');
  }

  afterInit() {
    this.logger.log('=======================');
    this.logger.log('Initialized Message Gateway');
    this.logger.log('=======================');
  }

  // disconnect event to change status to false
  @SubscribeMessage('user-disconnected')
  async handleDisconnectEvent(
    @ConnectedSocket() client: Socket,
  ): Promise<void> {
    this.logger.log('Disconnect event received');
    const token = client.handshake.auth.token as string;
    if (!token) {
      return;
    }
    const user = await this.authService.validateToken(token,true);
    if (!user || !user.userId) {
      return;
    }

    this.logger.log(`User disconnected: ${user.email}`);

    await this.chatService.updateUserOnlineStatus(user.userId,false);

    this.io.emit('userOffline',{
      id: user.userId,
      email: user.email,
    });
  }

  // User connected, set online status to true
  @SubscribeMessage('user-connected')
  async handleConnect(@ConnectedSocket() client: Socket): Promise<void> {
    this.logger.log('Connect event received User-connected');
    const token = client.handshake.auth.token as string;
    if (!token) {
      return;
    }
    const user = await this.authService.validateToken(token,true);
    if (!user || !user.userId) {
      return;
    }

    this.logger.log(`User connected: ${user.email}`);

    await this.chatService.updateUserOnlineStatus(user.userId,true);

    // join the user to their own room
    client.join(`user/${user.userId}`);

    this.io.emit('userOnline',{
      id: user.userId,
      email: user.email,
    });
  }

  @SubscribeMessage('chat')
  async handleChat(@ConnectedSocket() client: Socket): Promise<void> {
    const token =
      client.handshake.auth.token || (client.handshake.headers.auth as string);
    if (!token) {
      return;
    }

    const user = await this.authService.validateToken(token,true);
    if (!user || !user.userId) {
      return;
    }
    const conversations = await this.chatService.getMyConversations(
      user.userId,
    );

    this.logger.debug(`FETCHING DATA FOR THIS USER =====> ${conversations}`)
    client.emit('chat',conversations);
  }

  @SubscribeMessage('users')
  async handleUsers(@ConnectedSocket() client: Socket): Promise<void> {
    this.logger.log('Users event received');
    const token = client.handshake.auth.token as string;
    if (!token) {
      return;
    }

    const user = await this.authService.validateToken(token,true);
    if (!user || !user.userId) {
      return;
    }

    const users = await this.chatService.getAllUsers(user.userId);
    client.emit('users',users);
  }

  @SubscribeMessage('conversation')
  async handleConversation(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: {id: number},
  ): Promise<void> {
    const token =
      client.handshake.auth.token || (client.handshake.headers.auth as string);

    this.logger.debug(`Conversation event received ${JSON.stringify(data)}`);
    if (!token) {
      client.emit('error','Authorization token is required');
      return;
    }

    try {
      const user = await this.authService.validateToken(token,true);
      if (!user || !user.userId) {
        client.emit('error','Invalid or expired token');
        return;
      }

      const conversation = await this.chatService.getConversationMessages(
        data.id,
      );

      client.emit(`conversation/${data.id}`,conversation);

      // Emit only of the user is part of the conversation
      client.join(`conversation/${data.id}`);

      const conversations = await this.chatService.getMyConversations(
        user.userId,
      );

      client.emit('chat',conversations);
    } catch (e) {
      this.logger.error(`Error handling conversation: ${e.message}`);
      client.emit('error','An error occurred while fetching the conversation');
    }
  }

  @SubscribeMessage('chatHistory')
  async chatHistory(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: {id: number},
  ) {
    const token =
      client.handshake.auth.token || (client.handshake.headers.auth as string);
    if (!token) {
      return;
    }

    const user = await this.authService.validateToken(token,true);
    if (!user || !user.userId) {
      return;
    }

    const conversation = await this.chatService.getConversationByParticipants(
      user.userId,
      data.id,
    );

    if (!conversation) {
      return;
    }

    // Emit only of the user is part of the conversation, this is to prevent unauthorized access
    client.join(`conversation/${conversation.id}`);

    // Fetch the conversation messages
    const messages = await this.chatService.getConversationMessages(
      conversation.id,
    );

    client.emit('chatHistory',messages);
  }

  //#region

  @SubscribeMessage('chatAdmin')
  async handleChatAdmin(@ConnectedSocket() client: Socket): Promise<void> {

    const token =
      client.handshake.auth.token || (client.handshake.headers.auth as string);
    if (!token) {
      return;
    }

    const user = await this.authService.validateToken(token,true);
    if (!user || !user.userId) {
      return;
    }
    const conversations = await this.chatService.getMyConversationsAdmin(
      user.userId,
    );
    this.io.emit('chatAdmin',conversations);
  }

  @SubscribeMessage('createChatAdmin')
  async createChatRoomAdmin(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: {participant: number},
  ): Promise<void> {
    this.logger.log('Create chat room event received');
    const token =
      client.handshake.auth.token || (client.handshake.headers.auth as string);
    if (!token) {
      return;
    }

    console.log(token);
    const user = await this.authService.validateToken(token,true);

    this.logger.log(
      `Creating chat room for user ${user.userId} and participant ${data.participant}`,
    );

    const conversation = await this.chatService.createChat(
      user.userId,
      data.participant,
    );

    let input = {
      conversationId: Number(conversation.id),
      userId: user.userId,
      message: "Bienvenido Usuario",
      type: TypeMessage.TEXT,
      seen: true
    }

    const message = await this.chatService.sendMessageToConversationSend(input.conversationId,input.userId,input.message,input.type,input.seen);

    this.io.emit('createChat',conversation);
    this.io.socketsJoin(`conversation/${conversation.id}`);
    this.io.emit(
      'chatAdmin',
      await this.chatService.getMyConversations(user.userId),
    );
  }


  @SubscribeMessage('createChatGroupAdmin')
  async createChatRoomGroupAdmin(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: {participants: number},
  ): Promise<void> {
    this.logger.log('Create chat room event received');
    const token =
      client.handshake.auth.token || (client.handshake.headers.auth as string);
    if (!token) {
      return;
    }
    const user = await this.authService.validateToken(token,true);

    this.logger.log(
      `Creating chat room for user ${user.userId} and participant`,
    );

    //@ts-ignore
    const conversation = await this.chatService.createChatGroup(data.participants);


    let input = {
      conversationId: Number(conversation.id),
      userId: user.userId,
      message: "Bienvenido Usuario",
      type: TypeMessage.TEXT,
      seen: true
    }

    const message = await this.chatService.sendMessageToConversationSend(input.conversationId,input.userId,input.message,input.type,input.seen);

    client.emit('createChatAdmin',conversation);
    client.join(`conversation/${conversation.id}`);
    client.emit(
      'chatAdmin',
      await this.chatService.getMyConversations(user.userId),
    );

  }


  //#endregion


  @SubscribeMessage('sendMessageAdmin')
  async sendMessageAdmin(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: {conversationId: string,message: string,type: string,seen: boolean}
  ): Promise<void> {

    this.logger.log(`Send message event received ${JSON.stringify(data)}`);

    const token = client.handshake.auth.token || client.handshake.headers.auth as string;
    if (!token) {
      return;
    }

    const user = await this.authService.validateToken(token,true);
    if (!user || !user.userId) {
      return;
    }

    let input = {
      conversationId: Number(data.conversationId),
      userId: user.userId,
      message: data.message,
      type: data.type,
      seen: data.seen
    }

    const message = await this.chatService.sendMessageToConversationSend(input.conversationId,input.userId,input.message,input.type,input.seen);
    client.emit('sendMessageAdmin',message);
    client.to(`conversation/${data.conversationId}`).emit('newMessage',message);
  }


  @SubscribeMessage('createChatAdminApi')
  async createChatRoomAdminNew(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: {participant: number},
  ): Promise<void> {
    this.logger.log('Create chat room event received');
    const token =
      client.handshake.auth.token || (client.handshake.headers.auth as string);
    if (!token) {
      return;
    }
    const user = await this.authService.validateToken(token,true);

    this.logger.log(
      `Creating chat room for user ${user.userId} and participant ${data.participant}`,
    );

    const conversation = await this.chatService.createChat(
      user.userId,
      data.participant,
    );

    const conversations = await this.chatService.getMyConversationsAdmin(user.userId);

    client.emit(
      'chatAdminClient',conversations);
  }


  @SubscribeMessage('chatAdminApi')
  async handleChatAdminNew(@ConnectedSocket() client: Socket): Promise<void> {
    const token =
      client.handshake.auth.token || (client.handshake.headers.auth as string);
    if (!token) {
      return;
    }

    const user = await this.authService.validateToken(token,true);
    if (!user || !user.userId) {
      return;
    }
    const conversations = await this.chatService.getMyConversationsAdmin(
      user.userId,
    );
    client.emit('chatAdminClient',conversations);
  }


  //#endregion

  // Create new chat room WITH jobPosition enum string
  @SubscribeMessage('createChatByJobPosition')
  async createChat(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: {jobPosition: JobPosition},
  ): Promise<void> {
    const token =
      client.handshake.auth.token || (client.handshake.headers.auth as string);
    if (!token) {
      return;
    }
    const user = await this.authService.validateToken(token,true);
    if (!user || !user.userId || user.role !== Role.SUPER_ADMIN) {
      return;
    }

    // const conversation = await this.chatService.createChat(data.jobPosition);

    // this.io.emit('createChat',conversation);
  }

  // User fetch if they are in a conversation or not, if not create one (remember, the user only has one conversation)

  @SubscribeMessage('sendMessage')
  async sendMessage(
    @ConnectedSocket() client: Socket,
    @MessageBody()
    data: {
      userId: number; // ID del receptor del mensaje
      message: string;
      type?: string;
      seen?: boolean;
    },
  ): Promise<void> {
    const token =
      client.handshake.auth.token || (client.handshake.headers.auth as string);


    if (!token) {
      return;
    }

    const user = await this.authService.validateToken(token,true);
    if (!user || !user.userId) {
      return;
    }


    const conversation = await this.chatService.sendMessage(data.userId,user.userId,data.message);

    if (!conversation) {
      return;
    }

    const isAdmin = await this.chatService.hasAdminInConversation(Number(conversation.id));
    if (isAdmin) {
      client.emit('newMessageClientAdmin')
    }

    this.io.emit('sendMessage',conversation);
    client.emit('newMessage',conversation);
    client.to(`conversation/${conversation.id}`).emit('newMessage',conversation);
  }


  @SubscribeMessage('selectRoom')
  async joinRoom(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: {participant: string},
  ) {
    const token =
      client.handshake.auth.token || (client.handshake.headers.auth as string);
    if (!token) {
      return;
    }

    this.logger.log(`Select room event received ${JSON.stringify(data)}`);
    const user = await this.authService.validateToken(token,true);



    const conversation = await this.chatService.createChatOneToOne(
      user.userId,
      Number(data.participant),
    );

    this.logger.log(`User ${user.userId} joined conversation ${conversation.id}`);

    client.join(`conversation/${conversation.id}`);
    this.io.emit('chat',await this.chatService.getMyConversations(user.userId));
  };

  @SubscribeMessage('joinConversation')
  async joinConversation(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: {conversationId: string},
  ): Promise<void> {
    const token =
      client.handshake.auth.token || (client.handshake.headers.auth as string);
    if (!token) {
      return;
    }

    const user = await this.authService.validateToken(token,true);
    if (!user || !user.userId) {
      return;
    }

    client.join(`conversation/${data.conversationId}`);
    this.logger.log(
      `User ${user.userId} joined conversation ${data.conversationId}`,
    );
  }

  @SubscribeMessage('updatecategory')
  async updateCategory(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: {id: number; name: string},
  ): Promise<void> {
    const token = client.handshake.auth.token as string;
    if (!token) {
      return;
    }
    const user = await this.authService.validateToken(token,true);

    if (!user || !user.userId || user.role !== Role.SUPER_ADMIN) {
      return;
    }

    // const category = await this.chatService.updateCategory({
    //  id: data.id,
    //  name: data.name,
    // });

    // this.io.emit('updatecategory',category);
  }

  @SubscribeMessage('createChat')
  async fetchOrCreateChat(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: {participant: number},
  ): Promise<void> {
    const token = client.handshake.auth.token as string;
    if (!token) {
      return;
    }
    const user = await this.authService.validateToken(token,true);
    if (!user || !user.userId) {
      return;
    }

    const conversation = await this.chatService.createChatOneToOne(
      user.userId,
      data.participant,
    );

    client.emit(
      'chat',
      await this.chatService.getMyConversations(user.userId),
    );
  }

  // seenMessage event
  @SubscribeMessage('seenMessage')
  async seenMessage(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: {messageId: number},
  ): Promise<void> {
    const token = client.handshake.auth.token as string;
    if (!token) {
      return;
    }
    const user = await this.authService.validateToken(token,true);

    if (!user || !user.userId) {
      return;
    }
  }
}
