import {Injectable,Logger} from '@nestjs/common';
import {JobPosition,Message,Role,TypeMessage} from '@prisma/client';
import * as firebase from 'firebase-admin';

import {PrismaService} from '../common/services/prisma.service';

type ChatParams = {
  id?: number;
  page: number;
  limit: number;
  search?: string;
  orderBy?: string;
};

interface FormattedMessage {
  id: number;
  content: string;
  isRead?: boolean;
  sender: {
    id: number;
    name: string;
    avatar: string;
    active: boolean;
  };
}

@Injectable()
export class ChatService {
  private readonly logger = new Logger(ChatService.name);
  constructor(private readonly prismaService: PrismaService) { }

  async sendMessageToConversation({
    conversationId,
    message,
    userId,
  }: {conversationId: number,message: string,userId: number}) {
    try {
      const messageResponse = await this.prismaService.message.create({
        data: {
          conversationId,
          type: 'TEXT',
          content: message,
          seen: false,
          userId: userId,
        },
      });
      return messageResponse;
    } catch (error) {
      console.error('Error al enviar el mensaje:',error);
      throw error; // o manejar el error según tu lógica de aplicación
    }
  }

  async getConversationMessages(conversationId: number) {
    try {
      const messages = await this.prismaService.message.findMany({
        where: {
          conversationId: Number(conversationId),
        },
        select: {
          id: true,
          content: true,
          userId: true,
        },
        orderBy: {
          createdAt: 'desc',
        },
      });

      return messages;
    } catch (error) {
      console.error('Error al obtener los mensajes:',error);
      throw error; // o manejar el error según tu lógica de aplicación
    }
  }

  // Compare between two userID to find if the conversation already exists
  async getConversationByParticipants(userId: number,participant: number) {
    try {
      const conversation = await this.prismaService.conversation.findFirst({
        where: {
          participants: {
            some: {
              userId: userId,
            },
          },
          AND: {
            participants: {
              some: {
                userId: participant,
              },
            },
          },
        },
      });

      return conversation;
    } catch (error) {
      console.error('Error al obtener la conversación:',error);
      throw error; // o manejar el error según tu lógica de aplicación
    }
  }





  // kgetMyConversations
  async getMyConversations(userId: number) {
    try {
      // Obtener todas las conversaciones del usuario junto con los participantes y el último mensaje
      const conversations = await this.prismaService.conversationUser.findMany({
        where: {
          userId: userId,
        },
        include: {
          conversation: {
            include: {
              participants: {
                select: {
                  id: true,
                  user: true,
                },
              },
              messages: {
                take: 1,
                orderBy: {
                  createdAt: 'desc',
                },
                select: {
                  id: true,
                  content: true,
                  conversationId: true,
                  createdAt: true,
                  type: true,
                  seen: true,
                  userId: true,
                },
              },
            },
          },
        },
      });

      // Formatear las conversaciones y los mensajes
      const formattedConversations = conversations.map((conversation) => {
        const conversationParticipants = conversation.conversation.participants
          .filter(participant => participant.user.id !== userId)
          .map(participant => ({
            id: participant.id,
            user: participant.user,
          }));

        const latestMessage = conversation.conversation.messages[0] || null;

        return {
          conversations: conversationParticipants,
          latestMessage: latestMessage,
        };
      });

      return formattedConversations;
    } catch (error) {
      throw new Error(error.message);
    }
  }


  //#region Admin
  async getMyConversationsAdmin(userId: number) {
    try {
      const user = await this.prismaService.user.findUnique({
        where: {
          id: userId,
        },
        include: {
          conversations: {
            include: {
              conversation: {
                include: {
                  messages: true,
                  participants: {
                    select: {
                      id: true,
                      user: true
                    }
                  }
                }
              }
            }
          }
        },
      });

      if (!user) {
        throw new Error('User not found');
      }

      return user;
    } catch (error) {
      throw new Error(error.message);
    }
  }

  async sendMessage(to: number,from: number,message: string) {
    // Search by participants to see if the conversation already exists
    const conversation = await this.prismaService.conversation.findFirst({
      where: {
        participants: {
          some: {
            userId: to,
          },
        },
        AND: {
          participants: {
            some: {
              userId: from,
            },
          },
        },
      },
    });

    // Send push notification to the user
    await this.sendNotificationToUser(to,message);

    if (conversation) {
      const response = await this.sendMessageToConversationSend(
        conversation.id,
        from,
        message,
        'TEXT',
        false,
      );
      return response;
    }
  }

  async sendNotificationToUser(userId: number,message: string) {
    try {
      const user = await this.prismaService.user.findUnique({
        where: {
          id: userId,
        },
      });

      if (!user) {
        throw new Error('User not found');
      }


      const notification = await this.prismaService.notification.create({
        data: {
          title: 'Nuevo mensaje',
          body: message,
          user: {
            connect: {
              id: userId,
            }
          },
        },
      });

      const token = user?.fcm;

      this.logger.log('Sending notification to user ...');

      if (token) {
        this.logger.log('Token:',token);
        await firebase.messaging().send({
          notification: {
            title: 'Nuevo mensaje',
            body: message,
          },
          token: token,
        });
      }
      return notification;
    } catch (error) {
      throw new Error(error.message);
    }
  }

  async sendMessageToConversationSend(
    conversationId: number,
    userId: number,
    message: string,
    type: string,
    seen: boolean,
  ): Promise<Message> {
    try {
      const messageResponse = await this.prismaService.message.create({
        data: {
          conversationId,
          type: type as TypeMessage,
          content: message,
          seen: seen,
          userId: userId,
        },
      });
      console.log(`Mensaje enviado correctamente ... ${messageResponse.content}`);
      return messageResponse;
    } catch (error) {
      console.error('Error al enviar el mensaje:',error);
      throw error; // o manejar el error según tu lógica de aplicación
    }
  }






  //#endregion

  async getMessages(conversationId: number) {
    try {
      const messages = await this.prismaService.message.findMany({
        where: {
          conversationId: Number(conversationId),
        },
        include: {
          user: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              image: true,
              online: true,
              jobPosition: true,
            },
          },
        },
      });

      return messages;
    } catch (error) {
      throw new Error(error.message);
    }
  }

  // async sendMessageToConversation({
  //   conversationId,
  //   content,
  //   senderId,
  // }: {
  //   conversationId: number;
  //   content: string;
  //   senderId: number;
  // }) {
  //   try {
  //     const conversation = await this.prismaService.conversation.findUnique({
  //       where: {
  //         id: Number(conversationId),
  //       },
  //     });

  //     if (!conversation) {
  //       throw new Error('Conversation not found');
  //     }

  //     const message = await this.prismaService.message.create({
  //       data: {
  //         content,
  //         conversationId: Number(conversationId),
  //         type: TypeMessage.TEXT,
  //         userId: senderId,
  //       },
  //     });

  //     return message;
  //   } catch (error) {
  //     throw new Error(error.message);
  //   }

  // }

  async getAllUsers(userId: number) {
    try {
      const users = await this.prismaService.user.findMany({
        select: {
          id: true,
          firstName: true,
          lastName: true,
          email: true,
          image: true,
          online: true,
          role: true,
          jobPosition: true,
        },
        where: {
          id: {
            not: userId,
          },
        },
      });

      //
      return users;
    } catch (error) {
      throw new Error(error.message);
    }
  }

  // async createChat(userId: number, participant: number) {
  //   try {
  //     // Verificar que ambos usuarios existen
  //     const [user, participantUser] = await Promise.all([
  //       this.prismaService.user.findUnique({
  //         where: { id: userId },
  //       }),
  //       this.prismaService.user.findUnique({
  //         where: { id: participant },
  //       }),
  //     ]);

  //     if (!user) {
  //       throw new Error('User not found');
  //     }

  //     if (!participantUser) {
  //       throw new Error('Participant not found');
  //     }

  //     const conversation = await this.prismaService.conversation.create({
  //       data: {
  //         participants: {
  //           create: [
  //             { user: { connect: { id: userId } } },
  //             { user: { connect: { id: participant } } },
  //           ],
  //         },
  //       },
  //     });
  //     return conversation;
  //   } catch (error) {
  //     console.error('Error creating chat:', error);
  //     throw new Error(error.message);
  //   }
  // }

  async createChat(userId: number,participant: number) {
    try {
      // Verificar que ambos usuarios existen
      const [user,participantUser] = await Promise.all([
        this.prismaService.user.findUnique({
          where: {id: userId},
        }),
        this.prismaService.user.findUnique({
          where: {id: participant},
        }),
      ]);

      if (!user) {
        throw new Error('User not found');
      }

      if (!participantUser) {
        throw new Error('Participant not found');
      }

      const existingConversation = await this.prismaService.conversation.findFirst({
        where: {
          AND: [
            {participants: {some: {userId: userId}}},
            {participants: {some: {userId: participant}}},
          ],
        },
      });

      if (existingConversation) {
        return existingConversation;
      }
      const conversation = await this.prismaService.conversation.create({
        data: {
          participants: {
            create: [
              {userId: userId},
              {userId: participant},
            ],
          },
        },
      });
      return conversation;
    } catch (error) {
      console.error('Error creating chat:',error);
      throw new Error(error.message);
    }
  }

  async createChatByUser(userId: number,participants: number[]) {
    try {
      // Verificar que ambos usuarios existen
      const user = await this.prismaService.user.findUnique({
        where: {id: userId},
      });

      if (!user) {
        throw new Error('User not found');
      }

      const users = await this.prismaService.user.findMany({
        where: {
          id: {
            in: participants,
          },
        },
      });

      if (users.length !== participants.length) {
        throw new Error('One or more participants not found');
      }

      // find if conversation already exists with the two users
      const conversation = await this.prismaService.conversation.findFirst({
        where: {
          participants: {
            every: {
              userId: {
                in: participants,
              },
            },
          },
        },
      });

      if (conversation) {
        return conversation;
      }

      const newConversation = await this.prismaService.conversation.create({
        data: {
          participants: {
            create: participants.map((participant) => ({
              user: {connect: {id: participant}},
            })),
          },
        },
      });
      return newConversation;
    } catch (error) {
      console.error('Error creating chat:',error);
      throw new Error(error.message);
    }
  }

  async createChatOneToOne(userId: number,participant: number) {
    try {
      // Verificar que ambos usuarios existen
      const [user,participantUser] = await Promise.all([
        this.prismaService.user.findUnique({
          where: {id: userId},
        }),
        this.prismaService.user.findUnique({
          where: {id: participant},
        }),
      ]);

      if (!user) {
        throw new Error('User not found');
      }

      if (!participantUser) {
        throw new Error('Participant not found');
      }

      // find if conversation already exists with the two users
      const conversation = await this.prismaService.conversation.findFirst({
        where: {
          participants: {
            some: {
              userId: userId,
            },
          },
          AND: {
            participants: {
              some: {
                userId: participant,
              },
            },
          },
        },
      });

      if (conversation) {
        console.log('=== conversation:',conversation);
        return conversation;
      }

      const newConversation = await this.prismaService.conversation.create({
        data: {
          participants: {
            create: [
              {user: {connect: {id: userId}}},
              {user: {connect: {id: participant}}},
            ],
          },
        },
      });

      console.log('=== newConversation:',newConversation);
      return newConversation;
    } catch (error) {
      console.error('Error creating chat:',error);
      throw new Error(error.message);
    }
  }

  async updateUserOnlineStatus(userId: number,online: boolean) {
    try {
      const user = await this.prismaService.user.update({
        where: {
          id: userId,
        },
        data: {
          online,
        },
      });
      return user;
    } catch (error) {
      throw new Error(error.message);
    }
  }

  async createChatGroup(userIds: number[]) {
    try {
      // Verificar que todos los usuarios existen
      const users = await Promise.all(
        userIds.map(userId =>
          this.prismaService.user.findUnique({
            where: {id: userId},
          })
        )
      );

      // Verificar si alguno de los usuarios no existe
      const invalidUsers = users.filter(user => !user);
      if (invalidUsers.length > 0) {
        //@ts-ignore
        throw new Error(`User(s) not found: ${invalidUsers.map(user => user.id).join(', ')}`);
      }

      // Verificar si ya existe una conversación con exactamente los mismos participantes
      const existingConversation = await this.prismaService.conversation.findFirst({
        where: {
          AND: userIds.map(userId => ({
            participants: {some: {userId}}
          }))
        },
      });

      if (existingConversation) {
        return existingConversation;
      }

      // Crear la conversación con los participantes especificados
      const conversation = await this.prismaService.conversation.create({
        data: {
          participants: {
            create: userIds.map(userId => ({
              userId
            }))
          },
        },
      });

      return conversation;
    } catch (error) {
      console.error('Error creating chat:',error);
      throw new Error(error.message);
    }
  }


  async hasAdminInConversation(conversationId: number): Promise<boolean> {
    try {
      const conversations = await this.prismaService.conversation.findMany({
        where: {
          id: conversationId
        },
        include: {
          participants: {
            include: {
              user: true,
            },
          },
        },
      });

      return conversations.some(userAdmin =>
        userAdmin.participants.some(participant => participant.user.role === Role.SUPER_ADMIN)
      );
    } catch (error) {
      throw new Error(error.message);
    }
  }
}


