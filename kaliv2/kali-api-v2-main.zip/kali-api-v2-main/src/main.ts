import {NestFactory} from '@nestjs/core';
import {DocumentBuilder,SwaggerModule} from '@nestjs/swagger';
// import { ValidationPipe } from '@nestjs/common';
import {NestExpressApplication} from '@nestjs/platform-express';

// import * as helmet from 'helmet';
import * as requestIp from 'request-ip';
import {AppModule} from './app.module';
import {join} from 'path';

import {SocketIOAdapter} from './socket-io-adapter';

async function bootstrap() {
  // CORS is enabled
  const app = await NestFactory.create<NestExpressApplication>(AppModule,{
    cors: true,
  });
  app.enableCors({
    origin: [
      'http://localhost:3000',
      'http://localhost:3009',
      'http://localhost:5000',
      'https://kali-v2.vercel.app',
      'https://kali-v2-80653cb3bd06.herokuapp.com',
      '*',
    ],
  });
  // Request Validation
  //app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));

  // Public folder
  app.useStaticAssets(join(__dirname,'..','public'),{
    prefix: '/public',
  });

  app.use(requestIp.mw());
  app.useWebSocketAdapter(new SocketIOAdapter(app));

  // Helmet Middleware against known security vulnerabilities
  // app.use(helmet());

  // Swagger API Documentation
  const options = new DocumentBuilder()
    .setTitle('Miyaa API')
    .setDescription('Project Miyaa API Documentation')
    .setVersion('1.2.0')
    .addBearerAuth()
    .build();
  const document = SwaggerModule.createDocument(app,options);
  SwaggerModule.setup('api',app,document);

  await app.listen(process.env.PORT || 1337,'0.0.0.0');
}

bootstrap();
