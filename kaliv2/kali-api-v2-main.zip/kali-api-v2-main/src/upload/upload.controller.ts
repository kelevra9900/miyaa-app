import {
  Controller,
  Post,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import {FileInterceptor} from '@nestjs/platform-express';
import {S3} from 'aws-sdk';

@Controller('upload')
export class UploadController {
  private s3: S3;

  constructor() {
    this.s3 = new S3({
      signatureVersion: 'v4',
      accessKeyId: process.env.AWS_ACCESS_KEY_ID,
      secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
      region: process.env.AWS_DEFAULT_REGION,
    });
  }
  /**
   * Uploads a file to AWS S3 bucket.
   *
   * @param file - The file to be uploaded.
   * @returns The URL of the uploaded file.
   * @throws Error if the bucket name is not configured or if there is an error uploading the file to AWS S3.
   */
  @Post()
  @UseInterceptors(FileInterceptor('file'))
  async uploadFile(@UploadedFile() file: Express.Multer.File) {
    const bucketName = process.env.AWS_BUCKET;

    if (!bucketName) {
      throw new Error('El nombre del bucket no está configurado');
    }
    const fileName = file.originalname.trim().replace(/ /g,'-').toLowerCase();
    const uploadParams = {
      Bucket: bucketName,
      Key: fileName,
      Body: file.buffer,
    };

    try {
      const uploadResult = await this.s3.upload(uploadParams).promise();

      return uploadResult.Location;
    } catch (error) {
      console.error(error);
      throw new Error('Error al subir el archivo a AWS S3');
    }
  }
}
