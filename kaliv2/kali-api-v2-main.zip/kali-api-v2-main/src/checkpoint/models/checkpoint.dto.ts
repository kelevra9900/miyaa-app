import { ApiProperty } from '@nestjs/swagger';
import { Checkpoint } from '@prisma/client';
import {
  IsLatitude,
  IsLongitude,
  IsNotEmpty,
  IsNumber,
  IsString,
} from 'class-validator';

export class CreateCheckpoint {
  @ApiProperty({
    description: 'Checkpoint name',
    example: 'Checkpoint 1',
  })
  @IsNotEmpty()
  @IsString()
  location: string;

  @ApiProperty({
    description: 'Checkpoint latitude',
    example: '123.456',
  })
  @IsNotEmpty()
  @IsLatitude()
  latitude: number;

  @ApiProperty({
    description: 'Checkpoint longitude',
    example: '123.456',
  })
  @IsNotEmpty()
  @IsLongitude()
  longitude: number;

  @ApiProperty({
    description:
      'Round ID, must be a number and not empty, verify if th round exists',
    example: '1',
  })
  @IsNotEmpty()
  @IsNumber()
  roundId: number;

  @ApiProperty({
    description: 'Date when the checkpoint was checked',
    example: '2021-10-10 10:00:00',
  })
  @IsNotEmpty()
  @IsString()
  checkedAt: string;
}

export type CheckpointPagination = {
  data: Checkpoint[];
  total: number;
  totalPages: number;
  currentPage: number;
  perPage: number;
};

export type CheckpointResponse = {
  success: boolean;
  message: string;
  data?: Checkpoint;
};
