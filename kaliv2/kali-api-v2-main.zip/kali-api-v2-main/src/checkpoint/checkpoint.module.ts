import { Module } from '@nestjs/common';
import { PassportModule } from '@nestjs/passport';
import { CheckpointController } from './checkpoint.controller';
import { CheckpointService } from './checkpoint.service';
import { PrismaService } from '../common/services/prisma.service';

@Module({
  imports: [PassportModule.register({ defaultStrategy: 'jwt' })],
  controllers: [CheckpointController],
  providers: [CheckpointService, PrismaService],
  exports: [CheckpointService],
})
export class CheckpointModule {}
