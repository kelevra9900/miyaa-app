import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
  UnauthorizedException,
  UseGuards,
} from '@nestjs/common';
import {AuthGuard} from '@nestjs/passport';
import {ApiBearerAuth,ApiTags} from '@nestjs/swagger';
import {Checkpoint} from '@prisma/client';

import {CheckpointService} from './checkpoint.service';
import {
  CheckpointPagination,
  CheckpointResponse,
  CreateCheckpoint,
} from './models/checkpoint.dto';
import {AuthUser} from '../auth/auth-user';
import {Usr} from '../user/user.decorator';
import {PaginationModel} from '../notes/models/request/pagination.model';

@ApiTags('Checkpoints Management')
// @ApiBearerAuth()
// @UseGuards(AuthGuard())
@Controller('checkpoint')
export class CheckpointController {
  constructor(private readonly checkpointService: CheckpointService) { }

  /**
   * Retrieves a paginated list of checkpoints.
   *
   * @param page The page number to retrieve (optional).
   * @param limit The maximum number of checkpoints per page (optional).
   * @param search The search query to filter checkpoints (optional).
   * @returns A Promise that resolves to a CheckpointPagination object containing the paginated list of checkpoints.
   */
  @Get()
  @HttpCode(HttpStatus.OK)
  getCheckpoints(
    @Query() params: PaginationModel,
  ): Promise<CheckpointPagination> {
    return this.checkpointService.pagination(
      params.page ? params.page : 1,
      params.limit ? params.limit : 10,
      params.search ? params.search : '',
    );
  }

  /**
   * Retrieves a checkpoint by its ID.
   *
   * @param id The ID of the checkpoint.
   * @returns A Promise that resolves to a Checkpoint object.
   */
  @Get(':id')
  @HttpCode(HttpStatus.OK)
  getCheckpoint(@Param('id',ParseIntPipe) id: number): Promise<Checkpoint> {
    return this.checkpointService.get(id);
  }

  @Get('round/active')
  @HttpCode(HttpStatus.OK)
  getCheckpointsByRound(
    @Query('id',ParseIntPipe) id: number,
    @Query() params: PaginationModel,
  ): Promise<CheckpointPagination> {
    return this.checkpointService.getCheckpointsByRoundId(
      id,
      params.page ? params.page : 1,
      params.limit ? params.limit : 10,
    );
  }


  @Get('round/active/:id')
  @HttpCode(HttpStatus.OK)
  getCheckpointsByRoundWithId(
    @Param('id', ParseIntPipe) id: number,
    @Query() params: PaginationModel,
  ): Promise<CheckpointPagination> {
    return this.checkpointService.getCheckpointsByRoundId(
      id,
      params.page ? params.page : 1,
      params.limit ? params.limit : 10,
    );
  }

  /**
   * Creates a new checkpoint.
   *
   * @param data The data for the new checkpoint.
   * @param user The authenticated user performing the action.
   * @returns A Promise that resolves to a CheckpointResponse object.
   * @throws UnauthorizedException if the user is not authorized (must be super admin) to perform this action.
   */
  @Post()
  @HttpCode(HttpStatus.CREATED)
  createCheckpoint(
    @Body() data: CreateCheckpoint,
    @Usr() user: AuthUser,
  ): Promise<CheckpointResponse> {
    return this.checkpointService.create(data);
  }

  @Put(':id')
  @HttpCode(HttpStatus.OK)
  updateCheckpoint(
    @Param('id',ParseIntPipe) id: number,
    @Body() data: Checkpoint,
  ): Promise<CheckpointResponse> {
    console.log("object")
    return this.checkpointService.update(id,data);
  }


  @Delete(':id')
  public async deleteCheckpointById(@Param('id') id: string) {
    return this.checkpointService.delete( parseInt(id) )}
}
