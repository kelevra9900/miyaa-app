import {Injectable,InternalServerErrorException,NotFoundException} from '@nestjs/common';
import {PrismaService} from '../common/services/prisma.service';
import {CheckpointResponse,CreateCheckpoint} from './models/checkpoint.dto';
import {Checkpoint} from '@prisma/client';

@Injectable()
export class CheckpointService {
  constructor(private readonly prismaService: PrismaService) { }

  /**
   * Retrieves a paginated list of checkpoints.
   *
   * @param page The page number to retrieve (default: 1)
   * @param limit The number of checkpoints per page (default: 10)
   * @param search The search string to filter checkpoints by location (default: '')
   * @returns An object containing the paginated list of checkpoints, total count, total pages, current page, and number of checkpoints per page
   * @throws InternalServerErrorException if there is an error fetching the checkpoints
   */
  async pagination(page: number = 1,limit: number = 10,search: string = '') {
    const skip = (page - 1) * limit;

    const where = search
      ? {
        location: {
          contains: search,
        },
      }
      : {};

    try {
      const [checkpoints,count] = await Promise.all([
        this.prismaService.checkpoint.findMany({
          skip,
          take: limit,
          where,
        }),
        this.prismaService.checkpoint.count({where}),
      ]);

      const totalPages = Math.ceil(count / limit);

      return {
        data: checkpoints,
        success: true,
        total: count,
        totalPages,
        currentPage: page,
        perPage: limit,
      };
    } catch (error) {
      console.error('Error fetching checkpoints:',error);
      throw new InternalServerErrorException('Failed to fetch checkpoints');
    }
  }

  /**
   * Creates a new checkpoint.
   *
   * @param data The data for the new checkpoint
   * @returns An object containing the success status, message, and the created checkpoint data
   * @throws InternalServerErrorException if there is an error creating the checkpoint
   */
  async create(data: CreateCheckpoint): Promise<CheckpointResponse> {
    try {
      const checkpoint = await this.prismaService.checkpoint.create({
        data: {
          location: data.location,
          latitude: data.latitude,
          longitude: data.longitude,
          roundId: data.roundId,
          checkedAt: new Date(data.checkedAt),
        },
      });

      if (!checkpoint) {
        throw new InternalServerErrorException('Failed to create checkpoint');
      }

      return {
        success: true,
        message: 'Checkpoint created successfully',
        data: checkpoint,
      };
    } catch (error) {
      console.error('Error creating checkpoint:',error);
      throw new InternalServerErrorException('Failed to create checkpoint');
    }
  }

  /**
   * Retrieves a checkpoint by its ID.
   *
   * @param id The ID of the checkpoint to retrieve
   * @returns The checkpoint object if found
   * @throws InternalServerErrorException if there is an error fetching the checkpoint
   */
  async get(id: number) {
    try {
      const checkpoint = await this.prismaService.checkpoint.findUnique({
        where: {
          id,
        },
      });

      if (!checkpoint) {
        throw new NotFoundException('Checkpoint not found');
      }

      return checkpoint;
    } catch (error) {
      console.error('Error fetching checkpoint:',error);
      throw new InternalServerErrorException('Failed to fetch checkpoint');
    }
  }

  async getCheckpointsByRoundId(roundId: number,page: number = 1,limit: number = 10) {
    const skip = (page - 1) * limit;

    try {
      const checkpoints = await this.prismaService.checkpoint.findMany({
        skip,
        take: limit,
        where: {
          roundId,
        },
      });

      const count = await this.prismaService.checkpoint.count({
        where: {
          roundId,
        },
      });

      if (!checkpoints) {
        throw new NotFoundException('Checkpoints not found');
      }

      const totalPages = Math.ceil(count / limit);


      return {
        data: checkpoints,
        success: true,
        total: count,
        totalPages,
        currentPage: page,
        perPage: limit,
      };
    } catch (error) {
      console.error('Error fetching checkpoints:',error);
      throw new InternalServerErrorException('Failed to fetch checkpoints');
    }
  }

  /**
   * Updates a checkpoint by its ID.
   *
   * @param id The ID of the checkpoint to update
   * @param data The updated data for the checkpoint
   * @returns An object containing the success status, message, and the updated checkpoint data
   * @throws InternalServerErrorException if there is an error updating the checkpoint
   */
  async update(id: number,data: Checkpoint) {
    try {
      const checkpoint = await this.prismaService.checkpoint.update({
        where: {
          id,
        },
        data: {
          ...data,
        },
      });

      if (!checkpoint) {
        throw new InternalServerErrorException('Failed to update checkpoint');
      }

      return {
        success: true,
        message: 'Checkpoint updated successfully',
        data: checkpoint,
      };
    } catch (error) {
      console.error('Error updating checkpoint:',error);
      throw new InternalServerErrorException('Failed to update checkpoint');
    }
  }

  /**
   * Deletes a checkpoint by its ID.
   *
   * @param id The ID of the checkpoint to delete
   * @returns An object containing the success status and a message indicating the deletion status
   * @throws InternalServerErrorException if there is an error deleting the checkpoint
   */
  async delete(id: number) {
    try {
      const checkpoint = await this.prismaService.checkpoint.delete({
        where: {
          id,
        },
      });

      if (!checkpoint) {
        throw new InternalServerErrorException('Failed to delete checkpoint');
      }

      return {
        success: true,
        message: 'Checkpoint deleted successfully',
      };
    } catch (error) {
      return {
        success: false,
        message: 'Checkpoint not found',
      };
    }
  }
}
