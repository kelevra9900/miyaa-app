import { Injectable } from '@nestjs/common';
import { CreateNotificationDto } from './dto/create-notification.dto';
import { NotificationDto } from './dto/update-notification.dto';
import * as firebase from 'firebase-admin';
import { PrismaService } from '../common/services/prisma.service';

firebase.initializeApp({
  credential: firebase.credential.cert({
    privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
    clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
    projectId: process.env.FIREBASE_PROJECT_ID,
  }),
});

@Injectable()
export class NotificationService {
  constructor(private readonly prisma: PrismaService) {}
  /**
   * Creates a new notification.
   *
   * @param createNotificationDto - The data for creating the notification.
   * @returns An object with the success status and the created notification.
   */
  async create(createNotificationDto: CreateNotificationDto) {
    const notification = await this.prisma.notification.create({
      data: {
        title: createNotificationDto.title,
        body: createNotificationDto.body,
        user: {
          connect: {
            id: createNotificationDto.user_id,
          },
        },
      },
    });
    return {
      success: true,
      data: notification,
    };
  }
  /**
   * Retrieves all notifications.
   *
   * @returns An object with the success status and the array of notifications.
   */
  async findAll() {
    const notifications = await this.prisma.notification.findMany({
      include: {
        user: true,
      },
    });
    return {
      success: true,
      data: notifications,
    };
  }
  /**
   * Retrieves a notification by its ID.
   *
   * @param id - The ID of the notification.
   * @returns An object with the success status and the retrieved notification.
   */
  findOne(id: number) {
    const notification = this.prisma.notification.findUnique({
      where: {
        id,
      },
    });
    return {
      success: true,
      data: notification,
    };
  }
  /**
   * Updates a notification by its ID.
   *
   * @param id - The ID of the notification.
   * @param updateNotificationDto - The data for updating the notification.
   * @returns An object with the success status and the updated notification.
   */
  update(id: number, updateNotificationDto: NotificationDto) {
    const update = this.prisma.notification.update({
      where: {
        id,
      },
      data: {
        title: updateNotificationDto.title,
        body: updateNotificationDto.body,
      },
    });
    return {
      success: true,
      data: update,
    };
  }

  remove(id: number) {
    return `This action removes a #${id} notification`;
  }

  getNotifications = async (): Promise<any> => {
    const notifications = await this.prisma.notification.findMany({
      include: {
        user: true,
      },
    });
    return notifications;
  };

  sendPush = async (
    token: string,
    title: string,
    body: string,
  ): Promise<void> => {
    await firebase.messaging().send({
      token,
      notification: {
        title,
        body,
      },
    });
  };
}
