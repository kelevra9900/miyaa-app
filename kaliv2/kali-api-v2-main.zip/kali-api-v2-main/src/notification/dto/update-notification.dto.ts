import { PartialType } from '@nestjs/swagger';
import { CreateNotificationDto } from './create-notification.dto';
import { IsNumber } from 'class-validator';
import { Transform } from 'class-transformer';

export class NotificationDto extends PartialType(CreateNotificationDto) {
  @IsNumber()
  @Transform(({ value }) => Number(value))
  id: number;
}
