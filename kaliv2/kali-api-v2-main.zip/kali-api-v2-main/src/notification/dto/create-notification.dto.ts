import { ApiProperty } from '@nestjs/swagger';
import { AlertStatus } from '@prisma/client';
import { Transform } from 'class-transformer';
import { IsBoolean, IsEnum, IsNumber, IsString } from 'class-validator';

export class CreateNotificationDto {
  @ApiProperty({
    description: 'User id',
    example: 1,
  })
  @IsNumber()
  @Transform(({ value }) => Number(value))
  user_id: number;

  @ApiProperty({
    description: 'Token of device',
    example: 'token',
  })
  @IsString()
  token: string;

  @ApiProperty({
    description: 'Title of notification',
    example: 'Hi User!',
  })
  @IsString()
  title: string;

  @ApiProperty({
    description: 'Status of notification, default is CREATED',
    example: AlertStatus.CREATED,
  })
  @IsEnum(AlertStatus)
  @IsString()
  status?: AlertStatus;

  @ApiProperty({
    description: 'Body of notification',
    example: 'This is a notification',
  })
  @IsString()
  body: string;

  @ApiProperty({
    description: 'Read status of notification, default is false',
    example: false,
  })
  @IsBoolean()
  @Transform(({ value }) => Boolean(value))
  read?: boolean;

  @IsString()
  @Transform(({ value }) => value.toString())
  created_at?: Date;

  @IsString()
  @Transform(({ value }) => value.toString())
  updated_at?: Date;
}
