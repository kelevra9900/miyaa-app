import {Document} from "@prisma/client";

export class DocumentsResponse {
	id: number;
	documentType: string;
	filePath: string;
	valid: boolean;
	issuedAt: Date | null;
	validUntil: Date | null;


	static fromDocumentsEntity(entity: Document): DocumentsResponse {
		const response = new DocumentsResponse();
		response.id = entity.id;
		response.documentType = entity.documentType;
		response.filePath = entity.filePath;
		response.valid = entity.valid ?? false;
		response.issuedAt = entity.issuedAt;
		response.validUntil = entity.validUntil;
		return response;
	}
}

export interface DocumentRes {
	message: string;
	data: DocumentsResponse[];
}