interface DocumentInterface {
	id: number;
	userId: number;
	documentType: string;
	filePath: string;
	valid: boolean | null;
	issuedAt: Date | null;
	validUntil: Date | null;
	user: {
		id: number;
		firstName: string;
		lastName: string;
	};
}

interface UserDocumentData {
	id: string;
	userId: number;
	name: string;
	totalDocuments: number;
	moreFive: boolean;
	children: Document[];
}