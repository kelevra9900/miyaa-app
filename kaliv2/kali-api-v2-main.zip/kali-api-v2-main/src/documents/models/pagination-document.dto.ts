import {ApiProperty} from "@nestjs/swagger";
import {IsOptional,IsDateString} from 'class-validator';
import {PaginationModel} from "../../notes/models/request/pagination.model";


export class PaginationDocumentDto extends PaginationModel {
	@ApiProperty({required: false})
	@IsOptional()
	@IsDateString()
	isValidUntil?: string;

	@ApiProperty({required: false})
	@IsOptional()
	valid?: boolean;
}
