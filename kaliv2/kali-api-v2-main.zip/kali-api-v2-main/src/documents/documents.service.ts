import {Injectable,ConflictException,Logger} from '@nestjs/common';
import {PrismaService} from '../common/services/prisma.service';
import {PaginationDocumentDto} from './models/pagination-document.dto';
import {DocumentRes,DocumentsResponse} from './models/documents-response';
import {nanoid} from 'nanoid';
import {Document as PrismaDocument} from '@prisma/client';

interface Document extends PrismaDocument {
	user: {
		id: number;
		firstName: string;
		lastName: string;
	};
}

interface UserDocumentData {
	id: string;
	userId: number;
	name: string;
	totalDocuments: number;
	moreFive: boolean;
	children: Document[];
}

@Injectable()
export class DocumentsService {
	private readonly logger = new Logger(DocumentsService.name);

	constructor(private readonly prisma: PrismaService) { }

	async findAllDocuments(params: PaginationDocumentDto): Promise<any> {
		const {search,valid,isValidUntil,page = 1,limit = 30} = params;

		try {
			const whereCondition: any = {};
			if (search) {
				whereCondition.OR = [
					{documentType: {contains: search,mode: 'insensitive'}},
					{filePath: {contains: search,mode: 'insensitive'}},
				];
			}
			if (valid !== undefined) {
				whereCondition.valid = valid;
			}
			if (isValidUntil) {
				whereCondition.validUntil = isValidUntil;
			}

			const uniqueUserIds = await this.prisma.document.findMany({
				select: {userId: true},
				where: whereCondition,
				distinct: ['userId'],
			});
			const totalUsers = uniqueUserIds.length;

			// Obtener documentos paginados
			const skip = (page - 1) * limit;
			const documents: Document[] = await this.prisma.document.findMany({
				where: whereCondition,
				include: {user: true},
				skip,
				take: Number(limit),
				orderBy: {valid: 'desc'},
			});

			// Crear el objeto de respuesta agrupado por usuario
			const documentsGroupedByUser = documents.reduce((acc: Record<number,UserDocumentData>,document: Document) => {
				const userId = document.userId;
				if (!acc[userId]) {
					acc[userId] = {
						id: nanoid(10),
						userId,
						name: `${document.user.firstName} ${document.user.lastName}`,
						totalDocuments: 0,
						moreFive: false,
						children: [],
					};
				}
				acc[userId].totalDocuments++;
				if (acc[userId].totalDocuments >= 5) {
					acc[userId].moreFive = true;
				}
				if (acc[userId].children.length < 5) {
					acc[userId].children.push(document);
				}
				return acc;
			},{});

			let documentsArray: UserDocumentData[] = Object.values(documentsGroupedByUser);

			if (search) {
				documentsArray = documentsArray.filter((document) =>
					document.name.toLowerCase().includes(search.toLowerCase()),
				);
			}

			const totalPages = Math.ceil(totalUsers / limit);

			return {
				documents: documentsArray,
				total: totalUsers,
				totalPages,
				currentPage: page,
				perPage: limit,
			};
		} catch (e) {
			this.logger.error('Error in findAllDocuments method',e);
			throw new ConflictException('Error retrieving documents');
		}
	}

	async getDocuments(params: PaginationDocumentDto): Promise<any> {
		try {
			const whereCondition: any = {};

			if (params?.search) {
				whereCondition.OR = [
					{documentType: {contains: params.search,mode: 'insensitive'}},
					{filePath: {contains: params.search,mode: 'insensitive'}},
				];
			}

			if (params?.isValidUntil) {
				whereCondition.validUntil = new Date(params.isValidUntil);
			}

			const skip = (params?.page ? params.page - 1 : 0) * (params?.limit || 10);
			const take = params?.limit || 10;

			const total = await this.prisma.document.count({where: whereCondition});

			const documents = await this.prisma.document.findMany({
				skip: Number(skip),
				take: Number(take),
				where: whereCondition,
			});

			const totalPages = Math.ceil(total / take);
			const currentPage = params?.page || 1;
			const perPage = take;

			return {
				data: documents.map((doc) => DocumentsResponse.fromDocumentsEntity(doc)),
				total,
				totalPages,
				currentPage,
				perPage,
			};
		} catch (e) {
			this.logger.error('Error in getDocuments method',e);
			throw new ConflictException('Error retrieving documents');
		}
	}

	async getDocumentById(id: number): Promise<PrismaDocument | null> {
		try {
			return await this.prisma.document.findUnique({
				where: {id},
			});
		} catch (e) {
			this.logger.error('Error in getDocumentById method',e);
			throw new ConflictException('Error retrieving document');
		}
	}

	async createDocument(document: PrismaDocument): Promise<PrismaDocument> {
		try {
			return await this.prisma.document.create({
				data: document,
			});
		} catch (e) {
			this.logger.error('Error in createDocument method',e);
			throw new ConflictException('Error creating document');
		}
	}

	async createDocumentAdmin(
	body:any
	  ): Promise<any> {
		try {
		
		  const data = await this.prisma.document.create({
			data: {
			  user: {
				connect: {
				  id: Number(body.userId),
				},
			  },
			  documentType: body.documentType as any,
			  filePath: body.filePath,
			  issuedAt: new Date(),
			  validUntil: body.validUntil,
			  valid: body.valid
			},
		  });
	
		  this.logger.log('Document uploaded successfully',data);
	
		  return {
			message: 'Document uploaded successfully',
			data,
		  };
		} catch (e) {
		  this.logger.error('Error create document method',e,'UserService');
		  throw new ConflictException();
		}
	  }
	

	async updateDocument(id: number,document: PrismaDocument): Promise<PrismaDocument> {
		try {

			return this.prisma.document.update({
				where: {id},
				data: document,
			});

		} catch (e) {
			this.logger.error('Error in updateDocument method',e);
			throw new ConflictException('Error updating document');
		}
	}

	async getByUser(userId: number): Promise<DocumentRes> {
		try {
			const documents = await this.prisma.document.findMany({
				where: {
					userId
				},
			});

			return {
				message:
					documents.length > 0 ? 'Documents found' : 'No documents found',
				data: documents.map((doc) => DocumentsResponse.fromDocumentsEntity(doc)),
			};
		} catch (e) {
			this.logger.error(
				'Error get documents by user id method',
				e,
				'UserService',
			);
			throw new ConflictException();
		}
	}

	async getDocument(id: number): Promise<DocumentsResponse> {
		try {
			const document = await this.prisma.document.findUnique({
				where: {id},
			});
			if (!document) {
				throw new ConflictException('Document not found');
			}
			return DocumentsResponse.fromDocumentsEntity(document);
		} catch (e) {
			this.logger.error('Error get document by id method',e,'UserService');
			throw new ConflictException();
		}
	}

	async deleteDocument(id: number) {
		try {
		  await this.prisma.document.delete({
			where: {id}
		 });
		} catch (e) {
		  this.logger.error('Error delete user by id method',e,'UserService');
		  throw new ConflictException();
		}
	  }
}
