import {Module} from '@nestjs/common';
import {PassportModule} from '@nestjs/passport';

import {PrismaService} from '../common/services/prisma.service';
import {DocumentsController} from './documents.controller';
import {DocumentsService} from './documents.service';

@Module({
  imports: [PassportModule.register({defaultStrategy: 'jwt'})],
  controllers: [DocumentsController],
  providers: [DocumentsService,PrismaService],
  exports: [DocumentsService],
})
export class DocumentsModule { }
