import {Body,Controller,Delete,Get,HttpCode,HttpStatus,Param,ParseIntPipe,Post,Put,Query} from '@nestjs/common';
import {ApiTags} from '@nestjs/swagger';
import {Document as PrismaDocument} from '@prisma/client';

import {DocumentsService} from './documents.service';
import {PaginationDocumentDto} from './models/pagination-document.dto';
import { CreateDocumentRequest } from 'src/user/models/request/create-document-request.model';

@Controller('documents')
@ApiTags('Configuration')
export class DocumentsController {

	constructor(
		private readonly documentsService: DocumentsService
	) { }

	@Get()
	public async getDocuments(
		@Query() params: PaginationDocumentDto
	): Promise<any> {
		return this.documentsService.findAllDocuments(params);
	}

	@Get('by-user/:id')
	public async getDocumentById(
		@Param('id',ParseIntPipe) id: number,
	): Promise<any> {
		return this.documentsService.getByUser(id);
	}

	@Put('/documents/:id')
	@HttpCode(HttpStatus.OK)
	async modifyDocument(
		@Param('id',ParseIntPipe) id: number,
		@Body() updatedDocumentData: PrismaDocument,
	) {
		return this.documentsService.updateDocument(id,updatedDocumentData);
	}

	@Get(':id')
	public async getDocument(
		@Param('id',ParseIntPipe) id: number
	) {
		return this.documentsService.getDocument(id);
	}

	@Post()
	@HttpCode(HttpStatus.OK)
	async createDocument(
	  @Body() body: CreateDocumentRequest,
	) {
	  return this.documentsService.createDocumentAdmin(body);
	}

	@Delete(':id')
	@HttpCode(HttpStatus.OK)
	async deleteDocument(
		@Param('id',ParseIntPipe) id: number	) {
	  return this.documentsService.deleteDocument(id);
	}

}
