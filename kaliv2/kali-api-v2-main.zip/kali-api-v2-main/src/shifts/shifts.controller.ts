import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
  UseGuards,
} from '@nestjs/common';
import {ApiBearerAuth,ApiTags} from '@nestjs/swagger';
import {Shift} from '@prisma/client';
import {AuthGuard} from '@nestjs/passport';

import {ShiftsService} from './shifts.service';
import {ShiftPagination} from './models/shifts.response';
import {CreateShiftRequest} from './models';

@ApiTags('Shifts')
@Controller('shifts')
@ApiBearerAuth()
@UseGuards(AuthGuard())
export class ShiftsController {
  constructor(private readonly shiftsService: ShiftsService) { }
  /**
   * Create a new shift.
   *
   * @param data - The data for creating the shift.
   * @returns A promise that resolves to the created shift.
   */
  @Post()
  @HttpCode(HttpStatus.CREATED)
  async create(@Body() data: CreateShiftRequest): Promise<Shift> {
    return this.shiftsService.create(data);
  }

  /**
   * Retrieves a list of shifts based on the provided parameters.
   *
   * @param page - The page number for pagination.
   * @param limit - The maximum number of shifts to retrieve per page.
   * @param search - The search query to filter shifts.
   * @returns A promise that resolves to a ShiftPagination object containing the retrieved shifts.
   */
  @Get()
  @HttpCode(HttpStatus.OK)
  async findAll(
    @Query('page',ParseIntPipe) page?: number,
    @Query('limit',ParseIntPipe) limit?: number,
    @Query('search') search?: string,
  ): Promise<ShiftPagination> {
    return this.shiftsService.pagination(page,limit,search);
  }
  /**
   * Retrieves a single shift based on the provided ID.
   *
   * @param id - The ID of the shift to retrieve.
   * @returns A promise that resolves to the retrieved shift.
   */
  @Get(':id')
  @HttpCode(HttpStatus.OK)
  async findOne(@Param('id',ParseIntPipe) id: number): Promise<Shift> {
    return this.shiftsService.findOne(id);
  }

  /**
   * Updates a shift with the provided ID.
   *
   * @param id - The ID of the shift to update.
   * @param updateRequest - The data for updating the shift.
   * @returns A promise that resolves to the updated shift.
   */
  @Put(':id')
  @HttpCode(HttpStatus.OK)
  async update(
    @Param('id',ParseIntPipe) id: number,
    @Body() updateRequest: CreateShiftRequest,
  ): Promise<Shift> {
    return this.shiftsService.update(id,updateRequest);
  }
  /**
   * Removes a shift with the provided ID.
   *
   * @param id - The ID of the shift to remove.
   * @returns A promise that resolves to void.
   */
  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  async remove(@Param('id',ParseIntPipe) id: number) {
    return this.shiftsService.remove(id);
  }
}
