import {ConflictException,Injectable,Logger} from '@nestjs/common';
import {Shift} from '@prisma/client';

import {PrismaService} from '../common/services/prisma.service';
import {CreateShiftRequest} from './models/request/create-shift-request';
import {ShiftPagination} from './models/shifts.response';

@Injectable()
export class ShiftsService {
  constructor(private readonly prisma: PrismaService) { }

  /**
   * Creates a new shift.
   *
   * @param data - The data for the new shift.
   * @returns A promise that resolves to the created shift.
   * @throws {ConflictException} If there is an error creating the shift.
   */
  public async create(data: CreateShiftRequest): Promise<Shift> {
    try {
      return this.prisma.shift.create({
        data,
      });
    } catch (err) {
      Logger.error('Erro create Shift',err,'ShiftService');
      throw new ConflictException();
    }
  }

  /**
   * Retrieves a paginated list of shifts.
   *
   * @param page - The page number to retrieve (default: 1).
   * @param limit - The maximum number of shifts per page (default: 10).
   * @param search - Optional search query to filter shifts by name (default: undefined).
   * @returns A promise that resolves to a ShiftPagination object containing the paginated shifts.
   */
  public async pagination(
    page = 1,
    limit = 10,
    search?: string,
  ): Promise<ShiftPagination> {
    const total = await this.getTotalShiftCount(search);
    const shifts = await this.getShiftList(page,limit,search);

    const totalPages = Math.ceil(total / limit);
    const currentPage = page;
    const perPage = limit;

    return {
      total,
      totalPages,
      currentPage,
      perPage,
      data: shifts,
    };
  }

  /**
   * Retrieves a shift by its ID.
   *
   * @param id - The ID of the shift to retrieve.
   * @returns A promise that resolves to the shift with the specified ID.
   * @throws {ConflictException} If the shift is not found.
   */
  public async findOne(id: number): Promise<Shift> {
    try {
      const shiftFound = await this.prisma.shift.findUnique({
        where: {id},
      });

      if (!shiftFound) {
        throw new ConflictException('Shift not found');
      }

      return shiftFound;
    } catch (err) {
      Logger.error('Error finding Shift',err,'ShiftService');
      throw new ConflictException();
    }
  }

  /**
   * Updates a shift with the specified ID.
   *
   * @param id - The ID of the shift to update.
   * @param data - The updated data for the shift.
   * @returns A promise that resolves to the updated shift.
   * @throws {ConflictException} If there is an error updating the shift.
   */
  public async update(id: number,data: CreateShiftRequest): Promise<Shift> {
    try {
      return this.prisma.shift.update({
        where: {id},
        data,
      });
    } catch (err) {
      Logger.error('Error updating Shift',err,'ShiftService');
      throw new ConflictException();
    }
  }

  /**
   * Removes a shift with the specified ID.
   *
   * @param id - The ID of the shift to remove.
   * @returns A promise that resolves to the removed shift.
   * @throws {ConflictException} If there is an error removing the shift.
   */
  public async remove(id: number) {
    try {
      return this.prisma.shift.delete({
        where: {id},
      });
    } catch (err) {
      Logger.error('Error deleting Shift',err,'ShiftService');
      throw new ConflictException();
    }
  }

  /**
   * Retrieves the total count of shifts.
   *
   * @param search - Optional search query to filter shifts by name (default: undefined).
   * @returns A promise that resolves to the total count of shifts.
   */
  async getTotalShiftCount(search?: string): Promise<number> {
    if (search) {
      return this.prisma.shift.count({
        where: {
          OR: [{name: {contains: search}}],
        },
      });
    }
    return this.prisma.shift.count();
  }
  /**
   * Retrieves a list of shifts based on the specified page, limit, and search query.
   *
   * @param page - The page number to retrieve (default: 1).
   * @param limit - The maximum number of shifts per page (default: 10).
   * @param search - Optional search query to filter shifts by name (default: undefined).
   * @returns A promise that resolves to an array of shifts.
   */
  async getShiftList(
    page: number,
    limit: number,
    search?: string,
  ): Promise<Shift[]> {
    const whereCondition: any = {};

    if (search) {
      whereCondition.OR = [{name: {contains: search}}];
    }

    return this.prisma.shift.findMany({
      where: whereCondition,
      skip: (page - 1) * limit,
      take: limit,
      include: {
        users: true,
      },
    });
  }
}
