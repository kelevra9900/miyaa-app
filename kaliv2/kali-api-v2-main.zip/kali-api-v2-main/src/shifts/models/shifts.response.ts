import {Shift,User} from '@prisma/client';

export class ShiftResponse {
  id: number;
  name: string;
  start: string;
  end: string;
  createdAt: Date;
  updatedAt: Date;
  user?: User;

  static fromShiftEntity(entity: Shift,user?: User): ShiftResponse {
    const response = new ShiftResponse();
    response.id = entity.id;
    response.name = entity.name;
    response.start = entity.start;
    response.end = entity.end;
    response.createdAt = entity.createdAt;
    response.updatedAt = entity.updatedAt;
    response.user = user;
    return response;
  }
}

export type ShiftPagination = {
  data: ShiftResponse[];
  total: number;
  totalPages: number;
  currentPage: number;
  perPage: number;
};
