import { CreateShiftRequest } from './create-shift-request';

export class UpdateShiftRequest extends CreateShiftRequest {
  id: number;
}
