import { ApiProperty } from '@nestjs/swagger';
import { IsDateString, IsNotEmpty, IsString } from 'class-validator';

export class CreateShiftRequest {
  @ApiProperty({
    description: 'Name of the shift',
    example: 'Morning Shift',
  })
  @IsNotEmpty()
  @IsString()
  name: string;

  @ApiProperty({
    description: 'Start date of the shift',
    example: '2021-01-01T00:00:00.000Z',
  })
  @IsNotEmpty()
  @IsDateString()
  start: string;

  @ApiProperty({
    description: 'End date of the shift',
    example: '2021-01-01T00:00:00.000Z',
  })
  @IsNotEmpty()
  @IsDateString()
  end: string;
}
