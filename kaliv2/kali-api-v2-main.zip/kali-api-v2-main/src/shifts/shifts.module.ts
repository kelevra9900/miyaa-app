import { Module } from '@nestjs/common';
import { PassportModule } from '@nestjs/passport';

import { PrismaService } from '../common/services/prisma.service';
import { ShiftsService } from './shifts.service';
import { ShiftsController } from './shifts.controller';

@Module({
  imports: [PassportModule.register({ defaultStrategy: 'jwt' })],
  providers: [ShiftsService, PrismaService],
  exports: [ShiftsService],
  controllers: [ShiftsController],
})
export class ShiftsModule {}
