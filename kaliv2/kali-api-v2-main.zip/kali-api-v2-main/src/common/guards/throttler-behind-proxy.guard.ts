import { ThrottlerGuard } from '@nestjs/throttler';
import { Injectable } from '@nestjs/common';
import * as requestIp from 'request-ip';

@Injectable()
export class ThrottlerBehindProxyGuard extends ThrottlerGuard {
  /**
   * Returns the IP address of the client making the request.
   *
   * @param req - The request object.
   * @returns The IP address of the client, or 'null-ip' if the IP address cannot be determined.
   */
  protected getTracker(req: Record<string, unknown>): string {
    return (
      requestIp.getClientIp(req as unknown as requestIp.Request) ?? 'null-ip'
    );
  }
}
