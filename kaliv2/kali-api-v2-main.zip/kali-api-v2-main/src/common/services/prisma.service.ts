import { Injectable, OnModuleInit, OnModuleDestroy } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';

/**
 * PrismaService class.
 *
 * This class extends the PrismaClient class and implements the OnModuleInit and OnModuleDestroy interfaces.
 * It provides a service for interacting with the Prisma ORM.
 *
 * @constructor
 * Creates an instance of the PrismaService class.
 *
 * @method onModuleInit
 * Initializes the Prisma client by connecting to the database.
 *
 * @method onModuleDestroy
 * Disconnects the Prisma client from the database.
 */

@Injectable()
export class PrismaService
  extends PrismaClient
  implements OnModuleInit, OnModuleDestroy
{
  constructor() {
    super({
      log: ['error', 'warn'],
    });
  }

  async onModuleInit(): Promise<void> {
    await this.$connect();
  }

  async onModuleDestroy(): Promise<void> {
    await this.$disconnect();
  }
}
