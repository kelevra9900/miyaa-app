const CONFIG = {
  features: {
    blog_link: true,
  },
};

export { CONFIG };
