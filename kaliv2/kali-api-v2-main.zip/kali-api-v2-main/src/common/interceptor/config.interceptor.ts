import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { CONFIG } from './config';

@Injectable()
export class ConfigInterceptor implements NestInterceptor {
  /**
   * Intercepts the execution context and handles the call.
   *
   * @param context The execution context.
   * @param next The call handler.
   * @returns An Observable of unknown type.
   */
  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    return next.handle().pipe(
      map((data) => ({
        ...data,
        config: CONFIG,
      })),
    );
  }
}
