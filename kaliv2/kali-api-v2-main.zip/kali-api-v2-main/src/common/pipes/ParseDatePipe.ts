import { BadRequestException, Injectable, PipeTransform } from '@nestjs/common';

/**
 * Class: ParseDatePipe
 *
 * Description: This class is an implementation of the PipeTransform interface and is used as a pipe to transform a string value into a Date object.
 *
 * Methods:
 * - transform(value: string): Date: This method takes a string value as input and returns a Date object. It first creates a new Date object using the input value. If the date is invalid (isNaN(date.getTime())), it throws a BadRequestException with the message 'Validation failed'. Otherwise, it returns the valid Date object.
 *
 * Usage:
 * 1. Import the ParseDatePipe class from the appropriate module.
 * 2. Create an instance of the ParseDatePipe class.
 * 3. Call the transform method on the instance, passing a string value as the argument.
 * 4. The method will return a Date object if the input value is a valid date, otherwise it will throw a BadRequestException.
 *
 * Example:
 * const parseDatePipe = new ParseDatePipe();
 * const date = parseDatePipe.transform('2021-01-01');
 * console.log(date); // Output: Fri Jan 01 2021 00:00:00 GMT+0000 (Coordinated Universal Time)
 */
@Injectable()
export class ParseDatePipe implements PipeTransform {
  transform(value: string) {
    const date = new Date(value);
    if (isNaN(date.getTime())) {
      throw new BadRequestException('Validation failed');
    }
    return date;
  }
}
