import { PipeTransform, Injectable, BadRequestException } from '@nestjs/common';

/**
 * ParseIntPipe class.
 *
 * This class is an implementation of the PipeTransform interface in the @nestjs/common module.
 * It is used to transform a string value into a number by using the parseInt function.
 * If the value cannot be parsed into a number, a BadRequestException is thrown.
 *
 * @param value - The string value to be transformed into a number.
 * @returns The parsed integer value.
 * @throws BadRequestException if the value cannot be parsed into a number.
 */
@Injectable()
export class ParseIntPipe implements PipeTransform<string, number> {
  transform(value: string) {
    const val = parseInt(value, 10);
    if (isNaN(val)) {
      throw new BadRequestException('Validation failed');
    }
    return val;
  }
}
