import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
  UseGuards,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiOperation,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import {Notice,Role} from '@prisma/client';
import {AuthGuard} from '@nestjs/passport';

import {NoticeCreateInput} from './models/request/create-notice-request.dto';
import {NoticeService} from './notice.service';
import {Usr} from '../user/user.decorator';
import {AuthUser} from '../auth/auth-user';
import {PaginationModel} from 'src/notes/models/request/pagination.model';

@ApiTags('Notice')
@Controller('notice')
export class NoticeController {
  constructor(private readonly noticeService: NoticeService) { }

  /**
   * Get Notices
   *
   * Retrieves all notices.
   *
   * @returns {Promise<any>} A promise that resolves to the notices.
   * @throws {Error} If there is an error retrieving the notices.
   */
  @Get()
  @ApiOperation({summary: 'Get Notices'})
  @ApiResponse({status: 403,description: 'Forbidden.'})
  public async getNotices(
    @Query() params: PaginationModel,
  ): Promise<any> {
    return this.noticeService.getNotices(
      params.page ? params.page : 1,
      params.limit ? params.limit : 10,
      params.search ? params.search : '',
    );
  }
  /**
   * Get notice by Id
   *
   * Retrieves a notice by its Id.
   *
   * @param {number} id - The Id of the notice.
   * @returns {Promise<any>} A promise that resolves to the notice.
   * @throws {Error} If there is an error retrieving the notice.
   */
  @Get(':id')
  @ApiOperation({summary: 'Get notice by Id'})
  @ApiResponse({status: 403,description: 'Forbidden.'})
  public async getNoticeById(@Param('id',ParseIntPipe) id: number) {
    return this.noticeService.getNoticeById(id);
  }
  /**
   * Get notice by Environment Id
   *
   * Retrieves a notice by its Environment Id.
   *
   * @param {number} id - The Id of the Environment.
   * @param {AuthUser} user - The authenticated user.
   * @returns {Promise<any>} A promise that resolves to the notice.
   * @throws {Error} If the user is not authorized to view the data or if there is an error retrieving the notice.
   */
  @Get('environment/:id')
  @ApiBearerAuth()
  @UseGuards(AuthGuard())
  public async getNoticeByEnvironmentId(
    @Param('id',ParseIntPipe) id: number,
    @Usr() user: AuthUser,
  ) {
    if (user.environmentId !== id || user.role !== Role.SUPER_ADMIN) {
      return {
        message: 'You are not authorized to view this data.',
        status: 403,
      };
    }
    return this.noticeService.getNoticeByEnvironment(id);
  }
  /**
   * Create Notice
   *
   * Creates a new notice.
   *
   * @param {NoticeCreateInput} data - The data for creating the notice.
   * @param {AuthUser} user - The authenticated user.
   * @returns {Promise<any>} A promise that resolves to the created notice.
   * @throws {Error} If there is an error creating the notice.
   */
  @Post()
  @ApiBearerAuth()
  @UseGuards(AuthGuard())
  @ApiOperation({summary: 'Create Notice'})
  @ApiResponse({status: 403,description: 'Forbidden.'})
  public async createNotice(
    @Body() data: NoticeCreateInput,
    @Usr() user: AuthUser,
  ) {
    data.updatedBy = user.id;
    data.creator = user.firstName + ' ' + user.lastName;
    return this.noticeService.createNotice(data);
  }

  /**
   * Update Notice By Id
   *
   * Updates a notice by its Id.
   *
   * @param {number} id - The Id of the notice.
   * @param {NoticePayload} data - The updated data for the notice.
   * @returns {Promise<any>} A promise that resolves to the updated notice.
   * @throws {Error} If there is an error updating the notice.
   */
  @Put(':id')
  public async updateNoticeById(@Param('id') id: number,@Body() data: Notice) {
    return this.noticeService.updateNoticeById(id,data);
  }
  /**
   * Delete Notice By Id
   *
   * Deletes a notice by its Id.
   *
   * @param {number} id - The Id of the notice.
   * @returns {Promise<any>} A promise that resolves to the deleted notice.
   * @throws {Error} If there is an error deleting the notice.
   */
  @Delete(':id')
  public async deleteNoticeById(@Param('id') id: number) {
    return this.noticeService.deleteNoticeById(id);
  }
}
