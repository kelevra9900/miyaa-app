import {
  IsOptional,
  IsString,
  IsNotEmpty,
  IsNumber,
  IsBoolean,
  IsDateString,
} from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

enum StoreStatus {
  HIGHT = 'HIGHT',
  MEDIUM = 'MEDIUM',
  LOW = 'LOW',
}

export class NoticeCreateInput {
  @IsOptional()
  @IsNumber()
  @ApiProperty({ type: 'number', example: 1 })
  id?: number;

  @IsOptional()
  @ApiProperty({ enum: StoreStatus })
  priority?: StoreStatus | null;

  @IsNotEmpty()
  @IsString()
  @ApiProperty({ type: 'string' })
  creator: string;

  @IsNotEmpty()
  @IsString()
  @ApiProperty({ type: 'string' })
  notice: string;

  @IsOptional()
  @IsString()
  @ApiProperty({ type: 'string' })
  description?: string | null;

  @IsNotEmpty()
  @IsDateString()
  @ApiProperty({ type: 'string', format: 'date-time' })
  effectiveFrom: Date | string;

  @IsNotEmpty()
  @IsDateString()
  @ApiProperty({ type: 'string', format: 'date-time' })
  expiredAt: Date | string;

  @IsOptional()
  @IsString()
  @ApiProperty({ type: 'string' })
  type?: string | null;

  @IsNotEmpty()
  @IsNumber()
  @ApiProperty({ type: 'number' })
  updatedBy: number;

  @IsOptional()
  @IsBoolean()
  @ApiProperty({ type: 'boolean' })
  is_approved?: boolean | null;

  @IsNotEmpty()
  @IsNumber()
  @ApiProperty({ type: 'number' })
  environmentId: number;
}
