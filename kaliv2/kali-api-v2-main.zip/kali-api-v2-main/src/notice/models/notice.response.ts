import {Environment} from '@prisma/client';

enum Priority {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH',
}
export class NoticeResponse {
  id?: number;
  priority: Priority;
  creator: string;
  notice: string;
  description: string;
  effectiveFrom: Date;
  expiredAt: Date;
  type: string;
  environment: Environment;
}

export type NoticePagination = {
  notices: NoticeResponse[];
  total: number;
  totalPages: number;
  currentPage: number;
  perPage: number;
};
