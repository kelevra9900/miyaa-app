import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../common/services/prisma.service';
import { NoticeCreateInput } from './models/request/create-notice-request.dto';
import { StoreStatus } from '@prisma/client';
import { stringToStoreStatus } from 'src/utils';

@Injectable()
export class NoticeService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Retrieves a list of notices with optional pagination and search functionality.
   *
   * @param page - The page number to retrieve. Defaults to 1 if not provided.
   * @param limit - The maximum number of notices to retrieve per page. Defaults to 10 if not provided.
   * @param search - A search string to filter notices by. Notices will be filtered if their notice, description, or creator fields contain the search string (case-insensitive).
   *
   * @returns An object containing the retrieved notices, pagination information, and success status.
   * - data: An array of notices that match the search criteria (if provided) and fall within the specified pagination range.
   * - success: A boolean indicating whether the retrieval was successful.
   * - total: The total number of notices that match the search criteria (if provided).
   * - totalPages: The total number of pages based on the specified limit and total number of notices.
   * - currentPage: The current page number.
   * - perPage: The maximum number of notices per page.
   */
  public async getNotices(page?: number, limit = 0, search?: string) {
    const skip = page ? (page - 1) * limit : 0;
    const take = limit ? limit : 10;
    let notices: any;
    let count: any;
    try {
      if (search) {
        notices = await this.prisma.notice.findMany({
          skip,
          take: Number(take),
          where: {
            OR: [
              {
                notice: {
                  contains: search,
                  mode: 'insensitive',

                },
              },
              {
                description: {
                  contains: search,
                  mode: 'insensitive',
                },
              },
              {
                creator: {
                  contains: search,
                  mode: 'insensitive',
                },
              },
            ],
          },
        });

        count = await this.prisma.notice.count({
          where: {
            OR: [
              {
                notice: {
                  contains: search,
                  mode: 'insensitive',
                },
              },
              {
                description: {
                  contains: search,
                  mode: 'insensitive',
                },
              },
              {
                creator: {
                  contains: search,
                  mode: 'insensitive',
                },
              },
            ],
          },
        });
      } else {
        notices = await this.prisma.notice.findMany({
          skip,
          take: Number(take),
        });

        count = await this.prisma.notice.count();
      }

      // Pagination
      const totalPages = Math.ceil(count / limit);
      const currentPage = page ? page : 1;
      const perPage = limit ? limit : 10;
      return {
        data: notices,
        success: true,
        total: count,
        totalPages,
        currentPage,
        perPage,
      };
    } catch (e) {
      console.log(e);
      return {
        data: e,
        success: false,
      };
    }
  }
  /**
   * Retrieves a notice by its ID.
   *
   * @param id - The ID of the notice to retrieve.
   *
   * @returns An object containing the retrieved notice and success status.
   * - data: The notice that matches the provided ID.
   * - success: A boolean indicating whether the retrieval was successful.
   */
  public async getNoticeById(id: number) {
    try {
      const notice = await this.prisma.notice.findUnique({
        where: {
          id,
        },
      });
      return {
        data: notice,
        success: true,
      };
    } catch (e) {
      Logger.log(e);
      return {
        data: e,
        success: false,
      };
    }
  }
  /**
   * Updates a notice by its ID.
   *
   * @param id - The ID of the notice to update.
   * @param input - An object containing the updated notice data.
   *   - priority: The priority of the notice. Defaults to 'LOW' if not provided.
   *   - notice: The notice content.
   *   - description: The description of the notice.
   *   - effectiveFrom: The effective date of the notice.
   *   - expiredAt: The expiration date of the notice.
   *   - updatedBy: The user who updated the notice.
   *
   * @returns An object containing the updated notice and success status.
   *   - data: The updated notice.
   *   - success: A boolean indicating whether the update was successful.
   */
  public async updateNoticeById(id: number, input: any) {
    try {
      const notice = await this.prisma.notice.update({
        where: {
          id: Number(id),
        },
        data: {
          priority: stringToStoreStatus(input.priority ?? 'LOW'),
          notice: input.notice,
          description: input.description,
          effectiveFrom: new Date(input.effectiveFrom),
          expiredAt: new Date(input.expiredAt),
          updatedBy: input.updatedBy,
        },
      });
      return {
        data: notice,
        success: true,
      };
    } catch (e) {
      Logger.log(e);
      return {
        data: e,
        success: false,
      };
    }
  }
  /**
   * Creates a new notice.
   *
   * @param data - An object containing the notice data.
   *   - id: The ID of the notice (optional).
   *   - priority: The priority of the notice (optional). Defaults to 'LOW' if not provided.
   *   - creator: The creator of the notice.
   *   - notice: The notice content.
   *   - description: The description of the notice (optional).
   *   - effectiveFrom: The effective date of the notice.
   *   - expiredAt: The expiration date of the notice.
   *   - type: The type of the notice (optional).
   *   - updatedBy: The user who updated the notice.
   *   - is_approved: Whether the notice is approved (optional).
   *   - environmentId: The ID of the environment.
   *
   * @returns An object containing the created notice and success status.
   *   - data: The created notice.
   *   - success: A boolean indicating whether the creation was successful.
   */
  public async createNotice(data: NoticeCreateInput) {
    try {
      const notice = await this.prisma.notice.create({
        data: {
          ...data,
          effectiveFrom: new Date(data.effectiveFrom),
          expiredAt: new Date(data.expiredAt),
          priority: stringToStoreStatus(data.priority ?? 'LOW'),
        },
      });
      return {
        data: notice,
        success: true,
      };
    } catch (e) {
      Logger.log(e);
      return {
        data: e,
        success: false,
      };
    }
  }
  /**
   * Deletes a notice by its ID.
   *
   * @param id - The ID of the notice to delete.
   *
   * @returns An object containing the deleted notice and success status.
   *   - data: The deleted notice.
   *   - success: A boolean indicating whether the deletion was successful.
   */
  public async deleteNoticeById(id: number) {
    try {
      const notice = await this.prisma.notice.delete({
        where: {
          id: Number(id),
        },
      });
      return {
        data: notice,
        success: true,
      };
    } catch (e) {
      Logger.log(e);
      return {
        data: e,
        success: false,
      };
    }
  }
  /**
   * Retrieves notices by environment ID.
   *
   * @param environmentId - The ID of the environment.
   *
   * @returns An object containing the retrieved notices and success status.
   *   - data: An array of notices that belong to the specified environment.
   *   - success: A boolean indicating whether the retrieval was successful.
   */
  public async getNoticeByEnvironment(environmentId: number) {
    try {
      const notice = await this.prisma.notice.findMany({
        where: {
          environmentId,
        },
        orderBy: {
          priority: 'asc',
        },
      });
      return {
        data: notice,
        success: true,
      };
    } catch (e) {
      Logger.log(e);
      return {
        data: e,
        success: false,
      };
    }
  }
}
