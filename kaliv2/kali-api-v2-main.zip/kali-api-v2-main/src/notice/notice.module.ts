import { Module } from '@nestjs/common';
import { NoticeController } from './notice.controller';
import { NoticeService } from './notice.service';
import { PassportModule } from '@nestjs/passport';
import { PrismaService } from '../common/services/prisma.service';

@Module({
  imports: [PassportModule.register({ defaultStrategy: 'jwt' })],
  controllers: [NoticeController],
  providers: [NoticeService, PrismaService],
  exports: [NoticeService],
})
export class NoticeModule {}
