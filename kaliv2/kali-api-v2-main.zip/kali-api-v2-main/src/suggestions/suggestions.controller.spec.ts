import { PassportModule } from '@nestjs/passport';
import { Test, TestingModule } from '@nestjs/testing';
import { Suggestion } from '@prisma/client';
import { PrismaService } from '../common/services/prisma.service';
import { SuggestionsController } from './suggestions.controller';
import { SuggestionsService } from './suggestions.service';

describe('SuggestionsController', () => {
  let controller: SuggestionsController;
  let spyService: SuggestionsService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [SuggestionsController],
      providers: [SuggestionsService, PrismaService],
      imports: [PassportModule.register({ defaultStrategy: 'jwt' })],
    }).compile();

    controller = module.get<SuggestionsController>(SuggestionsController);
    spyService = module.get<SuggestionsService>(SuggestionsService);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
    expect(spyService).toBeDefined();
  });

  it('Should get all suggestions', async () => {
    await controller.getSuggestions();
    jest.spyOn(spyService, 'getSuggestions').mockResolvedValue({
      data: [],
      totalPages: 0,
      currentPage: 0,
      perPage: 0,
      total: 0,
    });
  });

  // it('Should get suggestion by id', async () => {
  //   const data: any = {
  //     id: 1,
  //     content: 'content',
  //     userId: 1,
  //     createdAt: new Date(),
  //     user: {},
  //   };
  //   await controller.getSuggestionById(1);
  //   jest.spyOn(spyService, 'getSuggestionEntityById').mockResolvedValue(data);
  // });

  // it('Should create a suggestion', async () => {
  //   const suggestion: Suggestion = {
  //     id: 1,
  //     content: 'Content',
  //     userId: 0,
  //     createdAt: new Date(),
  //   };

  //   await controller.createSuggestion(suggestion.content, suggestion.userId);
  //   jest.spyOn(spyService, 'createSuggestion').mockResolvedValue(suggestion);
  // });
});
