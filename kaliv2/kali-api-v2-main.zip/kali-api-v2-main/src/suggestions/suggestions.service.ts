import { Injectable } from '@nestjs/common';
import { PrismaService } from '../common/services/prisma.service';
import { CreateSuggestionRequest } from './models/request/create-suggestion-request';

@Injectable()
export class SuggestionsService {
  constructor(private readonly prismaService: PrismaService) {}

  /**
   * Retrieves a suggestion entity by its ID.
   *
   * @param id - The ID of the suggestion entity.
   * @returns A suggestion entity object with the corresponding ID, including the associated user information.
   */
  public async getSuggestionEntityById(id: number) {
    const suggestion: any = await this.prismaService.suggestion.findUnique({
      where: { id },
    });

    const response = await this.prismaService.user.findUnique({
      where: { id: suggestion.userId },
    });

    return {
      ...suggestion,
      user: response,
    };
  }

  /**
   * Retrieves a list of suggestions with pagination.
   *
   * @param page - The page number.
   * @param limit - The maximum number of suggestions per page.
   * @returns An object containing the suggestions, total count, total pages, current page, and number of suggestions per page.
   */
  public async getSuggestions(page: number, limit: number) {
    const skip = page ? (page - 1) * limit : 0;
    const take = limit ? limit : 15;

    const suggestions = await this.prismaService.suggestion.findMany({
      skip,
      take,
    });
    const count = await this.prismaService.suggestion.count();
    // Pagination
    const totalPages = Math.ceil(count / limit);
    const currentPage = page ? page : 1;
    const perPage = limit ? limit : 10;

    const response = suggestions.map(async (suggestion) => ({
      ...suggestion,
      user: await this.prismaService.user.findUnique({
        where: { id: suggestion.userId },
      }),
    }));

    const newResponse = await Promise.all(response);

    const suggestionsWithUser = newResponse.map((suggestion) => ({
      ...suggestion,
      user: {
        id: suggestion.user?.id,
        firstName: suggestion.user?.firstName,
        lastName: suggestion.user?.lastName,
        username: suggestion.user?.username,
        email: suggestion.user?.email,
        image: suggestion.user?.image,
        registrationDate: suggestion.user?.registrationDate,
      },
    }));

    return {
      suggestions: suggestionsWithUser,
      total: count,
      totalPages,
      currentPage,
      perPage,
    };
  }
  /**
   * Creates a new suggestion.
   *
   * @param suggestion - The suggestion object containing the content, userId, and optional rating.
   * @returns A promise that resolves to the created suggestion object.
   */
  public async createSuggestion(suggestion: CreateSuggestionRequest) {
    return this.prismaService.suggestion.create({
      data: {
        ...suggestion,
      },
    });
  }
  /**
   * Updates a suggestion entity with the specified ID.
   *
   * @param id - The ID of the suggestion entity to update.
   * @param content - The new content for the suggestion.
   * @returns A promise that resolves to the updated suggestion object.
   */
  public async updateSuggestion(id: number, content: string) {
    return this.prismaService.suggestion.update({
      where: { id },
      data: { content },
    });
  }
  /**
   * Deletes a suggestion entity with the specified ID.
   *
   * @param id - The ID of the suggestion entity to delete.
   * @returns A promise that resolves to the deleted suggestion object.
   */
  public async deleteSuggestion(id: number) {
    return this.prismaService.suggestion.delete({
      where: { id },
    });
  }

  /**
   * Retrieves a list of suggestions by user ID.
   *
   * @param userId - The ID of the user.
   * @returns A promise that resolves to an array of suggestion objects associated with the user.
   */
  public async getSuggestionByUserId(userId: number) {
    return this.prismaService.suggestion.findMany({
      where: { userId },
    });
  }
}
