import {
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  ParseIntPipe,
  Post,
  Put,
  UseGuards,
  Query,
  Body,
} from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { SuggestionResponse } from './models';
import { CreateSuggestionRequest } from './models/request/create-suggestion-request';
import { SuggestionsService } from './suggestions.service';

@ApiTags('Suggestions')
@ApiBearerAuth()
@UseGuards(AuthGuard())
@Controller('suggestions')
export class SuggestionsController {
  constructor(private readonly suggestionService: SuggestionsService) {}

  /**
   * Retrieves a list of suggestions.
   *
   * @param page The page number of the results (default: 1).
   * @param limit The maximum number of suggestions per page (default: 15).
   * @returns A list of suggestions.
   */
  @Get()
  @HttpCode(HttpStatus.OK)
  async getSuggestions(@Query('page') page = 1, @Query('limit') limit = 15) {
    return this.suggestionService.getSuggestions(Number(page), Number(limit));
  }

  /**
   * Retrieves a suggestion by its ID.
   *
   * @param id The ID of the suggestion.
   * @returns The suggestion entity.
   */
  @Get(':id')
  @HttpCode(HttpStatus.OK)
  async getSuggestionById(@Param('id', ParseIntPipe) id: number) {
    return this.suggestionService.getSuggestionEntityById(id);
  }

  /**
   * Retrieves suggestions by user ID.
   *
   * @param id The ID of the user.
   * @returns A promise that resolves to an array of SuggestionResponse objects.
   */
  @Get('user/:id')
  @HttpCode(HttpStatus.OK)
  async getSuggestionByUserId(
    @Param('id', ParseIntPipe) id: number,
  ): Promise<SuggestionResponse[]> {
    return this.suggestionService.getSuggestionByUserId(id);
  }
  /**
   * Creates a new suggestion.
   *
   * @param suggestion The suggestion object containing the content and userId.
   * @returns A promise that resolves to the created suggestion.
   */
  @Post()
  @HttpCode(HttpStatus.CREATED)
  async createSuggestion(
    @Body() suggestion: CreateSuggestionRequest,
  ): Promise<SuggestionResponse> {
    return this.suggestionService.createSuggestion(suggestion);
  }
  /**
   * Updates a suggestion by its ID.
   *
   * @param id The ID of the suggestion.
   * @param content The updated content of the suggestion.
   * @returns A promise that resolves to the updated suggestion.
   */
  @Put(':id')
  @HttpCode(HttpStatus.OK)
  async updateSuggestion(
    @Param('id', ParseIntPipe) id: number,
    @Param('content') content: string,
  ): Promise<SuggestionResponse> {
    return this.suggestionService.updateSuggestion(id, content);
  }
  /**
   * Deletes a suggestion by its ID.
   *
   * @param id The ID of the suggestion.
   * @returns A promise that resolves to an object with a message indicating the deletion status.
   */
  @Delete(':id')
  @HttpCode(HttpStatus.OK)
  async deleteSuggestion(@Param('id', ParseIntPipe) id: number): Promise<any> {
    await this.suggestionService.deleteSuggestion(id);
    return {
      message: 'Suggestion deleted',
    };
  }
}
