import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt, IsNotEmpty, IsString } from 'class-validator';

export class CreateSuggestionRequest {
  @ApiProperty({ required: true })
  @IsString()
  content: string;

  @ApiProperty({ required: true })
  @IsNotEmpty()
  @IsInt()
  userId: number;

  @ApiProperty({ required: false })
  @IsInt()
  @Transform((value) => Number(value))
  rating?: number;
}
