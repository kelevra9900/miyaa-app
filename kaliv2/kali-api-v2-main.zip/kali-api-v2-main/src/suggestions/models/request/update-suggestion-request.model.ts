import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsNotEmpty, Matches } from 'class-validator';

export class UpdateSuggestionRequest {
  @IsNotEmpty()
  @ApiProperty({
    type: 'number',
  })
  @Matches(RegExp('^[0-9]+$'))
  id: number;

  @IsNotEmpty()
  @ApiProperty({
    type: 'string',
  })
  @Matches(RegExp('^[a-zA-Z0-9]+$'))
  content: string;

  @IsNotEmpty()
  @ApiProperty({
    type: 'string',
  })
  @Transform(({ value }) => Number(value), { toClassOnly: true })
  userId: string;
}
