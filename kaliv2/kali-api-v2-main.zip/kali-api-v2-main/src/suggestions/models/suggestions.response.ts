import type { Suggestion } from '@prisma/client';

export class SuggestionResponse {
  id: number;
  content: string;
  userId: number;
  user?: {
    id: number;
    name: string;
    username: string;
    email: string;
    image: null;
    registration: Date;
  };

  static fromSuggestionEntity(entity: Suggestion): SuggestionResponse {
    const response = new SuggestionResponse();
    response.id = entity.id;
    response.content = entity.content;
    response.userId = entity.userId;
    return response;
  }
}

export type SuggestionPagination = {
  suggestions: SuggestionResponse[];
  total: number;
  totalPages: number;
  currentPage: number;
  perPage: number;
};
