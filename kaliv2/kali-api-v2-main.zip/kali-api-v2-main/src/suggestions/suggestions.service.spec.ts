import { Test, TestingModule } from '@nestjs/testing';
import { DeepMockProxy, mockDeep } from 'jest-mock-extended';
import { PrismaService } from '../common/services/prisma.service';
import { SuggestionsService } from './suggestions.service';

describe('SuggestionsService', () => {
  let service: SuggestionsService;
  let spyPrismaService: DeepMockProxy<PrismaService>;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        SuggestionsService,
        {
          provide: PrismaService,
          useFactory: () => mockDeep<PrismaService>(),
        },
      ],
    }).compile();

    service = module.get<SuggestionsService>(SuggestionsService);
    spyPrismaService = module.get(
      PrismaService,
    ) as DeepMockProxy<PrismaService>;
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  // it('Should get all suggestions', async () => {
  //   await service.getSuggestions();
  //   // Map suggestion
  //   expect(spyPrismaService.suggestion.findMany).toBeCalledTimes(1);
  // });

  // it('Should get suggestion by id', async () => {
  //   const id = 123;
  //   await service.getSuggestionEntityById(id);
  //   expect(spyPrismaService.suggestion.findUnique).toBeCalledTimes(1);
  //   expect(spyPrismaService.suggestion.findUnique).toBeCalledWith({
  //     where: { id },
  //   });
  // });

  it('Should create a suggestion', async () => {
    const content = 'content';
    const userId = 123;
    await service.createSuggestion(content, userId);
    expect(spyPrismaService.suggestion.create).toBeCalledTimes(1);
    expect(spyPrismaService.suggestion.create).toBeCalledWith({
      data: {
        content,
        userId,
      },
    });
  });

  it('Should delete a suggestion', async () => {
    const id = 123;
    await service.deleteSuggestion(id);
    expect(spyPrismaService.suggestion.delete).toBeCalledTimes(1);
    expect(spyPrismaService.suggestion.delete).toBeCalledWith({
      where: { id },
    });
  });

  it('Should update a suggestion', async () => {
    const id = 123;
    const content = 'content';
    await service.updateSuggestion(id, content);
    expect(spyPrismaService.suggestion.update).toBeCalledTimes(1);
    expect(spyPrismaService.suggestion.update).toBeCalledWith({
      where: { id },
      data: { content },
    });
  });
});
