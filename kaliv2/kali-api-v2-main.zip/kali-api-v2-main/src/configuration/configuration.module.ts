import { Module } from '@nestjs/common';
import { PassportModule } from '@nestjs/passport';
import { ConfigurationController } from './configuration.controller';
import { ConfigurationService } from './configuration.service';
import { PrismaService } from '../common/services/prisma.service';

@Module({
  imports: [PassportModule.register({ defaultStrategy: 'jwt' })],
  controllers: [ConfigurationController],
  providers: [ConfigurationService, PrismaService],
  exports: [ConfigurationService],
})
export class ConfigurationModule {}
