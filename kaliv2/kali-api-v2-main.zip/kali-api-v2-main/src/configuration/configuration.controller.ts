import {
  Body,
  Controller,
  Get,
  Param,
  Put,
  Post,
  UseGuards,
  Query,
  ParseIntPipe,
  Delete,
} from '@nestjs/common';
import {AuthGuard} from '@nestjs/passport';
import {ApiBearerAuth,ApiTags} from '@nestjs/swagger';
import {Environment} from '@prisma/client';
import {ConfigurationService} from './configuration.service';
import {
  EnvironmentPagination,
  EnvironmentRequest,
} from './models/environment-request';

@ApiTags('Configuration')
@ApiBearerAuth()
@UseGuards(AuthGuard())
@Controller('configuration')
export class ConfigurationController {
  constructor(private readonly configurationService: ConfigurationService) { }

  /**
   * Retrieves a paginated list of environments.
   *
   * @param page The page number to retrieve.
   * @param limit The maximum number of environments per page.
   * @param search The search query to filter environments.
   * @returns A Promise that resolves to an EnvironmentPagination object containing the paginated list of environments.
   */
  @Get('environments')
  public async getEnvironments(
    @Query('page',ParseIntPipe) page: number,
    @Query('limit',ParseIntPipe) limit: number,
    @Query('search') search: string,
  ): Promise<EnvironmentPagination> {
    return this.configurationService.findAll(page,limit,search);
  }
  /**
   * Modifies an environment.
   *
   * @param id The ID of the environment to modify.
   * @param data The data to update the environment with.
   * @returns A Promise that resolves to the modified environment.
   */
  @Put('environments/:id')
  public async modifyEnvironment(
    @Param('id') id: number,
    @Body() data: EnvironmentRequest,
  ): Promise<Environment> {
    return this.configurationService.modifyEnvironment(id,data);
  }
  /**
   * Retrieves an environment by ID.
   *
   * @param id The ID of the environment to retrieve.
   * @returns A Promise that resolves to the environment object, or null if not found.
   */
  @Get('environments/:id')
  public async getEnvironment(
    @Param('id') id: number,
  ): Promise<Environment | null> {
    return this.configurationService.getEnvironment(id);
  }
  /**
   * Creates a new environment.
   *
   * @param data The data for the new environment.
   * @returns A Promise that resolves to the created environment.
   */
  @Post('environments')
  public async createEnvironment(
    @Body() data: EnvironmentRequest,
  ): Promise<Environment> {
    return this.configurationService.createEnvironment(data);
  }
  /**
   * Deletes an environment by ID.
   *
   * @param id The ID of the environment to delete.
   * @returns A Promise that resolves to void.
   */
  @Delete('environments/:id')
  public async deleteEnvironment(@Param('id',ParseIntPipe) id: number) {
    return this.configurationService.deleteEnvironment(id);
  }
}
