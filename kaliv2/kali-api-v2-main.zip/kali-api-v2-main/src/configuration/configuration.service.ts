import {Injectable,Logger} from '@nestjs/common';
import {PrismaService} from '../common/services/prisma.service';
import {EnvironmentRequest} from './models/environment-request';
import {slugify} from 'src/utils';
import {ApiBody} from '@nestjs/swagger';
import {Environment} from '@prisma/client';

@Injectable()
export class ConfigurationService {
  constructor(private readonly prisma: PrismaService) { }

  /**
   * Creates a new environment.
   *
   * @param data - The data for the new environment.
   * @returns The created environment.
   * @throws If an error occurs during the creation process.
   */
  @ApiBody({type: EnvironmentRequest})
  async createEnvironment(data: EnvironmentRequest) {
    try {
      const environment = await this.prisma.environment.create({
        data: {
          name: data.name,
          primary_color: data.primary_color,
          secondary_color: data.secondary_color,
          logo: data.logo,
          description: data.description,
          Segment: {
            create: {
              name: slugify(data.name),
            },
          },
        },
      });

      return environment;
    } catch (e) {
      console.log(e);
      return e;
    }
  }
  /**
   * Retrieves an environment by its ID.
   *
   * @param id - The ID of the environment to retrieve.
   * @returns The retrieved environment.
   * @throws If an error occurs during the retrieval process.
   */
  async getEnvironment(id: number) {
    try {
      const environment = await this.prisma.environment.findUnique({
        where: {
          id: Number(id),
        },
      });

      return environment;
    } catch (e) {
      console.log(e);
      throw e;
    }
  }

  /**
   * Modifies an environment by its ID.
   *
   * @param id - The ID of the environment to modify.
   * @param data - The data to modify the environment with.
   * @returns The modified environment.
   * @throws If the environment with the given ID is not found.
   * @throws If an error occurs during the modification process.
   */
  @ApiBody({type: EnvironmentRequest})
  async modifyEnvironment(id: number,data: EnvironmentRequest) {
    const findEnvironment = await this.prisma.environment.findUnique({
      where: {
        id: Number(id),
      },
    });

    if (!findEnvironment) {
      throw new Error('Environment not found');
    }

    try {
      const environment = await this.prisma.environment.update({
        where: {
          id: Number(id),
        },
        data: {
          name: data.name,
          primary_color: data.primary_color,
          secondary_color: data.secondary_color,
          logo: data.logo,
          description: data.description,
        },
      });

      return environment;
    } catch (e) {
      throw e;
    }
    // try {
    //   const environment = await this.prisma.environment.update({
    //     where: {
    //       id: Number(id),
    //     },
    //     data: {
    //       name: data.name,
    //       primary_color: data.primary_color,
    //       secondary_color: data.secondary_color,
    //       logo: data.logo,
    //       description: data.description,
    //       Segment: {
    //         update: {
    //           name: slugify(data.name),
    //         },
    //       },
    //     },
    //   });

    //   return environment;
    // } catch (e) {
    //   console.log(e);
    //   throw e;
    // }
  }

  /**
   * Retrieves a list of environments with pagination and search functionality.
   *
   * @param page - The page number to retrieve. Default is 1.
   * @param limit - The maximum number of environments per page. Default is 10.
   * @param search - Optional search query to filter environments by name, primary color, or secondary color.
   * @returns An object containing the list of environments, total number of environments, total number of pages, current page number, and number of environments per page.
   * @throws If an error occurs during the retrieval process.
   */
  async findAll(page = 1,limit = 10,search?: string) {
    const total = await this.getTotalEnviromentsCount(search);
    const environments = await this.getEnviromentsList(page,limit,search);

    const totalPages = Math.ceil(total / limit);
    const currentPage = page;
    const perPage = limit;

    return {
      environments,
      total,
      totalPages,
      currentPage,
      perPage,
    };
  }

  /**
   * Retrieves the total number of environments.
   *
   * @param search - Optional search query to filter environments by first name, last name, or email.
   * @returns The total number of environments.
   * @throws If an error occurs during the retrieval process.
   */
  async getTotalEnviromentsCount(search?: string): Promise<number> {
    try {
      if (search) {
        return this.prisma.user.count({
          where: {
            OR: [
              {
                firstName: {
                  contains: search,
                  mode: 'insensitive',
                },
              },
              {
                lastName: {
                  contains: search,
                  mode: 'insensitive',
                },
              },
              {
                email: {
                  contains: search,
                  mode: 'insensitive',
                },
              },
            ],
          },
        });
      }
      return this.prisma.user.count();
    } catch (e) {
      console.log(e);
      throw e;
    }
  }

  /**
   * Retrieves a list of environments with pagination and search functionality.
   *
   * @param page - The page number to retrieve. Default is 1.
   * @param limit - The maximum number of environments per page. Default is 10.
   * @param search - Optional search query to filter environments by name, primary color, or secondary color.
   * @returns An array of environments.
   * @throws If an error occurs during the retrieval process.
   */
  async getEnviromentsList(
    page = 1,
    limit = 10,
    search?: string,
  ): Promise<Environment[]> {
    if (search) {
      const skip = (page - 1) * limit;
      const environments = await this.prisma.environment.findMany({
        skip,
        take: limit,
        where: {
          OR: [
            {
              name: {
                contains: search,
                mode: 'insensitive',
              },
            },
            {
              primary_color: {
                contains: search,
                mode: 'insensitive',
              },
            },
            {
              secondary_color: {
                contains: search,
                mode: 'insensitive',
              },
            },
          ],
        },
      });
      return environments;
    }

    const skip = (page - 1) * limit;
    const environments = await this.prisma.environment.findMany({
      skip,
      take: limit,
    });
    return environments;
  }

  /**
   * Deletes an environment by its ID.
   *
   * @param id - The ID of the environment to delete.
   * @returns An object with a message indicating the success of the deletion.
   * @throws If the environment with the given ID is not found.
   * @throws If an error occurs during the deletion process.
   */
  async deleteEnvironment(id: number) {
    try {
      const environment = await this.prisma.environment.findUnique({
        where: {
          id,
        },
      });

      if (!environment) {
        return {
          message: 'Environment not found',
        };
      }

      await this.prisma.environment.update({
        where: {
          id,
        },
        data: {
          Segment: {
            delete: true,
          },
        },
      });

      await this.prisma.environment.delete({
        where: {
          id,
        },
      });

      return {
        message: 'Environment deleted successfully',
      };
    } catch (e) {
      throw new Error(e);
    }
  }
}
