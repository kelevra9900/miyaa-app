import {
  IsNotEmpty,
  IsMongoId,
  IsString,
  IsEmpty,
  IsBoolean,
} from 'class-validator';

export class NotificationRequest {
  @IsNotEmpty()
  @IsMongoId()
  user_id: number;

  @IsString()
  @IsNotEmpty()
  title: string;

  @IsString()
  @IsNotEmpty()
  body: string;

  @IsBoolean()
  @IsEmpty()
  read: boolean;
}
