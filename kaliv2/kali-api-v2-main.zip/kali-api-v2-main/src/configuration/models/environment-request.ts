import {ApiProperty} from '@nestjs/swagger';
import {Environment} from '@prisma/client';
import {
  IsNotEmpty,
  IsString,
  IsArray,
  IsObject,
  IsOptional,
} from 'class-validator';

export class EnvironmentRequest {
  @IsString()
  logo?: string;

  @ApiProperty({
    type: String,
    description: 'The name of the environment',
    example: 'Kali Connect',
  })
  @IsNotEmpty()
  @IsString()
  name: string;

  @ApiProperty({
    type: String,
    description: 'The description of the environment',
    example: 'Kali Connect is a platform to connect with your friends',
  })
  @IsString()
  description: string;

  @ApiProperty({
    type: Array,
    description: 'The users that have access to the environment',
    example: [],
  })
  @IsOptional()
  @IsArray()
  users: string[];

  @IsObject()
  @IsOptional()
  segment: object;

  @ApiProperty({
    type: String,
    description: 'The primary color of the environment',
    example: '#000000',
  })
  @IsString()
  @IsOptional()
  primary_color: string;

  @ApiProperty({
    type: String,
    description: 'The secondary color of the environment',
    example: '#000000',
  })
  @IsString()
  @IsOptional()
  secondary_color: string;
}

export type EnvironmentPagination = {
  environments: Environment[];
  total: number;
  totalPages: number;
  currentPage: number;
  perPage: number;
};
