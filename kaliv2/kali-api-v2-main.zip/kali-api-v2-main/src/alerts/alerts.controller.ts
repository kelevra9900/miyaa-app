import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
  UseGuards,
} from '@nestjs/common';
import {AuthGuard} from '@nestjs/passport';
import {ApiBearerAuth,ApiTags} from '@nestjs/swagger';
import {AlertsService} from './alerts.service';
import {UpdateAlertRequest} from './models';
import {AlertPagination} from './models/alert.response';
import {CreateAlertRequest} from './models/request/create-alert-request.model';
import {QueryRequest} from './models/request/query-request';

@ApiTags('Alerts')
@ApiBearerAuth()
@UseGuards(AuthGuard())
@Controller('alerts')
export class AlertsController {
  constructor(private readonly alertService: AlertsService) { }

  @Get()
  @HttpCode(HttpStatus.OK)
  async getAlerts(
    @Query('page') page?: number,
    @Query('limit') limit?: number,
    @Query('search') search?: string,
    @Query('orderBy') orderBy?: string,
  ): Promise<AlertPagination> {
    return this.alertService.getAlerts({
      page: page || 1,
      limit: limit || 15,
      search,
      orderBy,
    });
  }

  @Get(':id')
  @HttpCode(HttpStatus.OK)
  async getAlert(@Param('id',ParseIntPipe) id: number) {
    return this.alertService.getAlert(id);
  }

  @Get('user/:userId')
  @HttpCode(HttpStatus.OK)
  async getAlertsByUser(@Param('userId',ParseIntPipe) userId: number) {
    return this.alertService.getAlertsByUser(userId);
  }

  @Post()
  @HttpCode(HttpStatus.CREATED)
  async createAlert(@Body() data: CreateAlertRequest) {
    return this.alertService.createAlert(data);
  }

  @Put(':id')
  @HttpCode(HttpStatus.OK)
  async updateAlert(
    @Param('id',ParseIntPipe) id: number,
    @Body() updateRequest: UpdateAlertRequest,
  ) {
    return this.alertService.updateAlert(id,updateRequest);
  }

  @Delete(':id')
  @HttpCode(HttpStatus.OK)
  async deleteAlert(@Param('id',ParseIntPipe) id: number) {
    return this.alertService.deleteAlert(id);
  }

  @Get('export')
  @HttpCode(HttpStatus.OK)
  async exportAlerts(@Query() query: QueryRequest) {
    const {startDate,endDate} = query;
    return this.alertService.exportAlertsByDate(startDate,endDate);
  }

  @Get('userOnline/today')
  @HttpCode(HttpStatus.OK)
  async getUser() {
    return this.alertService.getUsersListActiveTodayService();
  }
}
