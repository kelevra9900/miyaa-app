import {ConflictException,Injectable,Logger} from '@nestjs/common';
import * as firebase from 'firebase-admin';
import {Message} from 'firebase-admin/lib/messaging/messaging-api';

import {PrismaService} from '../common/services/prisma.service';
import {AlertResponse,UpdateAlertRequest} from './models';
import {AlertPagination} from './models/alert.response';
import {CreateAlertRequest} from './models/request/create-alert-request.model';
import {stringToAlertStatus} from '../utils';
import {Alert} from '@prisma/client';

type AlertParams = {
  page: number;
  limit: number;
  search?: string;
  orderBy?: string;
};

@Injectable()
export class AlertsService {
  private readonly logger = new Logger('AuthService');
  constructor(private readonly prisma: PrismaService) { }

  /**
   * Fetches alerts with pagination support and optional search.
   * @param page - Page number.
   * @param limit - Number of items per page.
   * @param search - Optional search query.
   * @returns Promise of AlertPagination.
   */
  public async getAlerts({
    page = 1,
    limit = 15,
    search,
  }: AlertParams): Promise<AlertPagination> {
    const {skip,take} = this.getSkipAndTake(page,limit);

    let alerts = await this.getAlertsBySearch(skip,take,search);

    const count = await this.prisma.alert.count();
    const totalPages = Math.ceil(count / limit);

    return this.buildPaginationResponse(alerts,count,totalPages,page,limit);
  }

  /**
   * Get alert by id with user data
   * @param id
   * @returns Promise of AlertResponse or an error.
   */

  public async getAlert(id: number): Promise<any | null> {
    try {
      const alert = await this.prisma.alert.findUnique({
        where: {id},
        include: {
          user: true,
        },
      });

      // found data user by id
      if (!alert) {
        return {
          message: 'Alert not found',
        };
      }

      const trackerSession = await this.prisma.tracking.findFirst({
        where: {
          userId: alert.userId,
        },
        orderBy: {
          id: 'desc',
        },
      });

      const formatResponse = {
        id: alert.id,
        content: alert.content,
        latitude: alert.latitude,
        longitude: alert.longitude,
        image: alert.image,
        status: alert.status,
        attended: alert.attendedBy,
        createdAt: alert.createdAt,
        updatedAt: alert.updatedAt,
        address: '',
        user: {
          id: alert.user.id,
          name: alert.user.firstName + ' ' + alert.user.lastName,
          email: alert.user.email,
          latestLocation: {
            latitude: trackerSession?.latitude,
            longitude: trackerSession?.longitude,
          },
        },
      };

      return {
        message: 'Alert found',
        alert: formatResponse,
      };
    } catch (error) {
      return {
        message: 'Something went wrong',
        error,
      };
    }
  }

  /**
   * Creates a new alert and ensures the existence of a tracking session for the user.
   * @param data - Data for creating the alert.
   * @returns Promise of AlertResponse or an error.
   */
  public async createAlert(
    data: CreateAlertRequest,
  ): Promise<AlertResponse | any> {
    try {
      await this.ensureTrackingSession(
        data.userId,
        data.latitude,
        data.longitude,
      );

      const alert = await this.prisma.alert.create({
        data,
      });

      return AlertResponse.fromAlertEntity(alert);
    } catch (error) {
      this.logger.error('Error creating alert',error,'AlertsService');
      throw new ConflictException();
    }
  }

  /**
   * Update an alert by id.
   * @param id
   * @param updateRequest
   * @returns Promise
   */
  public async updateAlert(
    id: number,
    updateRequest: UpdateAlertRequest,
  ): Promise<Alert | {message: string}> {
    try {
      const alert = await this.prisma.alert.findUnique({
        where: {id},
      });

      if (!alert) {
        return {
          message: 'Alert not found',
        };
      }

      const user = await this.prisma.user.findUnique({
        where: {id: alert.userId},
      });
      Logger.log('Alert found',JSON.stringify(alert));

      Logger.log('User found with token',user?.fcm);

      if (user && user.fcm) {
        // Log token
        Logger.log('===== userToken ======',user.fcm)
        Logger.log('Sending notification to user','Alerts Service');
        const title = 'Alerta actualizada';
        const body = `El alerta ${alert.id} ha sido actualizada - ${stringToAlertStatus(updateRequest.status)}`;
        await this.sendNotification(
          title,
          body,
          user.fcm ?? '',
          alert.userId,
        );
      }
      return this.prisma.alert.update({
        where: {id},
        data: {
          ...updateRequest,
        },
      });
    } catch (e) {
      this.logger.error(
        'Error update alert with recive message',
        e,
        'Alerts Service',
      );
      throw new ConflictException();
    }
  }

  /**
   * Send push notification to user by id
   * @param title
   * @param body
   * @param fcm
   * @param userId
   * @returns Promise
   */
  private async sendNotification(
    title: string,
    body: string,
    fcm: string,
    userId: number,
  ): Promise<boolean> {
    const message: Message = {
      notification: {
        title,
        body,
      },
      token: fcm,
    };
    await firebase.messaging().send(message);
    const newNotification = await this.prisma.notification.create({
      data: {
        title,
        body,
        user: {
          connect: {
            id: Number(userId),
          },
        },
      },
    });
    return !!newNotification;
  }

  /**
   * Delete an alert by id
   * @param id
   * @returns Promise of Alert or an error.
   */

  public async deleteAlert(id: number): Promise<Alert | {message: string}> {
    // find if exist tracking by user id
    try {
      const alert = await this.prisma.alert.findUnique({
        where: {id},
      });

      if (!alert) {
        return {
          message: 'Alert not found',
        };
      }

      this.logger.log('Alert deleted',JSON.stringify(alert));
      return this.prisma.alert.delete({
        where: {id},
      });
    } catch (e) {
      this.logger.error(
        'Error delete alert with recive message',
        e,
        'Alerts Service',
      );
      throw new ConflictException();
    }
  }

  /**
   * Alert by user id
   * @param userId
   * @returns Promise of last location or an error.
   */
  public async getAlertsByUser(userId: number): Promise<any> {
    try {
      const tracker = await this.prisma.tracking.findFirst({
        where: {userId},
        orderBy: {
          id: 'desc',
        },
      });

      if (!tracker) {
        return {
          message: 'Users without tracking session',
          alerts: [],
          lastLocation: {
            latitude: 0.0,
            longitude: 0.0,
          },
        };
      }

      const alerts = await this.prisma.alert.findMany({
        where: {
          userId,
        },
      });

      return {
        message: 'Alerts found',
        alerts,
        lastLocation: {
          latitude: tracker.latitude,
          longitude: tracker.longitude,
        },
      };
    } catch (e) {
      this.logger.error(
        'Error get alerts by user with recive message',
        e,
        'Alerts Service',
      );
      throw new ConflictException();
    }
  }

  /**
   * This method count all alerts for the admin dashboard, count all alerts
   * @returns Promise of number of alerts or an error.
   */
  public async countAlerts(): Promise<number> {
    try {
      return this.prisma.alert.count();
    } catch (e) {
      this.logger.error(
        'Error count alerts with recive message',
        e,
        'Alerts Service',
      );
      throw new ConflictException();
    }
  }

  /**
   * Export alerts by date range for the admin dashboard
   * @param startDate
   * @param endDate
   * @returns Promise of alerts or an error.
   */
  public async exportAlertsByDate(
    startDate: string,
    endDate: string,
  ): Promise<any> {
    try {
      const alerts = await this.prisma.alert.findMany({
        where: {
          OR: [
            {
              createdAt: {
                gte: startDate,
                lte: endDate,
              },
            },
          ],
        },
      });
      return {
        data: alerts.map((alert) => AlertResponse.fromAlertEntity(alert)),
      };
    } catch (e) {
      this.logger.error(
        'Error export alerts by date with recive message',
        e,
        'Alerts Service',
      );
      throw new ConflictException();
    }
  }

  /**
   * Alert by id
   * @param id
   * @returns Promise of alert or an error.
   */
  public async getAlertById(
    id: number,
  ): Promise<Alert | {message: string; alert: any}> {
    try {
      const alert = await this.prisma.alert.findUnique({
        where: {id},
        include: {
          user: true,
        },
      });

      // found data user by id
      if (!alert) {
        return {
          message: 'Alert not found',
          alert: null,
        };
      }

      const user = await this.prisma.user.findUnique({
        where: {id: alert.userId},
      });

      const formatResponse = {
        id: alert.id,
        content: alert.content,
        createdAt: alert.createdAt,
        updatedAt: alert.updatedAt,
        user: {
          id: user?.id,
          name: user?.firstName + ' ' + user?.lastName,
          email: user?.email,
        },
      };

      this.logger.log('Alert found',JSON.stringify(formatResponse));

      return {
        message: 'Alert found',
        alert: formatResponse,
      };
    } catch (error) {
      return {
        message: `Something went wrong ${error}`,
        alert: null,
      };
    }
  }

  /**
   * Get alerts by month for the admin dashboard
   * @returns Promise of alerts or an error.
   */

  public async getAlertsByYear(): Promise<{data: number[]}> {
    const currentYear = new Date().getFullYear();
    const alerts = await this.prisma.alert.findMany({
      where: {
        createdAt: {
          gte: new Date(currentYear,0,1),
          lte: new Date(currentYear,11,31,23,59,59),
        },
      },
    });

    const alertsByMonth: number[] = Array(12).fill(0);

    alerts.forEach((alert) => {
      if (!alert.createdAt) {
        return;
      }
      const date = new Date(alert.createdAt);
      const month = date.getMonth();
      alertsByMonth[month]++;
    });

    return {data: alertsByMonth};
  }

  /**
   * Track User Location
   * @param userId
   * @param latitude
   * @param longitude
   * @returns Promise of location or an error.
   */

  public async trackLocation(
    userId: number,
    latitude: number,
    longitude: number,
  ) {
    try {
      await this.prisma.user.update({
        where: {id: userId},
        data: {
          online: true,
          lastSeen: new Date(),
        },
      });
      const tracker = await this.prisma.tracking.create({
        data: {
          userId,
          latitude,
          longitude,
        },
        include: {
          user: true,
        },
      });

      return {
        message: 'Location tracked',
        data: tracker,
      };
    } catch (e) {
      this.logger.error(
        'Error update location with recive message',
        e,
        'Alerts Service',
      );
      throw new ConflictException();
    }
  }

  public async latestByUserId(id: number) {
    try {
      const result = await this.prisma.tracking.findMany({
        where: {
          userId: Number(id),
        },
        orderBy: {
          createdAt: 'desc',
        },
        take: 1,
      });

      if (result.length === 0) {
        return {
          message: 'No data found',
          location: null,
        };
      }

      return {
        message: 'Success',
        location: result[0],
      };
    } catch (e) {
      console.log(e);
      throw new Error(e);
    }
  }

  /**
   * Method for skip and take for pagination alerts
   * @param page
   * @param limit
   * @returns
   */
  private getSkipAndTake(page: number,limit: number) {
    const skip = (page - 1) * limit;
    const take = limit;
    return {skip,take};
  }
  /**
   * Methos to get alerts by search with pagination
   * @param skip
   * @param take
   * @param search
   * @returns
   */
  private async getAlertsBySearch(skip: number,take: number,search?: string) {
    const whereCondition: any = search
      ? {
        OR: [
          {
            content: {
              contains: search,
              mode: 'insensitive',
            },
          },
        ],
      }
      : {};

    return this.prisma.alert.findMany({
      skip,
      take: Number(take),
      orderBy: {
        id: 'desc',
      },
      where: whereCondition,
      include: {
        user: true,
      },
    });
  }

  /**
   * Build pagination response
   * @param alerts
   * @param count
   * @param totalPages
   * @param currentPage
   * @param perPage
   * @returns Promise of AlertPagination.
   */
  private buildPaginationResponse(
    alerts: any[],
    count: number,
    totalPages: number,
    currentPage: number,
    perPage: number,
  ): AlertPagination {
    return {
      data: alerts.map((alert) => AlertResponse.fromAlertEntity(alert)),
      total: count,
      totalPages,
      currentPage,
      perPage,
    };
  }

  /**
   * Ensure tracking session
   * @param userId
   * @param latitude
   * @param longitude
   */
  private async ensureTrackingSession(
    userId: number,
    latitude: number,
    longitude: number,
  ): Promise<void> {
    const tracker = await this.prisma.tracking.findFirst({
      where: {
        userId,
      },
      orderBy: {
        id: 'desc',
      },
    });

    if (!tracker) {
      await this.prisma.tracking.create({
        data: {
          userId,
          latitude: Number(latitude),
          longitude: Number(longitude),
        },
      });
    }
  }

  public async getUsersListActive(): Promise<any[]> {
    const whereCondition: any = {
      role: 'USER',
      online: true,
    };

    const users = await this.prisma.user.findMany({
      where: whereCondition,
    });

    if (users.length === 0) return [];

    const trackersPromises: any = users.map(user =>
      this.prisma.tracking.findMany({
        where: {userId: user.id},
        include: {
          user: true
        },
        orderBy: {createdAt: 'desc'},
        take: 1
      })
    );
    const usersTrackers = await Promise.all(trackersPromises);
    return usersTrackers;
  }


  public async getUsersListActiveToday(): Promise<any[]> {
    const now = new Date();
    const startOfDay = new Date(now.getFullYear(),now.getMonth(),now.getDate(),0,0,0,0).toISOString();
    const endOfDay = new Date(now.getFullYear(),now.getMonth(),now.getDate(),23,59,59,999).toISOString();

    const whereCondition: any = {
      role: 'USER',
      online: true,
    };

    const users = await this.prisma.user.findMany({
      where: whereCondition,
    });

    if (users.length === 0) return [];

    const trackersPromises: any = users.map(user =>
      this.prisma.tracking.findMany({
        where: {
          userId: user.id,
          createdAt: {
            gte: startOfDay,
            lte: endOfDay,
          },
        },
        include: {
          user: {
            include: {
              documents: true
            }
          }
        },
        orderBy: {createdAt: 'desc'},
        take: 1,
      })
    );


    const usersTrackers = await Promise.all(trackersPromises);

    return usersTrackers;
  }

  public async getUsersListActiveTodayService(): Promise<any> {
    const now = new Date();
    const startOfDay = new Date(now.getFullYear(),now.getMonth(),now.getDate(),0,0,0,0).toISOString();
    const endOfDay = new Date(now.getFullYear(),now.getMonth(),now.getDate(),23,59,59,999).toISOString();

    const whereCondition: any = {
      role: 'USER',
      online: true,
    };

    try {
      // Obtener la lista de usuarios que cumplen con la condición
      const users = await this.prisma.user.findMany({
        where: whereCondition,
      });

      // Si no hay usuarios, retornar un mensaje de vacío
      if (users.length === 0) {
        return {message: 'No active users found today'};
      }

      // Crear un array de promesas para obtener los trackers de cada usuario
      const trackersPromises = users.map(user =>
        this.prisma.tracking.findMany({
          where: {
            userId: user.id,
            createdAt: {
              gte: startOfDay,
              lte: endOfDay,
            },
          },
          include: {
            user: {
              include: {
                documents: true,
              }
            }
          },
          orderBy: {createdAt: 'desc'},
          take: 1,
        })
      );

      // Ejecutar todas las promesas en paralelo
      const usersTrackers = await Promise.all(trackersPromises);

      // Verificar si no hay datos en usersTrackers
      const hasData = usersTrackers.some(tracker => tracker.length > 0);

      if (!hasData) {
        return {message: 'No tracking data found for active users today'};
      }

      // Retornar los datos de los trackers
      return usersTrackers;
    } catch (error) {
      console.error('Error fetching user trackers:',error);
      throw new Error('An error occurred while fetching user trackers');
    }
  }


}
