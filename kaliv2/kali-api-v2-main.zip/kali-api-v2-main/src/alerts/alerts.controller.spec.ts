// Test file for the alerts controller
import { Reflector } from '@nestjs/core';
import { TestingModule, Test } from '@nestjs/testing';
import { Alert, AlertStatus } from '@prisma/client';
import { AuthGuard, PassportModule } from '@nestjs/passport';

import { PrismaService } from '../common/services/prisma.service';
import { AlertsController } from './alerts.controller';
import { AlertsService } from './alerts.service';
import { UpdateAlertRequest } from './models';
import { AlertPagination, AlertResponse } from './models/alert.response';
import { CreateAlertRequest } from './models/request/create-alert-request.model';

describe('AlertController', () => {
  let controller: AlertsController;
  let spyService: AlertsService;

  // Add token to the request

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [AlertsController],
      providers: [AlertsService, PrismaService],
      imports: [PassportModule.register({ defaultStrategy: 'jwt' })],
    }).compile();

    controller = module.get<AlertsController>(AlertsController);
    spyService = module.get<AlertsService>(AlertsService);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
    expect(spyService).toBeDefined();
  });

  it('should create a new alert', async () => {
    const alert = {
      content: 'test',
      userId: 1,
      latitude: 0,
      longitude: 0,
      status: AlertStatus.CREATED,
    };

    jest.spyOn(spyService, 'createAlert').mockResolvedValue({
      ...alert,
      id: 1,
      status: AlertStatus.CREATED,
    });

    expect(await controller.createAlert(alert)).toEqual({
      ...alert,
      id: 1,
      status: AlertStatus.CREATED,
    });
  });

  it('should return all alerts', async () => {
    const body: AlertPagination = {
      alerts: [],
      total: 0,
      totalPages: 0,
      currentPage: 0,
      perPage: 0,
    };

    jest.spyOn(spyService, 'getAlerts').mockResolvedValue(body);
  });

  it('should return an alert by id', async () => {
    // Get an alert by id
    const alert: Alert = {
      id: 1,
      content: 'test',
      status: AlertStatus.CREATED,
      userId: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
      image: null,
      latitude: 0.0,
      longitude: 0.0,
      attendedBy: 1,
    };

    jest.spyOn(spyService, 'getAlert').mockResolvedValue(alert);

    expect(await controller.getAlert(1)).toBe(alert);
  });

  it('should update an alert', async () => {
    // Update an alert
    const alert: UpdateAlertRequest = {
      content: 'Lorem ipsum',
      userId: 0,
      status: AlertStatus.CREATED,
      id: 0,
    };

    jest.spyOn(spyService, 'updateAlert').mockResolvedValue(alert);
  });

  it('should delete an alert', async () => {
    // Delete an alert
    const alert: UpdateAlertRequest = {
      content: 'Lorem ipsum',
      userId: 0,
      status: AlertStatus.CREATED,
      id: 0,
    };

    jest.spyOn(spyService, 'deleteAlert').mockResolvedValue(alert);
  });

  it('should return all alerts by user', async () => {
    // Get all alerts by user
    const alerts: UpdateAlertRequest[] = [];
    jest.spyOn(spyService, 'getAlertsByUser').mockResolvedValue(alerts);
  });
});
