import { Module } from '@nestjs/common';
import { PassportModule } from '@nestjs/passport';
import { JwtService } from '@nestjs/jwt';

import { AlertsService } from './alerts.service';
import { PrismaService } from '../common/services/prisma.service';
import { AlertsController } from './alerts.controller';
import { AlertsGateway } from './alerts.gateway';
import { AuthService } from '../auth/auth.service';
import { MailSenderService } from '../mail-sender/mail-sender.service';
import { NotificationService } from '../notification/notification.service';

@Module({
  imports: [PassportModule.register({ defaultStrategy: 'jwt' })],
  providers: [
    AuthService,
    JwtService,
    MailSenderService,
    AlertsService,
    PrismaService,
    AlertsGateway,
    NotificationService,
  ],
  exports: [AlertsService],
  controllers: [AlertsController],
})
export class AlertsModule {}
