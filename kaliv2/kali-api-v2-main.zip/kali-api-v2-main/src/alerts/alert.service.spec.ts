import { Test, TestingModule } from '@nestjs/testing';
import { AlertStatus } from '@prisma/client';
import { DeepMockProxy, mockDeep } from 'jest-mock-extended/lib/Mock';
import { PrismaService } from '../common/services/prisma.service';

import { AlertsService } from './alerts.service';
import { UpdateAlertRequest } from './models';

describe('AlertService', () => {
  let service: AlertsService;
  let spyPrismaService: DeepMockProxy<PrismaService>;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AlertsService,
        {
          provide: PrismaService,
          useFactory: () => mockDeep<PrismaService>(),
        },
      ],
    }).compile();

    service = module.get<AlertsService>(AlertsService);
    spyPrismaService = module.get(
      PrismaService,
    ) as DeepMockProxy<PrismaService>;
  });

  describe('getAlert', () => {
    it('should call alert with correct id', async () => {
      const id = 12313242;
      await service.getAlert(id);
      expect(spyPrismaService.alert.findUnique).toBeCalledTimes(1);
      expect(spyPrismaService.alert.findUnique).toHaveBeenCalledWith({
        where: { id },
      });
    });
  });

  describe('createAlert', () => {
    it('should create alert', async () => {
      const data = {
        content: 'test',
        userId: 1,
        latitude: 0.0,
        longitude: 0.0,
      };
      await service.createAlert(data);

      expect(spyPrismaService.alert.create).toBeCalledTimes(1);
      expect(spyPrismaService.alert.create).toHaveBeenCalledWith({
        data,
      });
    });

    describe('updateAlert', () => {
      it('should call Alert and update data', async () => {
        const id = 1;
        const data: UpdateAlertRequest = {
          id: 1,
          content: 'content',
          userId: 1,
          status: AlertStatus.UNDER_REVIEW,
        };

        await service.updateAlert(id, data);
        expect(spyPrismaService.alert.update).toBeCalledTimes(1);
      });
    });

    describe('deleteAlert', () => {
      it('Delete alert', async () => {
        const id = 12313242;
        await service.deleteAlert(id);
        expect(spyPrismaService.alert.delete).toBeCalledTimes(1);
        expect(spyPrismaService.alert.delete).toHaveBeenCalledWith({
          where: { id },
        });
      });
    });
  });
});
