import {Alert,AlertStatus} from '@prisma/client';

export class AlertResponse {
  id: number;
  content: string | null;
  status: AlertStatus | null;
  createdAt?: Date | null;
  updatedAt?: Date | null;
  latitude?: number | null;
  longitude?: number | null;
  image?: string | null;

  static fromAlertEntity(entity: Alert): AlertResponse {
    const response = new AlertResponse();
    response.id = entity.id;
    response.content = entity.content;
    response.status = entity.status ?? AlertStatus.CREATED;
    response.createdAt = entity.createdAt ?? new Date();
    response.updatedAt = entity.updatedAt ?? new Date();
    response.latitude = entity.latitude ?? 0.0;
    response.longitude = entity.longitude ?? 0.0;
    response.image = entity.image ?? null;
    return response;
  }
}

export type AlertPagination = {
  data: AlertResponse[];
  total: number;
  totalPages: number;
  currentPage: number;
  perPage: number;
};