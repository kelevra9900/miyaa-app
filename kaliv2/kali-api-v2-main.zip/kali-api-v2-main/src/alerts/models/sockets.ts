export interface SocketRequest {
  latitude?: number;
  longitude?: number;
  user_id: number;
  content: string;
  image?: string;
}

export interface SocketPaginationRequest {
  user_id: number;
  page: number;
  limit: number;
  search?: string;
  orderBy?: string;
}
