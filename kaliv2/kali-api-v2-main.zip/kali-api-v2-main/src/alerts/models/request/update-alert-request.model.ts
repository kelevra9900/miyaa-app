import {AlertStatus} from '@prisma/client';
import {
  IsNotEmpty,
  IsOptional,
  Matches,
  IsUrl,
  IsEnum,
  IsLatitude,
  IsLongitude,
} from 'class-validator';

export class UpdateAlertRequest {
  @IsNotEmpty()
  @Matches(RegExp('^[0-9]+$'))
  id: number;

  @IsOptional()
  @IsNotEmpty()
  @Matches(RegExp('^[a-zA-Z0-9 ]+$'))
  content?: string;

  @IsOptional()
  @IsUrl()
  image?: string;

  @IsOptional()
  @IsEnum(AlertStatus)
  status: AlertStatus;

  @IsNotEmpty()
  @Matches(RegExp('^[0-9]+$'))
  userId: number;

  @IsOptional()
  @IsNotEmpty()
  createdAt?: Date;

  @IsOptional()
  @IsNotEmpty()
  updatedAt?: Date;

  @IsOptional()
  @IsLatitude()
  latitude?: number;

  @IsOptional()
  @IsLongitude()
  longitude?: number;
}
