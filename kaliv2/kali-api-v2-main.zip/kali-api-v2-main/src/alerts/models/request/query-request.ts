export class QueryRequest {
  startDate: string;
  endDate: string;
}
