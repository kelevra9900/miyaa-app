// Create a model to create alert

// Path: src/alerts/models/request/create-alert-request.model.ts

import {ApiProperty} from '@nestjs/swagger';
import {Transform} from 'class-transformer';
import {IsInt,IsLatitude,IsLongitude,IsOptional,IsString} from 'class-validator';

export class CreateAlertRequest {
  @ApiProperty()
  @IsLatitude()
  latitude: number;

  @ApiProperty()
  @IsLongitude()
  longitude: number;

  @ApiProperty()
  @Transform(({value}) => Number(value),{toClassOnly: true})
  @IsInt()
  userId: number;

  @ApiProperty({
    example: 'http://example.com/image.jpg',
  })
  @IsOptional()
  @IsString()
  image: string;

  @ApiProperty()
  @IsOptional()
  content: string;
}