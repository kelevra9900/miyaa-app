import {Logger} from '@nestjs/common';
import {
  ConnectedSocket,
  MessageBody,
  OnGatewayConnection,
  OnGatewayDisconnect,
  SubscribeMessage,
  WebSocketGateway,
  WebSocketServer,
} from '@nestjs/websockets';
import {Namespace,Socket} from 'socket.io';

import {AlertsService} from './alerts.service';
import {CreateAlertRequest} from './models/request/create-alert-request.model';
import {SocketPaginationRequest} from './models/sockets';
import {AuthService} from 'src/auth/auth.service';

@WebSocketGateway({
  cors: true,
})
export class AlertsGateway implements OnGatewayConnection,OnGatewayDisconnect {
  @WebSocketServer() io: Namespace;

  private readonly logger = new Logger('AlertsGateway');

  constructor(
    private readonly alertsService: AlertsService,
    private readonly authService: AuthService,
  ) { }

  async handleConnection() {
    this.logger.log('Client connected');
  }

  async handleDisconnect() {
    this.logger.log('Client disconnected');
  }

  afterInit() {
    this.logger.log('=======================');
    this.logger.log('Initialized');
    this.logger.log('=======================');
  }

  @SubscribeMessage('alerts')
  async handleAlerts(
    @MessageBody() data: SocketPaginationRequest,
  ): Promise<void> {
    const alerts = await this.alertsService.getAlerts({
      page: data?.page || 1,
      limit: data?.limit || 15,
    });

    Logger.debug(alerts,'AlertsGateway');

    this.io.emit('all_alerts',{
      data: alerts.data,
      total: alerts.total,
      totalPages: alerts.totalPages,
      currentPage: alerts.currentPage,
      perPage: alerts.perPage,
    });
  }

  @SubscribeMessage('user_connect')
  async handleOnline(@ConnectedSocket() socket: Socket): Promise<void> {
    const payload = socket.handshake.headers['authorization'] as string;
    const res = await this.authService.validateToken(payload,true);
    this.io.emit('new_user_online',{
      id: res.userId,
      user: res.name,
      email: res.email,
    });
  }

  // New location event
  @SubscribeMessage('new_location')
  async handleNewLocation(
    @ConnectedSocket() socket: Socket,
    @MessageBody() data: any,
  ): Promise<void> {
    const token = socket.handshake.auth.token as string;
    const res = await this.authService.validateToken(token,true);

    if (isNaN(data.latitude) || isNaN(data.longitude) || res.userId == null) {
      return;
    }

    await this.alertsService.trackLocation(
      res.userId,
      data.latitude,
      data.longitude,
    );
    const userOnline = await this.alertsService.getUsersListActiveToday();
    this.io.emit('new_location',data);
    const trackers = await this.alertsService.latestByUserId(res.userId);
    this.io.emit('user_track',trackers);
    this.io.emit('userTrackOnline',userOnline);
  }

  @SubscribeMessage('user_disconnect')
  async handleOffline(@ConnectedSocket() socket: Socket): Promise<void> {
    const payload = socket.handshake.auth['authorization'];
    const res = await this.authService.validateToken(payload,false);
    this.io.emit('new_user_offline',{
      id: res.userId,
      user: res.name,
      email: res.email,
    });
  }

  @SubscribeMessage('new_alert')
  async handleNewAlert(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: CreateAlertRequest
  ): Promise<void> {
    const token = client.handshake.auth.token || client.handshake.headers.auth as string;

    if (!token) {
      return;
    }

    const user = await this.authService.validateToken(token,true);

    if (!user || !user.userId) {
      return;
    }

    this.logger.log(user);
    const input = {
      latitude: Number(data.latitude),
      longitude: Number(data.longitude),
      content: data.content,
      userId: user.userId,
      image: data.image,
    }


    const alert = await this.alertsService.createAlert(input);
    this.io.emit('new_alert',alert);
  }
}