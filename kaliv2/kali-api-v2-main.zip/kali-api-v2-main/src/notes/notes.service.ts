import {Injectable} from '@nestjs/common';
import {Note} from '@prisma/client';
import * as firebase from 'firebase-admin';

import {PrismaService} from '../common/services/prisma.service';
import {CreateNoteRequest,NotesResponse,UpdateNoteRequest} from './models';
import {NotesPagination} from './models/notes.response';

@Injectable()
export class NotesService {
  constructor(private readonly prisma: PrismaService) { }

  /**
   * Retrieves a paginated list of notes based on the provided parameters.
   *
   * @param page - The page number to retrieve. Defaults to 1 if not provided.
   * @param limit - The maximum number of notes to retrieve per page. Defaults to 10 if not provided.
   * @param search - The search term to filter notes by title or content. Case insensitive.
   * @returns A Promise that resolves to a NotesPagination object containing the paginated notes.
   */
  public async getNotes(
    page?: number,
    limit = 0,
    search?: string,
  ): Promise<NotesPagination> {
    // Pagination and search
    const skip = page ? (page - 1) * limit : 0;
    const take = limit ? limit : 10;
    const notes = await this.prisma.note.findMany({
      skip,
      take: Number(take),
      where: {
        OR: [
          {
            title: {
              contains: search,
              mode: 'insensitive',
            },
          },
          {
            content: {
              contains: search,
              mode: 'insensitive',
            },
          },
        ],
      },
    });

    // Count
    const count = await this.prisma.note.count({
      where: {
        OR: [
          {
            title: {
              contains: search,
              mode: 'insensitive',
            },
          },
          {
            content: {
              contains: search,
              mode: 'insensitive',
            },
          },
        ],
      },
    });

    // Pagination
    const totalPages = Math.ceil(count / limit);
    const currentPage = page ? page : 1;
    const perPage = limit ? limit : 10;

    return {
      data: notes.map((note) => NotesResponse.fromNotesEntity(note)),
      total: count,
      totalPages,
      currentPage,
      perPage,
    };
  }

  // Filter by Array of Category
  public async getNotesByCategory(
    page?: number,
    limit = 0,
    categories?: string[],
  ): Promise<NotesPagination> {
    const skip = page ? (page - 1) * limit : 0;
    const take = limit ? limit : 10;
    let where = {};

    if (categories) {
      where = {
        category: {
          id: {
            in: categories.map(Number),
          },
        },
      };
    }

    // Filter by Array of Category
    const notes = await this.prisma.note.findMany({
      skip,
      take: Number(take),
      where,
    });


    // Count
    const count = await this.prisma.note.count({
      where,
    });

    // Pagination
    const totalPages = Math.ceil(count / limit);
    const currentPage = page ? page : 1;
    const perPage = limit ? limit : 10;

    return {
      data: notes.map((note) => NotesResponse.fromNotesEntity(note)),
      total: count,
      totalPages,
      currentPage,
      perPage,
    };
  }



  // getCategories
  public async getCategories(): Promise<{id: number; name: string}[]> {
    return this.prisma.category.findMany({
      select: {
        id: true,
        name: true,
      },
    });
  }

  /**
   * Retrieves a note by its ID.
   *
   * @param id - The ID of the note to retrieve.
   * @returns A Promise that resolves to the retrieved note, or null if no note is found.
   */
  public async getNoteById(id: number): Promise<Note | null> {
    return this.prisma.note.findUnique({
      where: {id},
    });
  }

  /**
   * Retrieves a note by its slug.
   *
   * @param slug - The slug of the note to retrieve.
   * @returns A Promise that resolves to the retrieved note, or null if no note is found.
   */
  public async getNoteBySlug(slug: string): Promise<Note | null> {
    return this.prisma.note.findUnique({
      where: {slug},
    });
  }
  /**
   * Creates a new note with the provided data.
   *
   * @param data - The data for creating the note.
   * @returns A Promise that resolves to the created note.
   */
  public async createNote(data: CreateNoteRequest): Promise<Note> {
    const payload = {
      notification: {
        title: data.title,
        body: data.content,
      },
    };
    firebase.messaging().sendToTopic('all',payload);
    return this.prisma.note.create({
      data: {
        title: data.title,
        content: data.content,
        slug: data.slug,
        image: data.image,
        thumbnail: data.image,
        updatedAt: new Date(),
        createdAt: new Date(),
        user: {
          connect: {
            id: Number(data.createdBy),
          },
        },
        category: {
          connect: {
            id: Number(data.category_id),
          },
        },
      },
    });
  }
  /**
   * Updates a note by its ID.
   *
   * @param id - The ID of the note to update.
   * @param data - The data for updating the note.
   * @returns A Promise that resolves to the updated note.
   */
  public async updateNoteById(
    id: number,
    data: UpdateNoteRequest,
  ): Promise<Note> {
    const payload = {
      notification: {
        title: data.title,
        body: data.content,
      },
    };
    // firebase.messaging().sendToTopic('all', payload);
    return this.prisma.note.update({
      where: {
        id: Number(id),
      },
      data,
    });
  }

  /**
   * Deletes a note by its ID.
   *
   * @param id - The ID of the note to delete.
   * @returns A Promise that resolves to the deleted note.
   */
  public async deleteNoteById(id: number): Promise<Note> {
    return this.prisma.note.delete({
      where: {
        id: Number(id),
      },
    });

  }
  /**
   * Retrieves the total number of notes.
   *
   * @returns A Promise that resolves to the total number of notes.
   */
  public async countNotes(): Promise<number> {
    return this.prisma.note.count();
  }
}
