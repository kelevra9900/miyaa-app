import { Test, TestingModule } from '@nestjs/testing';
import { DeepMockProxy, mockDeep } from 'jest-mock-extended';
import { PrismaService } from '../common/services/prisma.service';
import { UpdateNoteRequest } from './models';
import { NotesService } from './notes.service';

describe('NotesService', () => {
  let service: NotesService;
  let spyPrismaService: DeepMockProxy<PrismaService>;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        NotesService,
        {
          provide: PrismaService,
          useFactory: () => mockDeep<PrismaService>(),
        },
      ],
    }).compile();

    service = module.get<NotesService>(NotesService);
    spyPrismaService = module.get(
      PrismaService,
    ) as DeepMockProxy<PrismaService>;
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
    expect(spyPrismaService).toBeDefined();
  });

  // it('Should get all notes', async () => {
  //   await service.getNotes();
  //   expect(spyPrismaService.note.findMany).toBeCalledTimes(1);
  // });

  it('Should get note by id', async () => {
    const id = 123;
    await service.getNoteById(id);
    expect(spyPrismaService.note.findUnique).toBeCalledTimes(1);
    expect(spyPrismaService.note.findUnique).toBeCalledWith({
      where: { id },
    });
  });

  it('Should create a note', async () => {
    const data = {
      content: 'test',
      title: 'test',
      createdBy: 0,
      image: 'https://test.com',
    };

    await service.createNote(data);
    expect(spyPrismaService.note.create).toBeCalledTimes(1);
    expect(spyPrismaService.note.create).toBeCalledWith({
      data,
    });
  });

  it('Should update a note', async () => {
    const id = 123;
    const data: UpdateNoteRequest = {
      content: 'test',
      title: 'test',
      createdBy: 0,
      image: 'https://test.com',
      is_approved: true,
      id: 0,
    };

    await service.updateNoteById(id, data);
    expect(spyPrismaService.note.update).toBeCalledTimes(1);
    expect(spyPrismaService.note.update).toBeCalledWith({
      where: { id },
      data,
    });
  });
});
