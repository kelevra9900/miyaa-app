import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
  Query,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Note } from '@prisma/client';
import { UpdateNoteRequest } from './models';
import { NotesPagination } from './models/notes.response';
import { CreateNoteRequest } from './models/request/create-note-request.model';
import { PaginationModel } from './models/request/pagination.model';
import { NotesService } from './notes.service';
import { AuthGuard } from '@nestjs/passport';

@ApiTags('Blog')
@Controller('notes')
export class NotesController {
  constructor(private readonly notesService: NotesService) {}

  /**
   * Retrieves a paginated list of notes.
   *
   * @param params - The pagination parameters.
   * @returns A promise that resolves to a NotesPagination object containing the paginated notes.
   */
  @Get()
  public async getNotes(
    @Query() params: PaginationModel,
  ): Promise<NotesPagination> {
    return this.notesService.getNotes(
      params.page ? params.page : 1,
      params.limit ? params.limit : 10,
      params.search ? params.search : '',
    );
  }

  /**
   * Creates a new note.
   *
   * @param data - The data for creating the note.
   * @returns A promise that resolves to the created note.
   */
  @Post()
  @ApiBearerAuth()
  @UseGuards(AuthGuard())
  public async createNote(@Body() data: CreateNoteRequest): Promise<Note> {
    return this.notesService.createNote(data);
  }

  /**
   * Updates a note by its ID.
   *
   * @param id - The ID of the note to update.
   * @param data - The data for updating the note.
   * @returns A promise that resolves to the updated note.
   */
  @Put(':id')
  @ApiBearerAuth()
  @UseGuards(AuthGuard())
  public async updateNoteById(
    @Param('id') id: number,
    @Body() data: UpdateNoteRequest,
  ): Promise<Note> {
   
    return this.notesService.updateNoteById(id, data);
  }
  /**
   * Deletes a note by its ID.
   *
   * @param id - The ID of the note to delete.
   * @returns A promise that resolves to a message indicating the success of the deletion.
   */
  @Delete(':id')
  @ApiBearerAuth()
  @UseGuards(AuthGuard())
  public async deleteNoteById(@Param('id') id: number) {
    await this.notesService.deleteNoteById(id);
    return {
      message: 'Note deleted successfully',
    };
  }

  /**
   * Retrieves a note by its slug.
   *
   * @param slug - The slug of the note.
   * @returns A promise that resolves to the note with the specified slug, or null if no note is found.
   */
  @Get(':slug')
  public async getNoteBySlug(
    @Param('slug') slug: string,
  ): Promise<Note | null> {
    return this.notesService.getNoteBySlug(slug);
  }
}
