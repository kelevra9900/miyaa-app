import {Module} from '@nestjs/common';
import {PassportModule} from '@nestjs/passport';
import {NotesController} from './notes.controller';
import {NotesService} from './notes.service';
import {PrismaService} from '../common/services/prisma.service';
import {MailSenderService} from 'src/mail-sender/mail-sender.service';
import {JwtService} from '@nestjs/jwt';
import {AuthService} from 'src/auth/auth.service';
import {NotesGateway} from './notes.gateway';

@Module({
  imports: [PassportModule.register({defaultStrategy: 'jwt'})],
  controllers: [NotesController],
  providers: [
    NotesService,
    PrismaService,
    AuthService,
    JwtService,
    MailSenderService,
    NotesGateway
  ],
  exports: [NotesService],
})
export class NotesModule { }
