import {Logger} from '@nestjs/common';
import {
	ConnectedSocket,
	MessageBody,
	OnGatewayConnection,
	OnGatewayDisconnect,
	SubscribeMessage,
	WebSocketGateway,
	WebSocketServer,
} from '@nestjs/websockets';
import {Namespace,Socket} from 'socket.io';
import {NotesService} from './notes.service';
import {AuthService} from 'src/auth/auth.service';


@WebSocketGateway({
	cors: true,
})
export class NotesGateway implements OnGatewayConnection,OnGatewayDisconnect {
	@WebSocketServer() io: Namespace;

	private readonly logger = new Logger('NotesGateway');

	constructor(
		private readonly notesService: NotesService,
		private readonly authService: AuthService,
	) { }

	async handleConnection() {
		this.logger.log('Client connected');
	}

	async handleDisconnect() {
		this.logger.log('Client disconnected');
	}

	afterInit() {
		this.logger.log('=======================');
		this.logger.log('Initialized');
		this.logger.log('=======================');
	}

	@SubscribeMessage('notes')
	async handleNotes(
		@ConnectedSocket() client: Socket,
		@MessageBody() data: {page: number,limit: number,categories: string[]},
	): Promise<void> {

		const {page,limit,categories} = data;

		this.logger.log('Notes event received');

		const token = client.handshake.headers.authorization as string;
		if (!token) {
			return;
		}
		const user = await this.authService.validateToken(token,true);
		if (!user || !user.userId) {
			return;
		}

		const notes = await this.notesService.getNotesByCategory(
			page,
			limit,
			categories,
		);

		this.io.emit('notes',notes);
	}

	@SubscribeMessage('categories')
	async handleCategories(
		@ConnectedSocket() client: Socket,
	): Promise<void> {
		const token = client.handshake.headers.authorization as string;
		if (!token) {
			return;
		}
		const user = await this.authService.validateToken(token,true);
		if (!user || !user.userId) {
			return;
		}

		const categories = await this.notesService.getCategories();
		this.io.emit('categories',{
			categories,
		});
	}
}

