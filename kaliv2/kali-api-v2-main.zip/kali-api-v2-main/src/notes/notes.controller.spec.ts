import { PassportModule } from '@nestjs/passport';
import { Test, TestingModule } from '@nestjs/testing';
import { PrismaService } from '../common/services/prisma.service';
import { NotesController } from './notes.controller';
import { NotesService } from './notes.service';

describe('NotesController', () => {
  let controller: NotesController;
  let spyService: NotesService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [NotesController],
      providers: [NotesService, PrismaService],
      imports: [PassportModule.register({ defaultStrategy: 'jwt' })],
    }).compile();

    controller = module.get<NotesController>(NotesController);
    spyService = module.get<NotesService>(NotesService);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
    expect(spyService).toBeDefined();
  });

  it('should create a new note', async () => {
    const note = {
      title: 'test',
      content: 'test',
      createdBy: 0,
      image: 'test',
      id: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
      is_approved: true,
      slug: 'test',
    };

    jest.spyOn(spyService, 'createNote').mockResolvedValue(note);

    expect(
      await controller.createNote({
        title: 'test',
        content: 'test',
        createdBy: 0,
        image: '',
        createdAt: new Date().toISOString(),
        slug: 'test',
      }),
    ).toBe(note);
  });

  it('should get a note by id', async () => {
    const note = {
      title: 'test',
      content: 'test',
      createdBy: 1,
      image: 'test',
      id: 1,
      createdAt: new Date(),
      updatedAt: new Date(),
      is_approved: true,
      slug: 'test',
    };

    jest.spyOn(spyService, 'getNoteBySlug').mockResolvedValue(note);

    expect(await controller.getNoteBySlug('test')).toBe(note);
  });

  it('should update a note by id', async () => {
    const note = {
      title: 'test',
      content: 'test',
      createdBy: 0,
      image: 'test',
      id: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
      slug: 'test',
      is_approved: true,
    };

    jest.spyOn(spyService, 'updateNoteById').mockResolvedValue(note);
    expect(
      await controller.updateNoteById(0, {
        title: 'test',
        content: 'test',
        createdBy: 0,
        image: '',
        updatedAt: new Date().toISOString(),
        slug: 'test',
        is_approved: true,
        id: 0,
      }),
    ).toBe(note);
  });

  it('should delete a note by id', async () => {
    const note = {
      title: 'test',
      content: 'test',
      createdBy: 0,
      image: 'test',
      id: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
      is_approved: true,
      slug: 'test',
    };

    jest.spyOn(spyService, 'deleteNoteById').mockResolvedValue(note);

    expect(await controller.deleteNoteById(0)).toStrictEqual({
      message: 'Note deleted successfully',
    });
  });
});
