import { Transform } from 'class-transformer';
import { IsNotEmpty, IsString, Matches } from 'class-validator';

export class CreateNoteRequest {
  // Add slug validation
  @IsNotEmpty()
  @Matches(RegExp('^[a-zA-Z0-9-]+$'))
  slug: string;

  @IsNotEmpty()
  @Transform(({ value }) => Number(value), { toClassOnly: true })
  category_id: number;

  @IsNotEmpty()
  @IsString()
  image: string;

  @IsNotEmpty()
  content: string;

  @IsNotEmpty()
  @Transform(({ value }) => Number(value), { toClassOnly: true })
  createdBy: number;

  @IsNotEmpty()
  title: string;

  @IsNotEmpty()
  @Matches(RegExp('([12]\\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01]))'))
  @Transform(({ value }) => new Date(value).toISOString(), {
    toClassOnly: true,
  })
  createdAt: string | Date; // ISO Date
}
