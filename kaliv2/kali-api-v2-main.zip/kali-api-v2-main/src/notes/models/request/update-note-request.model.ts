import { Transform } from 'class-transformer';
import {
  IsNotEmpty,
  IsOptional,
  Matches,
  IsInt,
  IsBoolean,
} from 'class-validator';

export class UpdateNoteRequest {
  @IsInt()
  @IsNotEmpty()
  id: number;

  @IsOptional()
  @IsNotEmpty()
  @Matches(RegExp('^[a-zA-Z0-9-]+$'))
  slug?: string;

  @IsOptional()
  @IsNotEmpty()
  image?: string;

  @IsOptional()
  @IsNotEmpty()
  @IsBoolean()
  is_approved: boolean;

  @IsOptional()
  @IsNotEmpty()
  content?: string;

  @IsOptional()
  @IsNotEmpty()
  createdBy?: number;

  @IsOptional()
  @IsNotEmpty()
  title: string;

  @IsOptional()
  @IsNotEmpty()
  @Matches(RegExp('([12]\\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01]))'))
  @Transform(({ value }) => new Date(value).toISOString(), {
    toClassOnly: true,
  })
  updatedAt?: string | Date; // ISO Date
}
