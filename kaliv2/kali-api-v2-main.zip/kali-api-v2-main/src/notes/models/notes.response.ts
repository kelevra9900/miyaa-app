import type {Note} from '@prisma/client';

export class NotesResponse {
  id: number;
  slug: string;
  image: string | null;
  content: string | null;
  title: string;
  createdAt: Date;
  updatedAt: Date;
  createdBy: number;
  is_approved?: boolean;

  static fromNotesEntity(entity: Note): NotesResponse {
    const response = new NotesResponse();
    response.id = entity.id;
    response.image = entity.image;
    response.content = entity.content;
    response.title = entity.title;
    response.createdAt = entity.createdAt;
    response.updatedAt = entity.updatedAt;
    response.createdBy = entity.createdBy;
    response.is_approved = entity.is_approved ?? false;
    response.slug = entity.slug;
    return response;
  }
}

export type NotesPagination = {
  data: NotesResponse[];
  total: number;
  totalPages: number;
  currentPage: number;
  perPage: number;
};
