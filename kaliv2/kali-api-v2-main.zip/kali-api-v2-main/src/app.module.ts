import {Module} from '@nestjs/common';
import {ConfigModule} from '@nestjs/config';
import {ThrottlerModule} from '@nestjs/throttler';
import {APP_GUARD} from '@nestjs/core';
import {ServeStaticModule} from '@nestjs/serve-static';
import {MulterModule} from '@nestjs/platform-express';
import {memoryStorage} from 'multer';
import {join} from 'path';
import {AwsSdkModule} from 'aws-sdk-v3-nest';
import {S3Client} from '@aws-sdk/client-s3';

import {UserModule} from './user/user.module';
import {AuthModule} from './auth/auth.module';
import {MailSenderModule} from './mail-sender/mail-sender.module';
import {ThrottlerBehindProxyGuard} from './common/guards/throttler-behind-proxy.guard';
import {AppController} from './app.controller';
import {AlertsModule} from './alerts/alerts.module';
import {SuggestionsModule} from './suggestions/suggestions.module';
import {NotesModule} from './notes/notes.module';
import {AnalyticsModule} from './analytics/analytics.module';
import {UploadController} from './upload/upload.controller';
import {SettingsModule} from './settings/settings.module';
import {TrackerModule} from './tracker/tracker.module';
import {MessagesModule} from './messages/messages.module';
import {ConfigurationModule} from './configuration/configuration.module';
import {CategoryModule} from './category/category.module';
import {ChatModule} from './chat/chat.module';
import {NoticeModule} from './notice/notice.module';
import {NotificationModule} from './notification/notification.module';
import {ConferencesModule} from './conferences/conferences.module';
import {AttendanceModule} from './attendance/attendance.module';
import {ShiftsModule} from './shifts/shifts.module';
import {RoundsModule} from './rounds/rounds.module';
import {CheckpointModule} from './checkpoint/checkpoint.module';
import {SectorModule} from './sector/sector.module';
import {DocumentsModule} from './documents/documents.module';
import {AnnouncementModule} from './announcement/announcement.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),
    ThrottlerModule.forRoot({
      ttl: 60,
      limit: 50,
    }),
    ServeStaticModule.forRoot({
      rootPath: join(__dirname,'..','../public'),
      serveRoot: '/public',
    }),
    MulterModule.register({
      storage: memoryStorage(),
    }),
    AwsSdkModule.register({
      isGlobal: true,
      client: new S3Client({
        region: process.env.AWS_DEFAULT_REGION || '',
        endpoint: process.env.AWS_ENDPOINT || '',
        credentials: {
          accessKeyId: process.env.AWS_ACCESS_KEY_ID || '',
          secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || '',
        },
      }),
    }),
    UserModule,
    AuthModule,
    MailSenderModule,
    AlertsModule,
    SuggestionsModule,
    NotesModule,
    AnalyticsModule,
    SettingsModule,
    TrackerModule,
    MessagesModule,
    ConfigurationModule,
    CategoryModule,
    ChatModule,
    NoticeModule,
    NotificationModule,
    ConferencesModule,
    AttendanceModule,
    ShiftsModule,
    RoundsModule,
    CheckpointModule,
    SectorModule,
    DocumentsModule,
    AnnouncementModule,
  ],
  providers: [
    {
      provide: APP_GUARD,
      useClass: ThrottlerBehindProxyGuard,
    },
  ],
  controllers: [AppController,UploadController],
})
export class AppModule { }
