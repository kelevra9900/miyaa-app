import {
  Body,
  Controller,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  Post,
  Query,
  UploadedFile,
  UseGuards,
  UseInterceptors,
  Headers,
} from '@nestjs/common';
import {ApiBearerAuth,ApiTags} from '@nestjs/swagger';
import {AuthGuard} from '@nestjs/passport';
import {AuthService} from './auth.service';
import {Usr} from '../user/user.decorator';
import {
  ChangeEmailRequest,
  ChangePasswordRequest,
  CheckEmailRequest,
  CheckEmailResponse,
  CheckUsernameRequest,
  CheckUsernameResponse,
  LoginRequest,
  LoginResponse,
  ResetPasswordRequest,
  SignupRequest,
} from './models';
import {UserResponse} from '../user/models';
import {AuthUser} from './auth-user';
import {FaceRecognitionResponse} from './models/response/face-recognition.response';
import {FileInterceptor} from '@nestjs/platform-express';

@ApiTags('auth')
@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) { }

  /**
   * Check the availability of a username.
   *
   * @param checkUsernameRequest - The request object containing the username to check.
   * @returns A promise that resolves to a CheckUsernameResponse object indicating whether the username is available or not.
   */
  @Post('check-username')
  @HttpCode(HttpStatus.OK)
  async checkUsernameAvailability(
    @Body() checkUsernameRequest: CheckUsernameRequest,
  ): Promise<CheckUsernameResponse> {
    const isAvailable = await this.authService.isUsernameAvailable(
      checkUsernameRequest.username,
    );
    return new CheckUsernameResponse(isAvailable);
  }

  /**
   * Check the availability of an email address.
   *
   * @param checkEmailRequest - The request object containing the email address to check.
   * @returns A promise that resolves to a CheckEmailResponse object indicating whether the email address is available or not.
   */
  @Post('check-email')
  @HttpCode(HttpStatus.OK)
  async checkEmailAvailability(
    @Body() checkEmailRequest: CheckEmailRequest,
  ): Promise<CheckEmailResponse> {
    const isAvailable = await this.authService.isEmailAvailable(
      checkEmailRequest.email,
    );
    return new CheckEmailResponse(isAvailable);
  }

  /**
   * Sign up a new user.
   *
   * @param signupRequest - The request object containing the user's signup information.
   * @returns A promise that resolves to void.
   */
  @Post('signup')
  @HttpCode(HttpStatus.CREATED)
  async signup(@Body() signupRequest: SignupRequest): Promise<void> {
    await this.authService.signup(signupRequest);
  }
  /**
   * Create a new user by a super admin.
   *
   * @param signupRequest - The request object containing the user's signup information.
   * @param user - The authenticated user object.
   * @throws Error - If the authenticated user is not a super admin.
   * @returns A promise that resolves to void.
   */
  @Post('create-user')
  @HttpCode(HttpStatus.CREATED)
  @UseGuards(AuthGuard())
  async createUser(
    @Body() signupRequest: SignupRequest,
    @Usr() user: AuthUser,
  ): Promise<void> {
    if (user.role !== 'SUPER_ADMIN') {
      throw new Error('Unauthorized');
    }
    await this.authService.signupRequestByAdmin(signupRequest);
  }

  /**
   * Log in a user.
   *
   * @param loginRequest - The request object containing the user's login information.
   * @returns A promise that resolves to a LoginResponse object containing the JWT token and the user's role.
   */
  @Post('login')
  @HttpCode(HttpStatus.OK)
  async login(@Body() loginRequest: LoginRequest): Promise<LoginResponse> {
    return new LoginResponse(await this.authService.login(loginRequest));
  }


  /**
   * Get the user with the provided token.
   *
   * @returns A promise that resolves to a UserResponse object containing the user's information.
   */
  @ApiBearerAuth()
  @Get()
  @HttpCode(HttpStatus.OK)
  @UseGuards(AuthGuard())
  async getUserWithToken(@Usr() user: AuthUser): Promise<UserResponse> {
    return UserResponse.fromUserEntity(user);
  }

  /**
   * Verify the user's email address.
   *
   * @param token - The verification token sent to the user's email address.
   * @returns A promise that resolves to void.
   */
  @Get('verify')
  @HttpCode(HttpStatus.OK)
  async verifyMail(@Query('token') token: string): Promise<void> {
    await this.authService.verifyEmail(token);
  }

  /**
   * Send a change email mail to the user.
   *
   * @param user - The authenticated user object.
   * @param changeEmailRequest - The request object containing the new email address.
   * @returns A promise that resolves to void.
   */
  @ApiBearerAuth()
  @Post('change-email')
  @HttpCode(HttpStatus.OK)
  @UseGuards(AuthGuard())
  async sendChangeEmailMail(
    @Usr() user: AuthUser,
    @Body() changeEmailRequest: ChangeEmailRequest,
  ): Promise<void> {
    await this.authService.sendChangeEmailMail(
      changeEmailRequest,
      user.id,
      user.firstName,
      user.email,
    );
  }
  /**
   * Change the user's email address.
   *
   * @param token - The verification token for changing the email address.
   * @returns A promise that resolves to void.
   */
  @Get('change-email')
  @HttpCode(HttpStatus.OK)
  async changeEmail(@Query('token') token: string): Promise<void> {
    await this.authService.changeEmail(token);
  }
  /**
   * Send a reset password email to the user.
   *
   * @param email - The email address of the user.
   * @returns A promise that resolves to void.
   */
  @Post('forgot-password/:email')
  @HttpCode(HttpStatus.OK)
  async sendResetPassword(@Param('email') email: string): Promise<void> {
    await this.authService.sendResetPasswordMail(email);
  }

  /**
   * Change the user's password.
   *
   * @param changePasswordRequest - The request object containing the new password.
   * @param user - The authenticated user object.
   * @returns A promise that resolves to void.
   */
  @Post('change-password')
  @HttpCode(HttpStatus.OK)
  @UseGuards(AuthGuard())
  async changePassword(
    @Body() changePasswordRequest: ChangePasswordRequest,
    @Usr() user: AuthUser,
  ): Promise<void> {
    await this.authService.changePassword(
      changePasswordRequest,
      user.id,
      user.firstName,
      user.email,
    );
  }

  /**
   * Perform biometric login using a file.
   *
   * @param file - The file containing the biometric data.
   * @returns A promise that resolves to the result of the biometric login.
   */
  @Post('biometrics')
  @HttpCode(HttpStatus.OK)
  @UseInterceptors(FileInterceptor('file'))
  async biometricLogin(
    @UploadedFile() file: Express.Multer.File,
    @Body() geo: {latitude: number,longitude: number},
  ): Promise<any> {
    return await this.authService.biometricLogin(file,geo);
  }

  @Post('logout')
  @HttpCode(HttpStatus.OK)
  @UseGuards(AuthGuard())
  @UseInterceptors(FileInterceptor('file'))
  async logout(
    @Usr() user: AuthUser,
    @UploadedFile() file: Express.Multer.File,
    @Body() geo: {latitude: number,longitude: number},
  ): Promise<void> {
    const {id} = user;
    await this.authService.logout(id,file,geo);
  }

  /**
   * Reset the user's password.
   *
   * @param resetPasswordRequest - The request object containing the new password.
   * @returns A promise that resolves to void.
   */
  @Post('reset-password')
  @HttpCode(HttpStatus.OK)
  async resetPassword(
    @Body() resetPasswordRequest: ResetPasswordRequest,
  ): Promise<void> {
    await this.authService.resetPassword(resetPasswordRequest);
  }

  /**
   * Resend the verification email to the user.
   *
   * @param user - The authenticated user object.
   * @returns A promise that resolves to void.
   */
  @Post('resend-verification')
  @HttpCode(HttpStatus.OK)
  @UseGuards(AuthGuard())
  async resendVerificationMail(@Usr() user: AuthUser): Promise<void> {
    await this.authService.resendVerificationMail(
      user.firstName,
      user.email,
      user.id,
    );
  }

  /**
   * Perform face recognition using an uploaded image file.
   *
   * @param file - The uploaded image file for face recognition.
   * @param authToken - The authorization token for authentication.
   * @returns A promise that resolves to a FaceRecognitionResponse object containing the result of the face recognition.
   */
  @Post('face-recognition')
  @HttpCode(HttpStatus.OK)
  @UseGuards(AuthGuard())
  @UseInterceptors(FileInterceptor('file'))
  async faceRecognitionImage(
    @UploadedFile() file: Express.Multer.File,
    @Headers('authorization') authToken: string,
  ): Promise<FaceRecognitionResponse> {
    return await this.authService.faceRecognitionImage(file,authToken);
  }
}
