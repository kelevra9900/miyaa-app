import type { User } from '@prisma/client';

export type AuthUser = User;

// Add pagination to the user service
// Path: src/user/user.service.ts

export type UserPagination = {
  users: any;
  total: number;
  totalPages: number;
  currentPage: number;
  perPage: number;
};
