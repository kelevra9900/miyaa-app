import { IsNotEmpty, IsString, IsUrl } from 'class-validator';

export class FaceRecognitionRequest {
  @IsNotEmpty()
  @IsString()
  @IsUrl()
  imageUrl: string;
}
