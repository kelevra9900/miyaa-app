import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, MinLength } from 'class-validator';

export class LoginRequest {
  @IsNotEmpty()
  @ApiProperty({ example: 'username or email' })
  // username or email
  identifier: string;

  @IsNotEmpty()
  @ApiProperty({ example: 'password' })
  @MinLength(8)
  password: string;
}
