import {ApiProperty} from '@nestjs/swagger';
import {Role,JobPosition} from '@prisma/client';
import {Transform} from 'class-transformer';
import {
  IsEmail,
  IsEnum,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  Matches,
  MaxLength,
  MinLength,
} from 'class-validator';

export class SignupRequest {
  @IsOptional()
  @ApiProperty({example: 'https://example.com/image.jpg'})
  image: string;

  @IsNotEmpty()
  @IsEmail()
  @ApiProperty({example: 'admin@gmail.com'})
  email: string;

  @IsNotEmpty()
  // alphanumeric characters and - are valid
  // you can change this as you like
  @ApiProperty({example: 'admin-1'})
  @Matches(RegExp('^[a-zA-Z0-9\\-]+$'))
  @MaxLength(20)
  username: string;

  @IsNotEmpty()
  @MinLength(8)
  @ApiProperty({example: '123456789'})
  password: string;

  @IsNotEmpty()
  @Matches(RegExp('^[A-Za-zıöüçğşİÖÜÇĞŞñÑáéíóúÁÉÍÓÚ ]+$'))
  @ApiProperty({example: 'Jhon'})
  @MaxLength(20)
  firstName: string;

  @IsNotEmpty()
  @Matches(RegExp('^[A-Za-zıöüçğşİÖÜÇĞŞñÑáéíóúÁÉÍÓÚ ]+$'))
  @MaxLength(20)
  @ApiProperty({example: 'Doe'})
  lastName: string;

  @IsOptional()
  @MaxLength(20)
  @Matches(RegExp('^[A-Za-zıöüçğşİÖÜÇĞŞñÑáéíóúÁÉÍÓÚ ]+$'))
  middleName?: string | null;

  @IsOptional()
  @ApiProperty({example: '1',type: 'number'})
  shiftId: number | null;

  @IsOptional()
  @IsEnum([Role.USER,Role.ADMIN,Role.SUPER_ADMIN,Role.OPERATOR])
  @ApiProperty({example: 'user',enum: ['user','admin']})
  role: Role;

  @IsOptional()
  @IsEnum([JobPosition.GUARD,JobPosition.PARKING_ENFORCER,JobPosition.GUARD_SSU,JobPosition.INSPECTOR_PIPEM_AC,JobPosition.INSPECTOR_HBS,JobPosition.INSPECTOR_SOC,JobPosition.FACILITATION_ASSISTANT,JobPosition.SUPERVISOR,JobPosition.HEAD_OF_SERVICE,JobPosition.CANINE_BINOMIAL])
  @ApiProperty({example: JobPosition.GUARD,enum: [JobPosition.CANINE_BINOMIAL,JobPosition.GUARD_SSU,JobPosition.GUARD]})
  jobPosition: string;

  @IsOptional()
  @IsString()
  icon: string;

  @IsOptional()
  @IsInt()
  @Transform(({value}) => Number(value))
  Sector?: number;

  @IsOptional()
  @ApiProperty({example: '1',type: 'number'})
  shift: number | null;

}
