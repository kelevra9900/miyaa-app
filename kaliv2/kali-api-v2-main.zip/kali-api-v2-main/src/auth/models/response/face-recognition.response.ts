export class FaceRecognitionResponse {
  matched: boolean;
  message: string;

  constructor(data: FaceRecognitionResponse) {
    this.matched = data.matched;
    this.message = data.message;
  }
}
