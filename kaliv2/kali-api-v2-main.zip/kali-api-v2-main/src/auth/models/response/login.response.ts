export class LoginResponse {
  jwt: string;
  role: string;

  constructor(data: { jwt: string; role: string }) {
    this.jwt = data.jwt;
    this.role = data.role;
  }
}
