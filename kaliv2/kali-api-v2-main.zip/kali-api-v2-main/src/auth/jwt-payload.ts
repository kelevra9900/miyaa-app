import { Socket } from 'socket.io';

export interface JwtPayload {
  userId: number;
  username: string;
  email: string;
}

export type SocketWithAuth = Socket & JwtPayload;
