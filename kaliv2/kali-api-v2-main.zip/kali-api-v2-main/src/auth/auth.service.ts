import axios from 'axios';
import {S3} from 'aws-sdk';
import {
  ConflictException,
  Injectable,
  Logger,
  NotFoundException,
  UnauthorizedException,
} from '@nestjs/common';
import * as bcrypt from 'bcrypt';
import {JwtService} from '@nestjs/jwt';
import {nanoid} from 'nanoid';
import {AttendanceStatus,JobPosition,Prisma,Role} from '@prisma/client';
import {CompareFacesCommand,CompareFacesCommandInput,CompareFacesCommandOutput} from '@aws-sdk/client-rekognition'

import {JwtPayload} from './jwt-payload';
import {MailSenderService} from '../mail-sender/mail-sender.service';
import {
  ChangeEmailRequest,
  ChangePasswordRequest,
  LoginRequest,
  ResetPasswordRequest,
  SignupRequest,
} from './models';
import {AuthUser} from './auth-user';
import {PrismaService} from '../common/services/prisma.service';
import {FaceRecognitionResponse} from './models/response/face-recognition.response';
import rekognitionClient from '../utils/aws-client-rekognition.util';

@Injectable()
export class AuthService {
  private readonly logger = new Logger('AuthService');
  private s3: S3;

  constructor(
    private readonly prisma: PrismaService,
    private readonly jwtService: JwtService,
    private readonly mailSenderService: MailSenderService,
  ) {
    this.s3 = new S3({
      signatureVersion: 'v4',
      accessKeyId: process.env.AWS_ACCESS_KEY_ID,
      secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
      region: process.env.AWS_DEFAULT_REGION,
    });
  }

  private async downloadImage(imageUrl: string): Promise<Buffer> {
    try {
      const response = await axios.get(imageUrl,{responseType: 'arraybuffer'});
      return Buffer.from(response.data,'binary');
    } catch (error) {
      this.logger.error(`Error downloading image: ${error}`);
      throw new ConflictException('Error downloading image');
    }
  }
  /**
   * Registers a new user with the provided signup information.
   *
   * @param signupRequest - The signup information for the new user.
   * @returns Promise<void>
   * @throws ConflictException - If there is a conflict with the provided data (e.g., duplicate username or email).
   */
  async signup(signupRequest: SignupRequest): Promise<void> {
    const emailVerificationToken = nanoid();

    try {
      const {shiftId,...userData} = signupRequest;
      const createdUser = await this.prisma.user.create({
        data: {
          username: userData.username.toLowerCase(),
          email: userData.email.toLowerCase(),
          passwordHash: await bcrypt.hash(userData.password,10),
          firstName: userData.firstName,
          lastName: userData.lastName,
          middleName: userData.middleName,
          emailVerification: {
            create: {
              token: emailVerificationToken,
            },
          },
        },
        select: {
          id: true,
        },
      });
      if (shiftId) {
        await this.prisma.user.update({
          where: {id: createdUser.id},
          data: {
            shiftId: Number(shiftId),
          },
        });
      }
    } catch (e) {
      if (e instanceof Prisma.PrismaClientKnownRequestError) {
        if (e.code === 'P2002') {
          // unique constraint
          throw new ConflictException();
        } else throw e;
      } else throw e;
    }

    await this.mailSenderService.sendVerifyEmailMail(
      signupRequest.firstName,
      signupRequest.email,
      emailVerificationToken,
    );
  }

  private async compareFaces(sourceImage: Buffer,targetImage: Buffer): Promise<boolean> {
    const input: CompareFacesCommandInput = {
      SourceImage: {
        Bytes: sourceImage,
      },
      TargetImage: {
        Bytes: targetImage,
      },
      SimilarityThreshold: 70,
    };

    const command = new CompareFacesCommand(input);

    try {
      const response: CompareFacesCommandOutput = await rekognitionClient.send(command);

      if (response.FaceMatches && response.FaceMatches.length > 0) {
        const faceMatch = response.FaceMatches[0];
        if (faceMatch.Similarity && faceMatch.Similarity >= 70) {
          return true;
        }
      }

      return false;
    } catch (error) {
      console.error('Error comparing faces:',error);
      return false;
    }
  }

  /**
   * Create a user with face recognition (Only for admin)
   *
   * @param signupRequest - The signup request object containing user details
   * @returns Promise<void>
   * @throws {ConflictException} - If there is a conflict with the user data
   * @throws {Error} - If there is an error during the user creation process
   */
  async signupRequestByAdmin(signupRequest: SignupRequest): Promise<void> {
    const emailVerificationToken = nanoid();
    try {
      const {...userData} = signupRequest;
      const createdUser = await this.prisma.user.create({
        data: {
          username: userData.email.toLowerCase(),
          email: userData.email.toLowerCase(),
          passwordHash: await bcrypt.hash(userData.password,10),
          firstName: userData.firstName,
          lastName: userData.lastName,
          middleName: userData.middleName,
          image: userData.image,
          role: userData.role || Role.USER,
          jobPosition: userData.jobPosition as JobPosition,
          icon: userData.icon,
          shiftId: userData.shift,
          sectorId: userData.Sector,
          emailVerification: {
            create: {
              token: emailVerificationToken,
            },
          },
        },
        select: {
          id: true,
        },
      });

      // if (shiftId) {
      //   await this.prisma.user.update({
      //     where: {id: createdUser.id},
      //     data: {
      //       shiftId: Number(shiftId),
      //     }
      //   });
      // }

      // if (sector) {
      //   await this.prisma.user.update({
      //     where: {id: createdUser.id},
      //     data: {
      //       sectorId: Number(sector),
      //     }
      //   });
      // }
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError) {
        if (error.code === 'P2002') {
          throw new ConflictException();
        } else throw error;
      } else throw error;
    }
  }


  /**
   * Resends the verification email to the user.
   *
   * @param name - The name of the user.
   * @param email - The email of the user.
   * @param userId - The ID of the user.
   * @returns Promise<void>
   */
  async resendVerificationMail(
    name: string,
    email: string,
    userId: number,
  ): Promise<void> {
    // delete old email verification tokens if exist
    const deletePrevEmailVerificationIfExist =
      this.prisma.emailVerification.deleteMany({
        where: {userId},
      });

    const token = nanoid();

    const createEmailVerification = this.prisma.emailVerification.create({
      data: {
        userId,
        token,
      },
    });

    await this.prisma.$transaction([
      deletePrevEmailVerificationIfExist,
      createEmailVerification,
    ]);

    await this.mailSenderService.sendVerifyEmailMail(name,email,token);
  }

  /**
   * Verifies the email using the provided token.
   *
   * @param {string} token - The token used for email verification.
   * @returns {Promise<void>} - A promise that resolves when the email is successfully verified.
   * @throws {NotFoundException} - If the token is invalid or expired.
   */
  async verifyEmail(token: string): Promise<void> {
    const emailVerification = await this.prisma.emailVerification.findUnique({
      where: {token},
    });

    if (
      emailVerification !== null &&
      emailVerification.validUntil > new Date()
    ) {
      await this.prisma.user.update({
        where: {id: emailVerification.userId},
        data: {
          emailVerified: true,
        },
        select: null,
      });
    } else {
      this.logger.log(`Verify email called with invalid email token ${token}`);
      throw new NotFoundException();
    }
  }

  /**
   * Sends a change email mail to the user.
   *
   * @param changeEmailRequest - The request object containing the new email.
   * @param userId - The ID of the user requesting the email change.
   * @param name - The name of the user.
   * @param oldEmail - The current email of the user.
   * @returns Promise<void>
   * @throws ConflictException if the new email is already in use.
   */
  async sendChangeEmailMail(
    changeEmailRequest: ChangeEmailRequest,
    userId: number,
    name: string,
    oldEmail: string,
  ): Promise<void> {
    const emailAvailable = await this.isEmailAvailable(
      changeEmailRequest.newEmail,
    );
    if (!emailAvailable) {
      this.logger.log(
        `User with id ${userId} tried to change its email to already used ${changeEmailRequest.newEmail}`,
      );
      throw new ConflictException();
    }

    const deletePrevEmailChangeIfExist = this.prisma.emailChange.deleteMany({
      where: {userId},
    });

    const token = nanoid();

    const createEmailChange = this.prisma.emailChange.create({
      data: {
        userId,
        token,
        newEmail: changeEmailRequest.newEmail,
      },
      select: null,
    });

    await this.prisma.$transaction([
      deletePrevEmailChangeIfExist,
      createEmailChange,
    ]);

    await this.mailSenderService.sendChangeEmailMail(name,oldEmail,token);
  }

  /**
   * Change the email of a user using the provided token.
   *
   * @param {string} token - The token used to verify the email change request.
   * @returns {Promise<void>} - A promise that resolves when the email is successfully changed.
   * @throws {NotFoundException} - If the token is invalid or expired.
   */
  async changeEmail(token: string): Promise<void> {
    const emailChange = await this.prisma.emailChange.findUnique({
      where: {token},
    });

    if (emailChange !== null && emailChange.validUntil > new Date()) {
      await this.prisma.user.update({
        where: {id: emailChange.userId},
        data: {
          email: emailChange.newEmail.toLowerCase(),
        },
        select: null,
      });
    } else {
      this.logger.log(`Invalid email change token ${token} is rejected.`);
      throw new NotFoundException();
    }
  }

  /**
   * Sends a reset password email to the user.
   *
   * @param email - The email of the user.
   * @returns Promise<void>
   * @throws NotFoundException - If the user with the given email is not found.
   */
  async sendResetPasswordMail(email: string): Promise<void> {
    const user = await this.prisma.user.findUnique({
      where: {email: email.toLowerCase()},
      select: {
        id: true,
        firstName: true,
        email: true,
      },
    });

    if (user === null) {
      throw new NotFoundException();
    }

    const deletePrevPasswordResetIfExist = this.prisma.passwordReset.deleteMany(
      {
        where: {userId: user.id},
      },
    );

    const token = nanoid();

    const createPasswordReset = this.prisma.passwordReset.create({
      data: {
        userId: user.id,
        token,
      },
      select: null,
    });

    await this.prisma.$transaction([
      deletePrevPasswordResetIfExist,
      createPasswordReset,
    ]);

    await this.mailSenderService.sendResetPasswordMail(
      user.firstName,
      user.email,
      token,
    );
  }
  /**
   * Resets the password for a user.
   *
   * @param resetPasswordRequest - The request object containing the reset password token and the new password.
   * @throws {NotFoundException} - If the reset password token is invalid or expired.
   * @returns {Promise<void>}
   */
  async resetPassword(
    resetPasswordRequest: ResetPasswordRequest,
  ): Promise<void> {
    const passwordReset = await this.prisma.passwordReset.findUnique({
      where: {token: resetPasswordRequest.token},
    });

    if (passwordReset !== null && passwordReset.validUntil > new Date()) {
      await this.prisma.user.update({
        where: {id: passwordReset.userId},
        data: {
          passwordHash: await bcrypt.hash(resetPasswordRequest.newPassword,10),
        },
        select: null,
      });
    } else {
      this.logger.log(
        `Invalid reset password token ${resetPasswordRequest.token} is rejected`,
      );
      throw new NotFoundException();
    }
  }

  /**
   * Changes the password for a user.
   *
   * @param changePasswordRequest - The request object containing the new password.
   * @param userId - The ID of the user whose password is being changed.
   * @param name - The name of the user.
   * @param email - The email of the user.
   * @returns Promise<void>
   */
  async changePassword(
    changePasswordRequest: ChangePasswordRequest,
    userId: number,
    name: string,
    email: string,
  ): Promise<void> {
    await this.prisma.user.update({
      where: {
        id: userId,
      },
      data: {
        passwordHash: await bcrypt.hash(changePasswordRequest.newPassword,10),
      },
      select: null,
    });
    await this.mailSenderService.sendPasswordChangeInfoMail(name,email);
  }

  /**
   * Validates a user based on the provided JWT payload.
   *
   * @param payload - The JWT payload containing the user information.
   * @returns A Promise that resolves to the authenticated user.
   * @throws UnauthorizedException if the user is not valid or authorized.
   */
  async validateUser(payload: JwtPayload): Promise<AuthUser> {
    const user = await this.prisma.user.findUnique({
      where: {id: payload.userId},
    });

    if (
      user !== null &&
      user.email === payload.email &&
      user.username === payload.username
    ) {
      return user;
    }
    throw new UnauthorizedException();
  }

  /**
   * Authenticates a user and generates a JWT token.
   *
   * @param loginRequest - The login request object containing the user's identifier (username or email) and password.
   * @returns An object containing the JWT token and the user's role.
   * @throws UnauthorizedException if the user is not found or the password is incorrect.
   */
  async login(loginRequest: LoginRequest): Promise<any> {
    const normalizedIdentifier = loginRequest.identifier.toLowerCase();
    const user = await this.prisma.user.findFirst({
      where: {
        OR: [
          {
            username: normalizedIdentifier,
          },
          {
            email: normalizedIdentifier,
          },
        ],
      },
      select: {
        id: true,
        passwordHash: true,
        email: true,
        username: true,
        role: true,
      },
    });

    if (
      user === null ||
      !bcrypt.compareSync(loginRequest.password,user.passwordHash)
    ) {
      throw new UnauthorizedException();
    }

    // Actualizar el estado online del usuario a true
    await this.prisma.user.update({
      where: {id: user.id},
      data: {online: true},
    });

    const payload: JwtPayload = {
      userId: user.id,
      email: user.email,
      username: user.username,
    };

    const jwt = await this.jwtService.signAsync(payload);
    return {
      jwt,
      role: user.role,
    };
  }

  /**
   * Checks if a username is available.
   *
   * @param {string} username - The username to check.
   * @returns {Promise<boolean>} - Returns true if the username is available, false otherwise.
   */
  async isUsernameAvailable(username: string): Promise<boolean> {
    const user = await this.prisma.user.findUnique({
      where: {username: username.toLowerCase()},
      select: {username: true},
    });
    return user === null;
  }

  /**
   * Checks if the given email is available or already taken by another user.
   *
   * @param email - The email to check for availability.
   * @returns A boolean indicating whether the email is available (true) or already taken (false).
   */
  async isEmailAvailable(email: string): Promise<boolean> {
    const user = await this.prisma.user.findUnique({
      where: {email: email.toLowerCase()},
      select: {email: true},
    });
    return user === null;
  }

  /**
   * Validate token in headers, localize user and return user information.
   *
   * @param token - The token to be validated.
   * @param online - A boolean indicating if the user is online or not.
   * @returns An object containing the user information if the token is valid, otherwise false.
   */
  async validateToken(token: string,online: boolean): Promise<any> {
    const payload = this.jwtService.decode(token) as JwtPayload;
    if (payload === null) {
      return false;
    }
    const user = await this.prisma.user.findUnique({
      where: {id: payload.userId},
    });

    if (user) {
      await this.prisma.user.update({
        where: {id: user.id},
        data: {
          lastSeen: new Date(),
          online,
        },
      });
      return {
        userId: user?.id,
        name: user?.firstName + ' ' + user?.lastName,
        email: user?.email,
        role: user?.role,
      };
    }

    return false;
  }

  /**
   * Performs face recognition using a microservice.
   *
   * @param imageUrl The URL of the image to perform face recognition on.
   * @param authToken The authentication token for accessing the microservice.
   * @returns A promise that resolves to a FaceRecognitionResponse object containing the result of the face recognition.
   */
  async faceRecognition(
    imageUrl: string,
    authToken: string,
  ): Promise<FaceRecognitionResponse> {
    const url = process.env.MICROSERVICE_URL;
    try {
      const response = await axios.post(
        `${url}/face-recognition`,
        {
          image_url: imageUrl,
        },
        {
          headers: {
            Authorization: authToken,
          },
        },
      );
      return response.data;
    } catch (error) {
      this.logger.debug(
        `Face recognition failed ${JSON.stringify(error)}`,
        'AuthService',
      );
      return {
        message: 'Face recognition failed',
        matched: false,
      };
    }
  }

  /**
   * Uploads a face recognition image to an AWS S3 bucket.
   *
   * @param file - The file to be uploaded.
   * @returns A string representing the URL of the uploaded image, or an object with a message and matched property if the face recognition failed.
   * @throws Error if the name of the bucket is not configured.
   */
  async faceUpload(
    file: Express.Multer.File,
  ): Promise<string | {message: string; matched: boolean}> {
    const bucketName = process.env.AWS_BUCKET;

    if (!bucketName) {
      throw new Error('The name of the bucket is not configured');
    }

    const fileName = file.originalname.trim().replace(/ /g,'-').toLowerCase();
    const uploadParams = {
      Bucket: bucketName,
      Key: fileName,
      Body: file.buffer,
    };

    try {
      const uploadResult = await this.s3.upload(uploadParams).promise();
      this.logger.debug(
        `Face recognition image uploaded to s3 ${JSON.stringify(uploadResult)}`,
        'AuthService',
      );
      return uploadResult.Location;
    } catch (error) {
      this.logger.debug(
        `Face recognition failed ${JSON.stringify(error)}`,
        'AuthService',
      );
      return {
        message: 'Face recognition failed',
        matched: false,
      };
    }
  }

  /**
   * Delete image from S3 after face recognition.
   *
   * @param fileName - The name of the file to be deleted from S3.
   * @throws Error - If the name of the bucket is not configured.
   * @returns Promise<void>
   */
  async deleteImageFromS3(fileName: string) {
    const bucketName = process.env.AWS_BUCKET;

    if (!bucketName) {
      throw new Error('The name of the bucket is not configured');
    }

    await this.s3.deleteObject({Bucket: bucketName,Key: fileName}).promise();
  }

  /**
   * Performs face recognition on an image file.
   *
   * @param file - The image file to perform face recognition on.
   * @param authToken - The authentication token for the request.
   * @returns A FaceRecognitionResponse object containing the result of the face recognition.
   * @throws Error if the name of the bucket is not configured.
   */
  async faceRecognitionImage(
    file: Express.Multer.File,
    authToken: string,
  ): Promise<FaceRecognitionResponse> {
    const bucketName = process.env.AWS_BUCKET;

    if (!bucketName) {
      throw new Error('The name of the bucket is not configured');
    }

    const fileName = file.originalname.trim().replace(/ /g,'-').toLowerCase();
    const uploadParams = {
      Bucket: bucketName,
      Key: fileName,
      Body: file.buffer,
    };

    try {
      const uploadResult = await this.s3.upload(uploadParams).promise();
      const url = uploadResult.Location;

      const response = await this.faceRecognition(url,authToken);
      await this.s3
        .deleteObject({Bucket: bucketName,Key: fileName})
        .promise();

      return response;
    } catch (error) {
      this.logger.debug(
        `Face recognition failed ${JSON.stringify(error)}`,
        'AuthService',
      );
      return {
        message: 'Face recognition failed',
        matched: false,
      };
    }
  }


  /**
   * Performs biometric login using a face recognition image.
   *
   * @param file - The face recognition image file.
   * @returns A promise that resolves to the biometric login response.
   * @throws {ConflictException} If an error occurs during the biometric login process.
   * @throws {UnauthorizedException} If the user is not found during the biometric login process.
   */
  async biometricLogin(file: Express.Multer.File,geo: {latitude: number; longitude: number}): Promise<any> {
    try {
      const users = await this.prisma.user.findMany({
        select: {
          id: true,
          image: true,
          email: true,
          username: true,
          firstName: true,
          lastName: true,
          role: true,
        },
      });

      const uploadedImageBuffer = file.buffer;

      const promises = users.map(async (user) => {
        if (!user.image) {
          this.logger.debug(`User with id ${user.id} does not have an image`);
          return null;
        }

        const referenceImageBuffer = await this.downloadImage(user.image);
        const facesMatch = await this.compareFaces(uploadedImageBuffer,referenceImageBuffer);

        if (facesMatch) {
          this.logger.debug(`User with id ${user.id} logged in successfully`);
          return user;
        }

        return null;
      });

      const matchedUser = (await Promise.all(promises)).find((user) => user !== null);

      if (matchedUser) {
        const payload: JwtPayload = {
          userId: matchedUser.id,
          email: matchedUser.email,
          username: matchedUser.username,
        }

        await this.prisma.user.update({
          where: {id: matchedUser.id},
          data: {
            online: true,
          },
        });

        const token = await this.jwtService.signAsync(payload);
        if (geo.latitude != null && geo.longitude != null) {
          this.logger.debug(`User with id ${matchedUser.id} checked in successfully`);
          await this.prisma.attendance.create({
            data: {
              userId: matchedUser.id,
              checkIn: new Date(),
              status: 'ON_SITE',
              latitude: Number(geo.latitude),
              longitude: Number(geo.longitude),
              createdAt: new Date(),
            },
          });

          return {
            user: {
              name: matchedUser.firstName + ' ' + matchedUser.lastName,
              email: matchedUser.email,
              role: matchedUser.role,
            },
            message: 'Biometric login successful, location saved successfully',
            jwt: token,
            role: matchedUser.role,
          };
        }

        this.logger.debug(`User not checked in due to missing location data | ${geo.latitude} - ${geo.longitude} |`);

        return {
          user: {
            name: matchedUser.firstName + ' ' + matchedUser.lastName,
            email: matchedUser.email,
            role: matchedUser.role,
          },
          message: 'Biometric login successful',
          jwt: token,
          role: matchedUser.role,
        };
      }

      return {
        message: 'User not found',
        matched: false,
      };
    } catch (e) {
      this.logger.error(`Error in biometricLogin: ${e}`);
      if (e.response?.status === 404) {
        return {
          message: 'User not found',
          matched: false,
        };
      }
      throw new ConflictException();
    }
  }


  // logout
  async logout(id: number,file: Express.Multer.File,geo: {latitude: number; longitude: number}): Promise<void> {

    try {
      const users = await this.prisma.user.findMany({
        select: {
          id: true,
          image: true,
          email: true,
          username: true,
          firstName: true,
          lastName: true,
          role: true,
        },
      });

      const uploadedImageBuffer = file.buffer;

      const promises = users.map(async (user) => {
        if (!user.image) {
          this.logger.debug(`User with id ${user.id} does not have an image`);
          return null;
        }

        const referenceImageBuffer = await this.downloadImage(user.image);
        const facesMatch = await this.compareFaces(uploadedImageBuffer,referenceImageBuffer);

        if (facesMatch) {
          this.logger.debug(`User with id ${user.id} logged in successfully`);
          return user;
        }

        return null;
      });

      const matchedUser = (await Promise.all(promises)).find((user) => user !== null);

      if (matchedUser) {
        await this.prisma.user.update({
          where: {id: matchedUser.id},
          data: {
            online: false,
            lastSeen: new Date(),
          },
        });

        const attendance = await this.prisma.attendance.findFirst({
          where: {userId: id},
          orderBy: {checkIn: 'desc'},
        });

        if (attendance) {
          await this.prisma.attendance.update({
            where: {id: attendance.id},
            data: {
              checkOut: new Date(),
              status: AttendanceStatus.OFF_SITE,
            },
          });
        }
      }
    } catch (e) {
      this.logger.error(`Error in biometricLogin: ${e}`);
      throw new ConflictException();
    }
  }
}
