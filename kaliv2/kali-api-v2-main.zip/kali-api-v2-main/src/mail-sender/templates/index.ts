export { changeMail } from './change-mail.html';
export { changePasswordInfo } from './change-password-info.html';
export { confirmMail } from './confirm-mail.html';
export { resetPassword } from './reset-password.html';
