import { Logger } from '@nestjs/common';
import {
  WebSocketServer,
  OnGatewayConnection,
  OnGatewayDisconnect,
  SubscribeMessage,
  WebSocketGateway,
  MessageBody,
} from '@nestjs/websockets';
import { Namespace } from 'socket.io';
import { CreateTrackerRequest } from './models/create-tracker.controller';
import { TrackerService } from './tracker.service';

type Tracker = {
  userId: string;
};

@WebSocketGateway({
  cors: true,
})
export class TrackerGateway
  implements OnGatewayConnection, OnGatewayDisconnect
{
  @WebSocketServer() io: Namespace;

  constructor(private readonly trackerService: TrackerService) {}

  private readonly logger = new Logger('TrackerGateway');

  async handleConnection() {
    this.logger.log('Client connected to tracker');
  }

  async handleDisconnect() {
    this.logger.log('Client disconnected from tracker');
  }

  afterInit() {
    this.logger.log('=======================');
    this.logger.log('Initialized TrackerGateway');
    this.logger.log('=======================');
  }

  @SubscribeMessage('tracker')
  async handleTracker(): Promise<void> {
    const trackers = await this.trackerService.groupByUserId();

    this.io.emit('all_trackers', trackers);
  }

  // Get tracker by userId. Emit to admin (tracker_by_user_id)
  @SubscribeMessage('tracker_by_user_id')
  async handleTrackerByUserId(@MessageBody() data: Tracker): Promise<void> {
    const { userId } = data;
    const trackers = await this.trackerService.latestByUserId(Number(userId));

    this.io.emit('tracker_by_user_id', trackers);
  }

  // Initialize track by userId. Emit to admin (init_track)
  @SubscribeMessage('init_track')
  async handleInitTrack(
    @MessageBody() data: CreateTrackerRequest & Tracker,
  ): Promise<void> {
    const { userId } = data;
    await this.trackerService.create({
      ...data,
      userId: parseInt(userId),
    });
  }

  // todayByUserId
  @SubscribeMessage('today_by_user_id')
  async handleTodayByUserId(@MessageBody() data: number): Promise<void> {
    const trackers = await this.trackerService.latestByUserId(data);

    this.io.emit('user_track', trackers);
  }
}
