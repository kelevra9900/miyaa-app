import {
  Body,
  Controller,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
  UseGuards,
} from '@nestjs/common';
import {AuthGuard} from '@nestjs/passport';
import {ApiBearerAuth,ApiTags} from '@nestjs/swagger';

import {CreateTrackerRequest} from './models/create-tracker.controller';
import {TrackerService} from './tracker.service';
import {AuthUser} from 'src/auth/auth-user';
import {Usr} from 'src/user/user.decorator';

@ApiTags('Tracker')
@ApiBearerAuth()
@UseGuards(AuthGuard())
@Controller('tracker')
export class TrackerController {
  constructor(private readonly trackerService: TrackerService) { }
  /**
   * Create a new tracker.
   *
   * @param data - The data for creating the tracker.
   * @returns A Promise that resolves to the created tracker.
   */
  @Post()
  @HttpCode(HttpStatus.CREATED)
  async create(@Body() data: CreateTrackerRequest) {
    return this.trackerService.create(data);
  }

  /**
   * Get the alerts by grouping them by user ID.
   *
   * @returns A Promise that resolves to the grouped alerts.
   */
  @Get()
  @HttpCode(HttpStatus.OK)
  async getAlert() {
    return this.trackerService.groupByUserId();
  }

  /**
   * Get the latest tracker for a specific user.
   *
   * @param id - The ID of the user.
   * @returns A Promise that resolves to the latest tracker for the user.
   */
  @Get('user/:id')
  @HttpCode(HttpStatus.OK)
  async getLatest(@Param('id',ParseIntPipe) id: number) {
    return this.trackerService.latestByUserId(id);
  }
  /**
   * Update a tracker by ID.
   *
   * @param id - The ID of the tracker to update.
   * @param data - The updated data for the tracker.
   * @returns A Promise that resolves to the updated tracker.
   */
  @Put(':id')
  @HttpCode(HttpStatus.OK)
  async update(
    @Param('id',ParseIntPipe) id: number,
    @Body() data: CreateTrackerRequest,
  ) {
    return this.trackerService.updateByTrackId(id,data);
  }
  /**
   * Get the tracker for today by user ID.
   *
   * @param id - The ID of the user.
   * @returns A Promise that resolves to the tracker for today for the user.
   */
  @Get('today/:id')
  @HttpCode(HttpStatus.OK)
  async getToday(@Param('id',ParseIntPipe) id: number) {
    return this.trackerService.todayByUserId(id);
  }

  /**
   * Get the tracker for a specific user.
   *
   * @param user - The authenticated user.
   * @returns A Promise that resolves to the latest tracker for the user.
   */
  @Get('user')
  @HttpCode(HttpStatus.OK)
  async getTrackByUserId(@Usr() user: AuthUser) {
    return this.trackerService.todayByUserId(user.id);
  }


  @Get('trackingByUser')
  @HttpCode(HttpStatus.OK)
  async getTrackingByUser(
    @Query('userId') userId: string,
    @Query('start') start: string,
    @Query('end') end: string,

  ) {
    return this.trackerService.getTrackingByUser(start, end, userId);
  }
}
