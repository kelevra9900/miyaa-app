import { Injectable } from '@nestjs/common';
import { PrismaService } from '../common/services/prisma.service';
import { CreateTrackerRequest } from './models/create-tracker.controller';

@Injectable()
export class TrackerService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Creates a new tracker entry.
   *
   * @param data - The data for the new tracker entry.
   * @returns A promise that resolves to the created tracker entry.
   */
  public async create(data: CreateTrackerRequest) {
    return this.prisma.tracking.create({
      data,
    });
  }

  /**
   * Group locations by user IDs.
   *
   * @returns A promise that resolves to an object containing the grouped locations and the count of all locations.
   */
  public async groupByUserId() {
    return this.prisma.tracking.groupBy({
      by: ['userId'],
      _count: {
        _all: true,
      },
    });
  }

  /**
   * Retrieves the latest tracker entry for a given user ID.
   *
   * @param id - The user ID.
   * @returns A promise that resolves to an object containing the latest tracker entry, or null if no data is found.
   * @throws An error if there is an issue retrieving the data.
   */
  public async latestByUserId(id: number) {
    try {
      const result = await this.prisma.tracking.findMany({
        where: {
          userId: Number(id),
        },
        orderBy: {
          createdAt: 'desc',
        },
        take: 1,
      });

      if (result.length === 0) {
        return {
          message: 'No data found',
          location: null,
        };
      }

      return {
        message: 'Success',
        location: result[0],
      };
    } catch (e) {
      console.log(e);
      throw new Error(e);
    }
  }
  /**
   * Deletes multiple tracker entries by user ID.
   *
   * @param userId - The user ID.
   * @returns A promise that resolves to the number of deleted entries.
   */
  public async deleteByUserId(userId: string) {
    return this.prisma.tracking.deleteMany({
      where: {
        userId: parseInt(userId),
      },
    });
  }

  /**
   * Retrieves tracker entries for a given user ID and created at date.
   *
   * @param userId - The user ID.
   * @param createdAt - The created at date.
   * @returns A promise that resolves to an array of tracker entries.
   * @throws An error if there is an issue retrieving the data.
   */
  public async getByUserIdAndCreatedAt(
    userId: number,
    createdAt: string,
  ): Promise<any> {
    try {
      return this.prisma.tracking.findMany({
        where: {
          userId: userId,
          createdAt: {
            lte: new Date(createdAt),
          },
        },
      });
    } catch (e) {
      console.log(e);
      throw e;
    }
  }
  /**
   * Creates a new location tracker entry.
   *
   * @param data - The data for the new location tracker entry.
   * @returns A promise that resolves to the created location tracker entry.
   */
  public async createLocation(data: CreateTrackerRequest): Promise<any> {
    return this.prisma.tracking.create({
      data,
    });
  }
  /**
   * Updates a tracker entry by track ID.
   *
   * @param id - The track ID of the entry to be updated.
   * @param data - The updated data for the tracker entry.
   * @returns A promise that resolves to the updated tracker entry.
   */
  public async updateByTrackId(id: number, data: CreateTrackerRequest) {
    return this.prisma.tracking.update({
      where: {
        id: id,
      },
      data,
    });
  }

  /**
   * Retrieves the tracker entries for the current day for a given user ID.
   *
   * @param id - The user ID.
   * @returns A promise that resolves to an object containing the tracker entries for the current day, or an object with a message and null location if no data is found.
   * @throws An error if there is an issue retrieving the data.
   */
  public async todayByUserId(id: number) {
    try {
      const result = await this.prisma.tracking.findMany({
        where: {
          userId: Number(id),
          createdAt: {
            gte: new Date(new Date().setHours(0, 0, 0, 0)),
          },
        },
      });

      if (result.length === 0) {
        return {
          message: 'No data found',
          location: null,
        };
      }

      return {
        message: 'Success',
        location: result,
      };
    } catch (e) {
      console.log(e);
      throw new Error(e);
    }
  }

  public async getTrackingByUser(start: string, end: string, userId: string) {
    const startDate = new Date(start);
    const endDate = new Date(end);
    endDate.setMinutes(endDate.getMinutes() + 1); 
    
    console.log(endDate)

    const tracks = await this.prisma.tracking.findMany({
      where: {
        userId: Number(userId),
        createdAt: {
          gte: startDate,
          lte: endDate,
        },
      },
    });

    return tracks.map(track => ({
      lat: track.longitude, 
      lng: track.latitude,
    }));
  }
}
