import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsLatitude, IsLongitude, IsNotEmpty } from 'class-validator';

export class CreateTrackerRequest {
  @ApiProperty()
  @IsNotEmpty()
  @IsLatitude()
  latitude: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsLongitude()
  longitude: number;

  @ApiProperty()
  @IsNotEmpty()
  @Transform(({ value }) => Number(value), { toClassOnly: true })
  userId: number;
}
