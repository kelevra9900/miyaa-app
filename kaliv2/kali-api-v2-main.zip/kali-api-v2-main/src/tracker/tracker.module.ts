import { Module } from '@nestjs/common';
import { PassportModule } from '@nestjs/passport';
import { PrismaService } from '../common/services/prisma.service';
import { TrackerController } from './tracker.controller';
import { TrackerGateway } from './tracker.gateway';
import { TrackerService } from './tracker.service';

@Module({
  imports: [PassportModule.register({ defaultStrategy: 'jwt' })],
  providers: [TrackerService, PrismaService, TrackerGateway],
  exports: [TrackerService],
  controllers: [TrackerController],
})
export class TrackerModule {}
