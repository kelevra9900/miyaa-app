import {ApiProperty} from '@nestjs/swagger';
import {Conferences} from '@prisma/client';
import {IsArray,IsNotEmpty,IsString} from 'class-validator';

export class CreateConferenceRequest {
  @ApiProperty({
    description: 'Code to identify the conference',
    example: 'CONF20313',
  })
  @IsNotEmpty()
  @IsString()
  code: string;

  @ApiProperty({
    description: 'Name of the organizer',
    example: 'Roger Torres',
  })
  @IsNotEmpty()
  @IsString()
  organizer: string;

  @IsArray()
  @ApiProperty({
    description: 'List of speakers',
    example: ['Roger Torres','John Doe'],
  })
  participants: [];
}

export type ConferencePagination = {
  conferences: Conferences[];
  total: number;
  totalPages: number;
  currentPage: number;
  perPage: number;
};
