import {Injectable} from '@nestjs/common';
import {PrismaService} from '../common/services/prisma.service';
import {CreateConferenceRequest} from './models/conference.dto';
import {Conferences} from '@prisma/client';

@Injectable()
export class ConferencesService {
  constructor(private readonly prismaService: PrismaService) { }

  /**
   * Retrieves a list of conferences.
   *
   * @param page - The page number (default: 1).
   * @param limit - The maximum number of conferences to retrieve per page (default: 10).
   * @param search - The search term to filter conferences by (optional).
   * @returns A promise that resolves to an array of conferences.
   */
  async getConferenceList(
    page = 1,
    limit = 10,
    search?: string,
  ): Promise<Conferences[]> {
    const skip = (page - 1) * limit;
    if (search) {
      const conferences = await this.prismaService.conferences.findMany({
        skip,
        take: limit,
        where: {
          OR: [
            {
              code: {
                contains: search,
                mode: 'insensitive',
              },
            },
            {
              organizer: {
                contains: search,
                mode: 'insensitive',
              },
            },
          ],
        },
      });

      return conferences;
    }

    const conferences = await this.prismaService.conferences.findMany({
      skip,
      take: limit,
    });

    return conferences;
  }
  /**
   * Retrieves the total number of conferences.
   *
   * @param search - The search term to filter conferences by (optional).
   * @returns A promise that resolves to the total number of conferences.
   */
  async getTotalConferences(search?: string): Promise<number> {
    if (search) {
      const total = await this.prismaService.conferences.count({
        where: {
          OR: [
            {
              code: {
                contains: search,
                mode: 'insensitive',
              },
            },
            {
              organizer: {
                contains: search,
                mode: 'insensitive',
              },
            },
          ],
        },
      });

      return total;
    }

    const total = await this.prismaService.conferences.count();

    return total;
  }
  /**
   * Retrieves a paginated list of conferences with additional metadata.
   *
   * @param page - The page number (default: 1).
   * @param limit - The maximum number of conferences to retrieve per page (default: 10).
   * @param search - The search term to filter conferences by (optional).
   * @returns An object containing the paginated list of conferences, total number of conferences,
   *          total number of pages, current page number, and number of conferences per page.
   */
  async findAll(page = 1,limit = 10,search?: string) {
    const total = await this.getTotalConferences(search);
    const conferences = await this.getConferenceList(page,limit,search);

    const totalPages = Math.ceil(total / limit);
    const currentPage = page;
    const perPage = limit;

    return {
      conferences,
      total,
      totalPages,
      currentPage,
      perPage,
    };
  }
  /**
   * Retrieves a paginated list of conferences with additional metadata.
   *
   * @param page - The page number (default: 1).
   * @param limit - The maximum number of conferences to retrieve per page (default: 10).
   * @param search - The search term to filter conferences by (optional).
   * @returns An object containing the paginated list of conferences, total number of conferences,
   *          total number of pages, current page number, and number of conferences per page.
   */
  async createConference(data: CreateConferenceRequest) {
    try {
    } catch (e) { }
  }
  /**
   * Modifies a conference with the specified ID.
   *
   * @param id - The ID of the conference to modify.
   * @param data - The data to update the conference with.
   * @throws Error - If the conference with the specified ID is not found.
   * @returns The modified conference.
   */
  async modifyConference(id: number,data: CreateConferenceRequest) {
    const findConference = await this.prismaService.conferences.findUnique({
      where: {
        id,
      },
    });

    if (!findConference) {
      throw new Error('Conference not found');
    }

    try {
      const conference = await this.prismaService.conferences.update({
        where: {
          id,
        },
        data: {
          ...data,
          updatedAt: new Date(),
        },
      });

      return conference;
    } catch (e) {
      throw e;
    }
  }
  /**
   * Deletes a conference with the specified ID.
   *
   * @param id - The ID of the conference to delete.
   * @throws Error - If the conference with the specified ID is not found.
   * @returns The deleted conference.
   */
  async deleteConference(id: number) {
    const findConference = await this.prismaService.conferences.findUnique({
      where: {
        id,
      },
    });

    if (!findConference) {
      throw new Error('Conference not found');
    }

    try {
      const conference = await this.prismaService.conferences.delete({
        where: {
          id,
        },
      });

      return conference;
    } catch (e) {
      throw e;
    }
  }
}
