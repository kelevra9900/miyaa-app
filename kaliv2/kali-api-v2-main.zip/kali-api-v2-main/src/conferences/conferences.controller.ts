import {
  Body,
  Controller,
  Get,
  Param,
  Put,
  Post,
  UseGuards,
  Query,
  ParseIntPipe,
  Delete,
} from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ConferencesService } from './conferences.service';
import {
  ConferencePagination,
  CreateConferenceRequest,
} from './models/conference.dto';

/**
 * ConferencesController class
 *
 * This class is responsible for handling HTTP requests related to conferences.
 * It provides methods for retrieving, creating, modifying, and deleting conferences.
 *
 * @class
 * @public
 * @constructor
 * @param {ConferencesService} conferencesService - The service responsible for handling conference data.
 */
@ApiTags('Conferences')
@ApiBearerAuth()
@UseGuards(AuthGuard())
@Controller('conferences')
export class ConferencesController {
  constructor(private readonly conferencesService: ConferencesService) {}

  /**
   * Retrieves a list of conferences based on the provided query parameters.
   *
   * @param page The page number for pagination.
   * @param limit The maximum number of conferences to retrieve per page.
   * @param search The search query to filter conferences.
   * @returns A Promise that resolves to a ConferencePagination object containing the retrieved conferences.
   */
  @Get('conferences')
  public async getConferences(
    @Query('page', ParseIntPipe) page: number,
    @Query('limit', ParseIntPipe) limit: number,
    @Query('search') search: string,
  ): Promise<ConferencePagination> {
    return this.conferencesService.findAll(page, limit, search);
  }

  /**
   * Creates a new conference.
   *
   * @param data The data for creating the conference.
   * @returns A Promise that resolves to a ConferencePagination object or unknown.
   */
  @Post('conferences')
  public async createConference(
    @Body() data: CreateConferenceRequest,
  ): Promise<ConferencePagination | unknown> {
    return this.conferencesService.createConference(data);
  }
  /**
   * Modifies a conference with the specified ID.
   *
   * @param id The ID of the conference to modify.
   * @param data The data for modifying the conference.
   * @returns A Promise that resolves to a ConferencePagination object or unknown.
   */
  @Put('conferences/:id')
  public async modifyConference(
    @Param('id') id: number,
    @Body() data: CreateConferenceRequest,
  ): Promise<ConferencePagination | unknown> {
    return this.conferencesService.modifyConference(id, data);
  }

  /**
   * Deletes a conference with the specified ID.
   *
   * @param id The ID of the conference to delete.
   * @returns A Promise that resolves to a ConferencePagination object or unknown.
   */
  @Delete('conferences/:id')
  public async deleteConference(
    @Param('id') id: number,
  ): Promise<ConferencePagination | unknown> {
    return this.conferencesService.deleteConference(id);
  }
}
