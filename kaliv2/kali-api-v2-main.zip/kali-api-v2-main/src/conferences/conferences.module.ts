import { Module } from '@nestjs/common';
import { PassportModule } from '@nestjs/passport';
import { ConferencesController } from './conferences.controller';
import { ConferencesService } from './conferences.service';
import { PrismaService } from '../common/services/prisma.service';

@Module({
  imports: [PassportModule.register({ defaultStrategy: 'jwt' })],
  controllers: [ConferencesController],
  providers: [ConferencesService, PrismaService],
  exports: [ConferencesService],
})
export class ConferencesModule {}
