import { AuthUser } from '../../src/auth/auth-user';

export const mockUser = (fields?: Partial<AuthUser>): AuthUser => ({
  firstName: 'Roger',
  middleName: null,
  lastName: 'Torres',
  username: 'Slevin',
  image: null,
  birthDate: new Date('1998-09-21'),
  registrationDate: new Date(),
  email: 'torresroger445@gmail.com',
  id: 1,
  emailVerified: true,
  passwordHash: 'passwordHash',
  ...fields,
  role: 'USER',
  banned: false,
  oneSignalId: null,
  online: false,
  lastSeen: new Date(),
});
