import {faker} from '@faker-js/faker';
import {RoundStatus} from '@prisma/client';


export const fakeUsers = () => ({
	username: faker.internet.userName(),
	email: faker.internet.email(),
	firstName: faker.name.firstName(),
	lastName: faker.name.lastName(),
	middleName: faker.name.middleName(),
	passwordHash: faker.internet.password(),
	image: faker.image.imageUrl(),
	emailVerified: true,
	birthDate: faker.date.past(),
});


export const fakeCategories = () => ({
	// Unique name
	name: faker.lorem.word(),
	slug: faker.lorem.slug(),
	thumbnail: faker.image.imageUrl(),
	image: faker.image.imageUrl()
})


export const fakeNotes = () => ({
	title: faker.lorem.sentence(),
	slug: faker.lorem.slug(),
	image: faker.image.imageUrl(),
	thumbnail: faker.image.imageUrl(),
	content: faker.lorem.paragraph(),
	createdBy: parseInt(faker.random.numeric(1)),
	is_approved: true,
})


export const fakeSuggestions = () => ({
	content: faker.lorem.paragraph(),
	userId: parseInt(faker.random.numeric(1)),
	rating: parseInt(faker.random.numeric(1)),
})


export const fakeSettings = () => ({
	logo: faker.image.imageUrl(),
	siteName: faker.lorem.word(),
	siteSubtitle: faker.lorem.sentence(),
	metaTitle: faker.lorem.sentence(),
	metaDescription: faker.lorem.paragraph(),
	metaTags: faker.lorem.words(),
	canonicalUrl: faker.internet.url(),
	ogTitle: faker.lorem.sentence(),
	ogDescription: faker.lorem.paragraph(),
	ogImage: faker.image.imageUrl(),
	ogUrl: faker.internet.url(),
	twitterHandle: faker.internet.userName(),
	twitterCardType: faker.lorem.word(),
	contactNumber: faker.phone.phoneNumber(),
	facebookUrl: faker.internet.url(),
	instagramUrl: faker.internet.url(),
	linkedinUrl: faker.internet.url(),
	location: faker.address.city(),
	tiktokUrl: faker.internet.url(),
	twitterUrl: faker.internet.url(),
	website: faker.internet.url(),
	youtubeUrl: faker.internet.url(),
});


export const fakeEnvironments = () => ({
	name: faker.lorem.word(),
	active: true,
	primary_color: faker.internet.color(),
	secondary_color: faker.internet.color(),
	logo: faker.image.imageUrl(),
	description: faker.lorem.paragraph(),
})

export const fakeRounds = () => ({
	name: faker.lorem.word(),
	start: faker.date.past().toISOString(),
	end: faker.date.future().toISOString(),
	status: RoundStatus.ACTIVE,
	timestamp: faker.date.recent(),
	user_roundParticipants: {
		connect: {

		}
	}
})


export const fakeShifts = () => ({
	name: faker.lorem.word(),
	start: faker.date.past().toISOString(),
	end: faker.date.future().toISOString(),
})

export const fakeCheckpoints = () => ({
	location: faker.address.city(),
	latitude: parseInt(faker.address.latitude()),
	longitude: parseInt(faker.address.longitude()),
	roundId: parseInt(faker.random.numeric(1)),
})

export const fakeSector = () => ({
	name: 'Inspector SOC',
})