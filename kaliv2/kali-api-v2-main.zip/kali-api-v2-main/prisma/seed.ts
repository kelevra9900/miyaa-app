// prisma/seed.ts
import {PrismaClient} from '@prisma/client';
import * as dotenv from 'dotenv';
import {fakeCheckpoints,fakeSector} from './sedders/fake-data';

const prisma = new PrismaClient({
  log: ['query'],
});

async function main() {
  const fakerRounds = 20;
  dotenv.config();
  /// --------- Fake data ---------------
  // for (let i = 0; i < fakerRounds; i++) {
  //   const data = fakeCheckpoints();
  //   await prisma.checkpoint.create({
  //     data,
  //   });
  // }
  const data = fakeSector();
  await prisma.sector.create({
    data,
  });
}

main()
  .catch((e) => console.error(e))
  .finally(async () => {
    await prisma.$disconnect();
  });
