-- AlterTable
ALTER TABLE "environment" ADD COLUMN     "logo" TEXT;
