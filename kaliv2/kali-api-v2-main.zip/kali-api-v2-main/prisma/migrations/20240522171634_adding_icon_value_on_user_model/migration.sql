-- AlterTable
ALTER TABLE "user" ADD COLUMN     "icon" TEXT;
