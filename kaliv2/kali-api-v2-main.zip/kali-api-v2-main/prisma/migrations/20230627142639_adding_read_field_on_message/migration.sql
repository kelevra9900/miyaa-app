-- AlterTable
ALTER TABLE "message" ADD COLUMN     "isRead" BOOLEAN NOT NULL DEFAULT false;
