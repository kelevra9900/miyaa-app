/*
  Warnings:

  - You are about to drop the `StoreNotice` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "StoreNotice" DROP CONSTRAINT "StoreNotice_environmentId_fkey";

-- DropForeignKey
ALTER TABLE "StoreNotice" DROP CONSTRAINT "StoreNotice_updatedBy_fkey";

-- DropTable
DROP TABLE "StoreNotice";

-- CreateTable
CREATE TABLE "Notice" (
    "id" SERIAL NOT NULL,
    "priority" "StoreStatus" NOT NULL DEFAULT 'HIGHT',
    "creator" TEXT NOT NULL,
    "notice" TEXT NOT NULL,
    "description" TEXT,
    "effectiveFrom" TIMESTAMP(3) NOT NULL,
    "expiredAt" TIMESTAMP(3) NOT NULL,
    "type" TEXT,
    "updatedBy" INTEGER NOT NULL,
    "environmentId" INTEGER NOT NULL,

    CONSTRAINT "Notice_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "Notice" ADD CONSTRAINT "Notice_environmentId_fkey" FOREIGN KEY ("environmentId") REFERENCES "environment"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Notice" ADD CONSTRAINT "Notice_updatedBy_fkey" FOREIGN KEY ("updatedBy") REFERENCES "user"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
