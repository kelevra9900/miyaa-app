/*
  Warnings:

  - You are about to drop the `user-toconferences` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "user-toconferences" DROP CONSTRAINT "user-toconferences_A_fkey";

-- DropForeignKey
ALTER TABLE "user-toconferences" DROP CONSTRAINT "user-toconferences_B_fkey";

-- AlterTable
ALTER TABLE "settings" ADD COLUMN     "terms" TEXT;

-- DropTable
DROP TABLE "user-toconferences";

-- CreateTable
CREATE TABLE "user-to-conferences" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL
);

-- CreateIndex
CREATE INDEX "_userToconferences_B_index" ON "user-to-conferences"("B");

-- CreateIndex
CREATE UNIQUE INDEX "_userToconferences_AB_unique" ON "user-to-conferences"("A", "B");

-- AddForeignKey
ALTER TABLE "user-to-conferences" ADD CONSTRAINT "user-to-conferences_A_fkey" FOREIGN KEY ("A") REFERENCES "user"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user-to-conferences" ADD CONSTRAINT "user-to-conferences_B_fkey" FOREIGN KEY ("B") REFERENCES "conferences"("id") ON DELETE CASCADE ON UPDATE CASCADE;
