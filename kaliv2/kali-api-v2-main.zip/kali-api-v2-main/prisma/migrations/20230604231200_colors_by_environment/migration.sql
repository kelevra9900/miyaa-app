-- AlterTable
ALTER TABLE "environment" ADD COLUMN     "primary_color" TEXT,
ADD COLUMN     "secondary_color" TEXT;
