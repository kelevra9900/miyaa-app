-- CreateEnum
CREATE TYPE "RoundStatus" AS ENUM ('IN_PROGRESS', 'COMPLETED', 'VERIFIED');

-- CreateTable
CREATE TABLE "Round" (
    "id" SERIAL NOT NULL,
    "start" TIMESTAMP(6) NOT NULL,
    "end" TIMESTAMP(6),
    "status" "RoundStatus" NOT NULL,

    CONSTRAINT "Round_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Checkpoint" (
    "id" SERIAL NOT NULL,
    "roundId" INTEGER NOT NULL,
    "location" TEXT NOT NULL,
    "timestamp" TIMESTAMP(6) NOT NULL,
    "latitude" DOUBLE PRECISION NOT NULL,
    "longitude" DOUBLE PRECISION NOT NULL,

    CONSTRAINT "Checkpoint_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "_RoundToUser" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL
);

-- CreateIndex
CREATE UNIQUE INDEX "_RoundToUser_AB_unique" ON "_RoundToUser"("A", "B");

-- CreateIndex
CREATE INDEX "_RoundToUser_B_index" ON "_RoundToUser"("B");

-- AddForeignKey
ALTER TABLE "Checkpoint" ADD CONSTRAINT "Checkpoint_roundId_fkey" FOREIGN KEY ("roundId") REFERENCES "Round"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_RoundToUser" ADD CONSTRAINT "_RoundToUser_A_fkey" FOREIGN KEY ("A") REFERENCES "Round"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_RoundToUser" ADD CONSTRAINT "_RoundToUser_B_fkey" FOREIGN KEY ("B") REFERENCES "user"("id") ON DELETE CASCADE ON UPDATE CASCADE;
