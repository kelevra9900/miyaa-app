-- AlterTable
ALTER TABLE "round" ADD COLUMN     "timestamp" TIMESTAMP(6) NOT NULL DEFAULT timezone('UTC'::text, now());
