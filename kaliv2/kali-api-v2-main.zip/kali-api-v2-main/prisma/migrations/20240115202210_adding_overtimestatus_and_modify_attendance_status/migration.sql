/*
  Warnings:

  - The `status` column on the `overtime` table would be dropped and recreated. This will lead to data loss if there is data in the column.

*/
-- CreateEnum
CREATE TYPE "Overtimetatus" AS ENUM ('ON_SITE', 'OFF_SITE', 'DONE');

-- AlterTable
ALTER TABLE "overtime" DROP COLUMN "status",
ADD COLUMN     "status" "Overtimetatus" DEFAULT 'ON_SITE';
