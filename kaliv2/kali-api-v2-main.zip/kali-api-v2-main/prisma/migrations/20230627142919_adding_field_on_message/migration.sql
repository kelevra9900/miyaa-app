-- AlterTable
ALTER TABLE "message" ADD COLUMN     "isMedia" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "media" TEXT;
