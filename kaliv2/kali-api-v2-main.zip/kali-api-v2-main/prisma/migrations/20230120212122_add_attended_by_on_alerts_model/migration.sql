-- AlterTable
ALTER TABLE "alert" ADD COLUMN     "attendedBy" INTEGER;

-- AddForeignKey
ALTER TABLE "alert" ADD CONSTRAINT "alert_attendedBy_fkey" FOREIGN KEY ("attendedBy") REFERENCES "user"("id") ON DELETE SET NULL ON UPDATE CASCADE;
