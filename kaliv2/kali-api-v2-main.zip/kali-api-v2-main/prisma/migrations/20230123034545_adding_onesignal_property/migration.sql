-- AlterTable
ALTER TABLE "user" ADD COLUMN     "oneSignalId" TEXT;
