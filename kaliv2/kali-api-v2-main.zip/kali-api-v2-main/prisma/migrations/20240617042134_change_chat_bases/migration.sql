/*
  Warnings:

  - You are about to drop the column `isMedia` on the `message` table. All the data in the column will be lost.
  - You are about to drop the column `isRead` on the `message` table. All the data in the column will be lost.
  - You are about to drop the column `media` on the `message` table. All the data in the column will be lost.
  - You are about to drop the column `recipientId` on the `message` table. All the data in the column will be lost.
  - You are about to drop the column `senderId` on the `message` table. All the data in the column will be lost.
  - You are about to drop the `Conversation` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `_UserToconferences` table. If the table is not empty, all the data it contains will be lost.
  - Added the required column `userId` to the `message` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "_UserToconferences" DROP CONSTRAINT "_UserToconferences_A_fkey";

-- DropForeignKey
ALTER TABLE "_UserToconferences" DROP CONSTRAINT "_UserToconferences_B_fkey";

-- DropForeignKey
ALTER TABLE "conversation_user" DROP CONSTRAINT "conversation_user_conversationId_fkey";

-- DropForeignKey
ALTER TABLE "message" DROP CONSTRAINT "message_conversationId_fkey";

-- DropForeignKey
ALTER TABLE "message" DROP CONSTRAINT "message_recipientId_fkey";

-- DropForeignKey
ALTER TABLE "message" DROP CONSTRAINT "message_senderId_fkey";

-- AlterTable
ALTER TABLE "message" DROP COLUMN "isMedia",
DROP COLUMN "isRead",
DROP COLUMN "media",
DROP COLUMN "recipientId",
DROP COLUMN "senderId",
ADD COLUMN     "seen" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "userId" INTEGER NOT NULL;

-- DropTable
DROP TABLE "Conversation";

-- DropTable
DROP TABLE "_UserToconferences";

-- CreateTable
CREATE TABLE "_userToconferences" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL
);

-- CreateTable
CREATE TABLE "conversation" (
    "id" SERIAL NOT NULL,

    CONSTRAINT "conversation_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "_userToconferences_B_index" ON "_userToconferences"("B");

-- CreateIndex
CREATE UNIQUE INDEX "_userToconferences_AB_unique" ON "_userToconferences"("A", "B");

-- AddForeignKey
ALTER TABLE "conversation_user" ADD CONSTRAINT "conversation_user_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES "conversation"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "message" ADD CONSTRAINT "message_userId_fkey" FOREIGN KEY ("userId") REFERENCES "user"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "message" ADD CONSTRAINT "message_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES "conversation"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_userToconferences" ADD CONSTRAINT "_userToconferences_A_fkey" FOREIGN KEY ("A") REFERENCES "user"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_userToconferences" ADD CONSTRAINT "_userToconferences_B_fkey" FOREIGN KEY ("B") REFERENCES "conferences"("id") ON DELETE CASCADE ON UPDATE CASCADE;
