-- AlterTable
ALTER TABLE "suggestion" ADD COLUMN     "rating" INTEGER NOT NULL DEFAULT 0;
