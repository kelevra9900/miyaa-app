-- CreateEnum
CREATE TYPE "AlertStatus" AS ENUM ('CREATED', 'UNDER_REVIEW', 'SOLVED', 'REJECTED', 'FALSE_ALARM');

-- AlterTable
ALTER TABLE "alert" ADD COLUMN     "status" "AlertStatus" DEFAULT E'CREATED',
ADD COLUMN     "updatedAt" TIMESTAMP(6) NOT NULL DEFAULT timezone('UTC'::text, now());
