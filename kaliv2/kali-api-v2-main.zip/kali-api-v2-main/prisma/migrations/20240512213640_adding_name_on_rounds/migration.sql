/*
  Warnings:

  - Added the required column `name` to the `round` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "round" ADD COLUMN     "name" TEXT NOT NULL;
