-- AlterTable
ALTER TABLE "Notice" ADD COLUMN     "is_approved" BOOLEAN DEFAULT true;
