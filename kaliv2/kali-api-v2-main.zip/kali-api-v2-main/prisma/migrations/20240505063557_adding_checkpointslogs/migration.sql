-- CreateTable
CREATE TABLE "checkpoint_log" (
    "id" SERIAL NOT NULL,
    "checkpointId" INTEGER NOT NULL,
    "guardId" INTEGER NOT NULL,
    "roundId" INTEGER NOT NULL,
    "timestamp" TIMESTAMP(6) NOT NULL DEFAULT timezone('UTC'::text, now()),

    CONSTRAINT "checkpoint_log_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "checkpoint_log" ADD CONSTRAINT "checkpoint_log_checkpointId_fkey" FOREIGN KEY ("checkpointId") REFERENCES "checkpoint"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "checkpoint_log" ADD CONSTRAINT "checkpoint_log_guardId_fkey" FOREIGN KEY ("guardId") REFERENCES "user"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "checkpoint_log" ADD CONSTRAINT "checkpoint_log_roundId_fkey" FOREIGN KEY ("roundId") REFERENCES "round"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
