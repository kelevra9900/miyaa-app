-- AlterTable
ALTER TABLE "Notice" ALTER COLUMN "priority" DROP NOT NULL;
