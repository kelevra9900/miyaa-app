-- AlterTable
ALTER TABLE "user" ADD COLUMN     "banned" BOOLEAN DEFAULT false;
