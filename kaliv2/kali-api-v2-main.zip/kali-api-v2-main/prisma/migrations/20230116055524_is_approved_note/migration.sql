-- AlterTable
ALTER TABLE "alert" ADD COLUMN     "image" TEXT,
ALTER COLUMN "createdAt" DROP NOT NULL,
ALTER COLUMN "updatedAt" DROP NOT NULL;

-- AlterTable
ALTER TABLE "note" ADD COLUMN     "is_approved" BOOLEAN DEFAULT false;
