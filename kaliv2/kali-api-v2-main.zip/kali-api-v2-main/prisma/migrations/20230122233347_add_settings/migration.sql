-- CreateTable
CREATE TABLE "settings" (
    "id" SERIAL NOT NULL,
    "logo" TEXT,
    "siteName" TEXT,
    "siteSubtitle" TEXT,
    "currency" TEXT,
    "metaTitle" TEXT,
    "metaDescription" TEXT,
    "metaTags" TEXT,
    "canonicalUrl" TEXT,
    "ogTitle" TEXT,
    "ogDescription" TEXT,
    "ogImage" TEXT,
    "ogUrl" TEXT,
    "twitterHandle" TEXT,
    "twitterCardType" TEXT,

    CONSTRAINT "settings_pkey" PRIMARY KEY ("id")
);
