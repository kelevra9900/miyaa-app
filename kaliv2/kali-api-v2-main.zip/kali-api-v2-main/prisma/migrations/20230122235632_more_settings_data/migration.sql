-- AlterTable
ALTER TABLE "settings" ADD COLUMN     "contactNumber" TEXT,
ADD COLUMN     "facebookUrl" TEXT,
ADD COLUMN     "instagramUrl" TEXT,
ADD COLUMN     "linkedinUrl" TEXT,
ADD COLUMN     "location" TEXT,
ADD COLUMN     "tiktokUrl" TEXT,
ADD COLUMN     "twitterUrl" TEXT,
ADD COLUMN     "website" TEXT,
ADD COLUMN     "youtubeUrl" TEXT;
