-- AlterTable
ALTER TABLE "environment" ADD COLUMN     "description" TEXT;
