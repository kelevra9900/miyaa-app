/*
  Warnings:

  - The values [PENDING,APPROVED,REJECTED] on the enum `AttendanceStatus` will be removed. If these variants are still used in the database, this will fail.
  - The values [ON_SITE,OFF_SITE,DONE] on the enum `Overtimetatus` will be removed. If these variants are still used in the database, this will fail.

*/
-- AlterEnum
BEGIN;
CREATE TYPE "AttendanceStatus_new" AS ENUM ('ON_SITE', 'OFF_SITE', 'DONE');
ALTER TABLE "attendance" ALTER COLUMN "status" DROP DEFAULT;
ALTER TABLE "attendance" ALTER COLUMN "status" TYPE "AttendanceStatus_new" USING ("status"::text::"AttendanceStatus_new");
ALTER TYPE "AttendanceStatus" RENAME TO "AttendanceStatus_old";
ALTER TYPE "AttendanceStatus_new" RENAME TO "AttendanceStatus";
DROP TYPE "AttendanceStatus_old";
ALTER TABLE "attendance" ALTER COLUMN "status" SET DEFAULT 'ON_SITE';
COMMIT;

-- AlterEnum
BEGIN;
CREATE TYPE "Overtimetatus_new" AS ENUM ('PENDING', 'APPROVED', 'REJECTED');
ALTER TABLE "overtime" ALTER COLUMN "status" DROP DEFAULT;
ALTER TABLE "overtime" ALTER COLUMN "status" TYPE "Overtimetatus_new" USING ("status"::text::"Overtimetatus_new");
ALTER TYPE "Overtimetatus" RENAME TO "Overtimetatus_old";
ALTER TYPE "Overtimetatus_new" RENAME TO "Overtimetatus";
DROP TYPE "Overtimetatus_old";
ALTER TABLE "overtime" ALTER COLUMN "status" SET DEFAULT 'PENDING';
COMMIT;

-- AlterTable
ALTER TABLE "attendance" ALTER COLUMN "status" SET DEFAULT 'ON_SITE';

-- AlterTable
ALTER TABLE "overtime" ALTER COLUMN "status" SET DEFAULT 'PENDING';
