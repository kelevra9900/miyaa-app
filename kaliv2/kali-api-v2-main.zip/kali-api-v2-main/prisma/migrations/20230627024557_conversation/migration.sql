/*
  Warnings:

  - You are about to drop the column `body` on the `message` table. All the data in the column will be lost.
  - You are about to drop the column `conversation_id` on the `message` table. All the data in the column will be lost.
  - You are about to drop the column `created_at` on the `message` table. All the data in the column will be lost.
  - You are about to drop the column `seen` on the `message` table. All the data in the column will be lost.
  - You are about to drop the column `updated_at` on the `message` table. All the data in the column will be lost.
  - You are about to drop the column `user_id` on the `message` table. All the data in the column will be lost.
  - You are about to drop the column `currency` on the `settings` table. All the data in the column will be lost.
  - You are about to drop the `conversation` table. If the table is not empty, all the data it contains will be lost.
  - Added the required column `content` to the `message` table without a default value. This is not possible if the table is not empty.
  - Added the required column `conversationId` to the `message` table without a default value. This is not possible if the table is not empty.
  - Added the required column `recipientId` to the `message` table without a default value. This is not possible if the table is not empty.
  - Added the required column `senderId` to the `message` table without a default value. This is not possible if the table is not empty.

*/
-- CreateEnum
CREATE TYPE "StoreStatus" AS ENUM ('HIGHT', 'MEDIUM', 'LOW');

-- DropForeignKey
ALTER TABLE "conversation" DROP CONSTRAINT "conversation_user_id_fkey";

-- DropForeignKey
ALTER TABLE "message" DROP CONSTRAINT "message_conversation_id_fkey";

-- DropForeignKey
ALTER TABLE "message" DROP CONSTRAINT "message_user_id_fkey";

-- AlterTable
ALTER TABLE "message" DROP COLUMN "body",
DROP COLUMN "conversation_id",
DROP COLUMN "created_at",
DROP COLUMN "seen",
DROP COLUMN "updated_at",
DROP COLUMN "user_id",
ADD COLUMN     "content" TEXT NOT NULL,
ADD COLUMN     "conversationId" INTEGER NOT NULL,
ADD COLUMN     "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN     "recipientId" INTEGER NOT NULL,
ADD COLUMN     "senderId" INTEGER NOT NULL;

-- AlterTable
ALTER TABLE "settings" DROP COLUMN "currency";

-- DropTable
DROP TABLE "conversation";

-- CreateTable
CREATE TABLE "Conversation" (
    "id" SERIAL NOT NULL,

    CONSTRAINT "Conversation_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "conversation_user" (
    "id" SERIAL NOT NULL,
    "userId" INTEGER NOT NULL,
    "conversationId" INTEGER NOT NULL,

    CONSTRAINT "conversation_user_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "StoreNotice" (
    "id" SERIAL NOT NULL,
    "priority" "StoreStatus" NOT NULL DEFAULT 'HIGHT',
    "creator" TEXT NOT NULL,
    "notice" TEXT NOT NULL,
    "description" TEXT,
    "effectiveFrom" TIMESTAMP(3) NOT NULL,
    "expiredAt" TIMESTAMP(3) NOT NULL,
    "type" TEXT,
    "updatedBy" INTEGER NOT NULL,
    "environmentId" INTEGER NOT NULL,

    CONSTRAINT "StoreNotice_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "conversation_user" ADD CONSTRAINT "conversation_user_userId_fkey" FOREIGN KEY ("userId") REFERENCES "user"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "conversation_user" ADD CONSTRAINT "conversation_user_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES "Conversation"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "message" ADD CONSTRAINT "message_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES "user"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "message" ADD CONSTRAINT "message_recipientId_fkey" FOREIGN KEY ("recipientId") REFERENCES "user"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "message" ADD CONSTRAINT "message_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES "Conversation"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "StoreNotice" ADD CONSTRAINT "StoreNotice_environmentId_fkey" FOREIGN KEY ("environmentId") REFERENCES "environment"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "StoreNotice" ADD CONSTRAINT "StoreNotice_updatedBy_fkey" FOREIGN KEY ("updatedBy") REFERENCES "user"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
