-- AlterTable
ALTER TABLE "environment" ADD COLUMN     "createdAt" TIMESTAMP(6) NOT NULL DEFAULT timezone('UTC'::text, now()),
ADD COLUMN     "updatedAt" TIMESTAMP(6) NOT NULL DEFAULT timezone('UTC'::text, now());
