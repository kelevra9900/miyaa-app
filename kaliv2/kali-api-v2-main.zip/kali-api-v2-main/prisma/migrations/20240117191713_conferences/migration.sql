-- CreateTable
CREATE TABLE "conferences" (
    "id" SERIAL NOT NULL,
    "code" TEXT NOT NULL,
    "organizer" TEXT NOT NULL,
    "createdAt" TIMESTAMP(6) NOT NULL DEFAULT timezone('UTC'::text, now()),
    "updatedAt" TIMESTAMP(6) NOT NULL DEFAULT timezone('UTC'::text, now()),

    CONSTRAINT "conferences_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "_UserToconferences" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL
);

-- CreateIndex
CREATE UNIQUE INDEX "_UserToconferences_AB_unique" ON "_UserToconferences"("A", "B");

-- CreateIndex
CREATE INDEX "_UserToconferences_B_index" ON "_UserToconferences"("B");

-- AddForeignKey
ALTER TABLE "_UserToconferences" ADD CONSTRAINT "_UserToconferences_A_fkey" FOREIGN KEY ("A") REFERENCES "user"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_UserToconferences" ADD CONSTRAINT "_UserToconferences_B_fkey" FOREIGN KEY ("B") REFERENCES "conferences"("id") ON DELETE CASCADE ON UPDATE CASCADE;
