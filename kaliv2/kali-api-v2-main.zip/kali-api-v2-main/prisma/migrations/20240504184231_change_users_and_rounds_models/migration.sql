/*
  Warnings:

  - You are about to drop the `Checkpoint` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `Notice` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `Round` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `_RoundToUser` table. If the table is not empty, all the data it contains will be lost.

*/
-- AlterEnum
-- This migration adds more than one value to an enum.
-- With PostgreSQL versions 11 and earlier, this is not possible
-- in a single migration. This can be worked around by creating
-- multiple migrations, each migration adding only one value to
-- the enum.


ALTER TYPE "RoundStatus" ADD VALUE 'ACTIVE';

-- DropForeignKey
ALTER TABLE "Checkpoint" DROP CONSTRAINT "Checkpoint_roundId_fkey";

-- DropForeignKey
ALTER TABLE "Notice" DROP CONSTRAINT "Notice_environmentId_fkey";

-- DropForeignKey
ALTER TABLE "Notice" DROP CONSTRAINT "Notice_updatedBy_fkey";

-- DropForeignKey
ALTER TABLE "_RoundToUser" DROP CONSTRAINT "_RoundToUser_A_fkey";

-- DropForeignKey
ALTER TABLE "_RoundToUser" DROP CONSTRAINT "_RoundToUser_B_fkey";

-- DropTable
DROP TABLE "Checkpoint";

-- DropTable
DROP TABLE "Notice";

-- DropTable
DROP TABLE "Round";

-- DropTable
DROP TABLE "_RoundToUser";

-- CreateTable
CREATE TABLE "round" (
    "id" SERIAL NOT NULL,
    "start" TIMESTAMP(6) NOT NULL,
    "end" TIMESTAMP(6),
    "status" "RoundStatus" NOT NULL DEFAULT 'IN_PROGRESS',

    CONSTRAINT "round_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "checkpoint" (
    "id" SERIAL NOT NULL,
    "roundId" INTEGER NOT NULL,
    "location" TEXT NOT NULL,
    "latitude" DOUBLE PRECISION NOT NULL,
    "longitude" DOUBLE PRECISION NOT NULL,
    "checkedAt" TIMESTAMP(6),

    CONSTRAINT "checkpoint_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "notice" (
    "id" SERIAL NOT NULL,
    "priority" "StoreStatus" DEFAULT 'HIGHT',
    "creator" TEXT NOT NULL,
    "notice" TEXT NOT NULL,
    "description" TEXT,
    "effectiveFrom" TIMESTAMP(3) NOT NULL,
    "expiredAt" TIMESTAMP(3) NOT NULL,
    "type" TEXT,
    "updatedBy" INTEGER NOT NULL,
    "environmentId" INTEGER NOT NULL,
    "is_approved" BOOLEAN DEFAULT true,

    CONSTRAINT "notice_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "_roundParticipants" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL
);

-- CreateTable
CREATE TABLE "_delayedRounds" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL
);

-- CreateIndex
CREATE UNIQUE INDEX "_roundParticipants_AB_unique" ON "_roundParticipants"("A", "B");

-- CreateIndex
CREATE INDEX "_roundParticipants_B_index" ON "_roundParticipants"("B");

-- CreateIndex
CREATE UNIQUE INDEX "_delayedRounds_AB_unique" ON "_delayedRounds"("A", "B");

-- CreateIndex
CREATE INDEX "_delayedRounds_B_index" ON "_delayedRounds"("B");

-- AddForeignKey
ALTER TABLE "checkpoint" ADD CONSTRAINT "checkpoint_roundId_fkey" FOREIGN KEY ("roundId") REFERENCES "round"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "notice" ADD CONSTRAINT "notice_environmentId_fkey" FOREIGN KEY ("environmentId") REFERENCES "environment"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "notice" ADD CONSTRAINT "notice_updatedBy_fkey" FOREIGN KEY ("updatedBy") REFERENCES "user"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_roundParticipants" ADD CONSTRAINT "_roundParticipants_A_fkey" FOREIGN KEY ("A") REFERENCES "round"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_roundParticipants" ADD CONSTRAINT "_roundParticipants_B_fkey" FOREIGN KEY ("B") REFERENCES "user"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_delayedRounds" ADD CONSTRAINT "_delayedRounds_A_fkey" FOREIGN KEY ("A") REFERENCES "round"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_delayedRounds" ADD CONSTRAINT "_delayedRounds_B_fkey" FOREIGN KEY ("B") REFERENCES "user"("id") ON DELETE CASCADE ON UPDATE CASCADE;
