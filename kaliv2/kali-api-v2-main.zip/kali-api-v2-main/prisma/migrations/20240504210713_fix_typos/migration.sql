/*
  Warnings:

  - You are about to drop the `_delayedRounds` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `_roundParticipants` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `checkpoint` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `notice` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "_delayedRounds" DROP CONSTRAINT "_delayedRounds_A_fkey";

-- DropForeignKey
ALTER TABLE "_delayedRounds" DROP CONSTRAINT "_delayedRounds_B_fkey";

-- DropForeignKey
ALTER TABLE "_roundParticipants" DROP CONSTRAINT "_roundParticipants_A_fkey";

-- DropForeignKey
ALTER TABLE "_roundParticipants" DROP CONSTRAINT "_roundParticipants_B_fkey";

-- DropForeignKey
ALTER TABLE "checkpoint" DROP CONSTRAINT "checkpoint_roundId_fkey";

-- DropForeignKey
ALTER TABLE "notice" DROP CONSTRAINT "notice_environmentId_fkey";

-- DropForeignKey
ALTER TABLE "notice" DROP CONSTRAINT "notice_updatedBy_fkey";

-- AlterTable
ALTER TABLE "round" ALTER COLUMN "status" DROP DEFAULT;

-- DropTable
DROP TABLE "_delayedRounds";

-- DropTable
DROP TABLE "_roundParticipants";

-- DropTable
DROP TABLE "checkpoint";

-- DropTable
DROP TABLE "notice";

-- CreateTable
CREATE TABLE "Checkpoint" (
    "id" SERIAL NOT NULL,
    "roundId" INTEGER NOT NULL,
    "location" TEXT NOT NULL,
    "timestamp" TIMESTAMP(6) NOT NULL,
    "latitude" DOUBLE PRECISION NOT NULL,
    "longitude" DOUBLE PRECISION NOT NULL,
    "name" TEXT NOT NULL,

    CONSTRAINT "Checkpoint_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Notice" (
    "id" SERIAL NOT NULL,
    "priority" "StoreStatus" DEFAULT 'HIGHT',
    "creator" TEXT NOT NULL,
    "notice" TEXT NOT NULL,
    "description" TEXT,
    "effectiveFrom" TIMESTAMP(3) NOT NULL,
    "expiredAt" TIMESTAMP(3) NOT NULL,
    "type" TEXT,
    "updatedBy" INTEGER NOT NULL,
    "environmentId" INTEGER NOT NULL,
    "is_approved" BOOLEAN DEFAULT true,

    CONSTRAINT "Notice_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "_RoundToUser" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL
);

-- CreateIndex
CREATE UNIQUE INDEX "_RoundToUser_AB_unique" ON "_RoundToUser"("A", "B");

-- CreateIndex
CREATE INDEX "_RoundToUser_B_index" ON "_RoundToUser"("B");

-- AddForeignKey
ALTER TABLE "Checkpoint" ADD CONSTRAINT "Checkpoint_roundId_fkey" FOREIGN KEY ("roundId") REFERENCES "round"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Notice" ADD CONSTRAINT "Notice_environmentId_fkey" FOREIGN KEY ("environmentId") REFERENCES "environment"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Notice" ADD CONSTRAINT "Notice_updatedBy_fkey" FOREIGN KEY ("updatedBy") REFERENCES "user"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_RoundToUser" ADD CONSTRAINT "_RoundToUser_A_fkey" FOREIGN KEY ("A") REFERENCES "round"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_RoundToUser" ADD CONSTRAINT "_RoundToUser_B_fkey" FOREIGN KEY ("B") REFERENCES "user"("id") ON DELETE CASCADE ON UPDATE CASCADE;
