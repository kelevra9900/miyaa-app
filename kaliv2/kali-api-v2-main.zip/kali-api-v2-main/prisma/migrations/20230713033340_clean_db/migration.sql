/*
  Warnings:

  - You are about to drop the column `altitude` on the `tracking` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "tracking" DROP COLUMN "altitude";
