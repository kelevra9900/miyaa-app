/*
  Warnings:

  - You are about to drop the column `oneSignalId` on the `user` table. All the data in the column will be lost.
  - You are about to drop the `_userToconferences` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `checkpoint_log` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `conversation_user` table. If the table is not empty, all the data it contains will be lost.

*/
-- CreateEnum
CREATE TYPE "TypeMessage" AS ENUM ('TEXT', 'IMAGE', 'VIDEO', 'AUDIO');

-- DropForeignKey
ALTER TABLE "_userToconferences" DROP CONSTRAINT "_userToconferences_A_fkey";

-- DropForeignKey
ALTER TABLE "_userToconferences" DROP CONSTRAINT "_userToconferences_B_fkey";

-- DropForeignKey
ALTER TABLE "checkpoint_log" DROP CONSTRAINT "checkpoint_log_checkpointId_fkey";

-- DropForeignKey
ALTER TABLE "checkpoint_log" DROP CONSTRAINT "checkpoint_log_guardId_fkey";

-- DropForeignKey
ALTER TABLE "checkpoint_log" DROP CONSTRAINT "checkpoint_log_roundId_fkey";

-- DropForeignKey
ALTER TABLE "conversation_user" DROP CONSTRAINT "conversation_user_conversationId_fkey";

-- DropForeignKey
ALTER TABLE "conversation_user" DROP CONSTRAINT "conversation_user_userId_fkey";

-- AlterTable
ALTER TABLE "message" ADD COLUMN     "type" "TypeMessage" NOT NULL DEFAULT 'TEXT';

-- AlterTable
ALTER TABLE "user" DROP COLUMN "oneSignalId",
ADD COLUMN     "fcm" TEXT;

-- DropTable
DROP TABLE "_userToconferences";

-- DropTable
DROP TABLE "checkpoint_log";

-- DropTable
DROP TABLE "conversation_user";

-- CreateTable
CREATE TABLE "conversation-user" (
    "id" SERIAL NOT NULL,
    "userId" INTEGER NOT NULL,
    "conversationId" INTEGER NOT NULL,

    CONSTRAINT "conversation-user_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "announcement" (
    "id" SERIAL NOT NULL,
    "title" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "image" TEXT,
    "createdAt" TIMESTAMP(6) NOT NULL DEFAULT timezone('UTC'::text, now()),
    "updatedAt" TIMESTAMP(6) NOT NULL DEFAULT timezone('UTC'::text, now()),
    "is_approved" BOOLEAN DEFAULT false,
    "createdBy" INTEGER NOT NULL,

    CONSTRAINT "announcement_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "user-toconferences" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL
);

-- CreateTable
CREATE TABLE "checkpoint-log" (
    "id" SERIAL NOT NULL,
    "checkpointId" INTEGER NOT NULL,
    "guardId" INTEGER NOT NULL,
    "roundId" INTEGER NOT NULL,
    "timestamp" TIMESTAMP(6) NOT NULL DEFAULT timezone('UTC'::text, now()),

    CONSTRAINT "checkpoint-log_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "_userToconferences_B_index" ON "user-toconferences"("B");

-- CreateIndex
CREATE UNIQUE INDEX "_userToconferences_AB_unique" ON "user-toconferences"("A", "B");

-- AddForeignKey
ALTER TABLE "conversation-user" ADD CONSTRAINT "conversation-user_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES "conversation"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "conversation-user" ADD CONSTRAINT "conversation-user_userId_fkey" FOREIGN KEY ("userId") REFERENCES "user"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "announcement" ADD CONSTRAINT "announcement_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES "user"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user-toconferences" ADD CONSTRAINT "user-toconferences_A_fkey" FOREIGN KEY ("A") REFERENCES "user"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user-toconferences" ADD CONSTRAINT "user-toconferences_B_fkey" FOREIGN KEY ("B") REFERENCES "conferences"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "checkpoint-log" ADD CONSTRAINT "checkpoint-log_checkpointId_fkey" FOREIGN KEY ("checkpointId") REFERENCES "checkpoint"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "checkpoint-log" ADD CONSTRAINT "checkpoint-log_guardId_fkey" FOREIGN KEY ("guardId") REFERENCES "user"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "checkpoint-log" ADD CONSTRAINT "checkpoint-log_roundId_fkey" FOREIGN KEY ("roundId") REFERENCES "round"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
