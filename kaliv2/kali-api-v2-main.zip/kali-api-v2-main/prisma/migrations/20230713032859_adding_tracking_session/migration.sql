-- CreateTable
CREATE TABLE "tracking" (
    "id" SERIAL NOT NULL,
    "latitude" DOUBLE PRECISION NOT NULL,
    "longitude" DOUBLE PRECISION NOT NULL,
    "altitude" DOUBLE PRECISION NOT NULL,
    "createdAt" TIMESTAMP(6) NOT NULL DEFAULT timezone('UTC'::text, now()),
    "updatedAt" TIMESTAMP(6) NOT NULL DEFAULT timezone('UTC'::text, now()),
    "userId" INTEGER NOT NULL,

    CONSTRAINT "tracking_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "tracking" ADD CONSTRAINT "tracking_userId_fkey" FOREIGN KEY ("userId") REFERENCES "user"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
