-- AlterTable
ALTER TABLE "environment" ALTER COLUMN "primary_color" SET DEFAULT '#0f406b',
ALTER COLUMN "secondary_color" SET DEFAULT '#1285c1';
