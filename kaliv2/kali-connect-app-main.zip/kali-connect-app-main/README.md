# Kali Connect app

Kali Connect is a cutting-edge mobile application developed using the Flutter SDK (version 3.1.0) that allows seamless communication and connection between individuals. This README provides essential information to get started with the project, including installation instructions, features, and basic usage guidelines.

![Logo](https://firebasestorage.googleapis.com/v0/b/kali-fe781.appspot.com/o/1024.png?alt=media&token=d0688b13-0a31-41b8-bdc4-c99fd4bf7619)

## Authors

- [Roger Torres D.](https://www.github.com/kelevra9900)

## Table of Contents

- [Features](#features)
- [Installation](#installation)
- [Usage](#usage)
- [License](#license)

## Features

Kali Connect comes packed with a variety of features designed to enhance communication and connection:

- **Instant Messaging**: Send and receive text messages in real-time with a user-friendly interface.
- **Media Sharing**: Share images, videos, and audio clips effortlessly within the app.
- **Real-time Alerts**: Alerts on real time.
- **Geolocalization**: Send your Lat and long in your alerts.
- **Status Updates**: Share your current status and let others know what you're up to.
- **User Profiles**: Customize your profile with a profile picture and status message.
- **Security**: Rest assured that your conversations are encrypted and secure.

## Installation

Follow these steps to install and set up Kali Connect on your device:

1. **Flutter Installation**: Make sure you have Flutter SDK version 3.16.9 installed. You can download it from [Flutter's official website](https://flutter.dev/docs/get-started/install).

2. **Clone the Repository**: Clone this repository to your local machine using the following command:

   ```sh
   git clone https://github.com/kelevra9900/kali-connect-app.git

Navigate to Project Directory: Change your working directory to the project folder:

   ```sh
    cd kali-connect-app
   ```

Install Dependencies: Run the following command to install the project's dependencies:

   ```sh
    fvm flutter pub get
   ```

Run the App: Launch the app on an emulator or a physical device using:

   ```sh
    fvm flutter run
   ```

The app should now be up and running on your device.

## Usage

User Registration: Upon launching the app, create an account or log in with your existing credentials.

Home Screen: The home screen will display the alert button, history, suggestions, and profile.

Chatting: Tap on a contact or group to start a conversation. Use the text input field to type messages.

Profile: Customize your profile picture and status by navigating to the profile section

## License

This project is licensed under the MIT License, which means you are free to use, modify, and distribute it according to the terms of the license.

For any further questions or inquiries, please contact our support team at <torresroger445@gmail.com>.

Thank you for choosing Kali Connect to stay connected! We hope you enjoy using our app.

sj0wouoX8ASDkLjP
miyaa
