package com.sissa.trablisa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
