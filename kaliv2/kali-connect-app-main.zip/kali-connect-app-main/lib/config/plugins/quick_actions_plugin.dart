import 'package:get/get.dart';
import 'package:quick_actions/quick_actions.dart';

import '../../routes/app_routes.dart';

class QuickActionsPlugin {
  static registerActions() {
    const QuickActions quickActions = QuickActions();

    quickActions.initialize((shortcutType) {
      switch (shortcutType) {
        case 'emergency':
          Get.toNamed(Routes.root);
          break;
        case 'chat':
          Get.toNamed(Routes.chat);
          break;
        case 'notifications':
          Get.toNamed(Routes.notifications);
          break;
        case 'settings':
          Get.toNamed(Routes.settings);
          break;
      }
    });

    quickActions.setShortcutItems(<ShortcutItem>[
      const ShortcutItem(
        type: 'emergency',
        localizedTitle: 'Emergency',
        icon: 'ic_launcher',
      ),
      const ShortcutItem(
        type: 'chat',
        localizedTitle: 'Chat',
        icon: 'ic_launcher',
      ),
      const ShortcutItem(
        type: 'notifications',
        localizedTitle: 'Notifications',
        icon: 'ic_launcher',
      ),
      const ShortcutItem(
        type: 'settings',
        localizedTitle: 'Settings',
        icon: 'ic_launcher',
      ),
    ]);
  }
}
