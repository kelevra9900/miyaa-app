import 'package:get/get.dart';

import '../utils/constants.dart';

class ChatsProvider extends GetConnect {
  String url = '${Constants().baseUrl}chats';

  getChats() async {}
}
