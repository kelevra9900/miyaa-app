import 'dart:io';

import 'package:dio/dio.dart' as dio;
import 'package:flutter/foundation.dart' as foundation;
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../models/attendance_model.dart';
import '../models/auth_response_model.dart';
import '../models/blog_model.dart';
import '../models/chat_model.dart';
import '../models/create_alert_model.dart';
import '../models/documents_model.dart';
import '../models/my_alerts_model.dart';
import '../models/rounds_model.dart';
import '../models/user_model.dart';
import '../services/auth_service.dart';
import '../utils/constants.dart';
import '../utils/endpoints.dart';
import 'dio_client.dart';

class LaravelApiClient extends GetxService {
  late GetStorage box = GetStorage();
  late DioClient _httpClient;
  final Rx<String> token = ''.obs;
  dio.Options? _optionsNetwork;

  LaravelApiClient() {
    _httpClient = DioClient(Constants().baseUrl, dio.Dio());
  }

  Future<LaravelApiClient> init() async {
    _optionsNetwork = _httpClient.optionsNetwork;
    var storedToken = await getToken();

    if (storedToken.isNotEmpty) {
      _setAuthorizationHeader(storedToken);
    }
    return this;
  }

  bool isLoading({String? task, List<String>? tasks}) {
    return _httpClient.isLoading(task: task, tasks: tasks);
  }

  void setToken(String tokenized) async {
    await box.write(Constants().key, tokenized);
    _setAuthorizationHeader(tokenized);
  }

  void _setAuthorizationHeader(String token) {
    _httpClient.optionsNetwork.headers = {
      'Authorization': 'Bearer $token',
    };
  }

  Future<String> getToken() async {
    final storedToken = await box.read(Constants().key);
    return storedToken ?? '';
  }

  void forceRefresh({Duration duration = const Duration(minutes: 10)}) {
    if (!foundation.kDebugMode) {}
  }

  void unForceRefresh({Duration duration = const Duration(minutes: 10)}) {
    if (!foundation.kDebugMode) {}
  }

  myInfo() async {
    // fetch my info to profile
    var user = await profile();
    if (user != null) {
      Get.find<AuthService>().user.value = user;
    }
  }

  Future<ResLogin> login(
      {required String username, required String password}) async {
    try {
      var response = await _httpClient.post(
        Endpoints.login,
        data: {
          'identifier': username,
          'password': password,
        },
        options: _optionsNetwork,
      );

      var received = ResLogin.fromJson(response.data);
      if (received.jwt != null) {
        setToken(received.jwt!);
        return received;
      } else {
        print(response.data);
        throw Exception(response.data['message']);
      }
    } catch (e) {
      // Proper error handling
      rethrow;
    }
  }

  Future<User?> profile() async {
    try {
      var response = await _httpClient.get(
        Endpoints.me,
      );
      if (response.data != null) {
        Get.find<AuthService>().user.value = User.fromJson(response.data);
        box.write('current_user', response.data);
        return User.fromJson(response.data);
      } else {
        throw Exception(['message']);
      }
    } catch (e) {
      Get.find<AuthService>().logout();
      return null;
    }
  }

  Future<void> refreshFCMToken() {
    // TODO: Implement this method
    // Get the actual token from the device and compare it with the one stored in the database
    // If they are different, update the token in the database and in the device storage
    throw UnimplementedError();
  }

  Future<void> logout() async {
    try {
      await _httpClient.post(
        Endpoints.logout,
      );
      box.erase();
    } catch (e) {
      rethrow;
    }
  }

// roundId: number,guardId: number,checkpointId: number
  Future<void> checkpointLog(int roundId, int checkpointId) async {
    try {
      await _httpClient.post('/users/me/checkpoint', data: {
        'roundId': roundId,
        'checkpointId': checkpointId,
      });
    } catch (e) {
      rethrow;
    }
  }

  Future<BlogResponse> blogs({
    int? page = 1,
  }) async {
    var blogs = await _httpClient.get(
      '/notes?page=$page&limit=10',
    );

    if (blogs.data != null) {
      return BlogResponse.fromJson(blogs.data);
    } else {
      throw Exception(['message']);
    }
  }

  Future<BlogResponse> blog({required int id}) async {
    var blog = await _httpClient.get(
      '/notes/$id',
    );
    if (blog.data != null) {
      return BlogResponse.fromJson(blog.data);
    } else {
      throw Exception(['message']);
    }
  }

  Future<MyAlertsResponse> alertHistory({
    int? page = 0,
    required int userId,
  }) async {
    var response = await _httpClient.get(
      '/alerts/user/$userId',
    );

    if (response.data != null) {
      return MyAlertsResponse.fromJson(response.data);
    } else {
      throw Exception(['message']);
    }
  }

  Future sendAlert(CreateAlertModel alert) async {
    var tkn = await getToken();
    var response = await _httpClient.post(
      '/alerts',
      options: dio.Options(
        headers: {
          'Authorization': 'Bearer $tkn',
        },
      ),
      data: alert.toJson(),
    );
    if (response.data != null) {
      return response.data;
    } else {
      throw Exception(['message']);
    }
  }

  Future sendSuggestion({
    required int userId,
    required String content,
    required double rating,
  }) async {
    var response = await _httpClient.post(
      '/suggestions',
      data: {
        'content': content,
        'userId': userId,
        'rating': rating,
      },
    );

    if (response.data != null) {
      return response.data;
    } else {
      throw Exception(['message']);
    }
  }

  Future<ChatResponse> getAllConversations({
    int? page = 0,
    required int userId,
  }) async {
    var conversations = await _httpClient.get(
      '/chat/my-conversations?page=$page&limit=10',
    );
    if (conversations.data != null) {
      return ChatResponse.fromJson(conversations.data);
    } else {
      throw Exception(['message']);
    }
  }

  Future sendMessage({required String message}) async {
    var response = await _httpClient.post(
      '/chat/send-message',
      data: {'content': message},
    );
    if (response.data != null) {
      return response.data;
    } else {
      throw Exception(['message']);
    }
  }

  Future<bool> updateUserProfile({required String token}) async {
    try {
      await _httpClient.put(
        '/users/me/onesignal',
        data: {'onesignalId': token},
      );
      return true;
    } catch (e) {
      throw Exception(['message']);
    }
  }

  Future<dynamic> updateNotificationToken({
    String? token,
    required int userId,
  }) async {
    Map<String, dynamic> data = {
      'oneSignalId': token,
    };
    return _httpClient
        .put(
          '/users/$userId',
          data: data,
        )
        .then(
          (response) => response.data,
        );
  }

  Future<dynamic> uploadImage({
    required dio.FormData formData,
    required String filePath,
  }) async {
    try {
      List<File> files = [File(filePath)];
      return await _httpClient.uploadFiles(
        uri: '/upload',
        formData: formData,
        files: files,
      );
    } catch (e) {
      // Proper error handling
      rethrow;
    }
  }

  Future<ResLogin?> uploadBiometric({
    required String filePath,
    required dio.FormData formData,
    required String uri,
  }) async {
    try {
      File file = File(filePath);

      final response = await _httpClient.uploadFileRecognition(
        uri: uri,
        formData: formData,
        file: file,
      );

      if (response != null) {
        setToken(response.jwt!);
        return response;
      }
      return response;
    } catch (e) {
      Get.log('Error uploading biometric $e');
      rethrow;
    }
  }

  Future<dynamic> checkInCheckOut({
    required String filePath,
    required dio.FormData formData,
    required String uri,
    required bool isCheckIn,
  }) async {
    try {
      File file = File(filePath);
      if (isCheckIn) {
        return await _httpClient.uploadFileRecognition(
          uri: uri,
          formData: formData,
          file: file,
        );
      } else {
        return await _httpClient.putFileRecognition(
          uri: uri,
          formData: formData,
          file: file,
        );
      }
    } catch (e) {
      Get.log('Error uploading biometric $e');
      rethrow;
    }
  }

  // get me attendance me/attendence
  Future<AttendanceModel?> getMyAttendance() async {
    try {
      var response = await _httpClient.get(
        '/users/me/attendance',
      );
      if (response.data != null) {
        return AttendanceModel.fromJson(response.data);
      } else {
        throw Exception(['message']);
      }
    } catch (e) {
      // Proper error handling
      rethrow;
    }
  }

  // check in
  Future<dynamic> checkIn() async {
    try {
      var response = await _httpClient.post(
        '/users/me/attendance/check-in',
      );
      if (response.data != null) {
        return AttendanceModel.fromJson(response.data);
      } else {
        throw Exception(['message']);
      }
    } catch (e) {
      // Proper error handling
      rethrow;
    }
  }

  // check out
  Future<dynamic> checkOut() async {
    try {
      var response = await _httpClient.put(
        '/users/me/attendance/check-out',
      );
      if (response.data != null) {
        return AttendanceModel.fromJson(response.data);
      } else {
        throw Exception(['message']);
      }
    } catch (e) {
      // Proper error handling
      rethrow;
    }
  }

  // getDocuments, response DocumentsModel[] /documents
  Future<MyDocuments> getDocuments() async {
    try {
      var response = await _httpClient.get(
        '/users/me/documents',
      );
      if (response.data != null) {
        return MyDocuments.fromJson(response.data);
      } else {
        throw Exception(['message']);
      }
    } catch (e) {
      // Proper error handling
      rethrow;
    }
  }

  // Create a new document, sending the file to multipart/form-data
  Future<DocumentsModel> createDocument({
    required String filePath,
    required dio.FormData formData,
    required String documentType,
  }) async {
    try {
      List<File> files = [File(filePath)];
      var response = await _httpClient.uploadDocuments(
        uri: '/users/me/documents',
        formData: formData,
        documentType: documentType,
        files: files,
      );

      return DocumentsModel.fromJson(response['data']);
    } catch (e) {
      rethrow;
    }
  }

  Stream<MyRounds> getRounds() {
    return _httpClient
        .getStream(
          '/users/me/rounds',
        )
        .cast<MyRounds>();
  }

  Stream<RoundsResponse> getAllRounds(int page, int limit) {
    return _httpClient
        .getRoundsStream(
          '/rounds',
        )
        .cast<RoundsResponse>();
  }
}
