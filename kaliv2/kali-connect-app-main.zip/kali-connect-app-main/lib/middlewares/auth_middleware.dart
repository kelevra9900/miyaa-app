import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../routes/app_routes.dart';
import '../utils/constants.dart';

class AuthMiddleware extends GetMiddleware {
  late GetStorage box = GetStorage();

  @override
  RouteSettings? redirect(String? route) {
    var token = box.read(Constants().key);
    if (token == null) {
      // return const RouteSettings(name: Routes.login);
    } else {
      // if (!isValidToken(token)) {
      //   // If the token is not valid, redirect to the login page
      //   return const RouteSettings(name: Routes.login);
      // }

      return null;
    }
    return null;
  }

  // Example method to check token validity (replace it with your actual logic)
  bool isValidToken(String token) {
    // You may need to make an API call or some other logic to validate the token
    // For simplicity, let's assume a valid token is any non-empty string
    return token.isNotEmpty;
  }
}
