import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import 'ui.dart';

class Helper {
  DateTime? currentBackPressTime;

  Future<bool> onWillPop() {
    DateTime now = DateTime.now();
    if (currentBackPressTime == null ||
        now.difference(currentBackPressTime!) > const Duration(seconds: 2)) {
      currentBackPressTime = now;
      Get.showSnackbar(
        Ui.defaultSnackBar(
          title: 'Atención',
          message: 'Toca de nuevo para salir de la aplicación!',
        ),
      );
      return Future.value(false);
    }
    SystemChannels.platform.invokeMethod('SystemNavigator.pop');
    return Future.value(true);
  }

  getDate(DateTime time) async {
    String date = DateFormat('dd MMMM yy').format(time);
    return date;
  }

  // Format date string to format 'dd MMMM yyyy'
  String formatDate(String date) {
    return DateFormat('dd MMMM yyyy').format(DateTime.parse(date));
  }

  // Format date string to hh:mm:s
  String formatTime(String date) {
    return DateFormat('hh:mm').format(DateTime.parse(date));
  }

  String formatDateTime(String date) {
    return DateFormat('hh:mm:s').format(DateTime.parse(date));
  }

  // Switch case for the status of the alert
  String getStatus(String status) {
    switch (status) {
      case 'CREATED':
        return 'Creado';
      case 'UNDER_REVIEW':
        return 'En revisión';
      case 'SOLVED':
        return 'Resuelto';
      case 'REJECTED':
        return 'Rechazado';
      case 'FALSE_ALARM':
        return 'Falsa alarma';
      default:
        return 'Pendiente';
    }
  }
}

extension DateTimeExtension on DateTime {
  String getMonthString() {
    switch (month) {
      case 1:
        return 'Jan.';
      case 2:
        return 'Feb.';
      case 3:
        return 'Mar.';
      case 4:
        return 'Apr.';
      case 5:
        return 'May';
      case 6:
        return 'Jun.';
      case 7:
        return 'Jul.';
      case 8:
        return 'Aug.';
      case 9:
        return 'Sept.';
      case 10:
        return 'Oct.';
      case 11:
        return 'Nov.';
      case 12:
        return 'Dec.';
      default:
        return 'Err';
    }
  }
}
