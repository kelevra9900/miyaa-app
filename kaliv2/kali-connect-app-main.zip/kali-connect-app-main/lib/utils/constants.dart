class Constants {
  final String appName = 'Trablisa';
  final String appVersion = '1.5.2';
  // final String baseUrl = 'https://kali-connect-api.herokuapp.com';
  final String baseUrl = 'http://10.0.2.2:1337';
  // final String baseUrl = 'https://7040-187-190-202-151.ngrok-free.app';
  final String key = 'TOKEN';
  final String currentUser = 'CURRENT_USER';
  final String themeMode = 'ThemeMode.light';
  final String logo = 'assets/images/logo.png';
}
