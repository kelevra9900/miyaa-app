import 'package:flutter/material.dart';

import '../common/theme.dart';

class ThemeUtils {
  static ThemeData isKali() {
    return ThemeData(
      unselectedWidgetColor: KaliColors.primaryColor,
      brightness: Brightness.light,
      visualDensity: VisualDensity.compact,
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ButtonStyle(
          backgroundColor: WidgetStateProperty.resolveWith<Color?>(
              (Set<WidgetState> states) {
            if (states.contains(WidgetState.hovered)) {
              return const Color(0xff031f41);
            }
            return const Color(0xff031f41);
          }),
          foregroundColor: WidgetStateProperty.resolveWith<Color?>(
              (Set<WidgetState> states) {
            return const Color(0xffebebeb);
          }),
        ),
      ),
      primaryColorLight: const Color(0xffffffff),
      // accentColor: const Color(0xff031f41),
      colorScheme: const ColorScheme(
        primary: Color(0xff031f41),
        secondary: Color(0xff031f41),
        surface: Color(0xffebebeb),
        error: Color(0xffb00020),
        onPrimary: Color(0x0ff00000),
        onSecondary: Color(0xffffffff),
        onSurface: Color(0xff031f41),
        onError: Color(0xffffffff),
        brightness: Brightness.light,
      ),
      shadowColor: Colors.grey,
      hoverColor: const Color(0xff054177),
    );
  }

  static ThemeData isMultiservice() {
    return ThemeData(
      unselectedWidgetColor: StudioBikeColos.primaryColor,
      brightness: Brightness.light,
      visualDensity: VisualDensity.compact,
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ButtonStyle(
          backgroundColor: WidgetStateProperty.resolveWith<Color?>(
              (Set<WidgetState> states) {
            if (states.contains(WidgetState.hovered)) {
              return StudioBikeColos.primaryColor;
            }
            return StudioBikeColos.primaryColor;
          }),
          foregroundColor: WidgetStateProperty.resolveWith<Color?>(
              (Set<WidgetState> states) {
            return const Color(0xffebebeb);
          }),
        ),
      ),
      primaryColorLight: const Color(0xffffffff),
      colorScheme: const ColorScheme(
        primary: StudioBikeColos.primaryColor,
        secondary: StudioBikeColos.primaryColor,
        surface: Color(0xffebebeb),
        error: Color(0xffb00020),
        onPrimary: Color(0xffffffff),
        onSecondary: Color(0xffffffff),
        onSurface: Color(0xffffffff),
        onError: Color(0xffffffff),
        brightness: Brightness.light,
      ),
      shadowColor: Colors.grey,
      hoverColor: const Color(0xff054177),
    );
  }

  static ThemeData isStudioBike() {
    return ThemeData(
      unselectedWidgetColor: StudioBikeColos.primaryColor,
      brightness: Brightness.light,
      visualDensity: VisualDensity.compact,
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ButtonStyle(
          backgroundColor: WidgetStateProperty.resolveWith<Color?>(
              (Set<WidgetState> states) {
            if (states.contains(WidgetState.hovered)) {
              return const Color(0xff031f41);
            }
            return const Color(0xff031f41);
          }),
          foregroundColor: WidgetStateProperty.resolveWith<Color?>(
              (Set<WidgetState> states) {
            return const Color(0xffebebeb);
          }),
        ),
      ),
      primaryColorLight: const Color(0xffffffff),
      // accentColor: const Color(0xff031f41),
      colorScheme: const ColorScheme(
        primary: StudioBikeColos.primaryColor,
        secondary: StudioBikeColos.primaryColor,
        surface: Color(0xffebebeb),
        error: Color(0xffb00020),
        onPrimary: Color(0xffffffff),
        onSecondary: Color(0xffffffff),
        onSurface: Color(0xffffffff),
        onError: Color(0xffffffff),
        brightness: Brightness.light,
      ),
      shadowColor: Colors.grey,
      hoverColor: StudioBikeColos.primaryColor,
    );
  }
}
