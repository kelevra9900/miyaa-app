import 'package:get/get.dart';
import 'package:miyaa/providers/laravel_provider.dart';
import 'package:miyaa/utils/constants.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;

class SocketManager extends GetxService {
  late IO.Socket socket;
  final _token = RxnString();

  // Inicializar el servicio
  Future<SocketManager> init() async {
    String? token = await LaravelApiClient().getToken();
    connectWithToken(token);
    return this;
  }

  void connectWithToken(String? token) {
    _token.value = token;

    socket = IO.io(Constants().baseUrl, <String, dynamic>{
      'transports': ['websocket'],
      'autoConnect': false,
      'extraHeaders': {'Authorization': token ?? ''},
    });

    socket.connect();

    setupListeners();
  }

  void setupListeners() {
    socket.onConnect((_) {
      print('Connected to Socket Server');
    });

    socket.onDisconnect((_) {
      print('Disconnected from Socket Server');
    });

    // Agrega otros manejadores de eventos según sea necesario
  }

  void disconnect() {
    if (socket.connected) {
      socket.disconnect();
    }
  }

  void emitEvent(String eventName, [dynamic data]) {
    if (socket.connected) {
      socket.emit(eventName, data);
    }
  }

  void updateToken(String newToken) {
    if (_token.value != newToken) {
      disconnect();
      connectWithToken(newToken);
    }
  }

  @override
  void onClose() {
    disconnect();
    super.onClose();
  }
}
