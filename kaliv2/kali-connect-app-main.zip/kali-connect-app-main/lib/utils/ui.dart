// ignore_for_file: non_constant_identifier_names

import 'dart:math';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Ui {
  static GetSnackBar defaultSnackBar(
      {String title = 'Alert', required String message}) {
    return GetSnackBar(
      titleText: Text(
        title.tr,
        style: Get.textTheme.titleLarge!.merge(
          const TextStyle(
            color: Colors.white,
          ),
        ),
      ),
      messageText: Text(
        message,
        style: Get.textTheme.bodySmall!.merge(
          const TextStyle(
            color: Colors.white,
          ),
        ),
      ),
      snackPosition: SnackPosition.BOTTOM,
      margin: const EdgeInsets.all(20),
      backgroundColor: Get.theme.colorScheme.primary,
      borderColor: Get.theme.focusColor.withOpacity(0.1),
      icon: const Icon(
        Icons.warning_amber_rounded,
        size: 32,
        color: Colors.white,
      ),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
      borderRadius: 7,
      duration: const Duration(seconds: 5),
    );
  }

  static GetSnackBar errorSnackBar(
      {String title = 'Error', required String message}) {
    return GetSnackBar(
      titleText: Text(
        title.tr,
        style: Get.textTheme.titleLarge!.merge(
          const TextStyle(
            color: Colors.white,
          ),
        ),
      ),
      messageText: Text(
        message.substring(
          0,
          min(message.length, 700),
        ),
        style: Get.textTheme.bodySmall!.merge(
          const TextStyle(color: Colors.white),
        ),
      ),
      snackPosition: SnackPosition.BOTTOM,
      margin: const EdgeInsets.all(20),
      backgroundColor: Colors.redAccent,
      icon: const Icon(
        Icons.remove_circle_outline,
        size: 32,
        color: Colors.white,
      ),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
      borderRadius: 8,
      duration: const Duration(seconds: 5),
    );
  }

  static GetSnackBar SuccessSnackBar(
      {String title = 'Success', String? message}) {
    Get.log('[$title] $message');
    return GetSnackBar(
      titleText: Text(
        title.tr,
        style: Get.textTheme.titleLarge!.merge(
          const TextStyle(color: Colors.white),
        ),
      ),
      messageText: Text(
        message ?? '',
        style: Get.textTheme.bodySmall!.merge(
          const TextStyle(
            color: Colors.white,
          ),
        ),
      ),
      snackPosition: SnackPosition.BOTTOM,
      margin: const EdgeInsets.all(20),
      backgroundColor: Colors.green,
      icon: const Icon(
        Icons.check_circle_outline,
        size: 32,
        color: Colors.white,
      ),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
      borderRadius: 8,
      dismissDirection: DismissDirection.horizontal,
      duration: const Duration(seconds: 5),
    );
  }

  static BoxDecoration getBoxDecoration(
      {Color? color, double? radius, Border? border, Gradient? gradient}) {
    return BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.all(Radius.circular(radius ?? 10)),
      boxShadow: [
        BoxShadow(
          color: Get.theme.focusColor.withOpacity(0.1),
          blurRadius: 10,
          offset: const Offset(0, 5),
        ),
      ],
      border: border ??
          Border.all(
            color: Get.theme.focusColor.withOpacity(0.05),
          ),
      gradient: gradient,
    );
  }
}
