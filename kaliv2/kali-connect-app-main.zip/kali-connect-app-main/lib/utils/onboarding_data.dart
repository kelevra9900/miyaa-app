class OnboardingContents {
  final String title;
  final String image;
  final String desc;

  OnboardingContents(
      {required this.title, required this.image, required this.desc});
}

List<OnboardingContents> contents = [
  OnboardingContents(
    title: 'Track your alarms',
    image: 'assets/images/onboard1.png',
    desc: 'Keep track of your alarms and their reminders.',
  ),
  OnboardingContents(
    title: 'Stay connected and safe',
    image: 'assets/images/onboard2.png',
    desc: 'Stay connected to your alarm and receive notifications.',
  ),
  OnboardingContents(
    title: 'Get notified when alarm is atended',
    image: 'assets/images/onboard3.png',
    desc:
        'Take control of notifications, collaborate live or on your own time.',
  ),
];
