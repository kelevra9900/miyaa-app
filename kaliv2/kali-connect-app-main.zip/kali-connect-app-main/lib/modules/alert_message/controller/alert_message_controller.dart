import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:miyaa/utils/handle_permissions.dart';
import 'package:sn_progress_dialog/sn_progress_dialog.dart';

import '../../../providers/laravel_provider.dart';
import '../../../services/auth_service.dart';
import '../../home/home_controller.dart';

class AlertWithMessageController extends GetxController {
  final LaravelApiClient laravelApiClient = LaravelApiClient();
  final TextEditingController messageTextCtrl = TextEditingController();
  final FocusNode messageFocusNode = FocusNode();
  final ImagePicker picker = ImagePicker();
  final Rx<bool> isSending = false.obs;
  late RxString imagepath = ''.obs;
  final Rx<bool> imageSelected = false.obs;
  late RxString? imageURL = ''.obs;
  File? imageFile;

  @override
  void onInit() {
    super.onInit();
    messageFocusNode.addListener(() => handleFocusChange());
    checkAndRequestPermissions();
    laravelApiClient.init();
  }

  void handleFocusChange() {
    if (!messageFocusNode.hasFocus) {
      // print('No Focus');
    }
  }

  Future<void> sendAlertMessage() async {
    if (messageTextCtrl.text.isNotEmpty) {
      showSendingMessageDialog();
      var socket = Get.find<HomeController>().socket;

      socket.emit('new_alert', buildAlertData());

      closeDialogsAndNotifyUser();
    }
  }

  void showSendingMessageDialog() {
    Get.dialog(
      Dialog(
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 20),
              Text('Sending message...'.tr),
              const SizedBox(height: 20),
              const CircularProgressIndicator(),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Map<String, dynamic> buildAlertData() {
    return {
      'latitude': Get.find<HomeController>().currentLatLng.value.latitude,
      'longitude': Get.find<HomeController>().currentLatLng.value.longitude,
      'userId': Get.find<AuthService>().user.value.id,
      'content': messageTextCtrl.text,
      'image': imageURL?.value,
    };
  }

  void closeDialogsAndNotifyUser() {
    Get.until((route) => !(Get.isDialogOpen ?? false));
    Get.back();
    Get.snackbar(
      'Alert sent',
      'The alert has been sent successfully',
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: Colors.green,
      colorText: Colors.white,
    );
  }

  Future<void> selectImage(ImageSource source) async {
    await checkAndRequestPermissions();

    final XFile? image = await picker.pickImage(source: source);
    if (image != null) {
      await processSelectedImage(image);
    }
  }

  Future<void> processSelectedImage(XFile image) async {
    imageFile = File(image.path);
    Uint8List imageBytes = await imageFile!.readAsBytes();
    imagepath.value = base64.encode(imageBytes);
    await saveAndUploadImage(image);
  }

  Future<void> saveAndUploadImage(XFile image) async {
    ProgressDialog progressDialog = ProgressDialog(context: Get.context);
    progressDialog.show(max: 100, msg: 'Procesando imagen...');
    await Future.delayed(const Duration(seconds: 1));
    progressDialog.update(value: 50, msg: 'Casi listo...');
    await Future.delayed(const Duration(seconds: 2));

    progressDialog.update(value: 100, msg: 'Imagen procesada...');
    await Future.delayed(const Duration(seconds: 1));
    progressDialog.close();

    Get.snackbar(
      'Imagen procesada',
      'La imagen se ha procesado correctamente',
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: Colors.green,
      colorText: Colors.white,
    );
    imageSelected.value = true;
  }
}
