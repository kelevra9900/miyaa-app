import 'package:get/get.dart';

import '../controller/alert_message_controller.dart';

class AlertMessageBingind extends Bindings {
  @override
  void dependencies() {
    Get.put(AlertWithMessageController());
  }
}
