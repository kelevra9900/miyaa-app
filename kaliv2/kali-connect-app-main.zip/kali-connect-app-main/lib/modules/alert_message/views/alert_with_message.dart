import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

import '../../../common/theme.dart';
import '../../auth/widgets/block_button.dart';
import '../../suggestions/widgets/input.dart';
import '../controller/alert_message_controller.dart';

class CreateAlertWithMessage extends GetView<AlertWithMessageController> {
  const CreateAlertWithMessage({super.key});

  @override
  Widget build(BuildContext context) {
    FocusScope.of(context).requestFocus(controller.messageFocusNode);

    return Form(
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            'Alert with message'.tr,
            style: const TextStyle(
              color: KaliColors.textMainColor,
            ),
          ),
          leading: IconButton(
            icon: const Icon(
              Icons.chevron_left,
              color: KaliColors.textMainColor,
              size: 30,
            ),
            onPressed: () {
              Get.back();
            },
          ),
        ),
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(15),
            children: [
              const SizedBox(height: 20),
              SizedBox(
                width: 120,
                height: 120,
                child: Image.asset(
                  'assets/logo/logo.png',
                ),
              ),
              const SizedBox(height: 20),
              Builder(builder: (context) {
                return SuggestionTextField(
                  label: 'Type your message here...'.tr,
                  maxLines: 7,
                  textInputAction: TextInputAction.send,
                  onChanged: (text) {
                    controller.messageTextCtrl.text = text;
                  },
                  onSubmitted: (_) => _submit(context),
                );
              }),
              const SizedBox(height: 10),
              if (controller.imageSelected.value)
                Builder(builder: (context) {
                  return SizedBox(
                    width: 80,
                    height: 80,
                    child: Image.memory(
                      controller.imageFile!.readAsBytesSync(),
                    ),
                  );
                }),
              Builder(builder: (context) {
                return Padding(
                  padding: const EdgeInsets.all(8),
                  child: SizedBox(
                    height: 50,
                    width: 200,
                    child: OutlinedButton.icon(
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.black87,
                        side: const BorderSide(color: Colors.black87),
                      ),
                      onPressed: () {
                        controller.selectImage(ImageSource.camera);
                      },
                      icon: const Icon(
                        Icons.photo_camera,
                        color: KaliColors.primaryColor,
                      ),
                      label: Obx(() {
                        if (controller.isSending.value) {
                          return const SizedBox(
                            height: 20,
                            width: 20,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                            ),
                          );
                        }
                        return Text('Take a photo'.tr);
                      }),
                    ),
                  ),
                );
              }),
              Divider(
                color: Colors.grey[200],
                thickness: 1,
              ),
              Builder(builder: (context) {
                return Padding(
                  padding: const EdgeInsets.all(8),
                  child: SizedBox(
                    height: 50,
                    width: 200,
                    child: OutlinedButton.icon(
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Get.theme.primaryColor,
                        side: const BorderSide(
                          color: KaliColors.primaryColor,
                        ),
                      ),
                      onPressed: () {
                        controller.selectImage(ImageSource.gallery);
                      },
                      icon: const Icon(
                        Icons.image,
                        color: KaliColors.primaryColor,
                      ),
                      label: Obx(() {
                        if (controller.isSending.value) {
                          return const SizedBox(
                            height: 20,
                            width: 20,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                            ),
                          );
                        }
                        return Text('Import image'.tr);
                      }),
                    ),
                  ),
                );
              }),
              Divider(
                color: Colors.grey[200],
                thickness: 1,
              ),
              Builder(builder: (context) {
                return RoundedBlockButtonWidget(
                  width: 200,
                  buttonText: 'Send message'.tr,
                  onpressed: () {
                    _submit(context);
                  },
                );
              }),
            ],
          ),
        ),
      ),
    );
  }

  void _submit(BuildContext context) {
    final formState = Form.of(context);
    if (formState.validate() && !controller.isSending.value) {
      if (controller.messageTextCtrl.text.isEmpty) {
        return;
      }
      controller.sendAlertMessage();
    }
  }
}
