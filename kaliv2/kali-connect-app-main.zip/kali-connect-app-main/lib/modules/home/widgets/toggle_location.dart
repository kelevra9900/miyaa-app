import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../common/theme.dart';
import '../home_controller.dart';

class ToggleLocation extends GetView<HomeController> {
  const ToggleLocation({super.key});

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      return Container(
        margin: const EdgeInsets.only(top: 10),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Send location?'.tr,
              style: const TextStyle(
                color: Colors.black,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(width: 10),
            Switch(
              value: controller.isSosSend.value,
              thumbColor: WidgetStateProperty.all(KaliColors.primaryColor),
              trackColor: WidgetStateProperty.all(
                  Colors.grey.shade400.withOpacity(0.5)),
              trackOutlineColor: WidgetStateProperty.all(Colors.grey.shade400),
              onChanged: (value) {
                controller.isSosSend.value = value;
                if (value) {
                  controller.startLocationService();
                  // print('Location service started');
                } else {
                  controller.stopLocationService();
                  // print('Location service stopped');
                }
              },
              activeTrackColor: Colors.grey,
              activeColor: Colors.red,
            ),
          ],
        ),
      );
    });
  }
}
