import 'package:avatar_glow/avatar_glow.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../common/block_button.dart';
import '../home_controller.dart';

class EmergencyScreen extends GetView<HomeController> {
  const EmergencyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.black,
        leading: IconButton(
          icon: const Icon(
            Icons.chevron_left,
            size: 40,
            color: Colors.white,
          ),
          onPressed: () => {Get.back(), controller.isEmergency.value = false},
        ),
      ),
      body: Container(
        height: double.infinity,
        margin: const EdgeInsets.all(10),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                height: Get.height * 0.1,
              ),
              AvatarGlow(
                glowColor: const Color(0xFFDF0503),
                duration: const Duration(milliseconds: 2000),
                repeat: true,
                child: const Material(
                  elevation: 8.0,
                  shape: CircleBorder(),
                  child: CircleAvatar(
                    backgroundColor: Color(0xFFDF0503),
                    radius: 40,
                    child: Icon(Icons.error_outline, size: 50),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const SizedBox(
                child: Text(
                  'Haz enviado una alerta de emergencia',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(height: 5),
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.8,
                child: const Text(
                  'En breve llegará una persona a tu casa para atender tu emergencia',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              SizedBox(
                height: Get.height * 0.1,
              ),
              Obx(() {
                return Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Tu posición actual:',
                            style: TextStyle(
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            '${controller.currentAddress}',
                            style: const TextStyle(
                              color: Colors.white,
                            ),
                          )
                        ],
                      ),
                    ),
                    const Icon(Icons.person_pin, color: Colors.white, size: 32),
                  ],
                );
              }),
              SizedBox(height: MediaQuery.of(context).size.height * 0.24),
              BlockButtonWidget(
                  text: Stack(
                    alignment: AlignmentDirectional.centerStart,
                    children: [
                      const Icon(
                        Icons.chevron_left,
                        color: Colors.white,
                        size: 30,
                      ),
                      SizedBox(
                        width: double.infinity,
                        child: Text(
                          'Go back'.tr,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                  color: Get.theme.colorScheme.secondary,
                  onPressed: () {
                    Get.back();
                    controller.isEmergency.value = false;
                  }).paddingOnly(
                bottom: 20,
                right: 20,
                left: 20,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
