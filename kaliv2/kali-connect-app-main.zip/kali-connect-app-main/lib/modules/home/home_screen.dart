import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';

import '../../common/card_carousel_item.dart';
import '../../common/neomorphism_button.dart';
import '../../models/carousel_item_model.dart';
import 'home_controller.dart';
import 'widgets/toggle_location.dart';

class HomeScreen extends GetView<HomeController> {
  HomeScreen({super.key});

  final _carousel = [
    Carousel(
      'Vigilance',
      'menssages',
      'assets/icons/writing.png',
      Colors.lightBlue,
      Colors.lightBlueAccent,
      FontAwesomeIcons.shield,
    ),
    Carousel(
      'Send a message',
      'menssages',
      'assets/icons/writing.png',
      Colors.red,
      Colors.redAccent,
      FontAwesomeIcons.message,
    ),
    Carousel(
      'Conferences',
      'conferences',
      'assets/icons/settings.png',
      Colors.blue,
      Colors.blueAccent,
      FontAwesomeIcons.video,
    ),
    Carousel(
      'Historial',
      'history',
      'assets/icons/history.png',
      Colors.green,
      Colors.greenAccent,
      FontAwesomeIcons.clockRotateLeft,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    List<Widget> itemMap = _carousel.map((item) {
      return CardCarouselItem(
        heroTag: item.title,
        title: item.title,
        color1: item.color1,
        color2: item.color2,
        icon: item.icon,
      );
    }).toList();

    return PopScope(
      canPop: false,
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Stack(
          children: [
            Container(
              margin: const EdgeInsets.only(top: 10),
              child: ListView(
                physics: const BouncingScrollPhysics(),
                children: [
                  buildHeaderText('You have a emergency'.tr),
                  const SizedBox(height: 10),
                  buildHeaderText('Press the button to send a alert'.tr),
                  const SizedBox(height: 24),
                  const NeomorphinButton(),
                  const SizedBox(height: 20),
                  const ToggleLocation(),
                  buildNotSureSection(),
                  ...itemMap,
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget buildHeaderText(String text) {
    return SizedBox(
      width: Get.width * 0.9,
      child: Text(
        text,
        style: TextStyle(
          fontSize: 17,
          fontWeight: FontWeight.w600,
          color: Get.theme.colorScheme.primary,
        ),
        textAlign: TextAlign.center,
      ),
    );
  }

  Widget buildNotSureSection() {
    return Container(
      padding: const EdgeInsets.all(10),
      child: Column(
        children: [
          Text(
            'You can see the available options in the menu'.tr,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w400,
              color: Get.theme.colorScheme.primary,
            ),
          )
        ],
      ),
    );
  }
}
