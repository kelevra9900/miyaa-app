import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:background_location/background_location.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart' as path_provider;
import 'package:sn_progress_dialog/sn_progress_dialog.dart';
import 'package:socket_io_client/socket_io_client.dart';

import '../../models/create_alert_model.dart';
import '../../providers/laravel_provider.dart';
import '../../providers/push_notifications_provider.dart';
import '../../services/auth_service.dart';
import '../../services/notifications_service.dart';
import '../../utils/constants.dart';

class HomeController extends FullLifeCycleController with FullLifeCycleMixin {
  Socket socket = io(Constants().baseUrl, <String, dynamic>{
    'transports': ['websocket'],
    'autoConnect': false,
    'authorization': LaravelApiClient().getToken(),
  });

  late GetStorage box = GetStorage();
  late AnimationController _controller;

  ScrollController? scrollController;
  final currentAddress = 'Sin dirección'.obs;
  ImagePicker picker = ImagePicker();
  RxBool isImageSelected = false.obs;
  RxBool isEmergency = false.obs;
  RxBool isActivatedLocation = false.obs;

  late RxString imagepath = ''.obs;
  late CreateAlertModel creatAlertModel;

  final formKey = GlobalKey<FormState>();
  final formSuggestionKey = GlobalKey<FormState>();
  PushNotificationsProvider pushNotificationsProvider =
      PushNotificationsProvider();

  TextEditingController messageController = TextEditingController();

  String message = ''.obs();
  String suggestion = ''.obs();

  File? imageFile;
  late Rx<LatLng> currentLatLng = const LatLng(0, 0).obs;

  RxBool isSosSend = false.obs;

  HomeController() {
    connectAndListen();
    if (isSosSend.value) {
      startLocationService();
    } else {
      stopLocationService();
    }
  }

  @override
  Future<void> onInit() async {
    super.onInit();
    getGeoLocationPosition();
    await Get.find<AuthService>().getCurrentUser();
    _initNotifications();
    verifyToken();
  }

  Future _initNotifications() async {
    await NotificationService().initFirebasePushNotification();
  }

  @override
  void dispose() {
    super.dispose();
    _controller.dispose();
    _positionStreamSubscription?.cancel();
  }

  // // Mandatory
  @override
  void onDetached() {
    // print('HomeController - onDetached called');
    stopLocationService();
  }

  // Mandatory
  @override
  void onInactive() {
    // print('HomeController - onInactive called');
    socket.disconnect();
  }

  @override
  void onPaused() {
    // print('HomeController - onPaused called');
    setupBackgroundLocation();
  }

  @override
  void onResumed() {
    //BackgroundLocation.stopLocationService();
  }

  @override
  void onHidden() {}

  Future<void> startLocationService() async {
    await BackgroundLocation.startLocationService();

    await BackgroundLocation.setAndroidNotification(
      title: 'Trablisa Location Service'.tr,
      message: 'Location service is running in the background'.tr,
      icon: '@mipmap/ic_launcher',
    );

    await BackgroundLocation.getLocationUpdates(
      (location) {
        getAddressFromLatLong(
          Position(
            latitude: location.latitude!,
            longitude: location.longitude!,
            timestamp: DateTime.now(),
            accuracy: 0.0,
            altitude: 0.0,
            heading: 0.0,
            speed: 0.0,
            altitudeAccuracy: 0.0,
            headingAccuracy: 0.0,
            speedAccuracy: 0.0,
          ),
        );
        Get.log(
            'Background Location to emit message: ${location.latitude}, ${location.longitude}');
        socket.emit('new_location', {
          'latitude': location.latitude,
          'longitude': location.longitude,
          'userId': Get.find<AuthService>().user.value.id,
        });
      },
    );
  }

  Future<void> verifyToken() async {
    await pushNotificationsProvider.verifyToken();
  }

  void sendLocation() {
    socket.emit('new_location', {
      'latitude': currentLatLng.value.latitude,
      'longitude': currentLatLng.value.longitude,
      'userId': Get.find<AuthService>().user.value.id,
    });
  }

  Future<void> stopLocationService() async {
    await BackgroundLocation.stopLocationService();
    stopListeningLocationChanges();
  }

  Future refreshHome({bool showMessage = false}) async {
    await getGeoLocationPosition();
    if (showMessage) {
      Get.snackbar('Actualizado', 'Se ha actualizado la ubicación');
    }
  }

  void setupBackgroundLocation() async {
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      return;
    }

    await Geolocator.openAppSettings();
  }

  void initScrollController() {
    scrollController = ScrollController();
    scrollController?.addListener(() {
      if (scrollController?.position.userScrollDirection ==
          ScrollDirection.reverse) {
        Get.back();
      }
    });
  }

  Future<Position> getGeoLocationPosition() async {
    bool serviceEnabled;
    LocationPermission permission;
    // Test if location services are enabled.
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      // Location services are not enabled don't continue
      // accessing the position and request users of the
      // App to enable the location services.
      await Geolocator.openLocationSettings();
      isActivatedLocation.value = false;
      return Future.error('Location services are disabled.');
    }
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error('Location permissions are denied');
      }
    }
    if (permission == LocationPermission.deniedForever) {
      isActivatedLocation.value = false;
      // Permissions are denied forever, handle appropriately.
      return Future.error(
          'Location permissions are permanently denied, we cannot request permissions.');
    }
    // When we reach here, permissions are granted and we can
    // continue accessing the position of the device.
    Position position = await Geolocator.getCurrentPosition();
    getAddressFromLatLong(position);
    return await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );
  }

  Future<void> getAddressFromLatLong(Position position) async {
    try {
      currentLatLng.value = LatLng(position.latitude, position.longitude);
      List<Placemark> placemarks =
          await placemarkFromCoordinates(position.latitude, position.longitude);
      Placemark place = placemarks[0];
      currentAddress('${place.street}, ${place.postalCode}');
    } catch (e) {
      Get.snackbar('Error', 'No se ha podido obtener la dirección');
    }
  }

  void showAlertDialog() {
    Widget galleryButton = ElevatedButton(
      onPressed: () {
        Get.back();
        selectImage(ImageSource.gallery);
      },
      child: Text('Gallery'.tr),
    );

    Widget cameraButton = ElevatedButton(
      onPressed: () {
        Get.back();
        selectImage(ImageSource.camera);
      },
      child: Text('Camera'.tr),
    );

    AlertDialog alertDialog = AlertDialog(
      title: Text('Image Selected'.tr),
      actions: [galleryButton, cameraButton],
    );

    showDialog(
      context: Get.context!,
      builder: (BuildContext context) {
        return alertDialog;
      },
    );
  }

  Future selectImage(ImageSource imageSource) async {
    final XFile? image = await picker.pickImage(source: imageSource);
    if (image != null) {
      isImageSelected.value = true;
      imageFile = File(image.path);

      Uint8List imagebytes = await imageFile!.readAsBytes(); //convert to bytes
      String base64string =
          base64.encode(imagebytes); //convert bytes to base64 string
      imagepath.value = base64string;

      final dir = await path_provider.getTemporaryDirectory();
      final targetPath = '${dir.absolute.path}/temp.jpg';

      await imageFile!.copy(targetPath);
      imageFile = File(targetPath);
      isImageSelected.value = true;

      ProgressDialog progressDialog = ProgressDialog(context: Get.context);
      progressDialog.show(max: 10, msg: 'Procesando imagen...');
      await Future.delayed(
        const Duration(seconds: 1),
      );
      progressDialog.update(value: 50, msg: 'Procesando imagen...');
      await Future.delayed(
        const Duration(seconds: 2),
      );

      progressDialog.update(value: 100, msg: 'Procesando imagen...');

      await Future.delayed(
        const Duration(seconds: 1),
      );

      progressDialog.close();
    }
  }

  void sendAlert() {
    isSosSend.value = true;
    socket.emit('new_alert', {
      'latitude': currentLatLng.value.latitude,
      'longitude': currentLatLng.value.longitude,
      'userId': Get.find<AuthService>().user.value.id,
      'content': messageController.text.trim().isNotEmpty
          ? messageController.text.trim()
          : 'S.O.S',
    });
    listenLocationChanges();
  }

  void emitOnline() async {
    socket.emit('user_connect', () => {});
  }

  void connectAndListen() {
    socket.connect();
    socket.onConnect((data) {
      emitOnline();
    });
  }

  // Stream to listen location changes
  // getposition stream
  StreamSubscription? _positionStreamSubscription;

  void listenLocationChanges() {
    _positionStreamSubscription =
        Geolocator.getPositionStream().listen((Position position) {
      socket.emit('new_location', {
        'latitude': position.latitude,
        'longitude': position.longitude,
        'userId': Get.find<AuthService>().user.value.id,
      });
      getAddressFromLatLong(position);
    });
  }

  void stopListeningLocationChanges() {
    _positionStreamSubscription?.cancel();
  }
}
