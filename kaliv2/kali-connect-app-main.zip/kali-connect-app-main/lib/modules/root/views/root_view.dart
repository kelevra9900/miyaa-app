import 'package:animated_bottom_navigation_bar/animated_bottom_navigation_bar.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../common/theme.dart';
import '../../../routes/app_routes.dart';
import '../controllers/root_controller.dart';

class RootView extends GetView<RootController> {
  final iconList = <IconData>[
    Icons.home,
    Icons.account_circle_rounded,
    Icons.book,
  ];

  RootView({super.key});

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      return Scaffold(
        body: controller.currentPage,
        floatingActionButton: FloatingActionButton(
          backgroundColor: KaliColors.primaryColor,
          // full round shape
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(
              Radius.circular(30.0),
            ),
          ),
          child: IconButton(
            onPressed: () {
              Get.toNamed(Routes.chat);
            },
            icon: const Icon(Icons.chat_bubble, color: Colors.white),
          ),
          onPressed: () {},
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.endDocked,
        bottomNavigationBar: AnimatedBottomNavigationBar(
          backgroundColor: const Color.fromARGB(255, 248, 248, 248),
          activeColor: Colors.red,
          leftCornerRadius: 32,
          icons: iconList,
          activeIndex: controller.currentIndex.value,
          gapLocation: GapLocation.end,
          notchSmoothness: NotchSmoothness.defaultEdge,
          notchAndCornersAnimation: controller.borderRadiusAnimation,
          hideAnimationController: controller.hideBottomBarAnimationController,
          shadow: BoxShadow(
            color: Colors.grey.withOpacity(0.4),
            blurRadius: 9,
          ),
          onTap: (index) {
            controller.currentIndex.value = index;
          },
          //other params
        ),
      );
    });
  }
}
