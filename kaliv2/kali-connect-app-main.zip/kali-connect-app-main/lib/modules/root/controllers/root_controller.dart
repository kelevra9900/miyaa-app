import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:socket_io_client/socket_io_client.dart';

import '../../../models/auth_response_model.dart';
import '../../../models/location_model.dart';
import '../../../providers/push_notifications_provider.dart';
import '../../../routes/app_routes.dart';
import '../../../services/auth_service.dart';
import '../../../utils/constants.dart';
import '../../blog/controllers/blog_controller.dart';
import '../../blog/views/blog_screen.dart';
import '../../home/home_controller.dart';
import '../../home/home_screen.dart';
import '../../profile/views/profile_screen.dart';
import '../../settings/views/settings_view.dart';

class RootController extends GetxController with GetTickerProviderStateMixin {
  Rx<Location> location = Rx<Location>(Location(latitude: 0.0, longitude: 0.0));

  ResLogin session =
      ResLogin.fromJson(GetStorage().read('current_session') ?? {});

  PushNotificationsProvider pushNotificationsProvider =
      PushNotificationsProvider();
  Socket socket = io(Constants().baseUrl, <String, dynamic>{
    'transports': ['websocket'],
    'autoConnect': false
  });

  final currentIndex = 0.obs;

  AnimationController? hideBottomBarAnimationController;
  Animation<double>? borderRadiusAnimation;
  CurvedAnimation? borderRadiusCurve;
  AnimationController? borderRadiusAnimationController;
  AnimationController? fabAnimationController;

  List<Widget> pages = [
    HomeScreen(),
    const ProfileScreen(),
    const BlogScreen(),
    SettingsView(),
  ];

  @override
  void onInit() {
    super.onInit();
    _initLocationStream();
    fabAnimationController = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    borderRadiusAnimationController = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );

    borderRadiusCurve = CurvedAnimation(
      parent: borderRadiusAnimationController!,
      curve: const Interval(0.5, 1.0, curve: Curves.fastOutSlowIn),
    );

    borderRadiusAnimation = Tween<double>(begin: 0, end: 1).animate(
      borderRadiusCurve!,
    );

    hideBottomBarAnimationController = AnimationController(
      duration: const Duration(milliseconds: 200),
      vsync: this,
    );

    Future.delayed(
      const Duration(seconds: 1),
      () => borderRadiusAnimationController!.forward(),
    );
  }

  @override
  void onClose() {
    hideBottomBarAnimationController!.dispose();
    borderRadiusAnimationController!.dispose();
    fabAnimationController!.dispose();
    super.onClose();
  }

  Widget get currentPage => pages[currentIndex.value];

  Future<void> changePageInRoot(int index) async {
    currentIndex.value = index;
  }

  void _initLocationStream() {
    Geolocator.getPositionStream().listen((position) {
      location.value = Location(
        latitude: position.latitude,
        longitude: position.longitude,
      );
      notifyChildrens();
    }, onError: (error) {
      // print('Error getting location: $error');
    });
  }

  Future<void> changePageOutRoot(int index) async {
    if (!Get.find<AuthService>().isAuth && index > 0) {
      await Get.toNamed(Routes.login);
    }
    currentIndex.value = index;
    await refreshPage(index);
    await Get.offNamedUntil(Routes.root, (Route route) {
      if (route.settings.name == Routes.root) {
        return true;
      }
      return false;
    }, arguments: index);
  }

  Future<void> changePage(int index) async {
    if (Get.currentRoute == Routes.root) {
      await changePageInRoot(index);
    } else {
      await changePageOutRoot(index);
    }
  }

  Future<void> refreshPage(int index) async {
    switch (index) {
      case 0:
        {
          await Get.find<HomeController>().refreshHome();
          break;
        }
      case 1:
        {
          break;
        }
    }
  }

  void saveToken() {
    if (session.jwt != null) {
      pushNotificationsProvider.saveToken(session.jwt!);
    }
  }

  void connectAndListen() {
    if (session.jwt != null) {
      socket.connect();
      socket.onConnect((data) {
        emitOnline();
      });
    }
  }

  void emitOnline() {
    socket.emit('user_connect');
  }
}
