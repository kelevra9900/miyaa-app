import 'package:get/get.dart';

import '../../blog/controllers/blog_controller.dart';
import '../../home/home_controller.dart';
import '../controllers/root_controller.dart';

class RootBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<RootController>(() => RootController());

    Get.lazyPut<HomeController>(() => HomeController());

    Get.lazyPut<BlogController>(() => BlogController());
  }
}
