import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../services/auth_service.dart';
// import '../../../utils/jitsi_meet_utils.dart';

class ConferenceController extends GetxController {
  GlobalKey<ScaffoldState> scaffoldState = GlobalKey();
  TextEditingController meetingIDController = TextEditingController();
  GlobalKey<FormState> joinMeetingFormkey = GlobalKey<FormState>();

  RxBool isVisibleHost = false.obs;
  RxInt selectedIndex = 0.obs;
  RxInt selectedScreen = 0.obs;
  PageController? pageController;

  // init
  @override
  void onInit() {
    pageController = PageController();
    super.onInit();
  }

  // dispose
  @override
  void onClose() {
    pageController!.dispose();
    super.onClose();
  }

  // Change tab
  void changeTab(int index) {
    selectedIndex.value = index;
    pageController!.animateToPage(selectedIndex.value,
        duration: const Duration(milliseconds: 500), curve: Curves.ease);
    update();
  }

  // Join Meeting method
  void joinMeeting() {
    var currentUser = Get.find<AuthService>().user;
    // JitsiMeetUtils().joinMeeting(
    //   roomCode: meetingIDController.value.text,
    //   nameText: '${currentUser.value.firstName} ${currentUser.value.lastName}',
    // );
  }

  // Host Meeting method
  void hostMeeting(String roomCode) {
    var currentUser = Get.find<AuthService>().user;
    // JitsiMeetUtils().joinMeeting(
    //   roomCode: roomCode,
    //   nameText: '${currentUser.value.firstName} ${currentUser.value.lastName}',
    // );
  }
}
