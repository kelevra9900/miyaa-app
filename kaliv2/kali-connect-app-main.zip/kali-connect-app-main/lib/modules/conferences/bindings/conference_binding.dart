import 'package:get/get.dart';

import '../controllers/conference_controller.dart';

class ConferenceBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<ConferenceController>(() => ConferenceController());
  }
}
