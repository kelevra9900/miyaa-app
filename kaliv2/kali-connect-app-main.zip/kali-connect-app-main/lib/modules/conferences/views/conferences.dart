import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../common/theme.dart';
import '../controllers/conference_controller.dart';
import '../widgets/host_meeting_card.dart';
import '../widgets/join_meeting_card.dart';

class ConferenceScreen extends GetView<ConferenceController> {
  const ConferenceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ConferenceController>(
      builder: (controller) {
        return Scaffold(
          appBar: AppBar(
            title: Text(
              'Conferences'.tr,
              style: const TextStyle(
                color: KaliColors.textMainColor,
              ),
            ),
            // back button color change
            leading: IconButton(
              icon: const Icon(
                Icons.chevron_left,
                color: KaliColors.textMainColor,
                size: 30,
              ),
              onPressed: () {
                Get.back();
              },
            ),
          ),
          body: SingleChildScrollView(
            child: Column(
              children: [
                const SizedBox(height: 20.0),
                /*Join meeting and Host Meeting Switch Button*/
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    tabButton(
                      0,
                      'Join Meeting'.tr,
                    ),
                    tabButton(
                      1,
                      'Host Meeting'.tr,
                    ),
                  ],
                ),
                const SizedBox(height: 20.0),
                SizedBox(
                  height: 430.0,
                  child: PageView(
                    physics: const NeverScrollableScrollPhysics(),
                    controller: controller.pageController,
                    children: const [
                      JoinMeeting(),
                      HostMeetingCard(),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  /*navigate between join meeting and host meeting*/
  Widget tabButton(int btnIndex, String btnTitle) {
    return GestureDetector(
      onTap: () {
        controller.changeTab(btnIndex);
      },
      child: Container(
        height: 40,
        width: Get.width / 2.3,
        decoration: BoxDecoration(
          borderRadius: btnIndex == 0
              ? const BorderRadius.only(
                  topLeft: Radius.circular(6),
                  bottomLeft: Radius.circular(5),
                )
              : const BorderRadius.only(
                  bottomRight: Radius.circular(6),
                  topRight: Radius.circular(5),
                ),
          // compatible with getx change state color
          boxShadow: controller.selectedIndex.value == btnIndex
              ? KaliColors.iconBoxShadow
              : null,
          color: controller.selectedIndex.value == btnIndex
              ? Colors.white
              : const Color(0xffF0F1F6),
        ),
        child: Center(
          child: Text(
            btnTitle,
            style: TextStyle(
              fontFamily: 'Avenir',
              fontWeight: FontWeight.w400,
              fontSize: 14,
              color: controller.selectedIndex.value == btnIndex
                  ? const Color(0xff222222)
                  : const Color(0xff5B5D80),
            ),
          ),
        ),
      ),
    );
  }
}
