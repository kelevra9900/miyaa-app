import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../common/theme.dart';
import '../controllers/conference_controller.dart';

class JoinMeeting extends StatefulWidget {
  const JoinMeeting({super.key});

  @override
  State<JoinMeeting> createState() => _JoinMeetingState();
}

class _JoinMeetingState extends State<JoinMeeting> {
  bool isLoading = false;

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 24),
          child: Container(
            padding: const EdgeInsets.all(16),
            child: Form(
              key: Get.find<ConferenceController>().joinMeetingFormkey,
              child: Column(
                children: [
                  const Text(
                    'Join Meeting',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: KaliColors.textMainColor,
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller:
                        Get.find<ConferenceController>().meetingIDController,
                    style: const TextStyle(
                      fontSize: 16,
                      color: KaliColors.textMainColor,
                    ),
                    decoration: const InputDecoration(
                      labelText: 'Meeting ID',
                      border: OutlineInputBorder(),
                      labelStyle: TextStyle(
                        fontSize: 16,
                        color: KaliColors.textMainColor,
                      ),
                      hintStyle: TextStyle(
                        fontSize: 16,
                        color: KaliColors.textMainColor,
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: KaliColors.textMainColor,
                        ),
                      ),
                    ),
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Please enter meeting ID';
                      }
                      return null;
                    },
                  ),

                  const SizedBox(height: 16),
                  // Button to join meeting
                  ElevatedButton(
                    onPressed: () {
                      if (Get.find<ConferenceController>()
                              .joinMeetingFormkey
                              .currentState
                              ?.validate() ??
                          false) {
                        Get.find<ConferenceController>().joinMeeting();
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: KaliColors.primaryColor,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      minimumSize: const Size(double.infinity, 50),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(7.0),
                      ),
                      // borderRadius: BorderRadius.circular(3.0),
                    ),
                    child: const Text(
                      'Join Meeting',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}
