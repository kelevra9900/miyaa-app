import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

import '../../../common/theme.dart';
import '../../../utils/constants.dart';
import '../controllers/conference_controller.dart';

class HostMeetingCard extends StatefulWidget {
  const HostMeetingCard({super.key});

  @override
  _HostMettingCardState createState() => _HostMettingCardState();
}

class _HostMettingCardState extends State<HostMeetingCard> {
  TextEditingController meetingTitleController = TextEditingController();

  final _chars =
      'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz1234567890';
  final math.Random _rnd = math.Random();
  String? randomMeetingCode;
  bool isLoading = false;
  String? joinWebUrl;
  String? meetingPrefix;
  String? linkMessage;

  @override
  void initState() {
    meetingPrefix = '${Constants().appName}-';
    randomMeetingCode = meetingPrefix! + getRandomString(9, _rnd);
    // JitsiMeet.addListener(
    //   JitsiMeetingListener(
    //     onConferenceWillJoin: JitsiMeetUtils().onConferenceWillJoin,
    //     onConferenceJoined: JitsiMeetUtils().onConferenceJoined,
    //     onConferenceTerminated: JitsiMeetUtils().onConferenceTerminated,
    //     onError: JitsiMeetUtils().onError,
    //   ),
    // );
    super.initState();
  }

  String getRandomString(int length, math.Random rnd) =>
      String.fromCharCodes(Iterable.generate(
          length, (_) => _chars.codeUnitAt(rnd.nextInt(_chars.length))));

  @override
  void dispose() {
    super.dispose();
    // JitsiMeet.removeAllListeners();
  }

  @override
  Widget build(BuildContext context) {
    joinWebUrl = '${Constants().baseUrl}room/$randomMeetingCode';
    double screenWidth = MediaQuery.of(context).size.width;
    return joinMeetingCard(screenWidth);
  }

  Widget joinMeetingCard(double screenWidth) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 24),
          child: SizedBox(
            child: Padding(
              padding: const EdgeInsets.only(
                  left: 20, top: 40, bottom: 50, right: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    'Host a Meeting'.tr,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: KaliColors.textMainColor,
                    ),
                  ),
                  const SizedBox(height: 30.0),
                  Container(
                    height: 48.0,
                    decoration: BoxDecoration(
                      borderRadius: const BorderRadius.all(
                        Radius.circular(3.0),
                      ),
                      border: Border.all(color: KaliColors.textMainColor),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Row(
                            children: <Widget>[
                              const Icon(
                                Icons.videocam,
                                color: KaliColors.textMainColor,
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 20.0),
                                child: Text(
                                  randomMeetingCode!,
                                  style: const TextStyle(
                                    fontSize: 16,
                                    color: KaliColors.textMainColor,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          GestureDetector(
                            onTap: () {
                              Clipboard.setData(
                                ClipboardData(text: randomMeetingCode!),
                              ).then((_) {
                                Get.snackbar('Copied', 'Meeting code copied');
                              });
                            },
                            child: const Icon(
                              Icons.content_copy,
                              color: KaliColors.textMainColor,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 15.0),
                  GestureDetector(
                    onTap: () {
                      Get.find<ConferenceController>()
                          .hostMeeting(randomMeetingCode!);
                    },
                    child: Container(
                      height: 48.0,
                      decoration: const BoxDecoration(
                        color: KaliColors.primaryColor,
                        borderRadius: BorderRadius.all(
                          Radius.circular(7.0),
                        ),
                      ),
                      child: Center(
                        child: Text(
                          'Join Meeting'.tr,
                          style: const TextStyle(
                            fontSize: 16,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}
