import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:nfc_manager/nfc_manager.dart';
import '../../../models/rounds_model.dart';
import '../../../repositories/user_repository.dart';
import '../../../repositories/vigilance_repository.dart';

class VigilantController extends GetxController {
  NfcManager nfcManager = NfcManager.instance;
  RxBool isNfcAvailable = false.obs;
  RxBool isReading = false.obs;
  late UserRepository _userRepository;
  int activeStep = 0;

  // Call VigilanceRepository
  final VigilanceRepository _vigilanceRepository = VigilanceRepository();

  @override
  void onInit() {
    super.onInit();
    _userRepository = UserRepository();
    checkNfcAvailability();
  }

  // Stream to get the rounds from the repository
  Stream<MyRounds> get myRoundsList => _vigilanceRepository.getRounds();

  Future<void> checkNfcAvailability() async {
    isNfcAvailable.value = await nfcManager.isAvailable();
  }

  void readNfc(int index, int roundId, int checkpointId) async {
    isReading.value = true;
    if (isNfcAvailable.value) {
      try {
        NfcManager.instance.startSession(onDiscovered: (NfcTag badge) async {
          var payload =
              badge.data['ndef']['cachedMessage']['records'][0]['payload'];
          var stringPayload = String.fromCharCodes(payload);

          int jsonStartIndex = stringPayload.indexOf('{');
          if (jsonStartIndex == -1) {
            Get.snackbar(
              'Error',
              'No se encontró el objeto JSON en la carga útil',
              snackPosition: SnackPosition.BOTTOM,
              backgroundColor: Colors.red,
              colorText: Colors.white,
            );
            NfcManager.instance.stopSession();
            return;
          }
          stringPayload = stringPayload.substring(jsonStartIndex);

          try {
            var data = jsonDecode(stringPayload);

            await _userRepository.checkpointLog(roundId, data['id']);

            Get.snackbar(
              'Éxito',
              'Punto de control registrado',
              snackPosition: SnackPosition.BOTTOM,
              backgroundColor: Colors.green,
              colorText: Colors.white,
            );
          } catch (e) {
            Get.snackbar(
              'Error',
              'Error al decodificar JSON: $e',
              snackPosition: SnackPosition.BOTTOM,
              backgroundColor: Colors.red,
              colorText: Colors.white,
            );
          }
          changeStep(index + 1);
          NfcManager.instance.stopSession();
        });
        isReading.value = false;
      } on PlatformException catch (e) {
        Get.snackbar(
          'Error',
          e.message ?? 'Error al leer la etiqueta NFC',
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.red,
          colorText: Colors.white,
        );
        isReading.value = false;
      }
    } else {
      Get.snackbar(
        'Error',
        'NFC no está disponible en este dispositivo',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    }
  }

  void changeStep(int index) {
    activeStep = index;
    update();
  }
}
