import 'package:get/get.dart';
import '../controller/vigilance_controller.dart';

class VigilanceBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(VigilantController());
  }
}
