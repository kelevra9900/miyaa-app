import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:miyaa/common/theme.dart';
import 'package:miyaa/utils/helper.dart';

class VigilanceBanner extends StatelessWidget {
  const VigilanceBanner({
    super.key,
    required this.shift,
    required this.start,
  });

  final String shift;
  final String start;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: Get.height * 0.2,
      width: Get.width,
      margin: const EdgeInsets.all(20),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: KaliColors.primaryColor,
        borderRadius: BorderRadius.circular(8),
      ),
      // Morning shift confirmation alert banner
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                shift,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(width: Get.width * 0.22),
              const CircleAvatar(
                backgroundColor: Colors.white,
                child: Icon(
                  Icons.warning,
                  color: KaliColors.primaryColor,
                ),
              ),
            ],
          ),
          Text(
            'El turno inicia: ${Helper().formatTime(start)}',
            style: TextStyle(
              color: Colors.white,
              fontSize: Get.width * 0.04,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            '¿Estás listo para iniciar tu turno?',
            style: TextStyle(
              color: Colors.white,
              fontSize: Get.width * 0.04,
            ),
          ),
        ],
      ),
    );
  }
}
