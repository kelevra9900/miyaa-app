import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:easy_stepper/easy_stepper.dart';
import '../../../common/theme.dart';

import '../../../models/rounds_model.dart';
import '../controller/vigilance_controller.dart';
import '../../../utils/helper.dart';

class VigilanceDetailScreen extends GetView<VigilantController> {
  const VigilanceDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var round = Get.arguments['round'] as Rounds;
    var checkpoints = Get.arguments['checkpoints'] as List<Checkpoint>;
    return Scaffold(
      appBar: AppBar(
        actions: [
          // Refresh button
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              controller.checkNfcAvailability();
            },
          ),
        ],
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              // Round information
              Container(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Una vez iniciada la ronda, acerca el dispositivo al punto de control para registrar la visita.',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.black,
                      ),
                    ),
                    SizedBox(height: Get.height * 0.04),
                    // Inicio y final de la ronda
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Inicio',
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.black,
                              ),
                            ),
                            const SizedBox(height: 5),
                            Text(
                              Helper().formatTime(round.start ?? ''),
                              style: const TextStyle(
                                fontSize: 16,
                                color: Colors.black,
                              ),
                            ),
                          ],
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Fin',
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.black,
                              ),
                            ),
                            const SizedBox(height: 5),
                            Text(
                              Helper().formatTime(round.end ?? ''),
                              style: const TextStyle(
                                fontSize: 16,
                                color: Colors.black,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: EasyStepper(
                  activeStep: controller.activeStep,
                  lineStyle: const LineStyle(
                    lineLength: 50,
                    lineType: LineType.normal,
                    lineThickness: 1.3,
                    lineSpace: 1,
                    lineWidth: 10,
                    unreachedLineType: LineType.normal,
                  ),
                  stepShape: StepShape.circle,
                  stepBorderRadius: 15,
                  borderThickness: 2,
                  internalPadding: 10,
                  padding: const EdgeInsetsDirectional.symmetric(
                    horizontal: 30,
                    vertical: 20,
                  ),
                  stepRadius: 28,
                  finishedStepBorderColor: Colors.deepOrange,
                  finishedStepTextColor: Colors.deepOrange,
                  finishedStepBackgroundColor: Colors.deepOrange,
                  activeStepIconColor: Colors.deepOrange,
                  showLoadingAnimation: false,
                  steps: [
                    for (var checkpoint in checkpoints)
                      EasyStep(
                        customStep: CircleAvatar(
                          radius: 8,
                          backgroundColor: Colors.white,
                          child: CircleAvatar(
                            radius: 7,
                            backgroundColor: controller.activeStep >= 2
                                ? KaliColors.secondaryColor
                                : KaliColors.primaryColor,
                          ),
                        ),
                        customTitle: Text(
                          checkpoint.location ?? '',
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                            color: KaliColors.primaryColor,
                          ),
                        ),
                      ),
                  ],
                  onStepReached: (index) => {
                    if (round.id != null && checkpoints[index].id != null)
                      {
                        controller.readNfc(
                          index,
                          round.id!,
                          checkpoints[index].id!,
                        )
                      }
                  },
                ),
              ),
              const SizedBox(height: 20),
              Obx(
                () => controller.isReading.value
                    ? const Text(
                        'Por favor acerque el dispositivo al punto de control',
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.black,
                        ),
                      )
                    : const Text(
                        '',
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
