import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controller/vigilance_controller.dart';

class InitVigilanceView extends GetView<VigilantController> {
  const InitVigilanceView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Vigilance', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: Colors.black),
      ),
    );
  }
}
