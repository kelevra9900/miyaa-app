import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:miyaa/common/theme.dart';
import 'package:miyaa/models/rounds_model.dart';
import 'package:miyaa/modules/vigilance/widgets/vigilance_banner.dart';
import 'package:miyaa/routes/app_routes.dart';
import 'package:miyaa/utils/helper.dart';

import '../controller/vigilance_controller.dart';

class VigilanceView extends GetView<VigilantController> {
  const VigilanceView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Rondas de vigilancia',
          style: TextStyle(color: Colors.black),
        ),
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Options for the user to select
            // Future Builder to get stream data from the controller
            StreamBuilder<MyRounds>(
              stream: controller.myRoundsList,
              builder:
                  (BuildContext context, AsyncSnapshot<MyRounds> snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                } else if (snapshot.hasError) {
                  print('==== getting error ======');
                  print(snapshot.error);
                  print('==== getting error ======');
                  return const Center(
                    child: Text(
                      'Error',
                      style: TextStyle(color: Colors.red),
                    ),
                  );
                } else if (snapshot.hasData && snapshot.data != null) {
                  return SingleChildScrollView(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          VigilanceBanner(
                            shift: snapshot.data?.shift?.name ?? '',
                            start: snapshot.data?.shift?.start ?? '',
                          ),
                          const SizedBox(height: 20),
                          const Padding(
                            padding: EdgeInsets.all(5.0),
                            child: Text(
                              'Rondas de vigilancia',
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: KaliColors.primaryColor,
                              ),
                            ),
                          ),
                          ListView.builder(
                            physics: const NeverScrollableScrollPhysics(),
                            shrinkWrap: true,
                            itemCount: snapshot.data!.rounds!.length,
                            itemBuilder: (BuildContext context, int index) {
                              var round = snapshot.data!.rounds![index];
                              return Container(
                                margin: const EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey.withOpacity(0.5),
                                      spreadRadius: 1,
                                      blurRadius: 7,
                                      offset: const Offset(0, 3),
                                    ),
                                  ],
                                ),
                                child: ListTile(
                                  onTap: () {
                                    if (round.checkpoint!.isNotEmpty) {
                                      Get.toNamed(
                                        Routes.vigilanceDetail,
                                        arguments: {
                                          'checkpoints': round.checkpoint,
                                          'round': round,
                                        },
                                      );
                                    } else {
                                      Get.snackbar(
                                        'Error',
                                        'No hay checkpoints para mostrar',
                                      );
                                    }
                                  },
                                  title: Text(
                                    'Estatus: ${round.status}',
                                    style: const TextStyle(
                                      fontSize: 16,
                                      color: Colors.black,
                                    ),
                                  ),
                                  subtitle: Text(
                                    'Inicia: ${Helper().formatTime(round.start ?? '')}',
                                    style: const TextStyle(
                                      fontSize: 16,
                                      color: Colors.black,
                                    ),
                                  ),
                                  trailing: const Icon(
                                    Icons.navigate_next,
                                    color: Colors.black,
                                  ),
                                  dense: true,
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  );
                } else {
                  return const Center(
                    child: Text('No hay datos para mostrar'),
                  );
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}
