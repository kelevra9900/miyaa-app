import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:miyaa/routes/app_routes.dart';

import '../../common/input_widget.dart';
import '../../utils/constants.dart';
import 'auth_controller.dart';
import 'widgets/block_button.dart';

class LoginScreen extends GetView<AuthController> {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    controller.loginFormKey = GlobalKey<FormState>();

    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: SingleChildScrollView(
            reverse: true,
            child: Column(
              children: [
                Header(controller: controller),
                Form(
                  key: controller.loginFormKey,
                  child: Padding(
                    padding: const EdgeInsets.all(17.0),
                    child: Column(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.asset(
                            Constants().logo,
                            width: 120,
                          ),
                        ),
                        SizedBox(height: Get.height * 0.1),
                        InputWidget(
                          keyboardType: TextInputType.emailAddress,
                          validator: (input) => !input!.contains('@')
                              ? 'Should be a valid email'.tr
                              : null,
                          labelText: 'Email',
                          onSaved: (input) =>
                              controller.currentUser?.value.email = input!,
                        ),
                        const SizedBox(height: 20),
                        Obx(
                          () => InputWidget(
                            suffixIcon: IconButton(
                              onPressed: () {
                                controller.hidePassword.value =
                                    !controller.hidePassword.value;
                              },
                              icon: Icon(
                                controller.hidePassword.value
                                    ? Icons.visibility
                                    : Icons.visibility_off,
                                color: Get.theme.colorScheme.primary,
                              ),
                            ),
                            keyboardType: TextInputType.visiblePassword,
                            validator: (input) => input!.length < 6
                                ? 'Should be at least 6 characters'.tr
                                : null,
                            labelText: 'Password'.tr,
                            hintText: '••••••••••••',
                            obscureText: controller.hidePassword.value,
                            onSaved: (input) => controller
                                .currentUser?.value.passwordHash = input!,
                          ),
                        ),
                        const SizedBox(height: 20),
                        Obx(
                          () => RoundedBlockButtonWidget(
                            buttonText: 'Login'.tr,
                            width: Get.width,
                            onpressed: controller.login,
                            loading: controller.loading.value,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          'O'.tr,
                          style: TextStyle(
                            color: Get.theme.colorScheme.primary,
                            fontSize: 14,
                            fontWeight: FontWeight.w300,
                          ),
                        ),
                        RoundedBlockButtonWidget(
                          buttonText: 'Reconocimiento facial'.tr,
                          width: Get.width,
                          onpressed: () {
                            Get.toNamed(Routes.faceRecognition);
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class Header extends StatelessWidget {
  Header({super.key, required AuthController controller});

  final AuthController controller = Get.find();
  final String? language = 'es';

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 15, right: 15, top: 30, bottom: 20),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 5, right: 5),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(bottom: 15),
                      child: Text(
                        'Login'.tr,
                        style: TextStyle(
                          color: Get.theme.colorScheme.primary,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 200,
                      child: Text(
                        'Welcome'.tr,
                        style: TextStyle(
                          color: Get.theme.colorScheme.primary,
                          fontSize: 13,
                          fontWeight: FontWeight.w300,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
