import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'auth_controller.dart';

class SelectEnvironmentScreen extends GetView<AuthController> {
  SelectEnvironmentScreen({super.key});
  final jobRoleCtrl = TextEditingController();

  void _selectEnvironment(String? value) {
    // controller.selectEnvironment(value);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Select a environment'.tr),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Column(
            children: [
              const SizedBox(height: 20),
              Center(
                child: Image.asset(
                  'assets/images/select_environment.png',
                  height: 200,
                ),
              ),
              Text(
                'Select_environment'.tr,
                style: TextStyle(
                  color: Get.theme.colorScheme.primary,
                  fontSize: 13,
                  fontWeight: FontWeight.w300,
                ),
              ),
              const SizedBox(
                height: 20,
              ),
              // CustomDropdown(
              //   hintText: 'Please select your environment',
              //   items: const ['Kali Connect', 'Insurance', 'MultiServicios'],
              //   controller: jobRoleCtrl,
              // ),
              const SizedBox(
                height: 20,
              ),
              //Button to select environment
              SizedBox(
                width: double.infinity,
                height: 40,
                child: ElevatedButton(
                  onPressed: () {
                    _selectEnvironment(jobRoleCtrl.text);
                    Navigator.pushNamed(context, '/login');
                  },
                  style: ElevatedButton.styleFrom(
                    foregroundColor: Colors.white,
                    backgroundColor: Get.theme.colorScheme.primary,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  child: Text('Next'.tr),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
