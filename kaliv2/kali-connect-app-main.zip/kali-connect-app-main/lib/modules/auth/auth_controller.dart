import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../../models/auth_response_model.dart';
import '../../models/user_model.dart';
import '../../repositories/user_repository.dart';
import '../../routes/app_routes.dart';
import '../../services/auth_service.dart';
import '../../utils/ui.dart';

class AuthController extends GetxController {
  final GetStorage box = GetStorage();
  final Rx<User>? currentUser = Get.find<AuthService>().user;
  final Rx<ResLogin> currentSession = Get.find<AuthService>().session;
  late GlobalKey<FormState> loginFormKey = GlobalKey<FormState>();
  final hidePassword = true.obs;
  final loading = false.obs;
  late final UserRepository _userRepository = UserRepository();

  void login() async {
    if (!validateForm()) return;
    loading.value = true;

    try {
      await attemptLogin();
    } catch (e) {
      print(e);
    } finally {
      loading.value = false;
    }
  }

  bool validateForm() {
    Get.focusScope?.unfocus();
    if (!(loginFormKey.currentState?.validate() ?? false)) return false;
    loginFormKey.currentState?.save();
    return true;
  }

  Future<void> attemptLogin() async {
    currentSession.value = await _userRepository.login(
      username: currentUser?.value.email,
      password: currentUser?.value.passwordHash,
    );
    if (currentSession.value.jwt == null) {
      Get.showSnackbar(Ui.errorSnackBar(message: 'Error'));
      return;
    }

    if (!validateUserDetails()) {
      return;
    }

    await updateUserProfile();
    navigateToHome();
  }

  bool validateUserDetails() {
    // if (currentUser?.value.role == null || currentUser?.value.shiftId == null) {
    //   logoutUser();
    //   return false;
    // }
    return true;
  }

  void logoutUser() {
    Get.find<AuthService>().logout();
    Get.offAllNamed(Routes.login);
    Get.showSnackbar(
      Ui.errorSnackBar(
        message:
            'Tu cuenta no está activa, por favor contacta a soporte técnico',
      ),
    );
  }

  Future<void> updateUserProfile() async {
    await _userRepository.profile();
    box.write('token', currentSession.value.jwt);
  }

  void navigateToHome() {
    Get.offAllNamed(Routes.root);
  }

  void handleError(Exception e) {
    Get.showSnackbar(Ui.errorSnackBar(message: e.toString()));
  }
}
