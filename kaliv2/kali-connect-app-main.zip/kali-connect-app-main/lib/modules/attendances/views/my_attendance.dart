import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../common/theme.dart';
import '../../../utils/helper.dart';
import '../controllers/attendance_controller.dart';
import '../widgets/check_button.dart';
import '../widgets/column_widget.dart';

class MyAttendance extends GetView<AttendanceController> {
  const MyAttendance({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<AttendanceController>(
      builder: (controller) {
        return Scaffold(
          appBar: AppBar(
            title: Text(
              'My Attendance'.tr,
              style: const TextStyle(
                color: KaliColors.textMainColor,
              ),
            ),
            leading: IconButton(
              icon: const Icon(
                Icons.chevron_left,
                color: KaliColors.textMainColor,
                size: 30,
              ),
              onPressed: () {
                Get.back();
              },
            ),
          ),
          body: RefreshIndicator(
            onRefresh: () async {
              controller.myAttendance();
            },
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  timeInHourAndMinutes(),
                  dayAndDate(),
                  Obx(
                    () => controller.isShiftDone.value
                        ? alreadyCheckedIn()
                        : CheckButton(
                            onPressed: controller.isCheckIn.value &&
                                    !controller.isShiftDone.value
                                ? controller.checkIn
                                : controller.checkOut,
                            label: controller.isCheckIn.value
                                ? 'Check in'.tr
                                : 'Check out'.tr,
                            backgroundColor: controller.isCheckIn.value
                                ? KaliColors.primaryColor
                                : Colors.red,
                            backgroundGradientColor: controller.isCheckIn.value
                                ? KaliColors.secondaryColor
                                : Colors.redAccent,
                          ),
                  ),
                  Obx(
                    () => controller.isShiftDone.value
                        ? checkInCheckOutTotalHours()
                        : const SizedBox(),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget checkInCheckOutTotalHours() {
    return Container(
      padding: const EdgeInsets.all(20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[
          ColumnWidget(
            icon: Icons.check_circle_outline,
            time: controller.attendanceModel?.checkIn != null
                ? Helper().formatDateTime(controller.attendanceModel!.checkIn!)
                : '00:00',
            totalHours: 'Checked in'.tr,
          ),
          ColumnWidget(
            icon: Icons.outbond_outlined,
            time: controller.attendanceModel?.checkOut != null
                ? Helper().formatDateTime(controller.attendanceModel!.checkOut!)
                : '00:00',
            totalHours: 'Checked out'.tr,
          ),
          ColumnWidget(
            icon: Icons.timeline_rounded,
            time: '02:00',
            totalHours: 'Total hours'.tr,
          ),
        ],
      ),
    );
  }

  Widget timeInHourAndMinutes() {
    return Container(
      padding: const EdgeInsets.all(20),
      child: Obx(
        () => RichText(
          textAlign: TextAlign.center,
          text: TextSpan(
            text:
                '${controller.currentTime.value.hour}:${controller.currentTime.value.minute}:${controller.currentTime.value.second}',
            style: const TextStyle(
              fontSize: 35,
              fontWeight: FontWeight.bold,
              color: KaliColors.textMainColor,
            ),
            children: <TextSpan>[
              TextSpan(
                text:
                    ' ${controller.currentTime.value.hour > 12 ? 'PM' : 'AM'}',
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  color: KaliColors.textMainColor,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget dayAndDate() {
    return SizedBox(
      child: Center(
        child: Obx(
          () => Text(
            controller.getFormattedDate(),
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w300,
              color: Colors.black,
            ),
          ),
        ),
      ),
    );
  }

  Widget alreadyCheckedIn() {
    return Container(
      padding: const EdgeInsets.all(20),
      child: RichText(
        textAlign: TextAlign.center,
        text: TextSpan(
          text: 'You have already registered your departure,'.tr,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w400,
            color: KaliColors.textMainColor,
          ),
          children: <TextSpan>[
            TextSpan(
              text:
                  ' You can send a message to your supervisor if you need to do overtime'
                      .tr,
              style: const TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.bold,
                color: KaliColors.textMainColor,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
