import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:image_picker/image_picker.dart';
import 'package:dio/dio.dart' as dio;
import 'package:path_provider/path_provider.dart' as path_provider;

import '../../../models/attendance_model.dart';
import '../../../providers/laravel_provider.dart';

class AttendanceController extends GetxController {
  LaravelApiClient laravelApiClient = LaravelApiClient();
  final Rx<DateTime> currentTime = DateTime.now().obs;
  late File imageFile;
  final ImagePicker picker = ImagePicker();

  late RxBool loading = false.obs;
  RxBool isCheckIn = false.obs;
  RxBool isShiftDone = false.obs;

  AttendanceModel? attendanceModel = AttendanceModel();

  AttendanceController() {
    laravelApiClient.init();
  }

  @override
  void onInit() {
    super.onInit();
    _startClock();
    myAttendance();
  }

  void _startClock() {
    // Actualiza la hora cada segundo
    Future.delayed(const Duration(seconds: 1), () {
      currentTime(DateTime.now());
      _startClock();
    });
  }

  String getFormattedDate() {
    final customFormat = DateFormat('EEEE - MMMM d, yyyy', 'es_MX');
    return customFormat.format(currentTime.value);
  }

  String getFormattedTime() {
    return '${currentTime.value.hour}:${currentTime.value.minute} ${currentTime.value.hour > 12 ? 'PM' : 'AM'}';
  }

  // Cambia el estado de la variable isCheckIn
  void checkIn() {
    showCustomDialog('Check in', 'Are you sure you want to check in?', false);
  }

  // Cambia el estado de la variable isCheckIn
  void checkOut() {
    showCustomDialog('Check out', 'Are you sure you want to check out?', true);
  }

  // Get my currence attendance
  Future myAttendance() async {
    var response = await laravelApiClient.getMyAttendance();
    attendanceModel = response;

    if (response?.checkIn != null && response?.checkOut != null) {
      isShiftDone(true);
    } else if (response?.checkIn != null) {
      isCheckIn(false);
    } else {
      isCheckIn(true);
    }
    return response;
  }

  Future<void> processBiometric(XFile image) async {
    imageFile = File(image.path);
    final name = DateTime.now().millisecondsSinceEpoch;

    final dir = await path_provider.getTemporaryDirectory();
    final targetPath = '${dir.absolute.path}/$name.jpg';

    await imageFile.copy(targetPath);
    imageFile = File(targetPath);

    try {
      checkInCheckOut();
    } catch (error) {
      // showImageErrorSnackbar('An error occurred: $error');
    } finally {
      loading.value = false;
    }
  }

  Future<void> getBiometric() async {
    loading.value = true;
    try {
      final XFile? image = await picker.pickImage(
        source: ImageSource.camera,
      );
      if (image != null) {
        await processBiometric(image);
      } else {
        // showImageErrorSnackbar('Para continuar, debes tomarte una foto');
      }
    } catch (error) {
      // showImageErrorSnackbar('A ocurrido un error: $error');
    } finally {
      loading.value = false;
    }
  }

  Future checkBiometric(String filePath) async {
    try {
      final dio.FormData formData = dio.FormData.fromMap({
        'file': await dio.MultipartFile.fromFile(filePath,
            filename: '${DateTime.now().millisecondsSinceEpoch}.jpg'),
      });
      var response = await laravelApiClient.checkInCheckOut(
        filePath: filePath,
        formData: formData,
        uri: 'attendances',
        isCheckIn: isCheckIn.value,
      );
      myAttendance();
      return response;
    } catch (e) {
      Get.log('Error uploading biometric $e');
      rethrow;
    }
  }

  Future checkInCheckOut() async {
    var formData = dio.FormData.fromMap({
      'file': await dio.MultipartFile.fromFile(imageFile.path,
          filename: '${DateTime.now().millisecondsSinceEpoch}.jpg'),
      'checkIn': DateTime.now().toIso8601String(),
    });
    await laravelApiClient.checkInCheckOut(
      filePath: imageFile.path,
      formData: formData,
      uri: isCheckIn.value
          ? '/users/me/attendance/check-in'
          : '/users/me/attendance/check-out',
      isCheckIn: isCheckIn.value,
    );
    myAttendance();
  }

  void showCustomDialog(String title, String message, bool checkIn) {
    Get.dialog(
      Dialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
        ),
        child: Container(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                title.tr,
                style: TextStyle(
                  color: Get.theme.primaryColor,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 15),
              Text(
                message.tr,
                style: TextStyle(
                  color: Get.theme.primaryColor,
                  fontSize: 16,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      Get.back(result: false);
                    },
                    style: ElevatedButton.styleFrom(
                      foregroundColor: Get.theme.primaryColor,
                      backgroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        side: BorderSide(color: Get.theme.primaryColor),
                      ),
                    ),
                    child: Text('No'.tr),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      getBiometric();
                      Get.back(result: true);
                    },
                    style: ElevatedButton.styleFrom(
                      foregroundColor: Colors.white,
                      backgroundColor: Get.theme.primaryColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                    ),
                    child: Text('Yes'.tr),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
      barrierDismissible: false,
    );
  }
}
