import 'package:flutter/material.dart';

import '../../../common/theme.dart';

class ColumnWidget extends StatelessWidget {
  const ColumnWidget({
    super.key,
    required this.icon,
    required this.time,
    required this.totalHours,
    this.timeColor = KaliColors.textMainColor,
    this.totalHoursColor = KaliColors.textMainColor,
  });

  final IconData icon;
  final String time;
  final Color? timeColor;
  final String totalHours;
  final Color? totalHoursColor;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Icon(icon),
        const SizedBox(height: 5),
        Text(
          time,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.bold,
            color: timeColor,
          ),
        ),
        Text(
          totalHours,
          style: TextStyle(
            fontSize: MediaQuery.of(context).size.width * 0.035,
            fontWeight: FontWeight.w400,
            color: totalHoursColor,
          ),
        ),
      ],
    );
  }
}
