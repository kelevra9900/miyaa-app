import 'package:flutter/material.dart';

import '../../../common/theme.dart';

class SuggestionTextField extends FormField<String> {
  SuggestionTextField({
    super.key,
    TextInputAction? textInputAction,
    required String label,
    bool obscureText = false,
    TextInputType? keyboardType,
    super.validator,
    void Function(String)? onSubmitted,
    void Function(String)? onChanged,
    int? maxLines = 1,
    FocusNode? focusNode,
  }) : super(
          autovalidateMode: AutovalidateMode.onUserInteraction,
          builder: (state) {
            bool isOk = !state.hasError &&
                state.value != null &&
                state.value!.isNotEmpty;
            return TextField(
              focusNode: focusNode,
              obscureText: obscureText,
              textInputAction: textInputAction,
              keyboardType: keyboardType,
              onSubmitted: onSubmitted,
              maxLines: maxLines,
              onChanged: (text) {
                state.didChange(text);
                if (onChanged != null) {
                  onChanged(text);
                }
              },
              style: const TextStyle(
                fontSize: 16,
                color: KaliColors.textMainColor,
              ),
              decoration: InputDecoration(
                label: Text(
                  label,
                  style: const TextStyle(
                    fontSize: 16,
                    color: KaliColors.textMainColor,
                  ),
                ),
                suffixIcon: Icon(
                  Icons.check_circle,
                  color: isOk ? Colors.green : Colors.black12,
                ),
                errorText: state.errorText,
                disabledBorder: const OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black12,
                  ),
                ),
                fillColor: Colors.white,
                // Border color
                enabledBorder: const OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black12,
                  ),
                ),
              ),
            );
          },
        );
}
