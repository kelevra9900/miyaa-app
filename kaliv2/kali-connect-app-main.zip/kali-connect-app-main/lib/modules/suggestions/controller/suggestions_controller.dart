import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../repositories/suggestions_repository.dart';
import '../../../services/auth_service.dart';
import '../../../utils/ui.dart';

class SuggestionsController extends GetxController {
  TextEditingController suggestionTextCtrl = TextEditingController();
  late SuggestionRepository _suggestionRepository;
  FocusNode suggestionFocusNode = FocusNode();
  double userRating = 3.0;

  late TextEditingController ratingController;
  double initialRating = 2.0;
  late double rating;

  RxBool isSending = false.obs;
  RxBool loading = false.obs;

  @override
  void onInit() {
    super.onInit();
    _suggestionRepository = SuggestionRepository();
    ratingController = TextEditingController(text: '3.0');
    rating = initialRating;
    suggestionFocusNode.addListener(_listener);
  }

  @override
  void onClose() {
    suggestionTextCtrl.dispose();
    super.onClose();
    suggestionFocusNode.removeListener(_listener);
  }

  void _listener() {
    suggestionFocusNode.addListener(() {
      if (suggestionFocusNode.hasFocus) {
        // print('Focus');
      } else {
        // print('No Focus');
      }
    });
  }

  Future sendSuggestion() async {
    loading.value = true;
    if (suggestionTextCtrl.text.isNotEmpty) {
      var content = suggestionTextCtrl.text;
      var userId = Get.find<AuthService>().user.value.id;
      await _suggestionRepository.sendSuggestion(
        suggestion: content,
        userId: int.parse(
          userId.toString(),
        ),
        rating: rating,
      );
      loading.value = false;
      isSending.value = true;
      Get.showSnackbar(
        Ui.SuccessSnackBar(
          message: 'Suggestion sent successfully'.tr,
        ),
      );
      // Duration 2 seconds to change isSending to false
      await Future.delayed(const Duration(seconds: 2));
      isSending.value = false;
      suggestionTextCtrl.clear();
      // Get.back();
      Get.back();
    } else {
      loading.value = false;
      Get.showSnackbar(
        Ui.errorSnackBar(
          message: 'Please, type your suggestion'.tr,
        ),
      );
    }
  }
}
