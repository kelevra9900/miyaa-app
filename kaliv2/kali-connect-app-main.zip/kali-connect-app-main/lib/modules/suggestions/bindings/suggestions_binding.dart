import 'package:get/get.dart';

import '../controller/suggestions_controller.dart';

class SuggestionBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(SuggestionsController());
  }
}
