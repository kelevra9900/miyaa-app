import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';

import '../../../common/theme.dart';
import '../../../utils/ui.dart';
import '../../auth/widgets/block_button.dart';
import '../controller/suggestions_controller.dart';
import '../widgets/input.dart';

class CreateSuggestionView extends GetView<SuggestionsController> {
  const CreateSuggestionView({super.key});

  @override
  Widget build(BuildContext context) {
    FocusScope.of(context).requestFocus(controller.suggestionFocusNode);
    return Form(
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            'Crear sugerencia',
            style: TextStyle(
              color: KaliColors.textMainColor,
            ),
          ),
          //  back button color
          leading: IconButton(
            icon: const Icon(
              Icons.chevron_left,
              color: KaliColors.textMainColor,
              size: 30,
            ),
            onPressed: () {
              Get.back();
            },
          ),
        ),
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(15),
            children: [
              const SizedBox(height: 20),
              SizedBox(
                width: 120,
                height: 120,
                child: Image.asset(
                  'assets/logo/logo.png',
                ),
              ),
              const SizedBox(height: 20),
              Builder(builder: (context) {
                return Center(
                  child: RatingBar.builder(
                    initialRating: controller.initialRating,
                    minRating: 1,
                    direction: Axis.horizontal,
                    allowHalfRating: true,
                    itemCount: 5,
                    itemPadding: const EdgeInsets.symmetric(horizontal: 4.0),
                    itemBuilder: (context, _) => const Icon(
                      Icons.star,
                      color: Colors.amber,
                    ),
                    onRatingUpdate: (rating) {
                      controller.rating = rating;
                      controller.ratingController.text = rating.toString();
                    },
                  ),
                );
              }),
              const SizedBox(height: 20),
              Builder(builder: (context) {
                return SuggestionTextField(
                  label: 'Type your suggestion here...'.tr,
                  maxLines: 5,
                  textInputAction: TextInputAction.send,
                  onChanged: (text) {
                    controller.suggestionTextCtrl.text = text;
                  },
                  onSubmitted: (_) => _submit(context),
                );
              }),
              const SizedBox(height: 20),
              Builder(builder: (context) {
                return RoundedBlockButtonWidget(
                  buttonText: 'Send'.tr,
                  width: 200,
                  onpressed: () {
                    if (controller.isSending.value) {
                      Get.showSnackbar(
                        Ui.defaultSnackBar(
                          title: 'Attention'.tr,
                          message:
                              'Please wait for the suggestion to be sent'.tr,
                        ),
                      );
                      return;
                    }
                    if (controller.suggestionTextCtrl.text.isEmpty) {
                      Get.showSnackbar(
                        Ui.defaultSnackBar(
                          title: 'Attention'.tr,
                          message: 'Please write your suggestion'.tr,
                        ),
                      );
                      return;
                    }
                    _submit(context);
                  },
                );
              }),
            ],
          ),
        ),
      ),
    );
  }

  void _submit(BuildContext context) {
    final formState = Form.of(context);
    if (formState.validate()) {
      if (controller.suggestionTextCtrl.text.isEmpty) {
        Get.showSnackbar(
          Ui.defaultSnackBar(
            title: 'Attention'.tr,
            message: 'Please write your suggestion'.tr,
          ),
        );
        return;
      }
      if (controller.isSending.value) {
        Get.showSnackbar(
          Ui.defaultSnackBar(
            title: 'Attention'.tr,
            message: 'Please wait for the suggestion to be sent'.tr,
          ),
        );
        return;
      }
      controller.sendSuggestion();
    }
  }
}
