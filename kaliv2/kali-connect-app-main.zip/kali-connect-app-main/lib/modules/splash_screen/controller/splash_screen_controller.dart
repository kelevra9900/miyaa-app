import 'dart:async';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../../../routes/app_routes.dart';

class SplashController extends GetxController {
  GetStorage? _box;
  Rx<String> environment = 'kali'.obs;

  SplashController() {
    _box = GetStorage();
    environment.value = _box!.read('environment_name') ?? 'kali';
  }

  @override
  void onReady() {
    super.onReady();
    loading();
  }

  Future<void> loading() async {
    var token = _box!.read('token');
    Timer(const Duration(seconds: 4), () {
      if (token != null) {
        Get.offNamed(Routes.root);
      } else {
        Get.offAndToNamed(Routes.login);
      }
    });
  }
}
