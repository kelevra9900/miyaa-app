import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../common/theme.dart';
import '../controllers/settings_controller.dart';
import '../widgets/tab_bar_widget.dart';
import '../../../routes/app_routes.dart';

class SettingsView extends GetView<SettingsController> {
  final _navigatorKey = Get.nestedKey(1);

  SettingsView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Settings'.tr,
          style: TextStyle(
            color: Get.theme.primaryColor,
            fontSize: 18,
            fontWeight: FontWeight.w500,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        automaticallyImplyLeading: false,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios,
            color: KaliColors.textMainColor,
          ),
          onPressed: () => Get.back(),
        ),
        elevation: 0,
        bottom: TabBarWidget(
          initialSelectedId: 0,
          tag: 'settings',
          tabs: [
            ChipWidget(
              tag: 'settings',
              text: 'Languages'.tr,
              id: 0,
              onSelected: (id) {
                controller.changePage(id);
              },
            ),
            // ChipWidget(
            //   tag: 'settings',
            //   text: 'Theme Mode'.tr,
            //   id: 1,
            //   onSelected: (id) {
            //     controller.changePage(id);
            //   },
            // )
          ],
        ),
      ),
      body: PopScope(
        canPop: true,
        child: Navigator(
          key: _navigatorKey,
          initialRoute: Routes.languages,
          onGenerateRoute: controller.onGenerateRoute,
        ),
      ),
    );
  }
}
