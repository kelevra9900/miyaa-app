import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../utils/ui.dart';
import '../controllers/language_controller.dart';

class LanguageView extends GetView<LanguageController> {
  final bool hideAppBar;

  const LanguageView({super.key, this.hideAppBar = false});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: hideAppBar
          ? null
          : AppBar(
              title: Text(
                'Languages'.tr,
                style: context.textTheme.titleLarge,
              ),
              centerTitle: true,
              backgroundColor: Colors.transparent,
              automaticallyImplyLeading: false,
              leading: IconButton(
                icon: Icon(Icons.arrow_back_ios, color: Get.theme.hintColor),
                onPressed: () => Get.back(),
              ),
              elevation: 0,
            ),
      body: ListView(
        primary: true,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(vertical: 5),
            margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
            decoration: Ui.getBoxDecoration(),
            child: Column(
              children: [
                RadioListTile(
                  value: 'es',
                  groupValue: Get.locale.toString(),
                  activeColor: Get.theme.colorScheme.secondary,
                  onChanged: (value) {
                    controller.updateLocale(value);
                  },
                  title: Text(
                    'Spanish'.tr,
                    style: Get.textTheme.bodyMedium?.merge(
                      const TextStyle(
                        color: Colors.black,
                      ),
                    ),
                  ),
                ),
                RadioListTile(
                  value: 'en',
                  groupValue: Get.locale.toString(),
                  activeColor: Get.theme.colorScheme.secondary,
                  overlayColor: WidgetStateProperty.all(Colors.red),
                  onChanged: (value) {
                    controller.updateLocale(value);
                  },
                  title: Text(
                    'English'.tr,
                    style: Get.textTheme.bodyMedium?.merge(
                      const TextStyle(
                        color: Colors.black,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
