import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../utils/ui.dart';
import '../controllers/theme_mode_controller.dart';

class ThemeModeView extends GetView<ThemeModeController> {
  final bool hideAppBar;

  const ThemeModeView({super.key, this.hideAppBar = false});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: !hideAppBar
          ? AppBar(
              backgroundColor: Get.theme.colorScheme.primary,
              title: const Text(
                'Theme Mode',
                style: TextStyle(color: Colors.white),
              ),
            )
          : null,
      body: ListView(
        primary: true,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(vertical: 5),
            margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
            decoration: Ui.getBoxDecoration(),
            child: Obx(
              () => Column(
                children: [
                  RadioListTile(
                    value: ThemeMode.light,
                    groupValue: controller.selectedThemeMode.value,
                    activeColor: Get.theme.colorScheme.secondary,
                    onChanged: (dynamic value) {
                      controller.changeThemeMode(value);
                    },
                    title: Text(
                      'Light Theme'.tr,
                      style: const TextStyle(
                        color: Colors.black,
                      ),
                    ),
                  ),
                  RadioListTile(
                    value: ThemeMode.dark,
                    groupValue: controller.selectedThemeMode.value,
                    activeColor: Get.theme.colorScheme.secondary,
                    onChanged: (dynamic value) {
                      controller.changeThemeMode(value);
                    },
                    title: Text(
                      'Dark Theme'.tr,
                      style: const TextStyle(
                        color: Colors.black,
                      ),
                    ),
                  ),
                  RadioListTile(
                    value: ThemeMode.system,
                    groupValue: controller.selectedThemeMode.value,
                    onChanged: (dynamic value) {
                      controller.changeThemeMode(value);
                    },
                    title: Text(
                      'System Theme'.tr,
                      style: const TextStyle(
                        color: Colors.black,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
