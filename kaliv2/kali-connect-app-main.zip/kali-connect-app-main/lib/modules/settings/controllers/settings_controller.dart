import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../routes/app_routes.dart';
import '../bindings/settings_binding.dart';
import '../views/language_view.dart';
import '../views/theme_mode_view.dart';
import '../widgets/tab_bar_widget.dart';

class SettingsController extends GetxController {
  var currentIndex = 0.obs;
  final pages = <String>[Routes.languages, Routes.themeMode];

  void changePage(int index) {
    currentIndex.value = index;
    Get.toNamed(pages[index], id: 1);
  }

  Route? onGenerateRoute(RouteSettings settings) {
    if (settings.name == Routes.languages) {
      return GetPageRoute(
        settings: settings,
        page: () => const LanguageView(hideAppBar: true),
        binding: SettingsBinding(),
      );
    }

    if (settings.name == Routes.themeMode) {
      return GetPageRoute(
        settings: settings,
        page: () => const ThemeModeView(hideAppBar: true),
        binding: SettingsBinding(),
      );
    }
    return null;
  }

  @override
  void onInit() {
    if (Get.isRegistered<TabBarController>(tag: 'settings')) {
      Get.find<TabBarController>(tag: 'settings').selectedId.value = '0';
    }
    currentIndex.value = 0;
    super.onInit();
  }
}
