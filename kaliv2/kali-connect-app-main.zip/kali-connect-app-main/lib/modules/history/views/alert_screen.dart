import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../../common/modal_map.dart';
import '../../../models/my_alerts_model.dart';
import '../../../services/auth_service.dart';
import '../../../utils/ui.dart';
import '../widgets/alert_row_widget.dart';
import '../widgets/alert_til_widget.dart';
import '../widgets/alert_title_bar_widget.dart';

class AlertDetailScreen extends StatelessWidget {
  const AlertDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var alert = Get.arguments['alert'] as Alerts;

    return Scaffold(
      // bottomNavigationBar: BookingActionsWidget(),
      body: RefreshIndicator(
        onRefresh: () async {
          // Get.find<LaravelApiClient>().forceRefresh();
          // controller.refreshBooking(showMessage: true);
          // Get.find<LaravelApiClient>().unForceRefresh();
        },
        child: CustomScrollView(
          primary: true,
          shrinkWrap: false,
          slivers: <Widget>[
            SliverAppBar(
              backgroundColor: Theme.of(context).scaffoldBackgroundColor,
              expandedHeight: 370,
              elevation: 0,
              floating: true,
              iconTheme: IconThemeData(color: Get.theme.primaryColor),
              centerTitle: true,
              automaticallyImplyLeading: false,
              leading: IconButton(
                icon: Icon(
                  Icons.arrow_back_ios,
                  color: Get.theme.primaryColor,
                ),
                onPressed: () async {
                  Get.back();
                },
              ),
              bottom: buildAlertTitleBarWidget(alert),
              flexibleSpace: FlexibleSpaceBar(
                collapseMode: CollapseMode.parallax,
                background: MapsUtil.getStaticMaps(
                  [alert.getLatLng()],
                  height: 600,
                  size: '700x600',
                  zoom: 14,
                ),
              ).marginOnly(bottom: 68),
            ),
            SliverToBoxAdapter(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  buildContactProvider(alert),
                  AlertTilWidget(
                    title: Text(
                      'Alert ID'.tr,
                      style: Get.textTheme.displayMedium?.copyWith(
                        fontWeight: FontWeight.w500,
                        fontSize: 18,
                        color: Get.theme.primaryColor,
                      ),
                    ),
                    actions: [
                      Text(
                        '#1',
                        style: Get.textTheme.bodyMedium?.copyWith(
                          color: Get.theme.hintColor,
                        ),
                      )
                    ],
                    content: Column(
                      children: [
                        AlertRowWidget(
                          descriptionFlex: 1,
                          valueFlex: 2,
                          description: 'Status'.tr,
                          hasDivider: true,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Container(
                                padding: const EdgeInsets.only(
                                    right: 12, left: 12, top: 6, bottom: 6),
                                decoration: BoxDecoration(
                                  borderRadius: const BorderRadius.all(
                                    Radius.circular(5),
                                  ),
                                  color: alert.status == 'Solucionada'
                                      ? Colors.green
                                      : Get.theme.focusColor.withOpacity(0.1),
                                ),
                                child: Text(
                                  alert.status ?? '',
                                  overflow: TextOverflow.clip,
                                  maxLines: 1,
                                  softWrap: true,
                                  style: TextStyle(
                                    color: alert.status == 'SOLVED'
                                        ? Colors.white
                                        : Get.theme.primaryColor,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  AlertTilWidget(
                    title: Text(
                      'Created At'.tr,
                      style: Get.textTheme.bodySmall?.copyWith(
                        color: Get.theme.primaryColor,
                        fontWeight: FontWeight.w500,
                        fontSize: 18,
                      ),
                    ),
                    actions: [
                      Container(
                        padding: const EdgeInsets.only(
                            right: 12, left: 12, top: 6, bottom: 6),
                        decoration: BoxDecoration(
                          borderRadius: const BorderRadius.all(
                            Radius.circular(5),
                          ),
                          color: Get.theme.focusColor.withOpacity(0.1),
                        ),
                        child: Text(
                          DateFormat('d MMMM y HH:mm', 'es_US')
                              .format(DateFormat('yyyy-MM-ddTHH:mm:ss.SSSZ')
                                  .parse(alert.createdAt!))
                              .toString(),
                          style: Get.textTheme.bodySmall?.copyWith(
                            color: Get.theme.primaryColor,
                          ),
                        ),
                      )
                    ],
                    content: Column(
                      children: [
                        AlertRowWidget(
                          description: 'Report At'.tr,
                          hasDivider: alert.createdAt != null,
                          child: Align(
                            alignment: Alignment.centerRight,
                            child: Text(
                              DateFormat('d MMMM y HH:mm', 'es_US')
                                  .format(DateFormat('yyyy-MM-ddTHH:mm:ss.SSSZ')
                                      .parse(alert.createdAt!))
                                  .toString(),
                              style: Get.textTheme.bodySmall,
                              textAlign: TextAlign.end,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  // AlertTilWidget(
                  //   title: Text('Comments'.tr),
                  //   actions: [
                  //     Container(
                  //       padding: const EdgeInsets.only(
                  //         right: 12,
                  //         left: 12,
                  //         top: 6,
                  //         bottom: 6,
                  //       ),
                  //       decoration: BoxDecoration(
                  //         borderRadius: const BorderRadius.all(
                  //           Radius.circular(5),
                  //         ),
                  //         color: Get.theme.focusColor.withOpacity(0.1),
                  //       ),
                  //       child: Text(
                  //         'Date'.tr,
                  //         style: Get.textTheme.bodyText2,
                  //       ),
                  //     )
                  //   ],
                  //   content: ListView.builder(
                  //     shrinkWrap: true,
                  //     primary: false,
                  //     itemCount: comments?.length ?? 0,
                  //     itemBuilder: (context, index) {
                  //       return AlertRowWidget(
                  //         description: comments?[index] ?? '',
                  //         hasDivider: index < comments!.length - 1,
                  //         child: Align(
                  //           alignment: Alignment.centerRight,
                  //           child: Text(
                  //             DateFormat(
                  //               'd, MM y HH:mm',
                  //               Get.locale.toString(),
                  //             ).format(
                  //               DateTime.parse(
                  //                 comments[index].fechaComentario ?? 'S.0.S',
                  //               ),
                  //             ),
                  //             style: Get.textTheme.caption,
                  //             textAlign: TextAlign.end,
                  //           ),
                  //         ),
                  //       );
                  //     },
                  //   ),
                  // )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  AlertTitleBarWidget buildAlertTitleBarWidget(Alerts history) {
    var currentUser = Get.find<AuthService>().user;
    var formattedDate = DateFormat('d MMMM y HH:mm', 'es_US')
        .format(
            DateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ").parse(history.createdAt!))
        .toString();
    return AlertTitleBarWidget(
      title: Row(
        children: [
          Flexible(
            fit: FlexFit.tight,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'Alert'.tr,
                  style: Get.textTheme.displayMedium?.merge(
                    TextStyle(
                      height: 1.1,
                      color: Get.theme.primaryColor,
                      fontSize: 26,
                    ),
                  ),
                  overflow: TextOverflow.fade,
                ),
                Row(
                  children: [
                    Icon(Icons.person_outline, color: Get.theme.primaryColor),
                    const SizedBox(width: 8),
                    Text(
                      '${currentUser.value.firstName} ${currentUser.value.lastName}',
                      style: Get.textTheme.labelMedium?.copyWith(
                        color: Get.theme.primaryColor,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.fade,
                    ),
                  ],
                ),
                Row(
                  children: [
                    Icon(Icons.place_outlined, color: Get.theme.primaryColor),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        formattedDate,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: Get.textTheme.bodySmall?.copyWith(
                          color: Get.theme.primaryColor,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Container(
            width: 80,
            decoration: BoxDecoration(
              color: Get.theme.colorScheme.secondary.withOpacity(0.2),
              borderRadius: const BorderRadius.all(Radius.circular(10)),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 6),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  DateFormat(
                    'HH:mm',
                    Get.locale.toString(),
                  ).format(
                    DateTime.parse(history.createdAt!),
                  ),
                  maxLines: 1,
                  style: Get.textTheme.bodySmall?.merge(
                    TextStyle(
                      color: Get.theme.colorScheme.secondary,
                      height: 1.4,
                    ),
                  ),
                  softWrap: false,
                  textAlign: TextAlign.center,
                  overflow: TextOverflow.fade,
                ),
                Text(
                  DateFormat(
                    'dd',
                    Get.locale.toString(),
                  ).format(
                    DateTime.parse(history.createdAt!),
                  ),
                  maxLines: 1,
                  style: Get.textTheme.displaySmall?.merge(
                    TextStyle(
                      color: Get.theme.colorScheme.primary,
                      height: 1,
                    ),
                  ),
                  softWrap: false,
                  textAlign: TextAlign.center,
                  overflow: TextOverflow.fade,
                ),
                Text(
                  DateFormat(
                    'MMM',
                    Get.locale.toString(),
                  )
                      .format(
                        DateTime.parse(history.createdAt!),
                      )
                      .toUpperCase(),
                  maxLines: 1,
                  style: Get.textTheme.bodyMedium?.merge(
                    TextStyle(
                        color: Get.theme.colorScheme.secondary, height: 1),
                  ),
                  softWrap: false,
                  textAlign: TextAlign.center,
                  overflow: TextOverflow.fade,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Container buildContactProvider(Alerts alert) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      decoration: Ui.getBoxDecoration(),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'More info'.tr,
                  style: Get.textTheme.labelMedium?.copyWith(
                    color: Get.theme.primaryColor,
                  ),
                ),
                Text(
                  'You have a question?',
                  style: Get.textTheme.labelSmall?.copyWith(
                    color: Get.theme.primaryColor,
                  ),
                ),
              ],
            ),
          ),
          Wrap(
            spacing: 5,
            children: [
              MaterialButton(
                onPressed: () {
                  // launchUrlString(
                  //     "tel:${_booking.eProvider?.phoneNumber ?? ''}");
                },
                height: 44,
                minWidth: 44,
                padding: EdgeInsets.zero,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
                color: Get.theme.colorScheme.secondary.withOpacity(0.2),
                elevation: 0,
                child: Icon(
                  Icons.phone_android_outlined,
                  color: Get.theme.colorScheme.secondary,
                ),
              ),
              MaterialButton(
                onPressed: () {
                  // controller.startChat();
                },
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                color: Get.theme.colorScheme.secondary.withOpacity(0.2),
                padding: EdgeInsets.zero,
                height: 44,
                minWidth: 44,
                elevation: 0,
                child: Icon(
                  Icons.chat_outlined,
                  color: Get.theme.colorScheme.secondary,
                ),
              ),
            ],
          )
        ],
      ),
    );
  }
}
