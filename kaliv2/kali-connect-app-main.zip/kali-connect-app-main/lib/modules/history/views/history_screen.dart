import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../../common/theme.dart';
import '../../../models/my_alerts_model.dart';
import '../../../providers/laravel_provider.dart';
import '../../../routes/app_routes.dart';
import '../../../utils/helper.dart';
import '../../../utils/ui.dart';
import '../controllers/history_controller.dart';

class HistoryScreen extends GetView<HistoryController> {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'My Alerts'.tr,
          style: const TextStyle(
            color: KaliColors.textMainColor,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        automaticallyImplyLeading: false,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: Get.theme.hintColor),
          onPressed: () => {
            Get.back(),
          },
        ),
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          Get.find<LaravelApiClient>().forceRefresh();
          await controller.refreshHistory(showMessage: true);
        },
        child: ListView(
          primary: true,
          children: <Widget>[
            Text(
              'Your History'.tr,
              style: TextStyle(
                color: Get.theme.primaryColor,
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            )
                .paddingOnly(
                  top: 25,
                  bottom: 0,
                  right: 22,
                  left: 22,
                )
                .paddingOnly(
                  top: 25,
                  bottom: 0,
                  right: 22,
                  left: 22,
                ),
            Text(
              'History description'.tr,
              style: Get.textTheme.bodySmall?.merge(
                const TextStyle(
                  fontWeight: FontWeight.w300,
                  color: KaliColors.textMainColor,
                ),
              ),
            ).paddingSymmetric(horizontal: 22, vertical: 5),
            historyList(),
          ],
        ),
      ),
    );
  }

  Widget historyList() {
    return Obx(
      () {
        if (controller.histories.isEmpty) {
          return Column(
            children: [
              const SizedBox(height: 50),
              Icon(
                Icons.notifications_off_outlined,
                color: Get.theme.focusColor.withOpacity(0.7),
                size: 150,
              ),
              const SizedBox(height: 20),
              Text(
                'No history yet'.tr,
                style: Get.textTheme.bodyMedium?.merge(
                  const TextStyle(
                    fontWeight: FontWeight.w300,
                    color: KaliColors.textMainColor,
                  ),
                ),
              ).paddingSymmetric(horizontal: 22, vertical: 5),
            ],
          );
        } else {
          return ListView.separated(
            itemCount: controller.histories.length,
            separatorBuilder: (context, index) {
              return const SizedBox(height: 2);
            },
            shrinkWrap: true,
            primary: false,
            itemBuilder: (context, index) {
              return _ListItem(d: controller.histories.elementAt(index));
            },
          );
        }
      },
    );
  }
}

class _ListItem extends StatelessWidget {
  final Alerts d;
  const _ListItem({required this.d});
  @override
  Widget build(BuildContext context) {
    return InkWell(
      child: Container(
        padding: const EdgeInsets.all(12),
        margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
        decoration: Ui.getBoxDecoration(
          color: d.status != 'SOLVED'
              ? Get.theme.primaryColor
              : Get.theme.focusColor.withOpacity(0.15),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Stack(
              children: <Widget>[
                Container(
                  width: 62,
                  height: 62,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    gradient: LinearGradient(
                      begin: Alignment.bottomLeft,
                      end: Alignment.topRight,
                      colors: [
                        d.status != 'Solucionada'
                            ? Colors.blue[900]!.withOpacity(0.6)
                            : Colors.blue[900]!.withOpacity(1),
                        d.status != 'Solucionada'
                            ? Colors.blue[600]!.withOpacity(0.1)
                            : Colors.blue[600]!.withOpacity(0.2),
                        // Get.theme.focusColor.withOpacity(0.2),
                      ],
                    ),
                  ),
                  child: Icon(
                    Icons.notifications_outlined,
                    color: Get.theme.scaffoldBackgroundColor,
                    size: 38,
                  ),
                ),
                Positioned(
                  right: -15,
                  bottom: -30,
                  child: Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      color: Theme.of(context)
                          .scaffoldBackgroundColor
                          .withOpacity(0.15),
                      borderRadius: BorderRadius.circular(150),
                    ),
                  ),
                ),
                Positioned(
                  left: -20,
                  top: -55,
                  child: Container(
                    width: 90,
                    height: 90,
                    decoration: BoxDecoration(
                      color: Theme.of(context)
                          .scaffoldBackgroundColor
                          .withOpacity(0.15),
                      borderRadius: BorderRadius.circular(150),
                    ),
                  ),
                )
              ],
            ),
            const SizedBox(width: 15),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                mainAxisSize: MainAxisSize.max,
                children: <Widget>[
                  Text(
                    Helper().getStatus(d.status ?? 'CREATED'),
                    overflow: TextOverflow.ellipsis,
                    maxLines: 3,
                    style: Get.textTheme.bodyLarge?.merge(
                      TextStyle(
                        fontWeight: d.status != 'SOLVED'
                            ? FontWeight.w300
                            : FontWeight.w600,
                        color: KaliColors.textMainColor,
                        fontSize: 16,
                      ),
                    ),
                  ),
                  Text(
                    // String to date
                    DateFormat('dd/MM/yyyy').format(
                      DateTime.parse(d.createdAt ?? ''),
                    ),
                    style: Get.textTheme.bodySmall?.merge(
                      const TextStyle(
                        fontWeight: FontWeight.w300,
                        color: KaliColors.textMainColor,
                      ),
                    ),
                  )
                ],
              ),
            )
          ],
        ),
      ),
      onTap: () {
        Get.toNamed(
          Routes.alertDetail,
          arguments: {'alert': d, 'heroTag': 'alert-list-item-${d.id}'},
        );
      },
    );
  }
}
