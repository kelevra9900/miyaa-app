import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../models/my_alerts_model.dart';
import '../../../repositories/history_repository.dart';
import '../../../services/auth_service.dart';
import '../../../utils/ui.dart';

class HistoryController extends GetxController {
  late HistoryRepository _historyRepository;

  final histories = <Alerts>[].obs;
  final page = 1.obs;
  final isLoading = true.obs;
  final isDone = false.obs;

  ScrollController scrollController = ScrollController();

  HistoryController() {
    _historyRepository = HistoryRepository();
  }

  @override
  Future<void> onInit() async {
    scrollController.addListener(() {
      if (scrollController.position.pixels ==
              scrollController.position.maxScrollExtent &&
          !isDone.value) {
        loadHistory();
      }
    });
    await refreshHistory();
    super.onInit();
  }

  Future refreshHistory({bool? showMessage}) async {
    await loadHistory();
    if (showMessage ?? false) {
      Get.showSnackbar(
        Ui.SuccessSnackBar(
          message: 'List of History refreshed successfully'.tr,
        ),
      );
    }
  }

  Future loadHistory() async {
    var userId = Get.find<AuthService>().user.value;
    try {
      isLoading.value = true;
      isDone.value = false;
      var response = await _historyRepository.getAll(
        page: page.value,
        userId: int.parse(userId.id.toString()),
      );
      page.value++;
      if (response.alerts!.isEmpty) {
        isDone.value = true;
      } else {
        histories.addAll(response.alerts!);
      }
    } catch (e) {
      isDone.value = true;
      Get.showSnackbar(Ui.errorSnackBar(message: e.toString()));
    } finally {
      isLoading.value = false;
    }
  }
}
