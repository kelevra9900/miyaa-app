import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../models/history_model.dart';
import '../../../routes/app_routes.dart';
import '../../../utils/ui.dart';

class HistoryItemWidget extends StatelessWidget {
  const HistoryItemWidget(
      {super.key,
      required this.historyModel,
      this.icon,
      this.onDismissed,
      this.onTap});

  final HistoryModel historyModel;
  final Widget? icon;
  final ValueChanged<HistoryModel>? onDismissed;
  final ValueChanged<HistoryModel>? onTap;

  @override
  Widget build(BuildContext context) {
    return Dismissible(
      key: Key(historyModel.idUsuarioCreo.hashCode.toString()),
      onDismissed: (direction) {
        // Get.find<HistoryController>().delete(historyModel.id);
      },
      child: InkWell(
        onTap: () {
          Get.toNamed(
            Routes.alertDetail,
            arguments: {'alert': historyModel, 'heroTag': 'alert-list-item'},
          );
          // onTap(notification);
        },
        child: Container(
          padding: const EdgeInsets.all(12),
          margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          decoration: Ui.getBoxDecoration(
            color: historyModel.estadoAlertaByIdEstado?.estadoAlerta == 'Creada'
                ? Get.theme.primaryColor
                : Get.theme.focusColor.withOpacity(0.15),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Stack(
                children: <Widget>[
                  Container(
                    width: 62,
                    height: 62,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      gradient: LinearGradient(
                        begin: Alignment.bottomLeft,
                        end: Alignment.topRight,
                        colors: [
                          historyModel.estadoAlertaByIdEstado?.estadoAlerta !=
                                  'Creada'
                              ? Get.theme.primaryColor.withOpacity(0.6)
                              : Get.theme.primaryColor.withOpacity(1),
                          historyModel.estadoAlertaByIdEstado?.estadoAlerta !=
                                  ''
                              ? Get.theme.primaryColor.withOpacity(0.1)
                              : Get.theme.primaryColor.withOpacity(0.2),
                          // Get.theme.focusColor.withOpacity(0.2),
                        ],
                      ),
                    ),
                    child: icon ??
                        Icon(
                          Icons.notifications_outlined,
                          color: Get.theme.scaffoldBackgroundColor,
                          size: 38,
                        ),
                  ),
                  Positioned(
                    right: -15,
                    bottom: -30,
                    child: Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        color: Theme.of(context)
                            .scaffoldBackgroundColor
                            .withOpacity(0.15),
                        borderRadius: BorderRadius.circular(150),
                      ),
                    ),
                  ),
                  Positioned(
                    left: -20,
                    top: -55,
                    child: Container(
                      width: 90,
                      height: 90,
                      decoration: BoxDecoration(
                        color: Theme.of(context)
                            .scaffoldBackgroundColor
                            .withOpacity(0.15),
                        borderRadius: BorderRadius.circular(150),
                      ),
                    ),
                  )
                ],
              ),
              const SizedBox(width: 15),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  mainAxisSize: MainAxisSize.max,
                  children: <Widget>[
                    Text(
                      historyModel.estadoAlertaByIdEstado?.estadoAlerta ?? '',
                      overflow: TextOverflow.ellipsis,
                      maxLines: 3,
                      style: Get.textTheme.bodyLarge?.merge(
                        const TextStyle(
                          fontWeight: FontWeight.w300,
                        ),
                      ),
                    ),
                    Text(
                      historyModel.fechaAlerta.toString(),
                      style: Get.textTheme.bodySmall,
                    )
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
