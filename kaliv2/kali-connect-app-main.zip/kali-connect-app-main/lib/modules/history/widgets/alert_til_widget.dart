import 'package:flutter/material.dart';

import '../../../utils/ui.dart';

class AlertTilWidget extends StatelessWidget {
  const AlertTilWidget({
    super.key,
    required this.title,
    required this.content,
    this.horizontalPadding,
    this.actions,
  });

  final Widget title;
  final Widget content;
  final double? horizontalPadding;
  final List<Widget>? actions;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
      padding: EdgeInsets.symmetric(
          horizontal: horizontalPadding ?? 20, vertical: 15),
      decoration: Ui.getBoxDecoration(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: title),
              if (actions != null)
                Wrap(
                  children: actions!,
                )
            ],
          ),
          const Divider(
            height: 26,
            thickness: 1.2,
          ),
          content,
        ],
      ),
    );
  }
}
