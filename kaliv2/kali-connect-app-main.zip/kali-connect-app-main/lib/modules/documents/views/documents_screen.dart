import 'package:draggable_home/draggable_home.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../common/theme.dart';
import '../../../models/documents_model.dart';
import '../../../routes/app_routes.dart';
import '../../../services/auth_service.dart';
import '../controllers/documents_controller.dart';
import '../widgets/document_item.dart';
import '../widgets/header_documents.dart';

class DocumentsScreen extends GetView<DocumentsController> {
  const DocumentsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: KaliColors.primaryColor,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios,
            color: Colors.white,
          ),
          onPressed: () {
            Get.back();
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(
              Icons.add,
              color: Colors.white,
            ),
            onPressed: () {
              Get.toNamed(Routes.createDocument);
            },
          ),
        ],
      ),
      body: DraggableHome(
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios,
            color: Colors.white,
          ),
          onPressed: () {
            Get.back();
          },
        ),
        appBarColor: KaliColors.primaryColor,
        title: SizedBox(
          height: 100,
          child: Center(
            child: Text('My documents'.tr),
          ),
        ),
        headerWidget: HeaderDocumentView(
          title:
              '${Get.find<AuthService>().user.value.firstName} ${Get.find<AuthService>().user.value.lastName}',
        ),
        body: [
          const SizedBox(
            height: 20,
          ),
          StreamBuilder<MyDocuments>(
            stream: controller.getDocuments(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(
                  child: CircularProgressIndicator(),
                );
              }
              if (snapshot.hasError) {
                return const Center(
                  child: Text('Error'),
                );
              }
              if (snapshot.data?.data?.uploaded?.isEmpty ?? true) {
                return Center(
                  child: Text(
                    'No documents to show'.tr,
                    style: const TextStyle(fontSize: 20, color: Colors.grey),
                  ),
                );
              }
              // Iteration over the documents
              return listView(snapshot.data?.data?.uploaded ?? []);
            },
          ),
          const SizedBox(
            height: 20,
          ),
          // Missing Documents Section
          StreamBuilder<MyDocuments>(
            stream: controller.getDocuments(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(
                  child: CircularProgressIndicator(),
                );
              }
              if (snapshot.hasError) {
                return const Center(
                  child: Text('Error'),
                );
              }
              if (snapshot.data?.data?.missing?.isEmpty ?? true) {
                return const SizedBox();
              }
              return Column(
                children: [
                  const Text(
                    'Parece que te falta algunos documentos',
                    style: TextStyle(
                      fontSize: 17,
                      color: Colors.grey,
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  listViewMissing(snapshot.data?.data?.missing ?? []),
                ],
              );
            },
          ),
        ],
      ),
    );
  }

  ListView listView(List<DocumentsModel> items) {
    return ListView.builder(
      padding: const EdgeInsets.only(top: 0),
      physics: const NeverScrollableScrollPhysics(),
      itemCount: items.length,
      shrinkWrap: true,
      itemBuilder: (context, index) => DocumentItem(
        title: items[index].documentType,
        subtitle: items[index].filePath,
        iconLeading: Icons.file_copy,
        iconTrailing: Icons.arrow_forward_ios,
        valid: items[index].valid ?? false,
      ),
    );
  }

  ListView listViewMissing(List<String> items) {
    return ListView.builder(
      padding: const EdgeInsets.only(top: 0),
      physics: const NeverScrollableScrollPhysics(),
      itemCount: items.length,
      shrinkWrap: true,
      itemBuilder: (context, index) => DocumentItem(
        title: items[index],
        subtitle: 'Missing',
        isMissing: true,
        iconLeading: Icons.file_copy,
        iconTrailing: Icons.arrow_forward_ios,
        valid: false,
      ),
    );
  }
}
