import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../common/theme.dart';
import '../controllers/documents_controller.dart';

class CreateDocumentScreen extends GetView<DocumentsController> {
  const CreateDocumentScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: KaliColors.primaryColor,
        title: Text('Create Document'.tr),
      ),
      // Form to create a document
      body: SingleChildScrollView(
        child: Center(
          child: Form(
            key: controller.formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(height: Get.height * 0.05),

                // Image
                Image.asset(
                  'assets/icons/upload-file.png',
                  width: Get.width * 0.4,
                ),
                const SizedBox(height: 20),
                // Document type
                SizedBox(
                  width: Get.width * 0.8,
                  child: DropdownButtonFormField<String>(
                    icon: const Icon(Icons.arrow_drop_down_circle_outlined),
                    decoration: InputDecoration(
                      helperText: 'Select the type of document'.tr,
                      helperStyle: const TextStyle(
                        color: Colors.black54,
                      ),
                      labelText: 'Document Type'.tr,
                      labelStyle: const TextStyle(
                        color: Colors.black54,
                      ),
                      border: const OutlineInputBorder(),
                    ),
                    value: controller.selectedTypeValue,
                    onChanged: (String? newValue) {
                      controller.setSelectedType(newValue!);
                    },
                    items: controller.types.map((dynamic type) {
                      return DropdownMenuItem<String>(
                        value: type['value'],
                        child: Text(
                          type['type'],
                          style: const TextStyle(
                            fontSize: 16,
                            color: Colors.black,
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),
                SizedBox(height: Get.height * 0.05),
                // File picker
                SizedBox(
                  width: Get.width * 0.8,
                  height: 40,
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      foregroundColor: KaliColors.primaryColor,
                      side: const BorderSide(
                        color: KaliColors.primaryColor,
                      ),
                    ),
                    onPressed: () {
                      controller.pickFile();
                    },
                    child: const Text('Selecciona un archivo'),
                  ),
                ),

                // Rounded circle if file is selected
                Obx(
                  () => controller.isFileSelected.value
                      ? const Padding(
                          padding: EdgeInsets.only(top: 20),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.check_circle,
                                color: KaliColors.primaryColor,
                              ),
                              SizedBox(width: 10),
                              Text(
                                'Archivo seleccionado',
                                style: TextStyle(
                                  color: KaliColors.primaryColor,
                                ),
                              ),
                            ],
                          ),
                        )
                      : const SizedBox(),
                ),
                SizedBox(height: Get.height * 0.2),
                // Submit button if file is selected and type is selected
                Obx(
                  () => controller.isFileSelected.value
                      ? SizedBox(
                          width: Get.width * 0.8,
                          height: 40,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: KaliColors.primaryColor,
                            ),
                            onPressed: () {
                              controller.createDocument();
                            },
                            child: controller.isUploading.value
                                ? const SizedBox(
                                    height: 20,
                                    width: 20,
                                    child: CircularProgressIndicator(
                                      color: Colors.white,
                                    ),
                                  )
                                : const Text(
                                    'Enviar',
                                    style: TextStyle(
                                      color: Colors.white,
                                    ),
                                  ),
                          ),
                        )
                      : SizedBox(
                          child: Text(
                            'Please select a file'.tr,
                            style: const TextStyle(
                              color: Colors.grey,
                              fontSize: 16,
                            ),
                          ),
                        ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
