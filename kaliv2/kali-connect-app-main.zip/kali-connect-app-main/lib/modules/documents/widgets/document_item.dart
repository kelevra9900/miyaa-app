import 'package:flutter/material.dart';
import 'package:get/get.dart';

class DocumentItem extends StatelessWidget {
  const DocumentItem({
    super.key,
    required this.title,
    required this.subtitle,
    required this.iconLeading,
    required this.iconTrailing,
    required this.valid,
    this.isMissing = false,
  });

  final String title;
  final String subtitle;
  final IconData iconLeading;
  final IconData iconTrailing;
  final bool valid;
  final bool isMissing;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(
        title.tr,
        style: const TextStyle(
          fontWeight: FontWeight.bold,
          color: Colors.black,
        ),
      ),
      subtitle: !isMissing
          ? Text(
              valid
                  ? 'Archivo verificado'
                  : 'El archivo no ha sido verificado'.tr,
              style: const TextStyle(
                color: Colors.black45,
              ),
            )
          : const Text(
              'Falta este documento',
              style: TextStyle(
                color: Colors.red,
              ),
            ),
      trailing: valid
          ? const Icon(
              Icons.check_circle,
              color: Colors.green,
            )
          : const Icon(
              Icons.error,
              color: Colors.red,
            ),
    );
  }
}
