import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../common/theme.dart';

class HeaderDocumentView extends StatelessWidget {
  const HeaderDocumentView({
    super.key,
    required this.title,
  });

  final String title;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: Get.height * 0.1,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            KaliColors.primaryColor,
            KaliColors.secondaryColor,
          ],
        ),
      ),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: Get.height * 0.05,
          ),
          const Text(
            'Hola!',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            title,
            style: TextStyle(
              fontSize: Get.width * 0.08,
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 10),
          Text(
            'Maneja tus documentos de manera fácil y segura.',
            style: TextStyle(
              fontSize: Get.width * 0.04,
              color: Colors.white,
            ),
          ),
          // Scroll to the right
          // Fix overflow bottom
        ],
      ),
    );
  }
}
