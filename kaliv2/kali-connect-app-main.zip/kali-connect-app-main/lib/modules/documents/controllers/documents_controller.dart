import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../models/documents_model.dart';
import '../../../repositories/documents_repository.dart';
import '../../../utils/ui.dart';

class DocumentsController extends GetxController {
  late Rx<MyDocuments> documents;
  late DocumentsRepository _documentsRepository;
  // If file is selected
  Rx<bool> isFileSelected = false.obs;
  Rx<bool> isUploading = false.obs;
  Rx<String> selectedType = 'EMPLOYMENT_CONTRACT'.obs;
  String? get selectedTypeValue => selectedType.value;

  File? file;

  // formKey
  final formKey = GlobalKey<FormState>();
  final List<dynamic> types = [
    {'type': 'Employment contract'.tr, 'value': 'EMPLOYMENT_CONTRACT'},
    {'type': 'Official ID'.tr, 'value'.tr: 'OFFICIAL_IDENTIFICATION'},
    {'type': 'Criminal Record'.tr, 'value': 'CRIMINAL_RECORD_LETTER'},
    {'type': 'Medical Exam', 'value'.tr: 'MEDICAL_EXAMINATION'},
    {'type': 'Psychological Cert'.tr, 'value': 'PSYCHOLOGICAL_FIT_CERTIFICATE'},
    {'type': 'Trust Exam', 'value'.tr: 'TRUST_EXAM'},
    {'type': 'Toxicological Exam'.tr, 'value': 'TOXICOLOGICAL_EXAM'},
    {'type': 'AVSEC Cert'.tr, 'value': 'AVSEC_TRAINING_CERTIFICATE'},
    {'type': 'AFAC Cert'.tr, 'value': 'AFAC_CERTIFICATION'},
    {
      'type': 'Security Training Record'.tr,
      'value': 'SECURITY_TRAINING_RECORD'
    },
  ];

  DocumentsController() {
    _documentsRepository = DocumentsRepository();
  }

  void setSelectedType(String newValue) {
    selectedType.value = newValue;
    update(); // Llama a este método para actualizar la UI si es necesario
  }

  Stream<MyDocuments> getDocuments() {
    return _documentsRepository.getDocuments();
  }

  //Pick file, use file_picker package
  void pickFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf', 'doc', 'docx'],
    );

    if (result != null) {
      file = File(result.files.single.path!);
      isFileSelected.value = true;
      update();
    } else {
      Get.snackbar('Error', 'No file selected');
    }
  }

  // Create document
  void createDocument() {
    if (formKey.currentState!.validate()) {
      isUploading.value = true;
      var data = CreateDocumentModel(documentType: selectedTypeValue!);
      _documentsRepository.createDocument(data, file).then((response) {
        Get.snackbar(
          'Success',
          'Document created',
          snackPosition: SnackPosition.TOP,
          backgroundColor: Colors.green,
          colorText: Colors.white,
        );
        reloadDocuments();

        Future.delayed(const Duration(seconds: 2), () {
          Get.back();
        });
      }).catchError((e) {
        Ui.errorSnackBar(message: 'Error creating document');
      }).whenComplete(() {
        isUploading.value = false;
        formKey.currentState!.reset();
        file = null;
        isFileSelected.value = false;
      });
    }
  }

  void reloadDocuments() {
    documents.bindStream(_documentsRepository.getDocuments());
  }
}
