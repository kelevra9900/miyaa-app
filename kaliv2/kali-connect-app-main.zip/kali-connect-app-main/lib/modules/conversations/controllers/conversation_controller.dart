import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../models/chat_model.dart';
import '../../../repositories/conversations_repository.dart';
import '../../../services/auth_service.dart';

class ConversationsController extends GetxController {
  final uploading = false.obs;
  final page = 1.obs;
  var message = ''.obs;
  List<Messages> messages = <Messages>[].obs;
  // messagesStream
  var idConversation = 0.obs;
  var recipientId = 0.obs;
  late ConversationsRepository _conversationsRepository;
  final isLoading = true.obs;
  final isDone = false.obs;
  ScrollController scrollController = ScrollController();
  final chatTextController = TextEditingController();

  final _messagesStreamController = StreamController<List<Messages>>();

  Stream<List<Messages>> get messagesStream => _messagesStreamController.stream;

  ConversationsController() {
    _conversationsRepository = ConversationsRepository();
  }

  @override
  void onInit() async {
    await listenForMessages();
    scrollController.addListener(() async {
      if (scrollController.position.pixels ==
              scrollController.position.maxScrollExtent &&
          !isDone.value) {
        await listenForMessages();
      }
    });
    super.onInit();
  }

  @override
  void onClose() {
    chatTextController.dispose();
    _messagesStreamController.close();
  }

  Future createMessage(String msg) async {
    message.value = msg;
    await _conversationsRepository.sendMessage(
      message: msg,
    );

    // After sending a message, update the stream
    await listenForMessages();
  }

  Future listenForMessages() async {
    isLoading.value = true;
    isDone.value = false;
    var userId = Get.find<AuthService>().user.value;
    var userMessages = await _conversationsRepository.getConversations(
      page: page.value,
      userId: int.parse(
        userId.id.toString(),
      ),
    );
    if (userMessages.success!) {
      if (userMessages.messages!.isNotEmpty) {
        messages.clear();
        messages.addAll(userMessages.messages!);
        page.value++;
        // Add the messages to the stream
        _messagesStreamController.add(messages.reversed.toList());
      }
      if (userMessages.conversationId != null) {
        idConversation.value = userMessages.conversationId!;
        recipientId.value = userMessages.recipient!;
      }
      messages = messages.reversed.toList();
      page.value = 1;
      isLoading.value = false;
      isDone.value = true;
    } else {
      isLoading.value = false;
      isDone.value = true;
    }
  }

  listenForChats() async {
    listenForMessages();
  }
}
