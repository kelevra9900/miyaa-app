import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../../services/auth_service.dart';

class ConversationItem extends StatelessWidget {
  final dynamic message;
  final Animation<double> animation;

  const ConversationItem({
    super.key,
    required this.message,
    required this.animation,
  });

  @override
  Widget build(BuildContext context) {
    final bool isMe =
        message.idUsuario == Get.find<AuthService>().user.value.id;
    return SizeTransition(
      sizeFactor: animation,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 5),
            child: Row(
              mainAxisAlignment:
                  isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
              children: [
                if (!isMe)
                  const Padding(
                    padding: EdgeInsets.only(right: 10),
                    child: CircleAvatar(
                      backgroundImage: AssetImage('assets/logo/logo.png'),
                      backgroundColor: Colors.white,
                      radius: 27,
                    ),
                  ),
                Container(
                  constraints: BoxConstraints(
                    maxWidth: Get.width * 0.7,
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 15,
                  ),
                  decoration: BoxDecoration(
                    color: isMe
                        ? Get.theme.colorScheme.secondary
                        : Get.theme.colorScheme.secondaryContainer,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    message.mensaje ?? '',
                    style: Get.textTheme.bodyLarge!.copyWith(
                      color: isMe
                          ? Get.theme.colorScheme.onSecondary
                          : Get.theme.colorScheme.onSecondary,
                    ),
                  ),
                ),
                if (isMe)
                  const Padding(
                    padding: EdgeInsets.only(left: 10),
                    child: CircleAvatar(
                      backgroundImage: AssetImage('assets/logo/logo.png'),
                      backgroundColor: Colors.white,
                      radius: 27,
                    ),
                  ),
              ],
            ),
          ),
          Text(
            DateFormat('d MMMM y | HH:mm ', Get.locale.toString())
                .format(message.hora ?? DateTime.now()),
            overflow: TextOverflow.fade,
            softWrap: false,
            style: Get.textTheme.bodySmall,
          ),
          const SizedBox(height: 10),
        ],
      ),
    );
  }
}
