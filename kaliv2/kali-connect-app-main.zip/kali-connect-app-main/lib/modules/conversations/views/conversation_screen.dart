import 'package:chat_bubbles/chat_bubbles.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../common/circular_loading_widget.dart';
import '../../../common/theme.dart';
import '../../../models/chat_model.dart';
import '../../../services/auth_service.dart';
import '../controllers/conversation_controller.dart';

class ConversationsScreen extends GetView<ConversationsController> {
  final _myListKey = GlobalKey<AnimatedListState>();

  ConversationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(
            Icons.chevron_left,
            color: KaliColors.textMainColor,
            size: 30,
          ),
          onPressed: () {
            Get.back();
          },
        ),
        title: Text(
          'Chat'.tr,
          style: const TextStyle(
            color: KaliColors.textMainColor,
          ),
        ),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<List<Messages>>(
              stream: controller.messagesStream,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const CircularLoadingWidget(
                    height: 200,
                    onCompleteText: '',
                  );
                } else if (snapshot.hasError) {
                  return const Text('Error loading messages');
                } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return const Text('No messages available.');
                } else {
                  final messages = snapshot.data!;
                  return AnimatedList(
                    key: _myListKey,
                    reverse: true,
                    physics: const AlwaysScrollableScrollPhysics(),
                    initialItemCount: messages.length,
                    itemBuilder: (context, index, animation) {
                      return SizeTransition(
                        sizeFactor: animation,
                        child: Column(
                          children: [
                            BubbleNormal(
                              tail: true,
                              color: messages[index].sender?.id ==
                                      Get.find<AuthService>().user.value.id
                                  ? KaliColors.darkTertiaryColor
                                  : KaliColors.primaryColor,
                              text: messages[index].content ?? 'empty',
                              textStyle: const TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                              ),
                              isSender: messages[index].sender?.id ==
                                  Get.find<AuthService>().user.value.id,
                              seen: messages[index].seen ?? false,
                              delivered: true,
                            ),
                            // Get the date of the message
                          ],
                        ),
                      );
                    },
                  );
                }
              },
            ),
          ),
          SafeArea(
            child: MessageBar(
              messageBarColor: Colors.white,
              sendButtonColor: KaliColors.primaryColor,
              actions: [
                InkWell(
                  child: const Icon(
                    Icons.add,
                    color: Colors.black,
                    size: 24,
                  ),
                  onTap: () {},
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 8, right: 8),
                  child: InkWell(
                    child: const Icon(
                      Icons.camera_alt,
                      color: KaliColors.primaryColor,
                      size: 24,
                    ),
                    onTap: () {},
                  ),
                ),
              ],
              onSend: (text) => {
                controller.createMessage(text),
              },
            ),
          ),
        ],
      ),
    );
  }
}
