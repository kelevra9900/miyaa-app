import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:miyaa/models/rounds_model.dart';
import 'package:nfc_manager/nfc_manager.dart';

import '../../../repositories/vigilance_repository.dart';

class NFCWriteController extends GetxController {
  final nameController = TextEditingController();
  final latitudeController = TextEditingController();
  final longitudeController = TextEditingController();
  late VigilanceRepository _vigilanceRepository;
  RxList<Rounds> rounds = <Rounds>[].obs;
  RxInt page = 1.obs;
  RxInt limit = 10.obs;

  // selectedRound
  Rx<Rounds> selectedRound = Rounds().obs;
  RxBool isWriting = false.obs;
  RxBool isNFCEnabled = false.obs;
  RxBool isNFCLocked = false.obs;
  ValueNotifier<dynamic> result = ValueNotifier(null);

  @override
  void onInit() {
    super.onInit();
    _vigilanceRepository = VigilanceRepository();
    checkNFCStatus();
  }

  @override
  void onClose() {
    nameController.dispose();
    latitudeController.dispose();
    longitudeController.dispose();
    super.onClose();
  }

  void checkNFCStatus() async {
    final bool isAvailable = await NfcManager.instance.isAvailable();
    isNFCEnabled.value = isAvailable;
  }

  void writeNFC() async {
    Map<String, dynamic> json = {
      'id': selectedRound.value.id,
      'roundId': selectedRound.value.id,
      'name': nameController.text,
      'latitude': latitudeController.text,
      'longitude': longitudeController.text,
    };

    String jsonString = jsonEncode(json);

    isWriting.value = true;
    NfcManager.instance.startSession(onDiscovered: (NfcTag tag) async {
      var ndef = Ndef.from(tag);
      if (ndef == null) {
        result.value = 'Tag is not NDEF compatible';
        NfcManager.instance.stopSession(errorMessage: result.value);
        Get.snackbar(
          'NFC Tag',
          result.value,
          snackPosition: SnackPosition.BOTTOM,
          colorText: Colors.white,
          backgroundColor: Colors.red,
        );
        return;
      }

      if (!ndef.isWritable) {
        result.value = 'Tag is not writable';
        NfcManager.instance.stopSession(errorMessage: result.value);
        Get.snackbar(
          'NFC Tag',
          result.value,
          snackPosition: SnackPosition.BOTTOM,
          colorText: Colors.white,
          backgroundColor: Colors.red,
        );
        return;
      }

      NdefMessage message = NdefMessage([
        NdefRecord.createMime(
            'application/json', Uint8List.fromList(jsonString.codeUnits)),
      ]);

      try {
        await ndef.write(message);
        result.value = 'Success to write NDEF';
        NfcManager.instance
            .stopSession(alertMessage: 'Información escrita con éxito');
        Get.snackbar(
          'NFC Tag',
          'Información escrita con éxito',
          snackPosition: SnackPosition.BOTTOM,
          colorText: Colors.white,
          backgroundColor: Colors.green,
        );
      } catch (e) {
        result.value = e.toString();
        NfcManager.instance.stopSession(errorMessage: result.value);
        Get.snackbar(
          'NFC Tag',
          'Error al escribir en la etiqueta',
          snackPosition: SnackPosition.BOTTOM,
          colorText: Colors.white,
          backgroundColor: Colors.red,
        );
      } finally {
        isWriting.value = false;
      }
    });
  }

  Stream<RoundsResponse> getRounds() {
    rounds.clear();
    var response = _vigilanceRepository.getAllRounds(page.value, limit.value);
    response.listen((event) {
      rounds.addAll(event.data);
    });
    return _vigilanceRepository.getAllRounds(page.value, limit.value);
  }
}
