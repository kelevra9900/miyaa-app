import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../../../services/settings_service.dart';

class ProfileController extends GetxController {
  final selectedThemeMode = ThemeMode.light.obs;
  RxBool lightMode = true.obs;
  GetStorage? _box;

  ProfileController() {
    _box = GetStorage();
  }

  void toggle() => lightMode.value = !lightMode.value;

  @override
  void onInit() {
    initTheme();
    super.onInit();
  }

  void initTheme() {
    String? themeMode = _box!.read<String>('theme_mode');
    switch (themeMode) {
      case 'ThemeMode.light':
        selectedThemeMode.value = ThemeMode.light;
        break;
      case 'ThemeMode.dark':
        selectedThemeMode.value = ThemeMode.dark;
        break;
      case 'ThemeMode.system':
        selectedThemeMode.value = ThemeMode.system;
        break;
      default:
        selectedThemeMode.value = ThemeMode.system;
    }
  }

  void changeThemeMode(ThemeMode themeMode) {
    Get.changeThemeMode(themeMode);
    selectedThemeMode.value = themeMode;
    if (themeMode == ThemeMode.dark) {
      Get.rootController.setTheme(Get.find<SettingsService>().getDarkTheme());
      lightMode(true);
    } else {
      lightMode(false);
      Get.rootController.setTheme(Get.find<SettingsService>().getLightTheme());
    }
    _box!.write('theme_mode', themeMode.toString());
    Get.rootController.refresh();
  }
}
