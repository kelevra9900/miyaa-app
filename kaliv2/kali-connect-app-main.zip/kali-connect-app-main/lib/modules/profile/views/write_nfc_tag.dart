import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:miyaa/common/block_button.dart';
import 'package:miyaa/common/input_widget.dart';
import 'package:miyaa/common/theme.dart';
import 'package:miyaa/models/rounds_model.dart';

import '../controllers/nfc_write_controller.dart';

class WriteNFCTag extends GetView<NFCWriteController> {
  const WriteNFCTag({super.key});

  @override
  Widget build(BuildContext context) {
    final GlobalKey<FormState> formKey = GlobalKey<FormState>();

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Punto de control NFC',
          style: TextStyle(
            color: Colors.black,
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          color: Colors.black,
          onPressed: () => Get.back(),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Image.asset(
                  'assets/icons/nfc.png',
                  width: 120,
                ),
                const SizedBox(height: 16),
                Obx(
                  () => controller.isNFCEnabled.value
                      ? const Text('NFC is enabled')
                      : const Text(
                          'NFC is disabled',
                          style: TextStyle(color: Colors.red, fontSize: 16),
                        ),
                ),
                const SizedBox(height: 16),
                StreamBuilder(
                  stream: controller.getRounds(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const CircularProgressIndicator();
                    }
                    return _buildDropdown();
                  },
                ),
                const SizedBox(height: 16),
                _buildInputWidget(
                  controller.nameController,
                  'Nombre del lugar',
                ),
                const SizedBox(height: 16),
                _buildInputWidget(
                  controller.latitudeController,
                  'Latitud',
                ),
                const SizedBox(height: 16),
                _buildInputWidget(
                  controller.longitudeController,
                  'Longitud',
                ),
                const SizedBox(height: 16),
                Obx(
                  () => CheckboxListTile(
                    title: const Text('Bloquear NFC después de escribir'),
                    activeColor: KaliColors.primaryColor,
                    dense: true,
                    side: const BorderSide(color: Colors.black),
                    value: controller.isNFCLocked.value,
                    onChanged: (value) => controller.isNFCLocked.value = value!,
                  ),
                ),
                const SizedBox(height: 16),
                BlockButtonWidget(
                  color: KaliColors.primaryColor,
                  text: const Text(
                    'Inicia la escritura en la etiqueta NFC',
                    style: TextStyle(color: Colors.white),
                  ),
                  onPressed: () {
                    if (formKey.currentState!.validate()) {
                      if (controller.isNFCEnabled.value) {
                        controller.writeNFC();
                      } else {
                        Get.snackbar(
                          'NFC is disabled',
                          'Please enable NFC to write the tag',
                          snackPosition: SnackPosition.BOTTOM,
                        );
                      }
                    }
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInputWidget(
    TextEditingController controller,
    String labelText,
  ) {
    return InputWidget(
      controller: controller,
      labelText: labelText,
      hintText: labelText,
      validator: (value) {
        if (value!.isEmpty) {
          return 'Por favor ingrese $labelText';
        }
        return null;
      },
    );
  }

  // Dropdown with Rounds and Checkpoints
  Widget _buildDropdown() {
    return Obx(
      () => DropdownButtonFormField<Rounds>(
        value: controller.rounds.isNotEmpty ? controller.rounds[0] : null,
        items: controller.rounds
            .map(
              (round) => DropdownMenuItem<Rounds>(
                value: round,
                child: Text(
                  round.name ?? '',
                  style: const TextStyle(
                    color: Colors.black,
                  ),
                ),
              ),
            )
            .toList(),
        onChanged: (value) {
          controller.selectedRound.value = value!;
        },
        decoration: InputDecoration(
          labelText: 'Selecciona la ronda',
          labelStyle: const TextStyle(
            color: Colors.black,
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ),
    );
  }
}
