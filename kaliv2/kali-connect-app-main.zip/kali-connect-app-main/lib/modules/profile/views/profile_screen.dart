import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../common/theme.dart';
import '../../../routes/app_routes.dart';
import '../../../services/auth_service.dart';
import '../../../utils/ui.dart';
import '../controllers/profile_controller.dart';
import '../widgets/account_link_widget.dart';

class ProfileScreen extends GetView<ProfileController> {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: SizedBox(
          child: Image.asset(
            'assets/logo/logo.png',
            height: 70,
          ),
        ),
        centerTitle: true,
        backgroundColor: KaliColors.primaryColor,
        automaticallyImplyLeading: false,
        elevation: 0,
      ),
      body: ListView(
        primary: true,
        children: [
          Stack(
            alignment: AlignmentDirectional.bottomCenter,
            children: [
              Container(
                height: 180,
                width: Get.width,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      KaliColors.primaryColor,
                      KaliColors.secondaryColor,
                    ],
                  ),
                  borderRadius:
                      const BorderRadius.vertical(bottom: Radius.circular(60)),
                  boxShadow: [
                    BoxShadow(
                      color: Get.theme.focusColor.withOpacity(0.2),
                      blurRadius: 10,
                      offset: const Offset(0, 5),
                    ),
                  ],
                ),
                margin: const EdgeInsets.only(bottom: 50),
                child: Padding(
                  padding: const EdgeInsets.all(15),
                  child: Column(
                    children: [
                      Text(
                        '${Get.find<AuthService>().user.value.firstName} ${Get.find<AuthService>().user.value.lastName}',
                        style: Get.textTheme.displaySmall?.merge(
                          const TextStyle(
                            color: Colors.white,
                            fontSize: 25,
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        Get.find<AuthService>().user.value.email ?? '',
                        style: Get.textTheme.bodySmall?.merge(
                          const TextStyle(color: Colors.white),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                decoration: Ui.getBoxDecoration(
                  radius: 14,
                  border: Border.all(
                    width: 2,
                    color: Colors.white,
                  ),
                ),
                child: ClipRRect(
                  borderRadius: const BorderRadius.all(Radius.circular(10)),
                  child: CachedNetworkImage(
                    height: 130,
                    width: 130,
                    fit: BoxFit.cover,
                    imageUrl: Get.find<AuthService>().user.value.image ??
                        'https://www.woolha.com/media/2020/03/eevee.png',
                    placeholder: (context, url) => Image.asset(
                      'assets/images/loading.gif',
                      fit: BoxFit.cover,
                      width: double.infinity,
                      height: 100,
                    ),
                    errorWidget: (context, url, error) =>
                        const Icon(Icons.error_outline),
                  ),
                ),
              ),
            ],
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
            margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
            decoration: Ui.getBoxDecoration(),
            child: Column(
              children: [
                AccountLinkWidget(
                  icon: Icon(Icons.document_scanner_outlined,
                      color: Get.theme.colorScheme.secondary),
                  text: Text(
                    'My Documents'.tr,
                    style: TextStyle(
                      color: Get.theme.colorScheme.secondary,
                    ),
                  ),
                  onTap: (e) {
                    Get.toNamed(Routes.documents);
                  },
                ),
                AccountLinkWidget(
                  icon: Icon(
                    Icons.nfc_outlined,
                    color: Get.theme.colorScheme.secondary,
                  ),
                  text: Text(
                    'Write NFC'.tr,
                    style: TextStyle(
                      color: Get.theme.colorScheme.secondary,
                    ),
                  ),
                  onTap: (e) {
                    Get.toNamed(Routes.writeNFCTag);
                  },
                ),
                AccountLinkWidget(
                  icon: Icon(
                    Icons.calendar_today_outlined,
                    color: Get.theme.colorScheme.secondary,
                  ),
                  text: Text(
                    'Attendances'.tr,
                    style: TextStyle(
                      color: Get.theme.colorScheme.secondary,
                    ),
                  ),
                  onTap: (e) {
                    Get.toNamed(Routes.attendances);
                  },
                ),
                AccountLinkWidget(
                  icon: Icon(Icons.translate_outlined,
                      color: Get.theme.colorScheme.secondary),
                  text: Text(
                    'Languages'.tr,
                    style: TextStyle(
                      color: Get.theme.colorScheme.secondary,
                    ),
                  ),
                  onTap: (e) {
                    Get.toNamed(Routes.languages);
                  },
                ),
                AccountLinkWidget(
                  icon: Icon(
                    Icons.logout,
                    color: Get.theme.colorScheme.secondary,
                  ),
                  text: Text(
                    'Logout'.tr,
                    style: TextStyle(
                      color: Get.theme.colorScheme.secondary,
                    ),
                  ),
                  onTap: (e) {
                    Get.find<AuthService>().logout();
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
