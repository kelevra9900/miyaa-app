import 'package:get/get.dart';
import 'package:miyaa/modules/profile/controllers/nfc_write_controller.dart';

class NFCBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<NFCWriteController>(() => NFCWriteController());
  }
}
