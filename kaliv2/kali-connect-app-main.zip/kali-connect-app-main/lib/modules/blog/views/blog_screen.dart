import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../providers/laravel_provider.dart';
import '../controllers/blog_controller.dart';
import '../widgets/blog_list_widget.dart';

class BlogScreen extends GetView<BlogController> {
  const BlogScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: RefreshIndicator(
        onRefresh: () async {
          if (!Get.find<LaravelApiClient>().isLoading(task: 'blogs')) {
            Get.find<LaravelApiClient>().forceRefresh();
            controller.refreshBlog(showMessage: true);
            Get.find<LaravelApiClient>().unForceRefresh();
          }
        },
        child: CustomScrollView(
          controller: controller.scrollController,
          physics: const AlwaysScrollableScrollPhysics(),
          shrinkWrap: false,
          slivers: const [
            SliverAppBar(
              expandedHeight: 10,
              elevation: 0.5,
              primary: true,
              floating: true,
              title: Text(
                'Blog',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 18,
                ),
              ),
              centerTitle: true,
              automaticallyImplyLeading: false,
            ),
            SliverToBoxAdapter(
              child: Wrap(
                children: [BlogListWidget()],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
