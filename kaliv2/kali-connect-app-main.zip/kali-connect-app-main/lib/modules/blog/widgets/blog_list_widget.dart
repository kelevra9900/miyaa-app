import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../providers/laravel_provider.dart';
import '../controllers/blog_controller.dart';
import 'blog_empty_list.dart';
import 'blog_list_item.dart';
import 'list_loader.dart';

class BlogListWidget extends GetView<BlogController> {
  const BlogListWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      if (Get.find<LaravelApiClient>().isLoading(task: 'blogs') &&
          controller.page.value == 1) {
        return const BlogListLoaderWidget();
      } else if (controller.blogs.value.notes?.isEmpty ?? true) {
        return const BlogEmptyListWidget();
      } else {
        return ListView.builder(
          padding: const EdgeInsets.only(bottom: 10, top: 10),
          primary: false,
          shrinkWrap: true,
          itemCount: controller.blogs.value.notes!.length + 1,
          itemBuilder: ((_, index) {
            if (index == controller.blogs.value.notes?.length) {
              return Obx(() {
                return Padding(
                  padding: const EdgeInsets.all(8.0),
                  // ignore: unnecessary_new
                  child: new Center(
                    child: Opacity(
                      opacity: controller.isLoading.value ? 1 : 0,
                      child: const CircularProgressIndicator(),
                    ),
                  ),
                );
              });
            } else {
              var data = controller.blogs.value.notes!.elementAt(index);
              return BlogListItemWidget(input: data);
            }
          }),
        );
      }
    });
  }
}
