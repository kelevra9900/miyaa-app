import 'dart:async';

import 'package:get/get.dart';

import '../../../utils/ui.dart';

class NoteController extends GetxController {
  late Timer timer;
  final heroTag = ''.obs;

  final note = dynamic.obs;

  @override
  void onInit() async {
    var arguments = Get.arguments as Map<String, dynamic>;
    note.value = arguments['note'];
    heroTag.value = arguments['heroTag'] as String;
    super.onInit();
  }

  Future<void> getNote() async {
    try {
      // note.value = await _blogRepository.getById(id: note.value.idNota!);
    } catch (e) {
      Get.showSnackbar(Ui.errorSnackBar(message: e.toString()));
    }
  }
}
