import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../models/blog_model.dart';
import '../../../repositories/blog_repository.dart';
import '../../../utils/ui.dart';

class BlogController extends GetxController {
  late BlogRepository _blogRepository;
  final blogs = BlogResponse().obs;

  final page = 1.obs;
  final isLoading = true.obs;
  final isDone = false.obs;

  ScrollController scrollController = ScrollController();

  BlogController() {
    _blogRepository = BlogRepository();
  }

  @override
  Future<void> onInit() async {
    // note.value = Get.arguments as BlogResponse;
    scrollController.addListener(() {
      if (scrollController.position.pixels ==
              scrollController.position.maxScrollExtent &&
          !isDone.value) {
        loadBlogs();
      }
    });
    await refreshBlog();
    super.onInit();
  }

  Future refreshBlog({bool? showMessage}) async {
    page.value = 1;
    await loadBlogs();
    if (showMessage == true) {
      Get.showSnackbar(
        Ui.SuccessSnackBar(
          message: 'List of blog refreshed successfully'.tr,
        ),
      );
    }
  }

  Future loadBlogs() async {
    try {
      isLoading.value = true;
      isDone.value = false;
      // await _blogRepository.getAll(page: page.value);
      blogs.value = await _blogRepository.getAll(page: page.value);
      page.value++;

      if (blogs.value.notes!.isEmpty) {
        isDone.value = true;
      }
    } catch (e) {
      isDone.value = true;
      Get.showSnackbar(Ui.errorSnackBar(message: e.toString()));
    } finally {
      isLoading.value = false;
    }
  }
}
