import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../common/circular_loading_widget.dart';
import 'notifications_controller.dart';
import 'widgets/message_notification_item_widget.dart';
import 'widgets/notification_item_widget.dart';

class NotificationsPage extends GetView<NotificationsController> {
  const NotificationsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Notifications',
          style: Get.textTheme.titleLarge,
        ),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
        automaticallyImplyLeading: false,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: Get.theme.hintColor),
          onPressed: () => {Get.back()},
        ),
      ),
      body: ListView(
        primary: true,
        children: [
          Text('Incoming Notifications'.tr, style: Get.textTheme.headlineSmall)
              .paddingOnly(top: 25, bottom: 0, right: 22, left: 22),
          Text('History description'.tr, style: Get.textTheme.bodySmall)
              .paddingSymmetric(horizontal: 22, vertical: 5),
          // notificationsList(),
        ],
      ),
    );
  }

  Widget notificationsList() {
    return Obx(() {
      if (!controller.notifications.isNotEmpty) {
        return CircularLoadingWidget(
          height: 300,
          onCompleteText: 'Notification List is Empty'.tr,
        );
      } else {
        var notifications = controller.notifications;
        return ListView.separated(
            itemCount: notifications.length,
            separatorBuilder: (context, index) {
              return const SizedBox(height: 7);
            },
            shrinkWrap: true,
            primary: false,
            itemBuilder: (context, index) {
              var notification = controller.notifications.elementAt(index);
              if (notification.data?['message_id'] != null) {
                return MessageNotificationItemWidget(
                    notification: notification);
              } else if (notification.data?['booking_id'] != null) {
                return const Text('booking');
                // return BookingNotificationItemWidget(notification: _notification);
              } else {
                return NotificationItemWidget(
                  notification: notification,
                  onDismissed: (notification) {
                    // controller.removeNotification(notification);
                  },
                  onTap: (notification) async {
                    // await controller.markAsReadNotification(notification);
                  },
                );
              }
            });
      }
    });
  }
}
