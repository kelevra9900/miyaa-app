import 'package:get/get.dart';

import '../../models/notification_model.dart';

class NotificationsController extends GetxController {
  final notifications = <NotificationModel>[].obs;

  NotificationsController();

  @override
  void onInit() {
    super.onInit();
    notifications.value = [];
  }
}
