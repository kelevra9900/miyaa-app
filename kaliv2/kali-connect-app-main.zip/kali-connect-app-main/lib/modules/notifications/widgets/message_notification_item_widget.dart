import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../models/notification_model.dart' as model;
import '../notifications_controller.dart';
import 'notification_item_widget.dart';

class MessageNotificationItemWidget extends GetView<NotificationsController> {
  const MessageNotificationItemWidget({super.key, this.notification});
  final model.NotificationModel? notification;

  @override
  Widget build(BuildContext context) {
    return NotificationItemWidget(
      notification: notification,
      onDismissed: (notification) {
        // controller!.removeNotification(notification);
      },
      icon: Icon(
        Icons.chat_outlined,
        color: Get.theme.scaffoldBackgroundColor,
        size: 34,
      ),
      onTap: (notification) async {
        // Get.toNamed(Routes.home, arguments: new Message([], id: notification.data['message_id'].toString()));
        // await controller.markAsReadNotification(notification);
      },
    );
  }
}
