import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../common/theme.dart';
import '../../auth/widgets/block_button.dart';
import '../controllers/face_recognition_controller.dart';

class FaceRecognitionScreen extends GetView<FaceRecognitionController> {
  const FaceRecognitionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<FaceRecognitionController>(
      builder: (controller) {
        return Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            backgroundColor: Colors.white,
            leading: IconButton(
              icon: const Icon(
                Icons.chevron_left,
                color: KaliColors.textMainColor,
                size: 30,
              ),
              onPressed: () {
                Get.back();
              },
            ),
          ),
          body: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  Text(
                    'Face Recognition'.tr,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: KaliColors.textMainColor,
                    ),
                  ),
                  // Text description
                  const SizedBox(height: 10),
                  Text(
                    'This is the face recognition screen'.tr,
                    style: TextStyle(
                      fontSize: Get.width * 0.04,
                      fontWeight: FontWeight.w300,
                      color: KaliColors.textMainColor,
                    ),
                  ),
                  const SizedBox(height: 20),
                  Center(
                    child: SizedBox(
                      width: Get.width * 0.8,
                      height: Get.height * 0.4,
                      // made transparent to show the background
                      child: Image.asset(
                        'assets/icons/face_recognition.png',
                      ),
                    ),
                  ),
                  SizedBox(height: Get.height * 0.07),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Image.asset('assets/icons/smiley.png', width: 20),
                            const SizedBox(width: 10),
                            Text(
                              'Uncovered face'.tr,
                              style: TextStyle(
                                fontSize: Get.width * 0.04,
                                color: Colors.black,
                              ),
                            ),
                            SizedBox(width: Get.width * 0.1),
                            Image.asset('assets/icons/daylight.png', width: 20),
                            const SizedBox(width: 10),
                            Text(
                              'Good lighting'.tr,
                              style: TextStyle(
                                fontSize: Get.width * 0.04,
                                color: Colors.black,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                  SizedBox(height: Get.height * 0.05),
                  Obx(() => controller.loading.value
                      ? const Center(
                          child: CircularProgressIndicator(),
                        )
                      : RoundedBlockButtonWidget(
                          buttonText: 'Start face recognition'.tr,
                          width: Get.width * 0.8,
                          onpressed: () => {
                            controller.startFaceRecognition(),
                          },
                        )),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
