import 'dart:async';
import 'dart:io';

import 'package:dio/dio.dart' as dio;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart' as path_provider;

import '../../../models/auth_response_model.dart';
import '../../../providers/laravel_provider.dart';
import '../../../repositories/user_repository.dart';
import '../../../routes/app_routes.dart';
import '../../../services/auth_service.dart';
import '../../../utils/ui.dart';

class FaceRecognitionController extends GetxController {
  final LaravelApiClient laravelApiClient = LaravelApiClient();
  final Rx<ResLogin?> currentSession = Get.find<AuthService>().session;
  late UserRepository _userRepository;

  final ImagePicker picker = ImagePicker();
  late GetStorage box = GetStorage();

  late File imageFile;
  late RxBool loading = false.obs;

  FaceRecognitionController() {
    _userRepository = UserRepository();
  }

  void startFaceRecognition() {
    getImage();
  }

  Future<void> getImage() async {
    loading.value = true;
    try {
      final XFile? image = await picker.pickImage(
        source: ImageSource.camera,
      );
      if (image != null) {
        await processImage(image);
      } else {
        showImageErrorSnackbar('Para continuar, debes tomarte una foto');
      }
    } catch (error) {
      showImageErrorSnackbar('A ocurrido un error: $error');
    } finally {
      loading.value = false;
    }
  }

  Future<void> processImage(XFile image) async {
    imageFile = File(image.path);
    final name = DateTime.now().millisecondsSinceEpoch;

    final dir = await path_provider.getTemporaryDirectory();
    final targetPath = '${dir.absolute.path}/$name.jpg';

    await imageFile.copy(targetPath);
    imageFile = File(targetPath);

    try {
      currentSession.value = await uploadBiometric(imageFile.path);

      if (currentSession.value != null &&
          currentSession.value!.jwt!.isNotEmpty) {
        await _userRepository.profile();
        box.write('token', currentSession.value!.jwt);
        Get.offAllNamed(Routes.root);
        showImageSuccessSnackbar('Éxito', 'Biometría registrada correctamente');
      } else {
        showImageErrorSnackbar('No se ha podido registrar la biometría');
      }
    } catch (e) {
      Get.showSnackbar(Ui.errorSnackBar(message: e.toString()));
    } finally {
      loading.value = false;
    }
  }

  Future<ResLogin?> uploadBiometric(String filePath) async {
    try {
      final dio.FormData formData = dio.FormData.fromMap({
        'image': await dio.MultipartFile.fromFile(filePath,
            filename: '${DateTime.now().millisecondsSinceEpoch}.jpg'),
      });
      return await laravelApiClient.uploadBiometric(
          filePath: filePath, formData: formData, uri: '/auth/biometrics');
    } catch (e) {
      Get.log('Error uploading biometric $e');
      rethrow;
    }
  }

  void showImageErrorSnackbar(String message,
      {Color backgroundColor = Colors.red}) {
    Get.snackbar(
      'Error',
      message,
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: backgroundColor,
      colorText: Colors.white,
    );
  }

  void showImageSuccessSnackbar(String title, String message) {
    Get.snackbar(
      title,
      message,
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: Colors.green,
      colorText: Colors.white,
    );
  }
}
