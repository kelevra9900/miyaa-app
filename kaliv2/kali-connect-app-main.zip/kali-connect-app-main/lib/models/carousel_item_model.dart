import 'package:flutter/material.dart';

class Carousel {
  final String title;
  final String heroTag;
  final String srcIcon;
  final Color color1;
  final Color color2;
  IconData icon = Icons.chevron_right;

  Carousel(
    this.title,
    this.heroTag,
    this.srcIcon,
    this.color1,
    this.color2,
    this.icon,
  );
}
