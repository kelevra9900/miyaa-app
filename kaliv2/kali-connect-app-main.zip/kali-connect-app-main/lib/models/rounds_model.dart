import 'parents/pagination_model.dart';

class MyRounds {
  List<Rounds>? rounds;
  Shift? shift;

  MyRounds({this.rounds, this.shift});

  MyRounds.fromJson(Map<String, dynamic> json) {
    if (json['rounds'] != null) {
      rounds = <Rounds>[];
      json['rounds'].forEach((v) {
        rounds!.add(Rounds.fromJson(v));
      });
    }
    shift = json['shift'] != null ? Shift.fromJson(json['shift']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (rounds != null) {
      data['rounds'] = rounds!.map((v) => v.toJson()).toList();
    }
    if (shift != null) {
      data['shift'] = shift!.toJson();
    }
    return data;
  }
}

class Rounds {
  int? id;
  String? start;
  String? end;
  String? status;
  String? timestamp;
  String? name;
  List<Checkpoint>? checkpoint;

  Rounds(
      {this.id,
      this.start,
      this.end,
      this.status,
      this.timestamp,
      this.checkpoint});

  Rounds.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    start = json['start'];
    end = json['end'];
    status = json['status'];
    timestamp = json['timestamp'];
    name = json['name'];
    if (json['checkpoint'] != null) {
      checkpoint = <Checkpoint>[];
      json['checkpoint'].forEach((v) {
        checkpoint!.add(Checkpoint.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['start'] = start;
    data['end'] = end;
    data['status'] = status;
    data['timestamp'] = timestamp;
    data['name'] = name;
    if (checkpoint != null) {
      data['checkpoint'] = checkpoint!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Checkpoint {
  int? id;
  int? roundId;
  String? location;
  double? latitude;
  double? longitude;
  String? checkedAt;

  Checkpoint(
      {this.id,
      this.roundId,
      this.location,
      this.latitude,
      this.longitude,
      this.checkedAt});

  Checkpoint.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    roundId = json['roundId'];
    location = json['location'];
    latitude = json['latitude'] ?? 0.0;
    longitude = json['longitude'] ?? 0.0;
    checkedAt = json['checkedAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['roundId'] = roundId;
    data['location'] = location;
    data['latitude'] = latitude;
    data['longitude'] = longitude;
    data['checkedAt'] = checkedAt;
    return data;
  }
}

class Shift {
  int? id;
  String? name;
  String? start;
  String? end;
  String? createdAt;
  String? updatedAt;

  Shift(
      {this.id,
      this.name,
      this.start,
      this.end,
      this.createdAt,
      this.updatedAt});

  Shift.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    start = json['start'];
    end = json['end'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['start'] = start;
    data['end'] = end;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    return data;
  }
}

class RoundsResponse extends Pagination {
  List<Rounds> data;

  RoundsResponse({
    required this.data,
    required super.total,
    required super.totelPage,
    required super.currentPage,
    required super.perPage,
  });

  factory RoundsResponse.fromJson(Map<String, dynamic> json) {
    return RoundsResponse(
      data: List<Rounds>.from(json['data'].map((x) => Rounds.fromJson(x))),
      total: json['total'] ?? 0,
      totelPage: json['totalPage'] ?? 0,
      currentPage: json['currentPage'] ?? 0,
      perPage: json['perPage'] ?? 0,
    );
  }

  @override
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['data'] = this.data.map((v) => v.toJson()).toList();
    data['total'] = total;
    data['totalPage'] = totelPage;
    data['currentPage'] = currentPage;
    data['perPage'] = perPage;
    return data;
  }
}
