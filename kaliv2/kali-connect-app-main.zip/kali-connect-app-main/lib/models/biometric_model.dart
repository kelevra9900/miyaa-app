class BiometricRes {
  String? jwt;
  bool? matched;
  String? message;
  String? role;

  BiometricRes({this.jwt, this.matched, this.message, this.role});

  BiometricRes.fromJson(Map<String, dynamic> json) {
    jwt = json['jwt'] ?? '';
    matched = json['matched'] ?? false;
    message = json['message'] ?? '';
    role = json['role'] ?? '';
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['jwt'] = jwt;
    data['matched'] = matched;
    data['message'] = message;
    data['role'] = role;
    return data;
  }
}
