class Pagination {
  int total;
  int totelPage;
  int currentPage;
  int perPage;

  Pagination({
    required this.total,
    required this.totelPage,
    required this.currentPage,
    required this.perPage,
  });

  factory Pagination.fromJson(Map<String, dynamic> json) {
    return Pagination(
      total: json['total'],
      totelPage: json['totalPage'],
      currentPage: json['currentPage'],
      perPage: json['perPage'],
    );
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['total'] = total;
    data['totalPage'] = totelPage;
    data['currentPage'] = currentPage;
    data['perPage'] = perPage;
    return data;
  }
}
