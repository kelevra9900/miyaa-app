class AttendanceModel {
  int? id;
  String? checkIn;
  String? checkOut;

  AttendanceModel({this.id, this.checkIn, this.checkOut});

  AttendanceModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    checkIn = json['checkIn'];
    checkOut = json['checkOut'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['checkIn'] = checkIn;
    data['checkOut'] = checkOut;
    return data;
  }
}
