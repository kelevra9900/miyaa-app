import 'parents/model.dart';

class Colono extends Model {
  int? idColono;
  String? nombre;
  String? email;
  String? password;
  String? telefono;
  dynamic idEmpleadoActualizo;
  String? fechaActualizo;
  dynamic idAccion;
  String? foto;
  dynamic idUsuario;
  bool? activo;
  UsuarioByIdUsuario? usuarioByIdUsuario;
  DireccionByIdColono? direccionByIdColono;
  List<ComunicacionesByIdUsuario>? comunicacionesByIdUsuario;

  bool? auth;

  Colono(
      {this.idColono,
      this.nombre,
      this.email,
      this.password,
      this.telefono,
      this.idEmpleadoActualizo,
      this.fechaActualizo,
      this.idAccion,
      this.foto,
      this.idUsuario,
      this.activo,
      this.usuarioByIdUsuario,
      this.direccionByIdColono,
      this.comunicacionesByIdUsuario});

  Colono.fromJson(Map<String, dynamic> json) {
    idColono = json['idColono'];
    nombre = json['nombre'];
    email = json['email'];
    telefono = json['telefono'];
    idEmpleadoActualizo = json['idEmpleadoActualizo'];
    fechaActualizo = json['fechaActualizo'];
    idAccion = json['idAccion'];
    foto = json['foto'];
    idUsuario = json['idUsuario'];
    activo = json['activo'];
    auth = boolFromJson(json, 'auth');
    usuarioByIdUsuario = json['usuarioByIdUsuario'] != null
        ? UsuarioByIdUsuario.fromJson(json['usuarioByIdUsuario'])
        : null;
    direccionByIdColono = json['direccionByIdColono'] != null
        ? DireccionByIdColono.fromJson(json['direccionByIdColono'])
        : null;
    if (json['comunicacionesByIdUsuario'] != null) {
      comunicacionesByIdUsuario = <ComunicacionesByIdUsuario>[];
      json['comunicacionesByIdUsuario'].forEach((v) {
        comunicacionesByIdUsuario!.add(ComunicacionesByIdUsuario.fromJson(v));
      });
    }
  }

  @override
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idColono'] = idColono;
    data['nombre'] = nombre;
    data['email'] = email;
    data['telefono'] = telefono;
    data['idEmpleadoActualizo'] = idEmpleadoActualizo;
    data['fechaActualizo'] = fechaActualizo;
    data['idAccion'] = idAccion;
    data['foto'] = foto;
    data['idUsuario'] = idUsuario;
    data['activo'] = activo;
    if (usuarioByIdUsuario != null) {
      data['usuarioByIdUsuario'] = usuarioByIdUsuario!.toJson();
    }
    if (direccionByIdColono != null) {
      data['direccionByIdColono'] = direccionByIdColono!.toJson();
    }
    if (comunicacionesByIdUsuario != null) {
      data['comunicacionesByIdUsuario'] =
          comunicacionesByIdUsuario!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class UsuarioByIdUsuario {
  int? idUsuario;
  String? username;
  String? password;
  int? isActive;
  int? emailVerified;
  int? tokenExpired;
  dynamic perfiles;
  dynamic empleadoByIdUsuario;
  dynamic colonoByIdUsuario;

  UsuarioByIdUsuario(
      {this.idUsuario,
      this.username,
      this.password,
      this.isActive,
      this.emailVerified,
      this.tokenExpired,
      this.perfiles,
      this.empleadoByIdUsuario,
      this.colonoByIdUsuario});

  UsuarioByIdUsuario.fromJson(Map<String, dynamic> json) {
    idUsuario = json['idUsuario'];
    username = json['username'];
    password = json['password'];
    isActive = json['isActive'];
    emailVerified = json['emailVerified'];
    tokenExpired = json['tokenExpired'];
    perfiles = json['perfiles'];
    empleadoByIdUsuario = json['empleadoByIdUsuario'];
    colonoByIdUsuario = json['colonoByIdUsuario'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idUsuario'] = idUsuario;
    data['username'] = username;
    data['password'] = password;
    data['isActive'] = isActive;
    data['emailVerified'] = emailVerified;
    data['tokenExpired'] = tokenExpired;
    data['perfiles'] = perfiles;
    data['empleadoByIdUsuario'] = empleadoByIdUsuario;
    data['colonoByIdUsuario'] = colonoByIdUsuario;
    return data;
  }
}

class DireccionByIdColono {
  int? idDireccion;
  double? latitud;
  double? longitud;
  String? calle;
  String? colonia;
  String? ciudad;
  String? estado;
  String? cp;
  int? idColono;
  bool? activo;
  String? alias;
  String? referencia;

  DireccionByIdColono(
      {this.idDireccion,
      this.latitud,
      this.longitud,
      this.calle,
      this.colonia,
      this.ciudad,
      this.estado,
      this.cp,
      this.idColono,
      this.activo,
      this.alias,
      this.referencia});

  DireccionByIdColono.fromJson(Map<String, dynamic> json) {
    idDireccion = json['idDireccion'];
    latitud = json['latitud'];
    longitud = json['longitud'];
    calle = json['calle'];
    colonia = json['colonia'];
    ciudad = json['ciudad'];
    estado = json['estado'];
    cp = json['cp'];
    idColono = json['idColono'];
    activo = json['activo'];
    alias = json['alias'];
    referencia = json['referencia'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idDireccion'] = idDireccion;
    data['latitud'] = latitud;
    data['longitud'] = longitud;
    data['calle'] = calle;
    data['colonia'] = colonia;
    data['ciudad'] = ciudad;
    data['estado'] = estado;
    data['cp'] = cp;
    data['idColono'] = idColono;
    data['activo'] = activo;
    data['alias'] = alias;
    data['referencia'] = referencia;
    return data;
  }
}

class ComunicacionesByIdUsuario {
  int? idComunicacion;
  int? idUsuario;
  String? mensaje;
  String? hora;
  bool? vistoUsuario;
  bool? vistoOperador;
  int? idUsuarioRealizo;
  dynamic colonoByIdUduario;

  ComunicacionesByIdUsuario(
      {this.idComunicacion,
      this.idUsuario,
      this.mensaje,
      this.hora,
      this.vistoUsuario,
      this.vistoOperador,
      this.idUsuarioRealizo,
      this.colonoByIdUduario});

  ComunicacionesByIdUsuario.fromJson(Map<String, dynamic> json) {
    idComunicacion = json['idComunicacion'];
    idUsuario = json['idUsuario'];
    mensaje = json['mensaje'];
    hora = json['hora'];
    vistoUsuario = json['vistoUsuario'];
    vistoOperador = json['vistoOperador'];
    idUsuarioRealizo = json['idUsuarioRealizo'];
    colonoByIdUduario = json['colonoByIdUduario'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idComunicacion'] = idComunicacion;
    data['idUsuario'] = idUsuario;
    data['mensaje'] = mensaje;
    data['hora'] = hora;
    data['vistoUsuario'] = vistoUsuario;
    data['vistoOperador'] = vistoOperador;
    data['idUsuarioRealizo'] = idUsuarioRealizo;
    data['colonoByIdUduario'] = colonoByIdUduario;
    return data;
  }
}
