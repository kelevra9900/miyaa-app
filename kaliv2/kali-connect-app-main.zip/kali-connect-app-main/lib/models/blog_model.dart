class BlogResponse {
  List<Notes>? notes;
  int? total;
  int? totalPages;
  String? currentPage;
  String? perPage;

  BlogResponse(
      {this.notes,
      this.total,
      this.totalPages,
      this.currentPage,
      this.perPage});

  BlogResponse.fromJson(Map<String, dynamic> json) {
    if (json['notes'] != null) {
      notes = <Notes>[];
      json['notes'].forEach((v) {
        notes!.add(Notes.fromJson(v));
      });
    }
    total = json['total'];
    totalPages = json['totalPages'];
    currentPage = json['currentPage'];
    perPage = json['perPage'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (notes != null) {
      data['notes'] = notes!.map((v) => v.toJson()).toList();
    }
    data['total'] = total;
    data['totalPages'] = totalPages;
    data['currentPage'] = currentPage;
    data['perPage'] = perPage;
    return data;
  }
}

class Notes {
  int? id;
  String? image;
  String? content;
  String? title;
  String? createdAt;
  String? updatedAt;
  int? createdBy;
  bool? isApproved;
  String? slug;

  Notes(
      {this.id,
      this.image,
      this.content,
      this.title,
      this.createdAt,
      this.updatedAt,
      this.createdBy,
      this.isApproved,
      this.slug});

  Notes.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    image = json['image'];
    content = json['content'];
    title = json['title'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
    createdBy = json['createdBy'];
    isApproved = json['is_approved'];
    slug = json['slug'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['image'] = image;
    data['content'] = content;
    data['title'] = title;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['createdBy'] = createdBy;
    data['is_approved'] = isApproved;
    data['slug'] = slug;
    return data;
  }
}
