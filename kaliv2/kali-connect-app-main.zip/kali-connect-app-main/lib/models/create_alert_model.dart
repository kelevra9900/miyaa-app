import 'dart:convert';

CreateAlertModel createAlertModelFromJson(String str) =>
    CreateAlertModel.fromJson(json.decode(str));

String createAlertModelToJson(CreateAlertModel data) =>
    json.encode(data.toJson());

class CreateAlertModel {
  CreateAlertModel({
    this.latitude,
    this.longitude,
    this.userId,
    this.content,
    this.image,
  });

  double? latitude;
  double? longitude;
  int? userId;
  String? content;
  String? image;

  factory CreateAlertModel.fromJson(Map<String, dynamic> json) =>
      CreateAlertModel(
        latitude: json['latitude'] ?? 0,
        longitude: json['longitude'] ?? 0,
        userId: json['userId'] ?? 0,
        content: json['content'] ?? '',
        image: json['image'] ?? '',
      );

  Map<String, dynamic> toJson() => {
        'latitude': latitude ?? 0,
        'longitude': longitude ?? 0,
        'userId': userId ?? 0,
        'content': content ?? '',
        'image': image ?? '',
      };
}

class HistorialAlertaByIdAlerta {
  HistorialAlertaByIdAlerta({
    this.comentario,
  });

  String? comentario;

  factory HistorialAlertaByIdAlerta.fromJson(Map<String, dynamic> json) =>
      HistorialAlertaByIdAlerta(
        comentario: json['comentario'] ?? '',
      );

  Map<String, dynamic> toJson() => {
        'comentario': comentario ?? '',
      };
}

class HistorialCambioEstadoByIdAlerta {
  HistorialCambioEstadoByIdAlerta({
    this.idHistorialCambioEstadoAlerta,
  });

  dynamic idHistorialCambioEstadoAlerta;

  factory HistorialCambioEstadoByIdAlerta.fromJson(Map<String, dynamic> json) =>
      HistorialCambioEstadoByIdAlerta(
        idHistorialCambioEstadoAlerta: json['idHistorialCambioEstadoAlerta'],
      );

  Map<String, dynamic> toJson() => {
        'idHistorialCambioEstadoAlerta': idHistorialCambioEstadoAlerta,
      };
}
