import 'package:google_maps_flutter/google_maps_flutter.dart';

import 'parents/model.dart';

class Address extends Model {
  String? description;
  String? address;
  double? latitude;
  double? longitude;
  bool? isDefault;
  String? userId;

  Address({
    this.description,
    this.address,
    this.latitude,
    this.longitude,
    this.isDefault,
    this.userId,
  });

  Address.fromJson(Map<String, dynamic> json) {
    super.fromJson(json);
  }

  @override
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['description'] = description;
    data['address'] = address;
    data['latitude'] = latitude;
    data['longitude'] = longitude;
    data['isDefault'] = isDefault;
    data['userId'] = userId;
    return data;
  }

  bool isUnknown() {
    return latitude == null || longitude == null;
  }

  LatLng getLatLng() {
    if (isUnknown()) {
      return const LatLng(38.806103, 52.4964453);
    } else {
      return LatLng(latitude!, longitude!);
    }
  }
}
