class Conversation {
  dynamic data;
  bool success;

  Conversation({
    this.data,
    this.success = false,
  });

  factory Conversation.fromJson(Map<String, dynamic> json) {
    return Conversation(
      data: json['data'],
      success: json['success'],
    );
  }

  Map<String, dynamic> toJson() => {
        'data': data,
        'success': success,
      };

  @override
  String toString() {
    return 'Conversation(data: $data, success: $success)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is Conversation &&
        other.data == data &&
        other.success == success;
  }
}
