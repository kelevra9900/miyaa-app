class Setting {
  String? environment;
  String? oneSignalId;
  String? defaultTheme;
  String? mobielLanguage;

  Setting({
    this.environment,
    this.oneSignalId,
    this.defaultTheme,
    this.mobielLanguage,
  });

  Setting.fromJson(Map<String, dynamic> json) {
    environment = json['environment'];
    oneSignalId = json['oneSignalId'];
    defaultTheme = json['defaultTheme'];
    mobielLanguage = json['mobielLanguage'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['environment'] = environment;
    data['oneSignalId'] = oneSignalId;
    data['defaultTheme'] = defaultTheme;
    data['mobielLanguage'] = mobielLanguage;
    return data;
  }
}
