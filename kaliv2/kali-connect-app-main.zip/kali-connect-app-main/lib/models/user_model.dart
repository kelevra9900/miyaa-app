class User {
  int? id;
  int? shiftId;
  String? username;
  String? email;
  String? passwordHash;
  String? firstName;
  String? lastName;
  String? middleName;
  dynamic image;
  bool? emailVerified;
  dynamic birthDate;
  String? registrationDate;
  String? lastSeen;
  String? role;
  bool? banned;
  bool? online;
  dynamic oneSignalId;
  dynamic environmentId;

  User({
    this.id,
    this.username,
    this.email,
    this.passwordHash,
    this.firstName,
    this.lastName,
    this.middleName,
    this.image,
    this.emailVerified,
    this.birthDate,
    this.registrationDate,
    this.lastSeen,
    this.role,
    this.banned,
    this.online,
    this.oneSignalId,
    this.environmentId,
    this.shiftId,
  });

  bool? auth;

  User.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    username = json['username'];
    email = json['email'];
    // passwordHash = json['passwordHash'];
    firstName = json['firstName'];
    lastName = json['lastName'];
    middleName = json['middleName'];
    image = json['image'];
    emailVerified = json['emailVerified'];
    birthDate = json['birthDate'];
    role = json['role'];
    shiftId = json['shiftId'];

    if (json['registrationDate'] != null) {
      registrationDate = json['registrationDate'];
    }

    if (json['lastSeen'] != null) {
      lastSeen = json['lastSeen'];
    }

    role = json['role'];
    banned = json['banned'];
    online = json['online'];
    oneSignalId = json['oneSignalId'];
    environmentId = json['environmentId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id ?? 0;
    data['username'] = username;
    data['email'] = email;
    data['passwordHash'] = passwordHash;
    data['firstName'] = firstName;
    data['lastName'] = lastName;
    data['middleName'] = middleName;
    data['image'] = image;
    data['emailVerified'] = emailVerified;
    data['birthDate'] = birthDate;
    data['registrationDate'] = registrationDate;
    data['lastSeen'] = lastSeen;
    data['role'] = role;
    data['banned'] = banned;
    data['online'] = online;
    data['oneSignalId'] = oneSignalId;
    data['environmentId'] = environmentId;
    data['role'] = role;
    data['shiftId'] = shiftId;
    return data;
  }
}
