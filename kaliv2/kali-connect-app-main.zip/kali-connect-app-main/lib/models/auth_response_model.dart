class ResLogin {
  String? jwt;
  String? role;
  String? message;

  ResLogin({
    this.jwt,
    this.role,
    this.message,
  });

  ResLogin.fromJson(Map<String, dynamic> json) {
    jwt = json['jwt'] ?? '';
    role = json['role'] ?? '';
    message = json['message'] ?? '';
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['jwt'] = jwt;
    data['role'] = role;
    data['message'] = message;
    return data;
  }
}
