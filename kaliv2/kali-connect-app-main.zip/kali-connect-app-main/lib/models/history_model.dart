import 'package:google_maps_flutter/google_maps_flutter.dart';

class HistoryModel {
  int? idAlerta;
  double? latitud;
  double? longitud;
  String? fechaReporte;
  String? fechaAlerta;
  int? idUsuarioCreo;
  int? idEstado;
  String? imagen;
  List<HistorialAlertaByIdAlerta>? historialAlertaByIdAlerta;
  dynamic usuarioByIdUsuarioCreo;
  EstadoAlertaByIdEstado? estadoAlertaByIdEstado;
  dynamic historialCambioEstadoByIdAlerta;

  HistoryModel({
    this.idAlerta,
    this.latitud,
    this.longitud,
    this.fechaReporte,
    this.fechaAlerta,
    this.idUsuarioCreo,
    this.idEstado,
    this.imagen,
    this.historialAlertaByIdAlerta,
    this.usuarioByIdUsuarioCreo,
    this.estadoAlertaByIdEstado,
    this.historialCambioEstadoByIdAlerta,
  });

  HistoryModel.fromJson(Map<String, dynamic> json) {
    idAlerta = json['idAlerta'];
    latitud = json['latitud'];
    longitud = json['longitud'];
    fechaReporte = json['fechaReporte'];
    fechaAlerta = json['fechaAlerta'];
    idUsuarioCreo = json['idUsuarioCreo'];
    idEstado = json['idEstado'];
    imagen = json['imagen'];
    if (json['historialAlertaByIdAlerta'] != null) {
      historialAlertaByIdAlerta = <HistorialAlertaByIdAlerta>[];
      json['historialAlertaByIdAlerta'].forEach((v) {
        historialAlertaByIdAlerta!.add(HistorialAlertaByIdAlerta.fromJson(v));
      });
    }
    usuarioByIdUsuarioCreo = json['usuarioByIdUsuarioCreo'];
    estadoAlertaByIdEstado = json['estadoAlertaByIdEstado'] != null
        ? EstadoAlertaByIdEstado.fromJson(json['estadoAlertaByIdEstado'])
        : null;
    historialCambioEstadoByIdAlerta = json['historialCambioEstadoByIdAlerta'];
  }

  bool isUnknown() {
    return latitud == null || longitud == null;
  }

  LatLng getLatLng() {
    if (isUnknown()) {
      return const LatLng(38.806103, 52.4964453);
    } else {
      return LatLng(latitud!, longitud!);
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idAlerta'] = idAlerta;
    data['latitud'] = latitud;
    data['longitud'] = longitud;
    data['fechaReporte'] = fechaReporte;
    data['fechaAlerta'] = fechaAlerta;
    data['idUsuarioCreo'] = idUsuarioCreo;
    data['idEstado'] = idEstado;
    data['imagen'] = imagen;
    if (historialAlertaByIdAlerta != null) {
      data['historialAlertaByIdAlerta'] =
          historialAlertaByIdAlerta!.map((v) => v.toJson()).toList();
    }
    data['usuarioByIdUsuarioCreo'] = usuarioByIdUsuarioCreo;
    if (estadoAlertaByIdEstado != null) {
      data['estadoAlertaByIdEstado'] = estadoAlertaByIdEstado!.toJson();
    }
    data['historialCambioEstadoByIdAlerta'] = historialCambioEstadoByIdAlerta;
    return data;
  }
}

class HistorialAlertaByIdAlerta {
  int? idHistorialAlerta;
  int? idAlerta;
  String? comentario;
  bool? visible;
  int? idUsuarioCreo;
  String? fechaComentario;
  UsuarioByIdUsuario? usuarioByIdUsuario;

  HistorialAlertaByIdAlerta(
      {this.idHistorialAlerta,
      this.idAlerta,
      this.comentario,
      this.visible,
      this.idUsuarioCreo,
      this.fechaComentario,
      this.usuarioByIdUsuario});

  HistorialAlertaByIdAlerta.fromJson(Map<String, dynamic> json) {
    idHistorialAlerta = json['idHistorialAlerta'];
    idAlerta = json['idAlerta'];
    comentario = json['comentario'];
    visible = json['visible'];
    idUsuarioCreo = json['idUsuarioCreo'];
    fechaComentario = json['fechaComentario'];
    usuarioByIdUsuario = json['usuarioByIdUsuario'] != null
        ? UsuarioByIdUsuario.fromJson(json['usuarioByIdUsuario'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idHistorialAlerta'] = idHistorialAlerta;
    data['idAlerta'] = idAlerta;
    data['comentario'] = comentario;
    data['visible'] = visible;
    data['idUsuarioCreo'] = idUsuarioCreo;
    data['fechaComentario'] = fechaComentario;
    if (usuarioByIdUsuario != null) {
      data['usuarioByIdUsuario'] = usuarioByIdUsuario!.toJson();
    }
    return data;
  }
}

class UsuarioByIdUsuario {
  int? idUsuario;
  String? username;
  String? password;
  int? isActive;
  int? emailVerified;
  int? tokenExpired;
  dynamic perfiles;
  EmpleadoByIdUsuario? empleadoByIdUsuario;
  ColonoByIdUsuario? colonoByIdUsuario;

  UsuarioByIdUsuario(
      {this.idUsuario,
      this.username,
      this.password,
      this.isActive,
      this.emailVerified,
      this.tokenExpired,
      this.perfiles,
      this.empleadoByIdUsuario,
      this.colonoByIdUsuario});

  UsuarioByIdUsuario.fromJson(Map<String, dynamic> json) {
    idUsuario = json['idUsuario'];
    username = json['username'];
    password = json['password'];
    isActive = json['isActive'];
    emailVerified = json['emailVerified'];
    tokenExpired = json['tokenExpired'];
    perfiles = json['perfiles'];
    empleadoByIdUsuario = json['empleadoByIdUsuario'] != null
        ? EmpleadoByIdUsuario.fromJson(json['empleadoByIdUsuario'])
        : null;
    colonoByIdUsuario = json['colonoByIdUsuario'] != null
        ? ColonoByIdUsuario.fromJson(json['colonoByIdUsuario'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idUsuario'] = idUsuario;
    data['username'] = username;
    data['password'] = password;
    data['isActive'] = isActive;
    data['emailVerified'] = emailVerified;
    data['tokenExpired'] = tokenExpired;
    data['perfiles'] = perfiles;
    if (empleadoByIdUsuario != null) {
      data['empleadoByIdUsuario'] = empleadoByIdUsuario!.toJson();
    }
    if (colonoByIdUsuario != null) {
      data['colonoByIdUsuario'] = colonoByIdUsuario!.toJson();
    }
    return data;
  }
}

class EmpleadoByIdUsuario {
  int? idEmpleado;
  String? empleado;
  String? ife;
  String? fechaActualizo;
  bool? activo;
  dynamic foto;
  String? telefono;
  int? idEmpleadoActualizo;
  int? idAccion;
  int? idUsuario;
  String? puesto;
  int? contrato;
  dynamic usuariosByIdUsuario;
  dynamic perfiles;

  EmpleadoByIdUsuario(
      {this.idEmpleado,
      this.empleado,
      this.ife,
      this.fechaActualizo,
      this.activo,
      this.foto,
      this.telefono,
      this.idEmpleadoActualizo,
      this.idAccion,
      this.idUsuario,
      this.puesto,
      this.contrato,
      this.usuariosByIdUsuario,
      this.perfiles});

  EmpleadoByIdUsuario.fromJson(Map<String, dynamic> json) {
    idEmpleado = json['idEmpleado'];
    empleado = json['empleado'];
    ife = json['ife'];
    fechaActualizo = json['fechaActualizo'];
    activo = json['activo'];
    foto = json['foto'];
    telefono = json['telefono'];
    idEmpleadoActualizo = json['idEmpleadoActualizo'];
    idAccion = json['idAccion'];
    idUsuario = json['idUsuario'];
    puesto = json['puesto'];
    contrato = json['contrato'];
    usuariosByIdUsuario = json['usuariosByIdUsuario'];
    perfiles = json['perfiles'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idEmpleado'] = idEmpleado;
    data['empleado'] = empleado;
    data['ife'] = ife;
    data['fechaActualizo'] = fechaActualizo;
    data['activo'] = activo;
    data['foto'] = foto;
    data['telefono'] = telefono;
    data['idEmpleadoActualizo'] = idEmpleadoActualizo;
    data['idAccion'] = idAccion;
    data['idUsuario'] = idUsuario;
    data['puesto'] = puesto;
    data['contrato'] = contrato;
    data['usuariosByIdUsuario'] = usuariosByIdUsuario;
    data['perfiles'] = perfiles;
    return data;
  }
}

class ColonoByIdUsuario {
  int? idColono;
  String? nombre;
  String? email;
  String? telefono;
  int? idEmpleadoActualizo;
  String? fechaActualizo;
  int? idAccion;
  String? foto;
  int? idUsuario;
  bool? activo;
  dynamic usuarioByIdUsuario;
  DireccionByIdColono? direccionByIdColono;
  dynamic comunicacionesByIdUsuario;

  ColonoByIdUsuario(
      {this.idColono,
      this.nombre,
      this.email,
      this.telefono,
      this.idEmpleadoActualizo,
      this.fechaActualizo,
      this.idAccion,
      this.foto,
      this.idUsuario,
      this.activo,
      this.usuarioByIdUsuario,
      this.direccionByIdColono,
      this.comunicacionesByIdUsuario});

  ColonoByIdUsuario.fromJson(Map<String, dynamic> json) {
    idColono = json['idColono'];
    nombre = json['nombre'];
    email = json['email'];
    telefono = json['telefono'];
    idEmpleadoActualizo = json['idEmpleadoActualizo'];
    fechaActualizo = json['fechaActualizo'];
    idAccion = json['idAccion'];
    foto = json['foto'];
    idUsuario = json['idUsuario'];
    activo = json['activo'];
    usuarioByIdUsuario = json['usuarioByIdUsuario'];
    direccionByIdColono = json['direccionByIdColono'] != null
        ? DireccionByIdColono.fromJson(json['direccionByIdColono'])
        : null;
    comunicacionesByIdUsuario = json['comunicacionesByIdUsuario'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idColono'] = idColono;
    data['nombre'] = nombre;
    data['email'] = email;
    data['telefono'] = telefono;
    data['idEmpleadoActualizo'] = idEmpleadoActualizo;
    data['fechaActualizo'] = fechaActualizo;
    data['idAccion'] = idAccion;
    data['foto'] = foto;
    data['idUsuario'] = idUsuario;
    data['activo'] = activo;
    data['usuarioByIdUsuario'] = usuarioByIdUsuario;
    if (direccionByIdColono != null) {
      data['direccionByIdColono'] = direccionByIdColono!.toJson();
    }
    data['comunicacionesByIdUsuario'] = comunicacionesByIdUsuario;
    return data;
  }
}

class DireccionByIdColono {
  int? idDireccion;
  double? latitud;
  double? longitud;
  String? calle;
  String? colonia;
  String? ciudad;
  String? estado;
  String? cp;
  int? idColono;
  bool? activo;
  String? alias;
  String? referencia;

  DireccionByIdColono(
      {this.idDireccion,
      this.latitud,
      this.longitud,
      this.calle,
      this.colonia,
      this.ciudad,
      this.estado,
      this.cp,
      this.idColono,
      this.activo,
      this.alias,
      this.referencia});

  DireccionByIdColono.fromJson(Map<String, dynamic> json) {
    idDireccion = json['idDireccion'];
    latitud = json['latitud'];
    longitud = json['longitud'];
    calle = json['calle'];
    colonia = json['colonia'];
    ciudad = json['ciudad'];
    estado = json['estado'];
    cp = json['cp'];
    idColono = json['idColono'];
    activo = json['activo'];
    alias = json['alias'];
    referencia = json['referencia'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idDireccion'] = idDireccion;
    data['latitud'] = latitud;
    data['longitud'] = longitud;
    data['calle'] = calle;
    data['colonia'] = colonia;
    data['ciudad'] = ciudad;
    data['estado'] = estado;
    data['cp'] = cp;
    data['idColono'] = idColono;
    data['activo'] = activo;
    data['alias'] = alias;
    data['referencia'] = referencia;
    return data;
  }
}

class EstadoAlertaByIdEstado {
  int? idEstadoAlerta;
  String? estadoAlerta;

  EstadoAlertaByIdEstado({this.idEstadoAlerta, this.estadoAlerta});

  EstadoAlertaByIdEstado.fromJson(Map<String, dynamic> json) {
    idEstadoAlerta = json['idEstadoAlerta'];
    estadoAlerta = json['estadoAlerta'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idEstadoAlerta'] = idEstadoAlerta;
    data['estadoAlerta'] = estadoAlerta;
    return data;
  }
}
