class ChatResponse {
  bool? success;
  int? conversationId;
  int? recipient;
  List<Messages>? messages;

  ChatResponse({this.success, this.messages});

  ChatResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    conversationId = json['conversationId'];
    recipient = json['recipient'];
    if (json['messages'] != null) {
      messages = <Messages>[];
      json['messages'].forEach((v) {
        messages!.add(Messages.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    data['conversationId'] = conversationId;
    data['recipient'] = recipient;
    if (messages != null) {
      data['messages'] = messages!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Messages {
  int? id;
  int? conversationId;
  String? content;
  Sender? sender;
  bool? seen;

  Messages({this.id, this.content, this.sender});

  Messages.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    conversationId = json['conversationId'];
    content = json['content'];
    seen = json['isRead'];
    sender = json['sender'] != null ? Sender.fromJson(json['sender']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['conversationId'] = conversationId;
    data['content'] = content;
    data['isRead'] = seen;
    if (sender != null) {
      data['sender'] = sender!.toJson();
    }
    return data;
  }
}

class Sender {
  int? id;
  String? name;
  String? avatar;
  bool? active;

  Sender({this.name, this.avatar, this.active});

  Sender.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    avatar = json['avatar'];
    active = json['active'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['avatar'] = avatar;
    data['active'] = active;
    return data;
  }
}
