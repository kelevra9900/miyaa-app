class CreateDocumentModel {
  String documentType;

  CreateDocumentModel({
    required this.documentType,
  });

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['documentType'] = documentType;
    return data;
  }
}

class MyDocuments {
  String? message;
  Data? data;

  MyDocuments({this.message, this.data});

  MyDocuments.fromJson(Map<String, dynamic> json) {
    message = json['message'];
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['message'] = message;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  List<DocumentsModel>? uploaded;
  List<String>? missing;

  Data({this.uploaded, this.missing});

  Data.fromJson(Map<String, dynamic> json) {
    if (json['uploaded'] != null) {
      uploaded = <DocumentsModel>[];
      json['uploaded'].forEach((v) {
        uploaded!.add(DocumentsModel.fromJson(v));
      });
    }
    missing = json['missing'].cast<String>();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (uploaded != null) {
      data['uploaded'] = uploaded!.map((v) => v.toJson()).toList();
    }
    data['missing'] = missing;
    return data;
  }
}

class DocumentsModel {
  int id;
  String documentType;
  String filePath;
  bool? valid;
  String? issuedAt;
  // String? validUntil;

  DocumentsModel({
    required this.id,
    required this.documentType,
    required this.filePath,
    this.valid,
    this.issuedAt,
    // this.validUntil,
  });

  DocumentsModel.fromJson(Map<String, dynamic> json)
      : id = json['id'],
        documentType = json['documentType'],
        filePath = json['filePath'],
        valid = json['valid'] ?? false,
        // DateTime recived converted to string
        issuedAt = json['issuedAt'] != null
            ? DateTime.parse(json['issuedAt']).toLocal().toString()
            : null;
  // validUntil = json['validUntil'] != null
  //     ? DateTime.parse(json['validUntil']).toLocal().toString()
  //     : null
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['documentType'] = documentType;
    data['filePath'] = filePath;
    data['valid'] = valid;
    data['issuedAt'] = issuedAt;
    // data['validUntil'] = validUntil;
    return data;
  }
}
