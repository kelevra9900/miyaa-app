import 'package:google_maps_flutter/google_maps_flutter.dart';

import 'parents/model.dart';

class MyAlertsResponse {
  List<Alerts>? alerts;
  LastLocation? lastLocation;

  MyAlertsResponse({this.alerts, this.lastLocation});

  MyAlertsResponse.fromJson(Map<String, dynamic> json) {
    if (json['alerts'] != null) {
      alerts = <Alerts>[];
      json['alerts'].forEach((v) {
        alerts!.add(Alerts.fromJson(v));
      });
    }
    lastLocation = json['lastLocation'] != null
        ? LastLocation.fromJson(json['lastLocation'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};

    if (alerts != null) {
      data['alerts'] = alerts!.map((v) => v.toJson()).toList();
    }
    if (lastLocation != null) {
      data['lastLocation'] = lastLocation!.toJson();
    }
    return data;
  }
}

class Alerts extends Model {
  String? content;
  String? image;
  int? userId;
  String? status;
  dynamic attendedBy;
  double? latitude;
  double? longitude;
  String? createdAt;
  String? updatedAt;

  Alerts({
    this.content,
    this.image,
    this.userId,
    this.status,
    this.attendedBy,
    this.latitude,
    this.longitude,
    this.createdAt,
    this.updatedAt,
  });

  Alerts.fromJson(Map<String, dynamic> json) {
    content = json['content'];
    image = json['image'];
    userId = json['userId'];
    status = json['status'];
    attendedBy = json['attendedBy'];
    latitude = parseDouble(json['latitude']);
    longitude = parseDouble(json['longitude']);
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
  }

  // Función auxiliar para convertir el valor a double de manera segura
  double parseDouble(dynamic value) {
    if (value is int) {
      return value.toDouble(); // Convertir a double si es un valor entero
    } else if (value is double) {
      return value; // Mantener el valor si ya es un double
    } else if (value is String) {
      return double.tryParse(value) ??
          0.0; // Intentar convertir desde String a double
    } else {
      return 0.0; // Valor predeterminado si no es posible convertir
    }
  }

  @override
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['content'] = content;
    data['image'] = image;
    data['userId'] = userId;
    data['status'] = status;
    data['attendedBy'] = attendedBy;
    data['latitude'] = parseDouble(latitude);
    data['longitude'] = parseDouble(longitude);
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    return data;
  }

  intToDouble() {
    latitude = latitude!.toDouble();
    longitude = longitude!.toDouble();
  }

  getLatLng() {
    return LatLng(latitude!, longitude!);
  }
}

class LastLocation {
  double? latitude;
  double? longitude;

  LastLocation({this.latitude, this.longitude});

  LastLocation.fromJson(Map<String, dynamic> json) {
    latitude = json['latitude'];
    longitude = json['longitude'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['latitude'] = latitude;
    data['longitude'] = longitude;
    return data;
  }
}
