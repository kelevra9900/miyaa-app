import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../models/auth_response_model.dart';
import '../models/user_model.dart';
import '../providers/laravel_provider.dart';
import '../repositories/user_repository.dart';
import 'settings_service.dart';

class AuthService extends GetxService {
  final user = User().obs;
  final fcm = ''.obs;
  final session = ResLogin().obs;
  late GetStorage _box;

  UserRepository? _usersRepo;

  AuthService() {
    _box = GetStorage();
    _usersRepo = UserRepository();
  }

  Future<AuthService> init() async {
    user.listen((User user) {
      if (Get.isRegistered<SettingsService>()) {
        Get.find<SettingsService>().address.value.id = user.id;
      }
      _box.write('current_user', user.toJson());
    });
    await getCurrentSession();
    return this;
  }

  Future<void> getCurrentUser() async {
    var response = await _usersRepo!.profile();
    if (response != null) {
      user.value = response;
      _box.write('current_user', response.toJson());

      if (fcm.value.isNotEmpty &&
              user.value.id != null &&
              user.value.oneSignalId != fcm.value ||
          user.value.oneSignalId == null) {
        await updateNotificationToken(token: fcm.value);
      }
      user.value.auth = true;
    } else {
      user.value.auth = false;
    }
  }

  Future getCurrentSession() async {
    if (session.value.jwt == null && _box.hasData('current_session')) {
      session.value = ResLogin.fromJson(await _box.read('current_session'));
      user.value.auth = true;
    } else {
      user.value.auth = false;
    }
  }

  void logout() async {
    user.value = User();
    session.value = ResLogin();
    _box.remove('current_user');
    _box.remove('current_session');
    user.value.auth = false;
    Get.offAllNamed('/login');

    await _usersRepo!.logout();
  }

  Future<void> updateNotificationToken({required String token}) async {
    var user = Get.find<AuthService>().user.value;
    if (user.id != null) {
      await Get.find<LaravelApiClient>().updateNotificationToken(
        token: token,
        userId: user.id!,
      );
    }
  }

  Future<void> setupToken() async {
    FirebaseMessaging messaging = FirebaseMessaging.instance;

    NotificationSettings settings = await messaging.requestPermission(
      alert: true,
      announcement: false,
      badge: true,
      carPlay: false,
      criticalAlert: false,
      provisional: false,
      sound: true,
    );

    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      String? token = await FirebaseMessaging.instance.getToken();
      fcm.value = token ?? '';
      var user = Get.find<AuthService>().user.value;

      FirebaseMessaging.instance.onTokenRefresh.listen(fcm.call);

      if (token != null && user.id != null) {
        await Get.find<LaravelApiClient>().updateNotificationToken(
          token: token,
          userId: user.id ?? 0,
        );
      }
    } else if (settings.authorizationStatus ==
        AuthorizationStatus.provisional) {
      Get.snackbar('Provisional permission',
          'Please allow notification in settings to receive notification');
    } else {
      Get.snackbar('Declined permission', 'Please allow notification');
    }
  }

  bool get isAuth => user.value.auth ?? false;
  String get apiToken =>
      (user.value.auth ?? false) ? user.value.id.toString() : '';
}
