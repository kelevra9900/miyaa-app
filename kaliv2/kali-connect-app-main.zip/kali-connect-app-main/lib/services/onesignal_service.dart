import 'package:get/get.dart';

class OneSignalService extends GetxService {
  RxString oneSignalId = ''.obs;

  OneSignalService();

  Future<OneSignalService> init() async {
    return this;
  }
}
