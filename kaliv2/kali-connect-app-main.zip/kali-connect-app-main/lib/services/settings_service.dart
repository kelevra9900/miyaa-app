import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../common/theme.dart';
import '../models/address_model.dart';
import '../models/setting_model.dart';
import '../utils/theme.dart';

class SettingsService extends GetxService {
  final setting = Setting().obs;
  final address = Address().obs;

  late GetStorage _box;

  SettingsService() {
    _box = GetStorage();
  }

  Future<SettingsService> init() async {
    address.listen((Address address) {
      _box.write('current_address', address.toJson());
    });
    return this;
  }

  ThemeData getLightTheme() {
    return ThemeUtils.isKali();
  }

  ThemeData getDarkTheme() {
    return ThemeData(
      unselectedWidgetColor: KaliColors.primaryColor,
      brightness: Brightness.dark,
      visualDensity: VisualDensity.compact,
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ButtonStyle(
          backgroundColor: WidgetStateProperty.resolveWith<Color?>(
              (Set<WidgetState> states) {
            if (states.contains(WidgetState.hovered)) {
              return const Color(0xff031f41);
            }
            return const Color(0xff031f41);
          }),
          foregroundColor: WidgetStateProperty.resolveWith<Color?>(
              (Set<WidgetState> states) {
            return const Color(0xffebebeb);
          }),
        ),
      ),
      primaryColorLight: const Color(0xffffffff),
      // accentColor: const Color(0xff031f41),
      colorScheme: const ColorScheme(
        primary: Color(0xff031f41),
        secondary: Color(0xff031f41),
        surface: Color(0xffebebeb),
        error: Color(0xffb00020),
        onPrimary: Color(0xffffffff),
        onSecondary: Color(0xffffffff),
        onSurface: Color(0xffffffff),
        onError: Color(0xffffffff),
        brightness: Brightness.dark,
      ),
      shadowColor: Colors.grey,
      hoverColor: const Color(0xff054177),
    );
  }

  ThemeMode getThemeMode() {
    String? themeMode = GetStorage().read<String>('theme_mode');
    switch (themeMode) {
      case 'ThemeMode.light':
        SystemChrome.setSystemUIOverlayStyle(
          SystemUiOverlayStyle.light
              .copyWith(systemNavigationBarColor: Colors.white),
        );
        return ThemeMode.light;
      case 'ThemeMode.dark':
        SystemChrome.setSystemUIOverlayStyle(
          SystemUiOverlayStyle.dark
              .copyWith(systemNavigationBarColor: Colors.black87),
        );
        return ThemeMode.dark;
      case 'ThemeMode.system':
        return ThemeMode.system;
      default:
        if (setting.value.defaultTheme == 'dark') {
          SystemChrome.setSystemUIOverlayStyle(
            SystemUiOverlayStyle.dark
                .copyWith(systemNavigationBarColor: Colors.black87),
          );
          return ThemeMode.dark;
        } else {
          SystemChrome.setSystemUIOverlayStyle(
            SystemUiOverlayStyle.light
                .copyWith(systemNavigationBarColor: Colors.white),
          );
          return ThemeMode.light;
        }
    }
  }
}
