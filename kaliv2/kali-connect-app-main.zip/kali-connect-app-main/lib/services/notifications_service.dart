import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:get/get.dart';

import '../routes/app_routes.dart';

class NotificationService extends GetxService {
  final FirebaseMessaging _fcm = FirebaseMessaging.instance;
  static const String fcmSubcriptionTopticforAll = 'all';

  NotificationService();

  init() async {
    await initFirebasePushNotification();
    return this;
  }

  Future handleNotificationPermissaion() async {
    NotificationSettings settings = await _fcm.requestPermission(
      alert: true,
      announcement: false,
      badge: true,
      carPlay: false,
      criticalAlert: false,
      provisional: false,
      sound: true,
    );
    if (settings.authorizationStatus == AuthorizationStatus.provisional) {
      Get.snackbar('Provisional permission',
          'Please allow notification in settings to receive notification');
    } else {
      Get.snackbar('Declined permission', 'Please allow notification');
    }
  }

  Future initFirebasePushNotification() async {
    await handleNotificationPermissaion();
    RemoteMessage? initialMessage = await _fcm.getInitialMessage();
    if (initialMessage != null) {
      Get.toNamed(Routes.notifications);
    }

    FirebaseMessaging.onMessage.listen((RemoteMessage message) async {
      Get.snackbar(
        message.notification!.title ?? '',
        message.notification!.body ?? '',
      );
    });

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) async {
      switch (message.messageType) {
        case 'notification':
          Get.toNamed(Routes.notifications);
          break;
        case 'chat':
          Get.toNamed(Routes.chat);
          break;
        default:
          Get.toNamed(Routes.notifications);
          break;
      }
    });
  }

  Future<bool?> checkingPermisson() async {
    bool? accepted;
    await _fcm
        .getNotificationSettings()
        .then((NotificationSettings settings) async {
      if (settings.authorizationStatus == AuthorizationStatus.authorized ||
          settings.authorizationStatus == AuthorizationStatus.provisional) {
        accepted = true;
      } else {
        accepted = false;
      }
    });
    return accepted;
  }

  Future subscribe() async {
    await _fcm.subscribeToTopic(fcmSubcriptionTopticforAll);
  }

  Future unsubscribe() async {
    await _fcm.unsubscribeFromTopic(fcmSubcriptionTopticforAll);
  }
}
