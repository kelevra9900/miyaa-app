import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class TranslationService extends GetxService {
  final translations = <String, Map<String, String>>{}.obs;
  static List<String> languages = [];

  late GetStorage _box = GetStorage();

  TranslationService() {
    _box = GetStorage();
  }

  Future<TranslationService> init() async {
    await loadTranslation();
    return this;
  }

  Future<void> loadTranslation({locale}) async {
    locale = locale ?? getLocale().languageCode;
  }

  Locale getLocale() {
    String? locale = _box.read<String>('language');
    if (locale == null || locale.isEmpty) {
      locale = 'es';
    }
    return fromStringToLocale(locale);
  }

  // get list of supported local in the application
  List<Locale> supportedLocales() {
    return TranslationService.languages.map((locale) {
      return fromStringToLocale(locale);
    }).toList();
  }

  // Convert string code to local object
  Locale fromStringToLocale(String locale) {
    if (locale.contains('_')) {
      // en_US
      return Locale(
          locale.split('_').elementAt(0), locale.split('_').elementAt(1));
    } else {
      // en
      return Locale(locale);
    }
  }
}
