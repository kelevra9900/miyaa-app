import 'package:flutter/material.dart';

class KaliColors {
  // Light Theme
  static const primaryColor = Color(0xFF15284b);
  static const secondaryColor = Color(0xFF15174A);
  static const tertiaryColor = Color(0xFF5886a5);
  static const highLight = Color(0xFF3da9fc);
  static const textMainColor = Color(0xFF000000);
  static const textSecondaryColor = Color(0xFFFFF0F0);
  static const gray = Color(0xFFE0E0E0);

  // Dark Theme
  static const darkPrimaryColor = Color(0xFF0F4C75);
  static const darkSecondaryColor = Color(0xFF7aa6c2);
  static const darkTertiaryColor = Color(0xFF022c4d);
  static const darkHighLight = Color(0xFF3da9fc);
  static const darkTextMainColor = Color(0xFFFFF0F0);
  static const Color overlayDark = Color(0x208F94FB);
  //icon boxShadow
  static List<BoxShadow> iconBoxShadow = [
    const BoxShadow(
      color: overlayDark,
      offset: Offset(1, 6.0),
      blurRadius: 15.0,
    ),
    const BoxShadow(
      color: overlayDark,
      offset: Offset(1, 6.0),
      blurRadius: 15.0,
    ),
  ];
}

final kaliGradients = [
  KaliColors.primaryColor,
  KaliColors.secondaryColor,
];

class StudioBikeColos {
  static const primaryColor = Color(0xFF62B32E);
}
