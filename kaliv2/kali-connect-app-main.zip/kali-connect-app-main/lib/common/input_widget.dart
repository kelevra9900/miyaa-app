import 'package:flutter/material.dart';
import 'package:get/get.dart';

class InputWidget extends StatelessWidget {
  final bool autocorrect;
  final TextInputType keyboardType;
  final void Function(String?)? onSaved;
  final String? Function(String?)? validator;
  // Controller
  final TextEditingController? controller;
  final String? labelText;
  final String? hintText;
  final bool obscureText;
  final bool filled;
  final bool disabled;
  final Widget? prefixIcon;
  final Widget? suffixIcon;

  const InputWidget({
    super.key,
    this.autocorrect = true,
    this.keyboardType = TextInputType.text,
    this.onSaved,
    this.validator,
    this.labelText,
    this.hintText,
    this.obscureText = false,
    this.filled = true,
    this.disabled = false,
    this.prefixIcon,
    this.suffixIcon,
    this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      autocorrect: autocorrect,
      keyboardType: keyboardType,
      onSaved: onSaved,
      validator: validator,
      obscureText: obscureText,
      style: TextStyle(
        color: Get.theme.colorScheme.primary,
      ),
      decoration: InputDecoration(
        enabled: !disabled,
        disabledBorder: const OutlineInputBorder(
          borderSide: BorderSide(
            color: Colors.grey,
          ),
        ),
        filled: filled,
        hintText: hintText,
        fillColor: Colors.white,
        border: const OutlineInputBorder(),
        prefixIcon: prefixIcon,
        suffixIcon: suffixIcon,
        contentPadding: const EdgeInsets.only(
          bottom: 10,
          left: 10,
          right: 10,
        ),
        label: Text(labelText?.tr ?? ''),
        labelStyle: TextStyle(
          color: Get.theme.colorScheme.secondary,
          fontSize: 13,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }
}
