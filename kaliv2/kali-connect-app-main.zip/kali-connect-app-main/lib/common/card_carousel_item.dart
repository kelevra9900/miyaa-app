import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';

import '../routes/app_routes.dart';

class CardCarouselItem extends StatelessWidget {
  const CardCarouselItem({
    super.key,
    required this.heroTag,
    required this.title,
    required this.icon,
    required this.color1,
    required this.color2,
  });

  final Color color1;
  final Color color2;
  final String heroTag;
  final IconData icon;
  final String title;

  void _navigateTo(String routeName) {
    if (routeName.isNotEmpty) {
      Get.toNamed(routeName);
    }
  }

  @override
  Widget build(BuildContext context) {
    final Map<String, String> routes = {
      'Profile': Routes.profile,
      'Blog': Routes.blog,
      'Historial': Routes.history,
      'Send a message': Routes.createAlertMessage,
      'Suggestions': Routes.createSuggestion,
      'Conferences': Routes.conferences,
      'Vigilance': Routes.vigilance,
      'Mis Documentos': Routes.documents,
    };

    return InkWell(
      onTap: () => _navigateTo(routes[title] ?? ''),
      child: Stack(
        alignment: Alignment.center,
        children: [
          _BackGroundButton(color1: color1, color2: color2, icon: icon),
          Center(
            child: Padding(
              padding: EdgeInsets.symmetric(
                horizontal: MediaQuery.of(context).size.width * 0.09,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  FaIcon(
                    icon,
                    color: Colors.white,
                    size: 30,
                  ),
                  const SizedBox(width: 20),
                  Expanded(
                    child: Text(
                      title.tr,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                      ),
                    ),
                  ),
                  const FaIcon(
                    FontAwesomeIcons.chevronRight,
                    color: Colors.white,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _BackGroundButton extends StatelessWidget {
  const _BackGroundButton({
    required this.color1,
    required this.color2,
    required this.icon,
  });

  final Color color1;
  final Color color2;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: MediaQuery.of(context).size.height * 0.12,
      margin: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        boxShadow: const [
          BoxShadow(color: Colors.black26, offset: Offset(4, 6), blurRadius: 10)
        ],
        borderRadius: BorderRadius.circular(15),
        gradient: LinearGradient(colors: [color1, color2]),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(15),
        child: Stack(
          children: [
            Positioned(
              right: -10,
              top: -10,
              child:
                  FaIcon(icon, size: 95, color: Colors.white.withOpacity(0.2)),
            ),
          ],
        ),
      ),
    );
  }
}
