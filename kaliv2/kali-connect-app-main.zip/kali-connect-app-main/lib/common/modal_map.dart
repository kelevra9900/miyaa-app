// ignore_for_file: no_leading_underscores_for_local_identifiers

import 'dart:ui' as ui;

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class MapsUtil {
  static Future<Uint8List> getBytesFromAsset(String path, int width) async {
    ByteData data = await rootBundle.load(path);
    ui.Codec codec = await ui.instantiateImageCodec(data.buffer.asUint8List(),
        targetWidth: width);
    ui.FrameInfo fi = await codec.getNextFrame();
    return (await fi.image.toByteData(format: ui.ImageByteFormat.png))!
        .buffer
        .asUint8List();
  }

  static Future<Marker> getMarker(
      {required LatLng latLng, String id = '', String description = ''}) async {
    final Uint8List markerIcon =
        await getBytesFromAsset('assets/images/marker.png', 120);
    final Marker marker = Marker(
      markerId: MarkerId(id),
      icon: BitmapDescriptor.fromBytes(markerIcon),
//        onTap: () {
//          //print(res.name);
//        },
      anchor: const Offset(0.5, 0.5),
      infoWindow: InfoWindow(
          title: description,
          //snippet: getDistance(res['distance'].toDouble(), setting.value.distanceUnit),
          onTap: () {
            //print(CustomTrace(StackTrace.current, message: 'Info Window'));
          }),
      position: latLng,
    );

    return marker;
  }

  static Widget getStaticMaps(List<LatLng> latLngs,
      {double height = 168, String size = '400x160', double zoom = 13}) {
    String _markers = '';
    for (var element in latLngs) {
      _markers +=
          'markers=icon:https://maps.google.com/mapfiles/ms/icons/blue-dot.png%7C${element.latitude},${element.longitude}&';
    }

    return CachedNetworkImage(
      height: height,
      width: double.infinity,
      fit: BoxFit.cover,
      imageUrl: 'https://maps.googleapis.com/maps/api/staticmap?'
          'zoom=$zoom&'
          'size=$size&'
          'language=es&'
          'maptype=roadmap&$_markers'
          'key=AIzaSyC7Avyq8g3Bl7_2YxhFzmHaR-L7rKoWzsQ',
      placeholder: (context, url) => Image.asset(
        'assets/images/loading.gif',
        fit: BoxFit.cover,
        width: double.infinity,
        height: height,
      ),
      errorWidget: (context, url, error) => const Icon(Icons.error_outline),
    );
  }
}
