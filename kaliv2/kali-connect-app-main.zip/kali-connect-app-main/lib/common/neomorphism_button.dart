import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../modules/home/home_controller.dart';
import '../routes/app_routes.dart';

class NeomorphinButton extends GetView<HomeController> {
  const NeomorphinButton({super.key});

  // Evaluate if the active location is true
  void _sendAlert() {
    controller.isEmergency.value = !controller.isEmergency.value;
    controller.sendAlert();
    Get.toNamed(Routes.emergency);
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Obx(() {
        return GestureDetector(
          onTap: _sendAlert,
          child: AnimatedContainer(
            duration: const Duration(
              milliseconds: 200,
            ),
            height: 200,
            width: 200,
            decoration: BoxDecoration(
              color: Colors.grey[300],
              borderRadius: BorderRadius.circular(100),
              boxShadow: !controller.isEmergency.value
                  ? [
                      const BoxShadow(
                        color: Colors.grey,
                        offset: Offset(4, 4),
                        blurRadius: 15,
                        spreadRadius: 1,
                      ),
                      const BoxShadow(
                        color: Colors.white,
                        offset: Offset(-4, -4),
                        blurRadius: 15,
                        spreadRadius: 1,
                      ),
                    ]
                  : null,
            ),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                height: 200,
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Color.fromARGB(255, 255, 4, 0),
                      Color.fromARGB(255, 190, 6, 2),
                    ],
                  ),
                  shape: BoxShape.circle,
                ),
                child: const Center(
                  child: Text(
                    'S.O.S',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      }),
    );
  }
}
