import 'package:flutter/material.dart';

import '../utils/curve_wave.dart';

class RippleAnimation extends StatelessWidget {
  const RippleAnimation({
    super.key,
    required this.size,
    required this.color,
    required this.controller,
  });
  final double size;
  final Color color;
  final AnimationController controller;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: ClipRRect(
        borderRadius: BorderRadius.circular(size),
        child: DecoratedBox(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              colors: <Color>[color, Color.lerp(color, Colors.black, .05)!],
            ),
          ),
          child: ScaleTransition(
            scale: Tween(begin: 0.95, end: 1.0).animate(
              CurvedAnimation(
                parent: controller,
                curve: const CurveWave(),
              ),
            ),
            child: const Text(
              'S.O.S',
              style: TextStyle(
                color: Colors.white,
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
