// ignore_for_file: library_private_types_in_public_api

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

class CircularLoadingWidget extends StatefulWidget {
  final double? height;
  final ValueChanged<void>? onComplete;
  final String? onCompleteText;

  const CircularLoadingWidget({
    super.key,
    this.height,
    this.onComplete,
    required this.onCompleteText,
  });

  @override
  _CircularLoadingWidgetState createState() => _CircularLoadingWidgetState();
}

class _CircularLoadingWidgetState extends State<CircularLoadingWidget>
    with SingleTickerProviderStateMixin {
  Animation<double>? animation;
  AnimationController? animationController;
  late Timer timer;

  @override
  void initState() {
    super.initState();
    // Asignar un valor por defecto si widget.height es null
    final initialHeight = widget.height ?? 10.0;
    animationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    timer = Timer(const Duration(seconds: 10), () {
      if (mounted) {
        animationController!.forward();
        if (widget.onComplete != null) {
          widget.onComplete!(null);
        }
      }
    });
    CurvedAnimation curve =
        CurvedAnimation(parent: animationController!, curve: Curves.easeOut);
    animation = Tween<double>(begin: initialHeight, end: 0).animate(curve)
      ..addListener(() {
        if (mounted) {
          setState(() {});
        }
      });
  }

  @override
  void dispose() {
    if (animationController != null) {
      animationController!.dispose();
    }
    if (timer.isActive) {
      timer.cancel();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return animationController!.isCompleted
        ? SizedBox(
            height: widget.height ?? 10,
            child: Center(
              child: Text(
                widget.onCompleteText ?? '',
                style: Get.textTheme.bodySmall!.merge(
                  const TextStyle(fontSize: 14),
                ),
              ),
            ),
          )
        : Opacity(
            opacity:
                animation!.value / 100 > 1.0 ? 1.0 : animation!.value / 100,
            child: SizedBox(
              height: animation!.value,
              child: const Center(
                child: CircularProgressIndicator(),
              ),
            ),
          );
  }
}
