class Routes {
  static const login = '/login';
  static const environments = '/environments';
  static const onboarding = '/onboarding';
  static const home = '/home';
  static const emergency = '/home/emergency';
  static const profile = '/profile';
  static const notifications = '/notifications';
  static const createSuggestion = '/create_suggestion';
  static const createAlertMessage = '/create_alert_message';

  static const conferences = '/conferences';
  static const attendances = '/attendances';

  static const root = '/root';
  static const faceRecognition = '/face_recognition';
  static const onRecognition = '/face_recognition/on_recognition';

  static const chat = '/chat';

  // History
  static const history = '/history';
  static const alertDetail = '/history/detail';

  static const blog = '/blog';
  static const note = '/blog/note';

  static const splash = '/splash';

  static const documents = '/documents';
  static const createDocument = '/documents/create';

  static const settings = '/settings';
  static const languages = '/settings/languages';
  static const themeMode = '/settings/themeMode';

  static const vigilance = '/vigilance';
  static const vigilanceDetail = '/vigilance/detail';
  static const writeNFCTag = '/write_nfc_tag';
}
