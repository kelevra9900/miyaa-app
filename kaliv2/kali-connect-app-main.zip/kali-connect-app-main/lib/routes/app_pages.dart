import 'package:get/get.dart';

import '../middlewares/auth_middleware.dart';
import '../modules/alert_message/bindings/alert_message_binding.dart';
import '../modules/alert_message/views/alert_with_message.dart';
import '../modules/attendances/bindings/attendance_binding.dart';
import '../modules/attendances/views/my_attendance.dart';
import '../modules/auth/auth_binding.dart';
import '../modules/auth/auth_screen.dart';
import '../modules/blog/bindings/blog_binding.dart';
import '../modules/blog/views/blog_screen.dart';
import '../modules/blog/views/note_detail.dart';
import '../modules/conferences/bindings/conference_binding.dart';
import '../modules/conferences/views/conferences.dart';
import '../modules/conversations/bindings/conversation_binding.dart';
import '../modules/conversations/views/conversation_screen.dart';
import '../modules/documents/bindings/documents_binding.dart';
import '../modules/documents/views/create_documents_screen.dart';
import '../modules/documents/views/documents_screen.dart';
import '../modules/face_recognition/bindings/face_recognition_binding.dart';
import '../modules/face_recognition/views/face_recognition.dart';
import '../modules/history/bindings/history_binding.dart';
import '../modules/history/views/alert_screen.dart';
import '../modules/history/views/history_screen.dart';
import '../modules/home/home_bindings.dart';
import '../modules/home/home_screen.dart';
import '../modules/home/widgets/emergency_screen.dart';
import '../modules/notifications/notifications_binding.dart';
import '../modules/notifications/notifications_screen.dart';
import '../modules/profile/bindings/nfc_write_binding.dart';
import '../modules/profile/bindings/profile_binding.dart';
import '../modules/profile/views/profile_screen.dart';
import '../modules/profile/views/write_nfc_tag.dart';
import '../modules/root/bindings/root_binding.dart';
import '../modules/root/views/root_view.dart';
import '../modules/settings/bindings/settings_binding.dart';
import '../modules/settings/views/settings_view.dart';
import '../modules/settings/views/theme_mode_view.dart';
import '../modules/splash_screen/bindings/splash_screen_binding.dart';
import '../modules/splash_screen/views/splash_screen.dart';
import '../modules/suggestions/bindings/suggestions_binding.dart';
import '../modules/suggestions/views/create_suggestion.dart';
import '../modules/vigilance/bindings/vigilance_bindings.dart';
import '../modules/vigilance/views/detail_round.dart';
import '../modules/vigilance/views/vigilance_view.dart';
import 'app_routes.dart';

class AppPage {
  static const initial = Routes.splash;
  static final routes = [
    GetPage(
      name: Routes.login,
      page: () => const LoginScreen(),
      binding: AuthBinding(),
      transition: Transition.cupertino,
      transitionDuration: const Duration(milliseconds: 700),
    ),
    GetPage(
      name: Routes.home,
      page: () => HomeScreen(),
      binding: HomeBinding(),
      middlewares: [AuthMiddleware()],
      preventDuplicates: false,
    ),
    GetPage(
      name: Routes.emergency,
      page: () => const EmergencyScreen(),
      binding: HomeBinding(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: Routes.settings,
      page: () => SettingsView(),
      binding: SettingsBinding(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: Routes.themeMode,
      page: () => const ThemeModeView(),
      binding: SettingsBinding(),
    ),
    GetPage(
      name: Routes.createSuggestion,
      page: () => const CreateSuggestionView(),
      binding: SuggestionBinding(),
      transition: Transition.cupertino,
    ),
    GetPage(
      name: Routes.profile,
      page: () => const ProfileScreen(),
      binding: ProfileBinding(),
      middlewares: [AuthMiddleware()],
      preventDuplicates: false,
    ),
    GetPage(
      name: Routes.notifications,
      page: () => const NotificationsPage(),
      binding: NotificationsBinding(),
      middlewares: [AuthMiddleware()],
      preventDuplicates: false,
    ),
    GetPage(
      name: Routes.blog,
      page: () => const BlogScreen(),
      binding: BlogBinding(),
      middlewares: [AuthMiddleware()],
      preventDuplicates: false,
    ),
    GetPage(
      name: Routes.note,
      page: () => const NoteDetailScreen(),
      binding: BlogBinding(),
      fullscreenDialog: false,
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: Routes.attendances,
      page: () => const MyAttendance(),
      binding: AttendanceBinding(),
      fullscreenDialog: false,
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: Routes.history,
      page: () => const HistoryScreen(),
      binding: HistoryBinding(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: Routes.conferences,
      page: () => const ConferenceScreen(),
      binding: ConferenceBinding(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: Routes.alertDetail,
      page: () => const AlertDetailScreen(),
      binding: HistoryBinding(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: Routes.createAlertMessage,
      page: () => const CreateAlertWithMessage(),
      binding: AlertMessageBingind(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: Routes.chat,
      page: () => ConversationsScreen(),
      binding: ConversationBinding(),
      middlewares: [AuthMiddleware()],
      preventDuplicates: false,
    ),
    GetPage(
      name: Routes.documents,
      page: () => const DocumentsScreen(),
      binding: DocumentsBinding(),
      middlewares: [AuthMiddleware()],
    ),
    // Create document
    GetPage(
      name: Routes.createDocument,
      page: () => const CreateDocumentScreen(),
      binding: DocumentsBinding(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: Routes.splash,
      page: () => const SplashScreen(),
      binding: SplashBinding(),
      transition: Transition.fade,
      transitionDuration: const Duration(milliseconds: 700),
    ),
    GetPage(
      name: Routes.root,
      page: () => RootView(),
      binding: RootBinding(),
      preventDuplicates: false,
    ),
    GetPage(
      name: Routes.faceRecognition,
      page: () => const FaceRecognitionScreen(),
      binding: FaceRecognitionBinding(),
    ),
    GetPage(
      name: Routes.writeNFCTag,
      page: () => const WriteNFCTag(),
      binding: NFCBinding(),
    ),
    GetPage(
      name: Routes.vigilance,
      page: () => const VigilanceView(),
      binding: VigilanceBinding(),
    ),
    GetPage(
      name: Routes.vigilanceDetail,
      page: () => const VigilanceDetailScreen(),
      binding: VigilanceBinding(),
    ),
  ];
}
