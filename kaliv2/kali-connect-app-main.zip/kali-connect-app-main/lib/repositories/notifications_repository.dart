class NotificationsRepository {
  NotificationsRepository() {
    // _laravelApiClient = LaravelApiClient();
  }

  getAll({int? page = 0}) async {}
}
