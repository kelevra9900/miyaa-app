import 'package:dio/dio.dart';

import '../models/documents_model.dart';
import '../providers/laravel_provider.dart';

class DocumentsRepository {
  late LaravelApiClient _laravelApiClient;

  DocumentsRepository() {
    _laravelApiClient = LaravelApiClient();
  }

  // Future<List<DocumentsModel>> getDocuments() {
  Stream<MyDocuments> getDocuments() {
    Stream<MyDocuments> documents = Stream.fromFuture(
      _laravelApiClient.getDocuments(),
    );

    return documents;
  }

  // Create document with file upload
  Future<DocumentsModel> createDocument(
      CreateDocumentModel data, dynamic file) async {
    var formData = FormData.fromMap({
      'documentType': data.documentType,
      'file': await MultipartFile.fromFile(file.path),
    });
    try {
      var response = await _laravelApiClient.createDocument(
        filePath: file.path,
        formData: formData,
        documentType: data.documentType,
      );

      return response;
    } catch (e) {
      // Proper error handling
      print('Error creating document respository $e');
      rethrow;
    }
  }
}
