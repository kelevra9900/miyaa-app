import '../models/my_alerts_model.dart';
import '../providers/laravel_provider.dart';

class HistoryRepository {
  late LaravelApiClient _laravelApiClient;

  HistoryRepository() {
    _laravelApiClient = LaravelApiClient();
  }

  Future<MyAlertsResponse> getAll({
    int? page = 0,
    required int userId,
  }) async {
    return _laravelApiClient.alertHistory(page: page, userId: userId);
  }
}
