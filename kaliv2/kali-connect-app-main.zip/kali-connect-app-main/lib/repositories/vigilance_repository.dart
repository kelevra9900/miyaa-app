import 'package:get/get.dart';
import 'package:miyaa/models/rounds_model.dart';
import 'package:miyaa/providers/laravel_provider.dart';

class VigilanceRepository {
  final LaravelApiClient _vigilanceApiClient = LaravelApiClient();

  RxList<MyRounds> myRoundsList = <MyRounds>[].obs;

  Stream<MyRounds> getRounds() {
    return _vigilanceApiClient.getRounds();
  }

  Stream<RoundsResponse> getAllRounds(int page, int limit) {
    return _vigilanceApiClient.getAllRounds(page, limit);
  }
}
