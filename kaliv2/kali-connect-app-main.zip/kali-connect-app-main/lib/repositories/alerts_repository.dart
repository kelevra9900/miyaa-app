import '../models/create_alert_model.dart';
import '../providers/laravel_provider.dart';

class AlertRepository {
  late LaravelApiClient _laravelApiClient;

  AlertRepository() {
    _laravelApiClient = LaravelApiClient();
  }

  Future sendAlert(CreateAlertModel alert) async {
    return _laravelApiClient.sendAlert(alert);
  }
}
