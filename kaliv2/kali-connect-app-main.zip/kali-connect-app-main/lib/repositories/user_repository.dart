import '../models/auth_response_model.dart';
import '../models/user_model.dart';
import '../providers/laravel_provider.dart';

class UserRepository {
  late LaravelApiClient _laravelApiClient;

  Future<ResLogin> login({required username, required password}) async {
    _laravelApiClient = LaravelApiClient();
    return _laravelApiClient.login(username: username, password: password);
  }

  Future<User?> profile() {
    _laravelApiClient = LaravelApiClient();
    return _laravelApiClient.profile();
  }

  Future<void> checkpointLog(int roundId, int checkpointId) {
    _laravelApiClient = LaravelApiClient();
    return _laravelApiClient.checkpointLog(roundId, checkpointId);
  }

  Future<void> logout() {
    _laravelApiClient = LaravelApiClient();
    return _laravelApiClient.logout();
  }
}
