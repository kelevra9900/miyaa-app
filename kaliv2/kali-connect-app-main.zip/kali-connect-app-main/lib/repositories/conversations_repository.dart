import '../models/chat_model.dart';
import '../providers/laravel_provider.dart';

class ConversationsRepository {
  late LaravelApiClient _laravelApiClient;

  ConversationsRepository() {
    _laravelApiClient = LaravelApiClient();
  }

  Future<ChatResponse> getConversations({int? page = 0, required int userId}) {
    return _laravelApiClient.getAllConversations(page: page, userId: userId);
  }

  Future sendMessage({
    required String message,
  }) {
    return _laravelApiClient.sendMessage(
      message: message,
    );
  }
}
