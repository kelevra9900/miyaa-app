import '../models/blog_model.dart';
import '../providers/laravel_provider.dart';

class BlogRepository {
  late LaravelApiClient _laravelApiClient;

  BlogRepository() {
    _laravelApiClient = LaravelApiClient();
  }

  Future<BlogResponse> getAll({int? page = 1}) async {
    return _laravelApiClient.blogs(page: page);
  }

  Future<BlogResponse> getById({required int id}) async {
    return _laravelApiClient.blog(id: id);
  }
}
