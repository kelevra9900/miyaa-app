import '../providers/laravel_provider.dart';

class SuggestionRepository {
  late LaravelApiClient _laravelApiClient;

  SuggestionRepository() {
    _laravelApiClient = LaravelApiClient();
  }

  Future sendSuggestion({
    required String suggestion,
    required int userId,
    required double rating,
  }) async {
    return _laravelApiClient.sendSuggestion(
      content: suggestion,
      userId: userId,
      rating: rating,
    );
  }
}
