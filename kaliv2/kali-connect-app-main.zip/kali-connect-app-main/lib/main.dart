import 'dart:async';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:miyaa/utils/socket_manager.dart';

import 'common/translation.dart';
import 'config/plugins/quick_actions_plugin.dart';
import 'modules/profile/controllers/profile_controller.dart';
import 'providers/laravel_provider.dart';
import 'routes/app_pages.dart';
import 'services/auth_service.dart';
import 'services/notifications_service.dart';
import 'services/settings_service.dart';
import 'services/translation_service.dart';
import 'utils/constants.dart';

initServices() async {
  Get.log('Starting services');
  await GetStorage.init();
  await Get.putAsync(() => AuthService().init());
  await Get.putAsync(() => LaravelApiClient().init());
  await Get.putAsync(() => SettingsService().init());
  await Get.putAsync(() => TranslationService().init());
  await Get.putAsync(() => NotificationService().init());
  await Get.putAsync(() => SocketManager().init());
  Get.put(ProfileController());
  Get.log('All services started...');
  QuickActionsPlugin.registerActions();
}

void main() async {
  // Firebase
  runZonedGuarded(
    () async {
      WidgetsFlutterBinding.ensureInitialized();
      await Firebase.initializeApp();
      await initServices();
      FlutterError.onError =
          FirebaseCrashlytics.instance.recordFlutterFatalError;

      runApp(
        GestureDetector(
          onTap: () {
            FocusManager.instance.primaryFocus?.unfocus();
          },
          child: GetMaterialApp(
            title: Constants().appName,
            initialRoute: AppPage.initial,
            getPages: AppPage.routes,
            localizationsDelegates: GlobalMaterialLocalizations.delegates,
            supportedLocales: const [
              Locale('es'),
              Locale('en'),
            ],
            translationsKeys: AppTranslation.translationsKeys,
            locale: Get.find<TranslationService>().getLocale(),
            fallbackLocale: Get.find<TranslationService>().getLocale(),
            debugShowCheckedModeBanner: false,
            defaultTransition: Transition.cupertino,
            themeMode: Get.find<SettingsService>().getThemeMode(),
            theme: Get.find<SettingsService>().getLightTheme(),
            darkTheme: Get.find<SettingsService>().getDarkTheme(),
          ),
        ),
      );
    },
    (error, stack) => FirebaseCrashlytics.instance.recordError(
      error,
      stack,
      fatal: true,
    ),
  );
}
