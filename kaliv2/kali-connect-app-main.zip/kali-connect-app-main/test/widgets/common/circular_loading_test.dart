import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:get/get.dart';
import 'package:miyaa/common/circular_loading_widget.dart';

void main() {
  testWidgets('test_default_height_and_animation_duration',
      (WidgetTester tester) async {
    await tester.pumpWidget(const GetMaterialApp(
      home: Scaffold(
        body: CircularLoadingWidget(height: 100, onCompleteText: ''),
      ),
    ));
    expect(find.byType(CircularProgressIndicator), findsOneWidget);
    expect(find.byType(SizedBox), findsOneWidget);
    expect(find.text(''), findsNothing);
  });

  testWidgets('test_height_0_when_height_is_null', (WidgetTester tester) async {
    await tester.pumpWidget(const GetMaterialApp(
      home: Scaffold(
        body: CircularLoadingWidget(height: null, onCompleteText: ''),
      ),
    ));

    expect(find.byType(SizedBox), findsOneWidget);

    final sizedBox = tester.widget<SizedBox>(find.byType(SizedBox));
    expect(sizedBox.height, 10);
    expect(find.text(''), findsNothing);
  });

  testWidgets('test_onComplete_called_when_animation_is_completed',
      (WidgetTester tester) async {
    var onCompleteCalled = false;
    await tester.pumpWidget(GetMaterialApp(
      home: Scaffold(
        body: CircularLoadingWidget(
          height: 100,
          onComplete: (void value) {
            onCompleteCalled = true;
          },
          onCompleteText: '',
        ),
      ),
    ));
    await tester.pumpAndSettle();
    expect(onCompleteCalled, true);
  });
}
