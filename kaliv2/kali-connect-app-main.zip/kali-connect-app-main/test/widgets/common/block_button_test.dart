import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:get/get.dart';

import 'package:miyaa/common/block_button.dart';

void main() {
  testWidgets('test_widget_displayed_with_correct_width_and_height',
      (WidgetTester tester) async {
    await tester.pumpWidget(
      GetMaterialApp(
        home: Scaffold(
          body: BlockButtonWidget(
            color: Colors.blue,
            text: const Text('Button'),
            onPressed: () {},
          ),
        ),
      ),
    );

    await tester.pumpAndSettle();

    final buttonFinder = find.byType(BlockButtonWidget);
    final buttonWidget = tester.widget<BlockButtonWidget>(buttonFinder);

    expect(buttonWidget.color, equals(Colors.blue));
    expect(buttonWidget.text, isA<Text>());
    expect(buttonWidget.onPressed, isA<VoidCallback>());
    expect(buttonWidget.onPressed, isNotNull);

    final buttonContainer = tester.widget<SizedBox>(find.byType(SizedBox));
    expect(buttonContainer.width, equals(Get.width * 0.8));
    expect(buttonContainer.height, equals(50));
  });
}
