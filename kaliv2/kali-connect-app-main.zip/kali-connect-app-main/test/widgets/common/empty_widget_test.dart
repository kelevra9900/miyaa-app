import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:get/get.dart';
import 'package:miyaa/common/empty.dart';

void main() {
  // Should display the correct icon and message
  testWidgets('should display correct icon and message',
      (WidgetTester tester) async {
    await tester.pumpWidget(
      const GetMaterialApp(
        home: Scaffold(
          body: EmptyView(
            icon: Icons.check,
            message: 'Empty view',
          ),
        ),
      ),
    );

    expect(find.byIcon(Icons.check), findsOneWidget);
    expect(find.text('Empty view'), findsOneWidget);
  });
}
